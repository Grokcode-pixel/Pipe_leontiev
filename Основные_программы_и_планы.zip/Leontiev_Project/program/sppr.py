"""СППР выбора конструкции и режима узла редуцирования ГРС с пучком труб Леонтьева (КТ5 плана 18.10.2026).
27.10.2026 — ядро: карточка задачи (п. 2.1) → перебор вариантов → прогноз ± σ (ГП по CFD) → баланс станции
(grs_balance2) → правила П1–П3 (п. 2.2) → карточка рекомендации + запись журнала решений (п. 4.7).
Программа ничего не регулирует: она готовит рекомендацию главному инженеру и предлагает адресный расчёт Fluent.

Правила (δ — допуск на погрешность эффекта, K; ε_N — порог различимости по подогревателю, кВт; оба — параметры ЛПР):
 П1 (u, f) ∉ Ω ИЛИ вариант k не рассчитан                         → Δ3 «вернуть задачу»
 П2 (u, f) ∈ Ω И (σ > δ ИЛИ p «рабочий» < p_hi ИЛИ лучший вариант
    может смениться в пределах погрешности более чем на ε_N)       → Δ2 «досчитать» (+ какой расчёт Fluent)
 П3 (u, f) ∈ Ω И σ ≤ δ И лучший устойчив                         → Δ1 «выдать» (в т. ч. «не рекомендовано»)
Паспорт Ω (п. 2.1): 0,2 ≤ m ≤ 0,96; факторы в границах обучающих данных (магистраль 2,5–5,5 МПа, t/d и L — посчитанные
геометрии); подогрев СВЗ (до сопел) — не выше рассчитанного.

usage: python sppr.py <карточка_задачи.json> [--no-journal]
"""
import io, contextlib, json, math, sys, time
from dataclasses import dataclass, field, asdict
from pathlib import Path
import numpy as np

D = Path(r'F:\Leontiev_Project\dataset')
sys.path.insert(0, str(D))
OUT = Path(r'F:\Leontiev_Project\runs\program')
JOURNAL = Path(r'F:\Leontiev_Project\runs\journal\Журнал_решений.md')
KINDS = ('гладкий', 'накатка RU 233137', 'диффузор RU 233137', 'три потока RU 2836642')
SIGMA_MULT = 1.6   # 29.10.2026, D-25: калибровка σ (покрытие ±1σ 45 %, ±2σ 84 % на 56 точках) — повторить после заморозки
# 31.10.2026 (D-30, заморозка): после заморозки классификатор (по D-11), порог p_hi и множитель σ — фиксированные, из FREEZE.json
FREEZE_FILE = Path(r'F:\Leontiev_Project\runs\models\FREEZE.json')
FREEZE = json.loads(FREEZE_FILE.read_text(encoding='utf-8')) if FREEZE_FILE.exists() else None
if FREEZE:
    SIGMA_MULT = float(FREEZE['sigma_mult'])
D32_Q = 0.9   # 31.10 (D-32): квантиль расстояния до ближайших данных, выше которого — «досчитать»
M_EDGE = 0.955   # 01.11 (решение автора, п. 1, пример Z3: 0,959 / 0,960): m + σ_m выше — подпись «на границе применимости»


@dataclass
class TaskCard:
    """Карточка задачи (п. 2.1): сценарий f, задание x0, допустимые проектные и режимные параметры, параметры ЛПР."""
    title: str
    p_main: float = 5.5            # f: давление магистрали, МПа
    T_main: float = 0.0            # f: температура газа, °C
    flow_nm3h: float = 5000.0      # f/x0: отпуск потребителю
    p_cons: float = 0.6            # x0: давление потребителя, МПа
    T_min: float = -10.0           # x0: −10 °C (0 °C — пучинистые грунты)
    lng_req_kgh: float = 0.0       # x0: требуемый выход СПГ (0 — потребителя холода нет)
    kinds: list = field(default_factory=lambda: ['гладкий'])
    geometries: list = field(default_factory=lambda: [[1.4, 400.0]])     # [t/d, L мм] — проектные
    dp_kPa: list = field(default_factory=lambda: [3, 5, 10, 20, 30, 50, 80, 105])   # режимные: перепад ДЗВ
    heater_place: list = field(default_factory=lambda: ['после'])          # z ∈ {до сопел; после}
    delta_K: float = 0.5
    eps_N_kW: float = 0.5
    u0: dict = field(default_factory=dict)   # существующая конструкция/режим (для режимного и проектного ресурса)
    map_scenarios: list = field(default_factory=list)   # п. 4.5: [[P_маг, T_газа], ...] — режимная карта для u_п (первая геометрия)
    # 30.10.2026 (решение автора): схема использования холода ДЗВ — 'СПГ' (весь холод в СПГ), 'внешнее тепло' (СПГ нет, ДЗВ
    # догревается внешним низкопотенциальным теплом), 'СПГ + внешнее тепло' (несжиженный пар после СПГ догревается внешним
    # теплом); None — как раньше (СПГ, только если задан выход СПГ). T_ext_C — до какой температуры догревает внешнее тепло
    # (None — температура газа магистрали); источник должен быть не холоднее T_ext + 5 K.
    scheme: str | None = None
    T_ext_C: float | None = None
    # 30.10.2026 (задание автора): куда идёт газ ДЗВ — 'СПГ' (основная схема) / 'транзит' / 'потребитель холода' (сценарии «если на
    # станции есть такая возможность»); задан — главнее scheme. Цель — 'min топлива' или 'max СПГ'. Параметр ЛПР — допустимая потеря
    # давления ДЗВ, кПа (для транзита можно задать давление на выходе, МПа). eps_lng_kgh — порог различимости по СПГ (цель max СПГ).
    dzv_to: str | None = None
    goal: str = 'min топлива'
    dp_max_kPa: float | None = None
    p_transit_min_MPa: float | None = None
    eps_lng_kgh: float = 1.0


class Models:
    """ГП эффекта, Q, G_СВЗ, G_ДЗВ (как station_gp) + классификатор CatBoost с порогом p_hi (как classifier_final)."""

    def __init__(self):
        with contextlib.redirect_stdout(io.StringIO()):
            import station_gp as G
            import classifier_final as CF
            import model_compare as MC
            import heldout_check as H
        self.G, self.H = G, H
        self.clf = FREEZE['classifier'] if FREEZE else 'CatBoost'
        fr, fc, pr, self._pc = MC.models()[self.clf]
        self.cb = fc(H.Z(CF.X), CF.w)
        if FREEZE:   # порог фиксирован при заморозке (D-11), не пересчитывается
            self.p_hi = float(FREEZE['p_hi'])
        else:
            p = CF.oof(CF.X, CF.w, CF.g, fc, self._pc)
            self.p_hi = CF.threshold(p, CF.w)
        self.lo, self.hi = G.lo, G.hi
        self.n_train = len(G.X)
        # 27.10 21:45: если вариант уже посчитан CFD (точка обучения), класс «рабочий / скачок» известен из расчёта —
        # П2 из-за неуверенности классификатора для него не нужен (иначе система просит повторить сделанный расчёт)
        self.done_X, self.done_w = np.array(CF.X, dtype=float), np.array(CF.w)
        # 31.10 (D-32, решение автора): «мало данных рядом» — расстояние до ближайшей точки обучения (7 входов, масштаб 0–1 по
        # границам обучения, евклидово) больше 90-го процентиля таких расстояний у самих точек обучения (сосед — другая точка,
        # повтор того же режима не считается)
        self.Ztr = G.Z(np.asarray(G.X, dtype=float))
        dd = np.sqrt(((self.Ztr[:, None, :] - self.Ztr[None, :, :]) ** 2).sum(2))
        dd[dd < 1e-9] = np.inf
        self.nn_p90 = float(np.quantile(dd.min(1), D32_Q))

    def tube_conflict(self, td, L, dp, working):
        """D-32 (б): точки CFD той же трубы с перепадом ближе, чем в 2 раза, и другим режимом (скачок / рабочий)."""
        X = self.done_X
        same = (np.abs(X[:, 0] - td) < 0.005) & (np.abs(X[:, 1] * 6.6 - L) < 1.0)
        near = same & (np.abs(X[:, 2] - math.log(dp)) <= math.log(2.0) + 1e-9) & ((self.done_w == 1) != working)
        return [(round(math.exp(X[i, 2]), 1), 'рабочий' if self.done_w[i] == 1 else 'скачок') for i in np.where(near)[0]]

    def predict(self, td, L, dp, p_cons, T, heat, pm):
        xr = [td, L / 6.6, math.log(dp), p_cons, T, heat, pm]
        x = self.G.Z(np.array([xr]))
        o = [g.predict(x, return_std=True) for g in self.G.GP]
        mu, sd = [float(v[0][0]) for v in o], [SIGMA_MULT * float(v[1][0]) for v in o]   # D-25: σ с множителем калибровки
        p = float(self._pc(self.cb, self.H.Z(np.array([xr])))[0])
        hit = np.where(np.all(np.isclose(self.done_X, np.array(xr), rtol=1e-6, atol=1e-6), axis=1))[0]
        cfd = bool(len(hit))
        if cfd:
            p = float(self.done_w[hit[0]])   # 1 — рабочий по расчёту, 0 — скачок
        inside = [bool(self.lo[i] - 1e-9 <= xr[i] <= self.hi[i] + 1e-9) for i in range(7)]
        m = mu[3] / mu[2]
        # 31.10 (D-31): σ доли ДЗВ m — из σ расходов СВЗ и ДЗВ (с множителем калибровки), независимые ошибки
        sigma_m = abs(m) * math.sqrt((sd[3] / mu[3]) ** 2 + (sd[2] / mu[2]) ** 2) if mu[2] and mu[3] else 0.0
        nn = float(np.sqrt(((self.Ztr - x) ** 2).sum(1)).min())
        conflict = [] if cfd else self.tube_conflict(td, L, dp, p >= 0.5)
        return dict(x=xr, effect_K=mu[0], sigma_K=sd[0], Q=mu[1], sigma_Q=sd[1], G_svz=mu[2], G_dzv=mu[3], sigma_Gs=sd[2], sigma_Gd=sd[3],
                    m=m, sigma_m=0.0 if cfd else sigma_m, p=p, cfd=cfd, inside=inside, working=True, nn=nn, conflict=conflict)


NAMES = ('t/d', 'L', 'перепад ДЗВ', 'давление потребителя', 'T газа', 'подогрев СВЗ', 'давление магистрали')
SCHEMES = ('СПГ', 'внешнее тепло', 'СПГ + внешнее тепло')


DZV_TO = {'СПГ': (True, None), 'транзит': (False, 'транзит'), 'потребитель холода': (False, 'внешнее тепло')}
GOALS = ('min топлива', 'max СПГ')


def dp_limit(card):
    """Допустимая потеря давления ДЗВ, кПа (параметр ЛПР; для транзита — из давления на выходе); None — не ограничена."""
    v = [x for x in (card.dp_max_kPa, (card.p_main - card.p_transit_min_MPa) * 1000 if card.p_transit_min_MPa else None) if x is not None]
    return min(v) if v else None


def bundle_scheme(card):
    """(lng, scheme для grs_balance2.Bundle) по карточке; None — прежнее поведение (СПГ, только если задан выход СПГ)."""
    if card.dzv_to is not None:
        if card.dzv_to not in DZV_TO:
            raise ValueError(f'куда идёт ДЗВ «{card.dzv_to}» — допустимы: {", ".join(DZV_TO)}')
        return DZV_TO[card.dzv_to]
    if card.scheme is None:
        return card.lng_req_kgh > 0, None
    if card.scheme not in SCHEMES:
        raise ValueError(f'схема «{card.scheme}» — допустимы: {", ".join(SCHEMES)}')
    return card.scheme != 'внешнее тепло', (None if card.scheme == 'СПГ' else card.scheme)


def scheme_text(card):
    if card.dzv_to:
        dl = dp_limit(card)
        s = (f'газ ДЗВ — {card.dzv_to}; цель — {card.goal}; допустимая потеря давления ДЗВ — ' +
             (f'{dl:.0f} кПа' if dl is not None else 'не задана'))
        if card.dzv_to == 'потребитель холода':
            t = card.T_main if card.T_ext_C is None else card.T_ext_C
            s += f' (потребитель холода возвращает газ ДЗВ при {t:+.1f} °C)'
        return s
    s = card.scheme or ('СПГ' if card.lng_req_kgh > 0 else 'без использования холода ДЗВ')
    if card.scheme in ('внешнее тепло', 'СПГ + внешнее тепло'):
        t = card.T_main if card.T_ext_C is None else card.T_ext_C
        s += f' (догрев до {t:+.1f} °C; источник не холоднее {t + 5:+.1f} °C)'
    return s


KNURL_AT = dict(p_main=5.5, p_cons=0.59, T_main=8.63, td=1.4, L=400.0, heat=4.83)   # режим A9_19, где накатка посчитана


def knurl_cfd():
    """30.10.2026 (задание автора): «накатка — только где посчитана, иначе П1». Посчитано CFD при равном расходе ДЗВ (D-24) в режиме
    A9_19 (t/d 1,4, L 400; 5,5 → 0,59 МПа; газ 8,63 °C; СВЗ до сопел +4,83 K). Вид → (строка результата CFD, перепад ДЗВ, кПа).
    Для честного сравнения рядом — гладкая труба того же расчёта (A9_19), а не ГП."""
    import csv
    R = Path(r'F:\Leontiev_Project\runs')
    rd = lambda f: {r['tag']: r for r in csv.DictReader(open(R / f, encoding='utf-8'))} if (R / f).exists() else {}
    A9, SH, EQ = rd('a9/a9_results.csv'), rd('patents/knurl_shallow_results.csv'), rd('patents/knurl_eqflow_results.csv')
    jf = R / 'patents/knurl_shallow.json'
    js = json.loads(jf.read_text(encoding='utf-8')) if jf.exists() else {}
    out = {'гладкий (CFD A9_19)': (A9.get('A9_19'), 11.98), 'накатка 0,1 мм': (SH.get('KM01_eq1c') or SH.get('KM01_eq1'), 14.91)}
    for pre, nm in (('KM02', 'накатка 0,2 мм'), ('KM03', 'накатка 0,3 мм')):
        b = js.get(pre)
        if b and str(b.get('start', '')).find('KM0') >= 0 and (SH.get(b['tag']) or {}).get('G_dzv'):   # только повтор от поля 0,1 мм
            out[nm] = (SH[b['tag']], b['dp'])
    out['накатка RU 233137'] = (EQ.get('KQ_A9_19_1'), 87.99)   # выступ 1,0 мм, шаг патента 4,75 мм
    return {k: v for k, v in out.items() if v[0] and v[0].get('G_dzv')}


def cfd_quality(r):
    """Метка «качество расчёта» точки CFD (отдельно от «скачок» и «вне Ω»): сошёлся по критериям / предел итераций + D-12."""
    if str(r.get('status', '')).startswith('сошёлся'):
        return 'сошёлся по критериям'
    q, net = float(r.get('Q') or 0), abs(float(r.get('net_W') or 'nan'))
    return f"предел итераций; дисбаланс {100 * net / q:.2f} % Q — " + ('D-12 выполнено' if net < 0.01 * q else 'D-12 НЕ выполнено')


def labels(o):
    """Три метки раздельно (задание автора 30.10): скачок / вне Ω / качество расчёта."""
    sh = ('да (CFD)' if o['p'] < 0.5 else 'нет (CFD)') if o['cfd'] else f"p «рабочий» {o['p']:.3f}"
    out = [NAMES[i] for i, ok in enumerate(o['inside']) if not ok]
    om = ('вне Ω: ' + ', '.join(out)) if out else ('вне Ω: m ' + f"{o['m']:.3f}" if not (0.2 <= o['m'] <= 0.96) else 'в Ω')
    return dict(скачок=sh, Ω=om, качество=o.get('quality') or (f"прогноз ГП, σ {o['sigma_K']:.2f} K" if not o['cfd'] else 'точка обучения CFD'))


def evaluate(card: TaskCard, M: Models):
    import grs_balance2 as B
    st = B.Station(p_main=card.p_main, T_main=card.T_main, flow_nm3h=card.flow_nm3h, p_cons=card.p_cons, T_min=card.T_min)
    base = B.var_a(st)
    rows = []
    lng, sch = bundle_scheme(card)
    dl = dp_limit(card)
    if card.goal not in GOALS:
        raise ValueError(f'цель «{card.goal}» — допустимы: {", ".join(GOALS)}')
    KN = knurl_cfd() if any(k != 'гладкий' for k in card.kinds) else {}
    at = all(abs(getattr(card, k) - KNURL_AT[k]) <= tol for k, tol in (('p_main', 0.01), ('p_cons', 0.01), ('T_main', 0.5)))
    for kind in card.kinds:
        for td, L in card.geometries:
            for zi, z in enumerate(card.heater_place):
                cfd = None
                if kind != 'гладкий':
                    if kind not in KN or not at or (td, L) != (KNURL_AT['td'], KNURL_AT['L']):
                        rows.append(dict(kind=kind, td=td, L=L, z=z, dp='—', rule='П1', cat='П1 вариант',
                                         why=f'вариант «{kind}» в данных CFD для этого сценария не рассчитан (посчитан только режим A9_19: '
                                             't/d 1,4, L 400, 5,5 → 0,59 МПа, газ 8,63 °C)'))
                        continue
                    if zi:
                        continue   # посчитанная точка — одно место подогревателя: до сопел +4,83 K (как CFD), остальное после пучка
                    cfd, dp_c = KN[kind]
                    z = f"как CFD: до сопел +{KNURL_AT['heat']} K, остальное после"
                for dp in ([dp_c] if cfd else card.dp_kPa):
                    r = dict(kind=kind, td=td, L=L, z=z, dp=dp)
                    last = {}
                    if cfd:
                        G_s, G_d = float(cfd['G_svz']), float(cfd['G_dzv'])
                        o_c = dict(x=None, effect_K=float(cfd['dT_svz_vs_throttle']), sigma_K=0.0, Q=float(cfd['Q']), sigma_Q=0.0,
                                   G_svz=G_s, G_dzv=G_d, m=G_d / G_s, p=0.0 if cfd.get('x_shock_m') else 1.0, cfd=True,
                                   inside=[True] * 7, working=True, quality=cfd_quality(cfd), src=cfd['tag'])
                        pred = lambda heat: dict(o_c)
                    else:
                        pred = lambda heat: M.predict(td, L, dp, card.p_cons, card.T_main, heat, card.p_main)

                    def tube(bd, st_, heat, dQ=0.0):
                        o = pred(heat)
                        last.update(o, heat=heat)
                        return dict(effect_K=o['effect_K'], Q=o['Q'] + dQ * o['sigma_Q'], G_svz=o['G_svz'], G_dzv=o['G_dzv'],
                                    m=o['m'], working=True)
                    o0 = pred(KNURL_AT['heat'] if cfd else 0.0)
                    n_max = B.n_rule(st, o0['G_svz'], o0['G_dzv'])
                    best = None
                    for n in range(1, n_max + 1):     # режимный параметр — число работающих труб
                        res = {}
                        for dQ in (0.0, -1.0, 1.0):
                            B.tube = lambda bd_, st_, heat, dQ=dQ: tube(bd_, st_, heat, dQ)
                            try:
                                v = B.var_v(st, B.Bundle(td=td, L_mm=L, dp_kPa=dp, n_on=n, heater_place='после' if cfd else z, lng=lng,
                                                         scheme=sch, T_ext=card.T_ext_C, heat_fixed_K=KNURL_AT['heat'] if cfd else None))
                            except ValueError:
                                v = None
                            res[dQ] = (v, dict(last))
                        v, o = res[0.0]
                        if v is None:
                            continue
                        N = [res[k][0]['Q_heater_kW'] if res[k][0] else v['Q_heater_kW'] for k in (0.0, -1.0, 1.0)]
                        G = [res[k][0]['lng_kgh'] if res[k][0] else v['lng_kgh'] for k in (0.0, -1.0, 1.0)]
                        c = dict(n=n, N=v['Q_heater_kW'], N_lo=min(N), N_hi=max(N), lng=v['lng_kgh'], lng_lo=min(G), lng_hi=max(G),
                                 fuel=v['fuel_nm3h'], heat=v['heater_svz_K'], o=o, ext=v.get('ext_kW', 0.0), pre=v['pre_kW'], post=v['post_kW'],
                                 T_dzv=v['T_dzv_C'], p_dzv=v['p_dzv_MPa'], G_dzv_kgh=v['m_dzv_kgs'] * 3600, T_ext=v['T_ext_C'], cfd_variant=bool(cfd))
                        if v['lng_kgh'] + 1e-9 < card.lng_req_kgh:
                            continue
                        key = (lambda c: (-round(c['lng'], 2), c['N'])) if card.goal == 'max СПГ' else (lambda c: (c['N'], -c['lng']))
                        if best is None or key(c) < key(best):
                            best = c
                    o = best['o'] if best else dict(o0, heat=0.0)
                    out_data = [NAMES[i] for i, ok in enumerate(o['inside']) if not ok]
                    r.update(best or {}, feasible=best is not None, labels=labels(o))
                    if best is None:
                        r['o'] = o
                    # 30.10 (задание автора): П1 проверяется раньше экономики; метки раздельно — скачок / вне Ω / качество расчёта.
                    # Порядок: ограничение ЛПР (потеря давления ДЗВ) → П1 (данные, опыт) → скачок по CFD → задание по СПГ → П2 / П3
                    if dl is not None and dp > dl + 1e-9:
                        r.update(rule='—', cat='ограничение ЛПР', feasible=False, why=f'потеря давления ДЗВ {dp:g} кПа > допустимой {dl:g} кПа')
                    elif out_data:
                        r.update(rule='П1', cat='П1 данные', why='вне данных CFD: ' + ', '.join(out_data))
                    elif not (0.2 <= o['m'] <= 0.96):
                        r.update(rule='П1', cat='П1 опыт', why=f"m = {o['m']:.3f} вне 0,2–0,96 (проверенная опытом область) — требуется опытная проверка")
                    elif best is not None and o['m'] + o.get('sigma_m', 0.0) > 0.96:
                        # 31.10 (D-31, принято автором): m в Ω, но с погрешностью может выйти за 0,96 — досчитать
                        r.update(rule='П2', cat='П2 граница Ω', why=f"оптимум на границе применимости: m + σ_m = {o['m']:.3f} + {o['sigma_m']:.3f} "
                                                                    f"= {o['m'] + o['sigma_m']:.3f} > 0,96 (D-31)")
                    elif o['cfd'] and o['p'] < 0.5:
                        r.update(rule='—', cat='скачок по CFD', feasible=False, why='вариант посчитан CFD: в канале скачок')
                    elif best is None:
                        r.update(rule='—', cat='ограничение СПГ', why=f'ни при каком числе труб (1…{n_max}) не выполнено G_СПГ ≥ {card.lng_req_kgh} кг/ч')
                    elif o['sigma_K'] > card.delta_K:
                        r.update(rule='П2', cat='П2 σ', why=f"σ = {o['sigma_K']:.2f} K > δ")
                    elif not o['cfd'] and o['p'] < M.p_hi:
                        r.update(rule='П2', cat='П2 класс', why=f"p «рабочий» = {o['p']:.3f} < p_hi {M.p_hi:.3f}")
                    elif not o['cfd'] and o.get('conflict'):
                        # 31.10 (D-32, решение автора): у той же трубы рядом по перепаду (ближе, чем в 2 раза) другой режим
                        r.update(rule='П2', cat='П2 граница скачка', why='у этой трубы рядом по перепаду другой режим: ' +
                                 ', '.join(f'{a:g} кПа — {b}' for a, b in o['conflict']) + ' (D-32)')
                    elif not o['cfd'] and o.get('nn', 0.0) > M.nn_p90:
                        r.update(rule='П2', cat='П2 мало данных', why=f"рядом мало данных: расстояние до ближайшей точки {o['nn']:.3f} > "
                                                                       f"90-го процентиля {M.nn_p90:.3f} (D-32)")
                    else:
                        r.update(rule='П3', cat='П3', why=f"σ = {o['sigma_K']:.2f} K ≤ δ, " +
                                 (f"посчитано CFD ({o.get('src', 'точка обучения')}; {o.get('quality', 'рабочий по расчёту')})" if o['cfd']
                                  else f"p = {o['p']:.3f} ≥ p_hi"))
                    rows.append(r)
    return base, rows


def heater_at(card, M, td, L, z, dp, n):
    """N_п (кВт) и СПГ при заданных u_п, u_р (для существующей конструкции/режима u0)."""
    import grs_balance2 as B
    st = B.Station(p_main=card.p_main, T_main=card.T_main, flow_nm3h=card.flow_nm3h, p_cons=card.p_cons, T_min=card.T_min)

    def tube(bd, st_, heat):
        o = M.predict(td, L, dp, card.p_cons, card.T_main, heat, card.p_main)
        return dict(effect_K=o['effect_K'], Q=o['Q'], G_svz=o['G_svz'], G_dzv=o['G_dzv'], m=o['m'], working=True)
    B.tube = tube
    lng, sch = bundle_scheme(card)
    v = B.var_v(st, B.Bundle(td=td, L_mm=L, dp_kPa=dp, n_on=n, heater_place=z, lng=lng, scheme=sch, T_ext=card.T_ext_C))
    return v['Q_heater_kW'], v['lng_kgh']


def resources(card, M, rows, base):
    """п. 2.1: режимный ресурс ΔN_р = N(u_п⁰, u_р⁰) − min по u_р N(u_п⁰, ·); проектный ΔN_пр = min по u_р N(u_п⁰, ·) − min по (u_п, u_р) N.
    Минимумы — только по вариантам в Ω (П2/П3) с выполненным заданием."""
    u0 = card.u0
    if not u0:
        return None
    N0, lng0 = heater_at(card, M, u0['td'], u0['L'], u0.get('z', 'после'), u0['dp'], u0['n'])
    ok = [r for r in rows if r.get('feasible') and r['rule'] in ('П2', 'П3')]
    own = [r for r in ok if r['td'] == u0['td'] and r['L'] == u0['L'] and r['z'] == u0.get('z', 'после')]
    if not own or not ok:
        return dict(N0=N0, lng0=lng0, note='для существующей конструкции нет вариантов режима в Ω')
    r_own, r_all = min(own, key=lambda r: r['N']), min(ok, key=lambda r: r['N'])
    return dict(N0=N0, lng0=lng0, own=r_own, all=r_all, dN_r=N0 - r_own['N'], dN_pr=r_own['N'] - r_all['N'])


# 30.10.2026: физические края (за ними расчёт не нужен) — по 1D-проверке запуска сверхзвука с текущим соплом A/A* 2,15
# (dataset\edge_task2_1d.py → runs\program\край_задачи2_1D.md: L 660 — 4,17, L 735 — 4,34, L 810 — 4,46 при пороге 4,2)
PHYS_EDGES = {('L, мм', 'макс.'): 'край физический: длиннее нельзя — при L > 660 мм с текущим соплом сверхзвук по 1D не удерживается '
                                    '(край_задачи2_1D.md)'}


def data_edges(M, b):
    """30.10.2026 (решение автора): лучший вариант на краю рассчитанного диапазона по проектному или режимному фактору
    (t/d, L, перепад ДЗВ; сопло и накатка — по данным модели) — оптимум может лежать за краем. Край: значение лучшего
    в пределах 5 % размаха от min / max значений, посчитанных CFD. Возвращает [(фактор, значение, край, шаг за край)]."""
    X = np.asarray(M.G.X, dtype=float)
    # шкала — как у входа модели (перепад ДЗВ в ln); значения ближе 5 % размаха — один уровень (L 654,7 и 660 мм)
    vals = {'t/d': (X[:, 0], b['td'], None), 'L, мм': (X[:, 1] * 6.6, b['L'], None), 'перепад ДЗВ, кПа': (X[:, 2], math.log(b['dp']), np.exp)}
    out = []
    for name, (col, v, back) in vals.items():
        u = np.unique(np.round(col, 6))
        span = u[-1] - u[0]
        if span <= 0:
            continue
        lev = [u[0]]
        for x in u[1:]:
            if x - lev[-1] > 0.05 * span:
                lev.append(x)
        hi_, lo_ = u[-1], u[0]
        for edge, step, side in ((hi_, hi_ - lev[-2] if len(lev) > 1 else 0, 'макс.'), (lo_, lev[1] - lo_ if len(lev) > 1 else 0, 'мин.')):
            if abs(v - edge) <= 0.05 * span:
                beyond = edge + step if side == 'макс.' else edge - step
                f = back or (lambda z: z)
                out.append((name, round(float(f(v)), 3), f'{side} в данных {float(f(edge)):.4g}',
                            None if (name, side) in PHYS_EDGES else round(float(f(beyond)), 3)))
    # сопло и накатка — не входы модели (D-28): в обучении одно значение (сопло базы A/A* 2,15; гладкая труба). Сопло — отдельное
    # исследование; накатка — посчитанные точки CFD (knurl_cfd), после заморозки — характеристика «тепло — потеря давления ДЗВ»
    return out


def decide(card, M, base, rows):
    d = _decide(card, M, base, rows)
    b = d.get('best')
    if b and b.get('o') and not b.get('cfd_variant'):   # край данных — по ГП; посчитанная точка CFD (накатка) — не по ГП
        e = data_edges(M, b)
        d['edges'] = e
        phys = [PHYS_EDGES[(n, w.split()[0])] for n, v, w, x in e if x is None]
        e = [t for t in e if t[3] is not None]
        if phys:
            d['why'] = d['why'] + '; ' + '; '.join(phys)
        # 30.10: край данных — только если лучший на краю ЗАМЕТНО (> ε_N) лучше всех вариантов внутри данных; при ничьей
        # (например, подогреватель 0 у всех при T_min −10 °C или без потребителя холода) край не определяет оптимум
        inner = [r for r in rows if r.get('feasible') and r.get('rule') in ('П2', 'П3') and r is not b
                 and r['N'] <= b['N'] + card.eps_N_kW and not [t for t in data_edges(M, r) if t[3] is not None]]
        if e and inner:
            r = min(inner, key=lambda r: r['N'])
            d['why'] += (f'; лучший на краю данных, но внутри данных есть равноценный вариант ({fmt(r)}: {r["N"]:.1f} кВт, '
                         f'разница ≤ ε_N {card.eps_N_kW} кВт) — край не определяет оптимум')
            e = []
        if e:
            ser = '; '.join(f'{n}: {v:g} ({w}) → серия за краем при {x:g}' for n, v, w, x in e)
            d.update(rule='П1', status='Δ3 «вернуть задачу»', cat='П1 край данных',
                     why=f'лучшее на границе данных — {ser}. Оптимум может лежать за краем: предложена серия CFD за краем '
                         f'(сценарий задачи), до неё рекомендация условная' + ('; ' + '; '.join(phys) if phys else ''), calc=None,
                     series=[dict(factor=n, at=v, beyond=x) for n, v, w, x in e])
    return d


def _decide(card, M, base, rows):
    ok = [r for r in rows if r.get('feasible') and r['rule'] in ('П2', 'П3')]
    # 30.10: при равном подогревателе (напр. 0 кВт у всех при T_min −10 °C) — больше СПГ, затем вариант с П3;
    # цель «max СПГ» (задание автора 30.10) — сначала больше СПГ, затем меньше подогреватель
    if card.goal == 'max СПГ':
        ok.sort(key=lambda r: (-round(r.get('lng', 0.0), 2), round(r['N'], 3), r['rule'] != 'П3'))
    else:
        ok.sort(key=lambda r: (round(r['N'], 3), -r.get('lng', 0.0), r['rule'] != 'П3'))
    if ok and card.goal != 'max СПГ' and card.lng_req_kgh <= 0 and ok[0]['N'] >= base['Q_heater_kW'] - card.eps_N_kW:
        # 30.10: без потребителя холода и с подогревателем после пучка пучок адиабатен — тепло трубы возвращается при смешении
        return dict(rule='П3', status='Δ1 «выдать»: не рекомендовано', best=None, cat='нет экономии',
                    why=f"пучок не уменьшает подогреватель больше чем на ε_N ({ok[0]['N']:.1f} против {base['Q_heater_kW']:.1f} кВт у дросселя): "
                        'при подогревателе после пучка и без потребителя холода (СПГ) тепло трубы возвращается при смешении потоков', calc=None)
    if not ok:
        from collections import Counter
        cats = Counter(r.get('cat', 'П1 вариант') for r in rows)
        why = '; '.join(f'{k} — {v}' for k, v in cats.most_common())
        p1 = [r for r in rows if r.get('rule') == 'П1']
        if p1:   # есть варианты, выполняющие задание, но вне Ω (данные / опыт) — задачу вернуть: расширить данные или опыт
            return dict(rule='П1', status='Δ3 «вернуть задачу»', best=None, cat='П1 опыт' if cats.get('П1 опыт') else 'П1 данные',
                        why=f'варианты, выполняющие задание, есть только вне паспорта Ω ({why})', calc=None)
        return dict(rule='П3', status='Δ1 «выдать»: не рекомендовано', best=None, cat='ограничение СПГ',
                    why=f'ни один вариант не выполняет задания, даже вне Ω ({why})', calc=None)
    b = ok[0]
    knurl_note = ''
    if not b['kind'].startswith('гладкий'):
        # 30.10: накатка выдаётся, только если выигрыш больше порога различимости (ε_N или ε_СПГ); иначе — гладкая
        # (проще и без лишней потери давления ДЗВ)
        sm = [r for r in ok if r['kind'].startswith('гладкий') and
              (r['lng'] >= b['lng'] - card.eps_lng_kgh if card.goal == 'max СПГ' else r['N'] <= b['N'] + card.eps_N_kW)]
        if sm:
            knurl_note = (f"; накатка ({b['kind']}) лучше гладкой меньше чем на порог различимости — выдана гладкая "
                          f"({sm[0]['N']:.1f} против {b['N']:.1f} кВт, СПГ {sm[0]['lng']:.1f} против {b['lng']:.1f} кг/ч)")
            b = sm[0]
    same = lambda r: r['kind'] == b['kind'] and r['td'] == b['td'] and r['L'] == b['L'] and r['z'] == b['z'] and r['dp'] == b['dp']
    if card.goal == 'max СПГ':
        rivals = [r for r in ok[1:] if r['lng_hi'] > b['lng_lo'] + card.eps_lng_kgh and not same(r)]
    else:
        rivals = [r for r in ok[1:] if r['N_lo'] < b['N_hi'] - card.eps_N_kW and not same(r)]
    # 01.11 (решение автора, п. 1): m у самой границы Ω — подпись «на границе применимости» (D-31 не сработал, но запас мал)
    o = b.get('o') or {}
    if o.get('m') is not None and o['m'] + o.get('sigma_m', 0.0) > M_EDGE:
        knurl_note += f"; m на границе применимости ({o['m']:.3f}; m + σ_m = {o['m'] + o.get('sigma_m', 0.0):.3f})"
    if b['rule'] == 'П2':
        return dict(rule='П2', status='Δ2 «досчитать»', best=b, cat=b['cat'], why=b['why'] + knurl_note, calc=b, rivals=rivals)
    if rivals:
        c = max([b] + rivals, key=lambda r: r['o']['sigma_K'])
        return dict(rule='П2', status='Δ2 «досчитать»', best=b, cat='П2 устойчивость', why=f'лучший вариант может смениться: {len(rivals)} соперник(ов) в пределах погрешности более чем на ε_N' + knurl_note,
                    calc=c, rivals=rivals)
    # 01.11 (решение автора, п. 3): накатка выдаётся только с пометкой, пока сетка накатки не проверена (D-33, п. 7)
    status = 'Δ1 «выдать»'
    if not b['kind'].startswith('гладкий') and not knurl_mesh_ok():
        status, knurl_note = 'Δ1 «выдать» (сетка не проверена — оценка)', knurl_note + '; сетка накатки не проверена — результат оценочный (D-33)'
    return dict(rule='П3', status=status, best=b, cat='П3', why=b['why'] + knurl_note, calc=None, rivals=[])


def knurl_mesh_ok():
    """Проверка сетки накатки (runs\\patents\\сетка_накатки.json, ok) — пока не пройдена, накатка — оценка."""
    f = Path(r'F:\Leontiev_Project\runs\patents\сетка_накатки.json')
    try:
        return bool(json.loads(f.read_text(encoding='utf-8')).get('ok'))
    except (OSError, ValueError):
        return False


def fmt(r):
    return (f"{r['kind']}, t/d {r['td']}, L {r['L']:.0f} мм, подогреватель {r['z']}; перепад ДЗВ {r['dp']} кПа, труб {r['n']}")


def report(card, M, base, rows, d):
    t = time.strftime('%d.%m.%Y %H:%M')
    L = [f'# Карточка рекомендации: {card.title} ({t})', '',
         f'Сценарий f: магистраль {card.p_main} МПа, газ {card.T_main:+.0f} °C, отпуск {card.flow_nm3h:.0f} нм³/ч. '
         f'Задание x0: потребитель {card.p_cons} МПа, T_min {card.T_min:+.0f} °C, G_СПГ ≥ {card.lng_req_kgh:.0f} кг/ч. '
         f'Параметры ЛПР: δ = {card.delta_K} K, ε_N = {card.eps_N_kW} кВт. Модели: ГП по {M.n_train} точкам CFD, CatBoost p_hi = {M.p_hi:.3f}.',
         f'Схема использования холода ДЗВ: {scheme_text(card)}.', '',
         f"**Было (дроссель + подогреватель):** подогреватель {base['Q_heater_kW']:.1f} кВт, топливо {base['fuel_nm3h']:.2f} нм³/ч.", '',
         f"## Решение: {d['status']} (правило {d['rule']}, причина: {d.get('cat', d['rule'])})", '', d['why'], '']
    b = d['best']
    if b:
        o = b['o']
        L += [f"**Лучший вариант:** {fmt(b)}.",
              f"Подогреватель **{b['N']:.1f} кВт** (по Q ± σ: {b['N_lo']:.1f}…{b['N_hi']:.1f}), было {base['Q_heater_kW']:.1f} кВт; СПГ {b['lng']:.1f} кг/ч; "
              f"топливо {b['fuel']:.2f} нм³/ч" + (f"; подогрев СВЗ до сопел {b['heat']:.1f} K" if b['z'] == 'до сопел' or b.get('cfd_variant') else '')
              + (f" (подогреватель = всё топливное тепло: до сопел {b['pre']:.1f} + после пучка {b['post']:.1f} кВт)" if b.get('pre') else '')
              + (f"; внешнее (не топливное) тепло {b['ext']:.1f} кВт" if b.get('ext') and card.dzv_to != 'потребитель холода' else '') + '.',
              f"Труба: эффект {o['effect_K']:+.2f} ± {o['sigma_K']:.2f} K, Q {o['Q']:.0f} ± {o['sigma_Q']:.0f} Вт, m {o['m']:.3f}, p «рабочий» {o['p']:.3f}.",
              'Метки: ' + '; '.join(f'{k} — {v}' for k, v in b['labels'].items()) + '.']
        if card.dzv_to == 'транзит':
            L += [f"Транзит: газ ДЗВ {b['G_dzv_kgh']:.0f} кг/ч уходит при {b['p_dzv']:.3f} МПа (потеря давления {b['dp']:g} кПа) и {b['T_dzv']:+.1f} °C "
                  f"(газ магистрали {card.T_main:+.1f} °C)."]
        if card.dzv_to == 'потребитель холода':
            L += [f"Холод потребителю: {b['ext']:.1f} кВт; газ ДЗВ {b['G_dzv_kgh']:.0f} кг/ч приходит при {b['T_dzv']:+.1f} °C, уходит при "
                  f"{b['T_ext']:+.1f} °C (потеря давления ДЗВ {b['dp']:g} кПа)."]
        L += ['']
        if d.get('edges'):
            L += ['**Лучшее на границе данных:** ' +
                  '; '.join((f'{n} {v:g} ({w}) — серия CFD за краем при {x:g}' if x is not None else f'{n} {v:g} ({w}) — {PHYS_EDGES[(n, w.split()[0])]}')
                            for n, v, w, x in d['edges']) + '.', '']
    rs = resources(card, M, rows, base)
    if rs:
        u0 = card.u0
        L += [f"**Существующая конструкция и режим u0:** t/d {u0['td']}, L {u0['L']:.0f} мм, перепад {u0['dp']} кПа, труб {u0['n']}: "
              f"подогреватель {rs['N0']:.1f} кВт, СПГ {rs['lng0']:.1f} кг/ч."]
        if 'own' in rs:
            L += [f"- режимный ресурс ΔN_р = {rs['dN_r']:+.1f} кВт: на той же конструкции — перепад {rs['own']['dp']} кПа, труб {rs['own']['n']} "
                  f"→ {rs['own']['N']:.1f} кВт ({rs['own']['rule']});",
                  f"- проектный ресурс ΔN_пр = {rs['dN_pr']:+.1f} кВт: {fmt(rs['all'])} → {rs['all']['N']:.1f} кВт ({rs['all']['rule']}).",
                  'Правило для ЛПР: сначала исчерпать режим, потом менять конструкцию.', '']
        else:
            L += [rs['note'], '']
    beyond = [r for r in rows if r.get('rule') == 'П1' and 'N' in r and (not b or r['N'] < b['N'] - card.eps_N_kW)]
    if beyond:
        r = min(beyond, key=lambda r: r['N'])
        L += [f"**За паспортом Ω есть варианты лучше** ({len(beyond)}; лучший — {fmt(r)}: {r['N']:.1f} кВт, {r['why']}). " +
              'Выдать их нельзя: решение ЛПР — оставить рекомендацию, заказать серию расчётов или опыт (К3, правило П1).', '']
    if d.get('calc'):
        c = d['calc']
        L += [f"**Предлагаемый расчёт Fluent (К3, подтверждает инженер-расчётчик):** {fmt(c)}; сценарий как в задаче. "
              f"Прогноз до расчёта: эффект {c['o']['effect_K']:+.2f} ± {c['o']['sigma_K']:.2f} K, p {c['o']['p']:.3f}.", '']
    L += ['## Все варианты', '', '| вариант | перепад, кПа | труб | правило | подогреватель, кВт | СПГ, кг/ч | эффект ± σ, K | m | p | '
          'метки: скачок / Ω / качество | почему |', '|---|---|---|---|---|---|---|---|---|---|---|']
    for r in sorted(rows, key=lambda r: (r.get('N', 1e9))):
        o = r.get('o') or {}
        L.append(f"| {r['kind']}, {r['td']}/{r['L']:.0f}, {r['z']} | {r['dp']} | {r.get('n', '—')} | {r.get('cat', r['rule'])} | "
                 f"{r['N']:.1f} | {r['lng']:.1f} | " if 'N' in r else
                 f"| {r['kind']}, {r['td']}/{r['L']:.0f}, {r['z']} | {r['dp']} | — | {r.get('cat', r['rule'])} | — | — | ")
        lb = ' / '.join(r['labels'].values()) if r.get('labels') else '—'
        L[-1] += (f"{o['effect_K']:+.2f} ± {o['sigma_K']:.2f} | {o['m']:.3f} | {o['p']:.3f} | {lb} | {r['why']} |" if o else f"— | — | — | {lb} | {r['why']} |")
    return '\n'.join(L) + '\n'


def regime_map(card, M):
    """п. 4.5: режимная карта для диспетчера — условия станции → перепад ДЗВ, число труб, мощность подогревателя (уставка
    T_min на выходе), статус по П1–П3 в каждой клетке. Конструкция фиксирована: первая геометрия и место подогревателя."""
    from dataclasses import replace
    td, L = card.geometries[0]
    z = card.heater_place[0]
    out = [f'## Режимная карта: t/d {td}, L {L:.0f} мм, подогреватель {z} (уставка T_min {card.T_min:+.0f} °C, G_СПГ ≥ {card.lng_req_kgh:.0f} кг/ч)', '',
           '| P магистрали, МПа | T газа, °C | статус | по какому правилу | перепад ДЗВ, кПа | труб | подогреватель, кВт (было) | СПГ, кг/ч | почему |',
           '|---|---|---|---|---|---|---|---|---|']
    for pm, T in card.map_scenarios:
        c = replace(card, p_main=pm, T_main=T, kinds=['гладкий'], geometries=[[td, L]], heater_place=[z], u0={})
        base, rows = evaluate(c, M)
        d = decide(c, M, base, rows)
        b = d['best']
        out.append(f"| {pm} | {T:+.0f} | {d['status']} | {d.get('cat', d['rule'])} | " + (f"{b['dp']} | {b['n']} | {b['N']:.1f} ({base['Q_heater_kW']:.1f}) | {b['lng']:.1f} | "
                   if b else f"— | — | — ({base['Q_heater_kW']:.1f}) | — | ") + f"{d['why']} |")
    out += ['', 'Причины статусов: **П3** — выдать (σ ≤ δ, класс «рабочий» — по классификатору или по расчёту CFD); '
            '**П2 σ / П2 класс / П2 устойчивость** — досчитать (погрешность эффекта, неуверенность в классе, лучший вариант может смениться); '
            '**П2 граница скачка / П2 мало данных** (D-32) — досчитать: у той же трубы ближе, чем в 2 раза по перепаду, другой режим; '
            'расстояние до ближайших данных больше 90-го процентиля; '
            '**П1 данные** — вернуть задачу: фактор вне рассчитанного диапазона (нужна серия расчётов); '
            '**П1 край данных** — вернуть задачу: лучший вариант на краю рассчитанного диапазона (t/d, L, перепад ДЗВ) — нужна серия за краем; '
            '**П1 опыт** — вернуть задачу: варианты, выполняющие задание, есть, но m вне 0,2–0,96, за краем опыта 2017 г. (нужна опытная проверка); '
            '**ограничение СПГ** — «не рекомендовано»: ни один вариант, даже вне Ω, не даёт требуемого выхода СПГ. '
            'Поэтому «вернуть задачу» мягче, чем «не рекомендовано»: в первом случае решение, возможно, есть, но не доказано; во втором его нет. '
            'Ограничение T_min не даёт отказов: подогреватель после пучка всегда догревает газ до уставки (его мощность и есть критерий).']
    return '\n'.join(out) + '\n'


def to_html(md, title):
    """Карточка в читаемый HTML для слайда (заголовки, жирный, таблицы, абзацы) — без внешних библиотек."""
    import html, re
    inline = lambda s: re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', html.escape(s))
    out, rows = [], []

    def flush():
        if rows:
            out.append('<table>' + ''.join('<tr>' + ''.join(f'<{t}>{inline(c)}</{t}>' for c in r) + '</tr>'
                                           for t, r in rows) + '</table>')
            rows.clear()
    for line in md.split('\n'):
        if line.startswith('|'):
            cells = [c.strip() for c in line.strip('|').split('|')]
            if set(''.join(cells)) <= set('-: '):
                continue
            rows.append(('th' if not rows else 'td', cells)); continue
        flush()
        if line.startswith('#'):
            n = len(line) - len(line.lstrip('#'))
            out.append(f'<h{n}>{inline(line[n:].strip())}</h{n}>')
        elif line.startswith('- '):
            out.append(f'<p class="li">• {inline(line[2:])}</p>')
        elif line.strip():
            out.append(f'<p>{inline(line)}</p>')
    flush()
    css = ('body{font-family:Segoe UI,Arial,sans-serif;max-width:1100px;margin:24px auto;padding:0 16px;color:#111;background:#fcfcfb}'
           'h1{font-size:22px}h2{font-size:18px;margin-top:22px}table{border-collapse:collapse;font-size:12px;margin:8px 0}'
           'th,td{border:1px solid #ccc;padding:3px 6px;vertical-align:top}th{background:#eef2f7}p{line-height:1.45}p.li{margin:2px 0 2px 12px}')
    return f'<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>{html.escape(title)}</title><style>{css}</style></head><body>{"".join(out)}</body></html>'


def journal(card, M, d, path_card, note=None):
    b = d['best']
    rec = (f"{fmt(b)}; подогреватель {b['N']:.1f} кВт ({b['N_lo']:.1f}…{b['N_hi']:.1f}); СПГ {b['lng']:.1f} кг/ч; "
           f"эффект {b['o']['effect_K']:+.2f} ± {b['o']['sigma_K']:.2f} K") if b else '—'
    L = ['', f'## Задача программы: {card.title} ({time.strftime("%d.%m.%Y %H:%M")})', '', '| Поле | Значение |', '|---|---|',
         f'| Задача, сценарий f | {card.p_main} МПа, газ {card.T_main:+.0f} °C, {card.flow_nm3h:.0f} нм³/ч; потребитель {card.p_cons} МПа, '
         f'T_min {card.T_min:+.0f} °C, G_СПГ ≥ {card.lng_req_kgh:.0f} кг/ч; {scheme_text(card)} (карточка {path_card.name}) |',
         f"| Ситуация и правило | **{d['rule']} → {d['status']}**: {d['why']} |"] + ([f'| Изменение статуса | **{note}** |'] if note else []) + [
         f'| Рекомендация (прогноз ± σ) | {rec} |',
         '| Решение ЛПР | ожидает (утверждено / отклонено) |',
         '| Проверочный расчёт Fluent и разница | ' + (f"предложен: {fmt(d['calc'])}" if d.get('calc') else 'не требуется') + ' |']
    with open(JOURNAL, 'a', encoding='utf-8') as f:
        f.write('\n'.join(L) + '\n')


def main(path, write_journal=True, note=None, M=None):
    path = Path(path)
    card = TaskCard(**json.loads(path.read_text(encoding='utf-8')))
    M = M or Models()
    base, rows = evaluate(card, M)
    d = decide(card, M, base, rows)
    OUT.mkdir(parents=True, exist_ok=True)
    txt = report(card, M, base, rows, d)
    if card.map_scenarios:
        txt += '\n' + regime_map(card, M)
    (OUT / (path.stem + '_рекомендация.md')).write_text(txt, encoding='utf-8')
    card_md = '# Карточка задачи\n\n| Поле | Значение |\n|---|---|\n' + ''.join(f'| {k} | {v} |\n' for k, v in asdict(card).items())
    (OUT / (path.stem + '_рекомендация.html')).write_text(to_html(card_md + '\n' + txt, card.title), encoding='utf-8')
    if write_journal:
        journal(card, M, d, path, note)
    print(txt)
    return d


CONF_FC = Path(r'F:\Leontiev_Project\runs\journal\confirm_forecasts.json')


def confirm_and_run(path):
    """29.10.2026 — команда «подтвердить → посчитать → статус обновился» (полный цикл К3, решение автора).
    30.10.2026 (решение автора): команда НЕ запускает Fluent, а СТАВИТ расчёт в очередь — текущий расчёт не прерывается,
    второй Fluent параллельно не запускается; считает dataset\\confirm_runner.py на своём месте в очереди.
    1) программа решает задачу; Δ2 «досчитать» → предложенный расчёт; П1 «край данных» → серия за краем (каждый нефизический
       край: новое значение фактора при прочих — лучшего варианта; 2–3 режима перепада ДЗВ от лучшего вверх по карточке);
    2) прогноз ± σ каждой точки записывается ДО расчёта (runs\\journal\\confirm_forecasts.json, теги CFnn, status «в очереди»);
    3) запись в журнал решений «поставлено в очередь»; после расчёта confirm_runner переобучает модели, решает задачу заново
       и пишет «был … → посчитали → новый статус».
    usage: python sppr.py <карточка.json> --confirm"""
    M = Models()
    d = main(path, False, M=M)
    card = TaskCard(**json.loads(Path(path).read_text(encoding='utf-8')))
    b = d.get('best')
    jobs = []
    if d.get('calc'):
        c = d['calc']
        jobs.append(dict(td=c['td'], L=c['L'], dp=c['dp'], z=c['z'], heat=float(c.get('heat') or 0.0) if c['z'] == 'до сопел' else 0.0,
                         why='досчёт предложенного варианта (Δ2)'))
    elif d.get('cat') == 'П1 край данных' and b:
        dps = [x for x in sorted(card.dp_kPa) if x >= b['dp']][:3]
        for s in d['series']:
            td = round(s['beyond'], 2) if s['factor'] == 't/d' else b['td']
            L_ = round(s['beyond'] / 10) * 10 if s['factor'] == 'L, мм' else b['L']
            dps_ = [round(s['beyond'], 1)] if s['factor'] == 'перепад ДЗВ, кПа' else dps
            for dp in dps_:
                jobs.append(dict(td=td, L=float(L_), dp=dp, z=b['z'], heat=float(b.get('heat') or 0.0) if b['z'] == 'до сопел' else 0.0,
                                 why=f"серия за краем: {s['factor']} {s['at']:g} → {s['beyond']:g}"))
    if not jobs:
        print(f"Статус {d['status']} ({d.get('cat')}) — расчёт не нужен."); return d
    fc = json.loads(CONF_FC.read_text(encoding='utf-8')) if CONF_FC.exists() else {}
    n0 = len([t for t in fc if not t.endswith(('h', 'c'))])
    rows, k = [], 0
    for j in jobs:
        o = M.predict(j['td'], j['L'], j['dp'], card.p_cons, card.T_main, j['heat'], card.p_main)
        if not (0.2 <= o['m'] <= 0.96):   # 30.10 (задание автора): точки с прогнозом вне Ω в очередь не ставятся
            rows.append(f"| — | t/d {j['td']}, L {j['L']:.0f}, перепад {j['dp']} кПа | {j['why']} | **не поставлено: прогноз m {o['m']:.3f} вне Ω "
                        f"(0,2–0,96)**; эффект {o['effect_K']:+.2f} ± {o['sigma_K']:.2f} K |")
            continue
        k += 1
        tag = f'CF{n0 + k:02d}'
        fc[tag] = dict(x=o['x'], effect_K=o['effect_K'], sigma_K=o['sigma_K'], Q=o['Q'], m=o['m'], p=o['p'], inside=all(o['inside']),
                       card=Path(path).name, job=dict(j, pm=card.p_main, pc=card.p_cons, T=card.T_main), status='в очереди',
                       prev=dict(rule=d['rule'], status=d['status'], cat=d.get('cat'), best=fmt(b) if b else None, N=b['N'] if b else None),
                       n_train=M.n_train, time=time.strftime('%d.%m.%Y %H:%M:%S'))
        rows.append(f"| {tag} | t/d {j['td']}, L {j['L']:.0f}, перепад {j['dp']} кПа, подогреватель {j['z']} | {j['why']} | "
                    f"{o['effect_K']:+.2f} ± {o['sigma_K']:.2f} K, m {o['m']:.3f}, p {o['p']:.3f}{'' if all(o['inside']) else ' (экстраполяция)'} |")
    CONF_FC.write_text(json.dumps(fc, ensure_ascii=False, indent=1), encoding='utf-8')
    L = ['', f'## Продолжение задачи «{card.title}»: расчёты поставлены в очередь ({time.strftime("%d.%m.%Y %H:%M")})', '',
         f"Статус до расчёта: **{d['rule']} → {d['status']}** ({d.get('cat')}): {d['why']}", '',
         'Прогноз записан ДО расчёта (обучение ' + f'{M.n_train} точек; σ с множителем D-25). Считает dataset\\confirm_runner.py в очереди '
         '(после текущей серии, одно окно Fluent).', '', '| тег | точка | зачем | прогноз ± σ |', '|---|---|---|---|'] + rows
    with open(JOURNAL, 'a', encoding='utf-8') as f:
        f.write('\n'.join(L) + '\n')
    print('\n'.join(L))
    return d

if __name__ == '__main__':
    if '--confirm' in sys.argv:
        import csv
        confirm_and_run(sys.argv[1])
    else:
        main(sys.argv[1], '--no-journal' not in sys.argv)
