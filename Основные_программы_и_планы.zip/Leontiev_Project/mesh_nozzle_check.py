import json,traceback,math
FIRST_LAYER_HEIGHT_M=float(json.load(open(r'F:\Leontiev_Project\mesh_run_config.json'))['first_layer_height_um'])*1e-6
r={'faces':[]}
r['first_layer_height_um']=FIRST_LAYER_HEIGHT_M*1e6
try:
    model=ExtAPI.DataModel.Project.Model
    md=ExtAPI.DataModel.MeshDataByName('Global')
    ns={str(n.Name):n for n in model.NamedSelections.Children if list(n.Location.Ids)}
    ids=list(ns['MESH_nozzle'].Location.Ids)
    settings=json.load(open(r'F:\Leontiev_Project\nozzle_setup.json'))
    if not settings.get('configured'):raise ValueError('Nozzle controls not configured')
    axial=[c['count'] for c in settings['controls'] if c['name']=='Nozzle_axial'][0]
    radial=[c['count'] for c in settings['controls'] if c['name']=='Nozzle_core_radial'][0]
    for fid in ids:
        reg=md.MeshRegionById(fid)
        elem_ids=list(reg.ElementIds)
        node_ids=sorted(set(nid for eid in elem_ids for nid in md.ElementById(eid).NodeIds))
        points=[md.NodeById(i) for i in node_ids]
        xs=sorted(n.X for n in points)
        stations=[]
        for x in xs:
            if not stations or abs(x-stations[-1])>1e-8:stations.append(x)
        nodes_per_station=[sum(abs(n.X-x)<1e-8 for n in points) for x in stations]
        kinds={}
        for eid in elem_ids:
            e=md.ElementById(eid)
            kind=str(e.Type)
            kinds[kind]=kinds.get(kind,0)+1
        rows=1 if len(elem_ids)==axial else radial
        item={'id':fid,'nodes':len(node_ids),'elements':len(elem_ids),'types':kinds,'stations':len(stations),'nodes_per_station':nodes_per_station,'rows':rows}
        item['structured']=len(stations)==axial+1 and all(n==rows+1 for n in nodes_per_station) and len(elem_ids)==axial*rows and len(node_ids)==(axial+1)*(rows+1) and all('Quad' in k for k in kinds)
        r['faces'].append(item)
    r['structured']=len(r['faces'])==21 and all(f['structured'] for f in r['faces']) and sum(f['rows']==1 for f in r['faces'])==20
    # At a nozzle boundary, geometric distances verify the 20 near-wall layers.
    allnodes=set(nid for fid in ids for eid in md.MeshRegionById(fid).ElementIds for nid in md.ElementById(eid).NodeIds)
    points=[md.NodeById(i) for i in allnodes]
    xmin=min(n.X for n in points);xmax=max(n.X for n in points)
    y0=max(n.Y for n in points if abs(n.X-xmin)<1e-8)
    y1=max(n.Y for n in points if abs(n.X-xmax)<1e-8)
    slope=(y1-y0)/(xmax-xmin)
    distances=sorted(set(round((y0-n.Y)/math.sqrt(1+slope*slope),12) for n in points if abs(n.X-xmin)<1e-8))
    actual=[d for d in distances if 1e-9<d<FIRST_LAYER_HEIGHT_M*(1.2**20-1)/0.2*1.04]
    expected=[FIRST_LAYER_HEIGHT_M*(1.2**(k+1)-1)/0.2 for k in range(20)]
    r['nozzle_distance_levels_m']=actual
    r['layer_max_abs_error_m']=max(abs(a-b) for a,b in zip(actual,expected)) if len(actual)==20 else None
    r['layers_verified']=len(actual)==20 and r['layer_max_abs_error_m']<1e-8
except:r['error']=traceback.format_exc()
with open(globals().get('MESH_NOZZLE_CHECK_PATH',r'F:\Leontiev_Project\nozzle_check.json'),'w') as f:json.dump(r,f,indent=2)
