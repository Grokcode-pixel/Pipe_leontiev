import json,traceback
FIRST_LAYER_HEIGHT_M=float(json.load(open(r'F:\Leontiev_Project\mesh_run_config.json'))['first_layer_height_um'])*1e-6
from Ansys.Mechanical.DataModel.Enums import GeometryDefineByType, PhaseType
from Ansys.ACT.Interfaces.Common import SelectionTypeEnum
r={'run_token':globals().get('MESH_RUN_TOKEN'), 'actions':[], 'scoping_enum':dir(GeometryDefineByType)}
r['first_layer_height_um']=FIRST_LAYER_HEIGHT_M*1e6
try:
    model=ExtAPI.DataModel.Project.Model
    mode=globals().get('MESH_MODE','series')
    if mode not in ('series','control'):raise ValueError('Unknown mesh mode '+str(mode))
    size_mm={'series':0.75,'control':0.25}[mode]
    model.Mesh.ElementSize=Quantity(str(size_mm)+' [mm]')
    r['mesh_mode']=mode
    r['mesh_size_mm']=size_mm
    r['body_phases']=[]
    for body in model.Geometry.GetChildren(DataModelObjectCategory.Body,True):
        name=str(body.Name).split('\\')[-1]
        if name not in ('air_svz','air_dzv','wall_abonite'):continue
        before=str(body.FluidSolidPhase)
        body.FluidSolidPhase=PhaseType.Solid if name=='wall_abonite' else PhaseType.LiquidGas
        r['body_phases'].append({'name':name,'before':before,'after':str(body.FluidSolidPhase)})
    geometry={}
    valid_ids=set()
    for a in ExtAPI.DataModel.GeoData.Assemblies:
        for p in a.Parts:
            for b in p.Bodies:
                geometry[str(b.Name).split('\\')[-1]]=b
                valid_ids.add(b.Id)
                valid_ids.update(f.Id for f in b.Faces)
                valid_ids.update(e.Id for e in b.Edges)
    ns={}
    for n in model.NamedSelections.Children:
        if 'NamedSelection' not in str(n.GetType()):continue
        ids=list(n.Location.Ids)
        if ids and set(ids).issubset(valid_ids):
            ns[str(n.Name)]=n
        else:
            n.SendToSolver=False
            if not str(n.Name).startswith('LEGACY_EMPTY_'):n.Name='LEGACY_EMPTY_'+str(n.Name)
            r['actions'].append('Disabled empty legacy selection '+str(n.Name))
    for name in ('air_svz','air_dzv','wall_abonite','wall_outer-air_svz','wall-air_svz-wall_abonite','interior-air_dzv-wall_abonite','wall_outer-air_dzv'):
        if name not in ns:raise ValueError('Missing named selection '+name)
    if 'MESH_core_structured' not in ns or len(ns['MESH_core_structured'].Location.Ids)!=147:
        raise ValueError('CAD layer partition missing: expected 147 structured faces. Verify the saved native TubeGeometry script before meshing.')
    def boundary(name,gas_name,source_names):
        gas_edges=set(e.Id for e in geometry[gas_name].Edges)
        ids=sorted(gas_edges.intersection(set(i for src in source_names for i in ns[src].Location.Ids)))
        if not ids:raise ValueError('Empty gas wall '+name)
        candidates=[n for n in model.NamedSelections.Children if str(n.Name)==name]
        n=candidates[0] if candidates else model.AddNamedSelection()
        n.Name=name
        selection=ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities)
        selection.Ids=ids
        n.Location=selection
        n.SendToSolver=False
        r['actions'].append('Created mesh helper '+name+' '+str(ids))
        return n
    svzwalls=boundary('MESH_walls_svz','air_svz',('wall_outer-air_svz','wall-air_svz-wall_abonite'))
    dzvwalls=boundary('MESH_walls_dzv','air_dzv',('wall_outer-air_dzv','interior-air_dzv-wall_abonite'))
    inflations=[o for o in model.Mesh.Children if str(o.GetType()).endswith('.Inflation')]
    for o,gas,walls in zip(inflations,('air_svz','air_dzv'),(svzwalls,dzvwalls)):
        r['actions'].append('Before '+str(o.Name)+' layers='+str(o.NumberOfLayers)+' max='+str(o.MaximumLayers)+' first='+str(o.FirstLayerHeight)+' growth='+str(o.GrowthRate))
        # Scoping is set by assigning the native named-selection object
        o.Location=ns[gas].Location
        o.BoundaryLocation=walls.Location
        o.MaximumLayers=20
        o.NumberOfLayers=20
        o.GrowthRate=1.2
        o.FirstLayerHeight=Quantity(str(FIRST_LAYER_HEIGHT_M*1000.0)+' [mm]')
        o.Suppressed=False
        o.Name='Inflation_'+gas
        r['actions'].append('Scoped '+str(o.Name)+' to '+gas+' and '+str(walls.Name))
    if len(inflations)!=2:raise ValueError('Expected two inflation controls')
    for o in model.Mesh.Children:
        if str(o.GetType()).endswith('.Sizing') and not str(o.Name).startswith('Nozzle_'):
            # Scoping is set by assigning the native named-selection object
            o.NamedSelection=ns['air_svz']
            o.ElementSize=Quantity(str(size_mm)+' [mm]')
            r['actions'].append('Scoped sizing '+str(o.Name)+' to air_svz; size '+str(o.ElementSize))
    if 'MESH_nozzle' in ns:
        execfile(r'F:\Leontiev_Project\mesh_nozzle_setup.py',{'ExtAPI':ExtAPI,'MESH_MODE':mode})
        r['nozzle_setup']=json.load(open(r'F:\Leontiev_Project\nozzle_setup.json'))
        if not r['nozzle_setup'].get('configured'):raise ValueError(str(r['nozzle_setup']))
    contacts=list(model.Connections.GetChildren(DataModelObjectCategory.ContactRegion,True))
    if len(contacts)<2:raise ValueError('Expected at least two thermal contact pair objects')
    for duplicate in contacts[2:]:
        duplicate.Suppressed=True
        r['actions'].append('Suppressed extra automatic contact '+str(duplicate.Name))
    for contact,group,source_body,target_body in zip(contacts[:2],('wall-air_svz-wall_abonite','interior-air_dzv-wall_abonite'),('air_svz','wall_abonite'),('wall_abonite','air_dzv')):
        ids=set(ns[group].Location.Ids)
        source=sorted(ids.intersection(set(e.Id for e in geometry[source_body].Edges)))
        target=sorted(ids.intersection(set(e.Id for e in geometry[target_body].Edges)))
        if not source or not target:raise ValueError('Incomplete physical contact '+group)
        info=ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities)
        info.Ids=source;contact.SourceLocation=info
        info=ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities)
        info.Ids=target;contact.TargetLocation=info
        contact.Suppressed=False
        r['actions'].append('Scoped physical thermal contact '+group+' '+str(source)+' / '+str(target))
    r['named_selections']=[(str(n.Name),list(n.Location.Ids),str(n.SendToSolver)) for n in model.NamedSelections.Children]
except:r['error']=traceback.format_exc()
with open(r'F:\Leontiev_Project\mesh_repair.json','w') as f:json.dump(r,f,indent=2)






