import json,traceback
FIRST_LAYER_HEIGHT_M=float(json.load(open(r'F:\Leontiev_Project\mesh_run_config.json'))['first_layer_height_um'])*1e-6
from Ansys.Mechanical.DataModel.Enums import MeshMetricType
r={'run_token':globals().get('MESH_RUN_TOKEN'),'metric_names':[n for n in dir(MeshMetricType) if not n.startswith('_')],'metrics':{}}
r['first_layer_height_um']=FIRST_LAYER_HEIGHT_M*1e6
mesh=ExtAPI.DataModel.Project.Model.Mesh
r['internal_members']=dir(mesh.InternalObject)
r['internal_type']=str(mesh.InternalObject.GetType())
for n in ('Skewness','OrthogonalAngle','AspectRatio','ElementQuality'):
    try:
        mesh.MeshMetric=getattr(MeshMetricType,n)
        r['metrics'][n]={k:str(getattr(mesh,k)) for k in ('Minimum','Maximum','Average','StandardDeviation')}
    except:r['metrics'][n]={'error':traceback.format_exc()}
try:
    md=ExtAPI.DataModel.MeshDataByName('Global')
    r['mesh_data_members']=dir(md)
    r['node_count']=md.NodeCount
    r['element_count']=md.ElementCount
    r['body_regions']=[]
    for a in ExtAPI.DataModel.GeoData.Assemblies:
        for p in a.Parts:
            for b in p.Bodies:
                region=md.MeshRegionById(b.Id)
                r['body_regions'].append({'name':str(b.Name),'nodes':len(region.NodeIds),'elements':len(region.ElementIds)})
except:r['meshdata_error']=traceback.format_exc()
try:
    if str(mesh.State)!='UpToDate' or str(mesh.ObjectState)!='Solved':raise ValueError('Mesh is incomplete or out of date')
    names={str(n.Name):n for n in ExtAPI.DataModel.Project.Model.NamedSelections.Children if list(n.Location.Ids)}
    if 'MESH_core_structured' in names:
        sp=globals().get('MESH_QUALITY_PATH',r'F:\Leontiev_Project\mesh_current_quality.json').replace('_quality.json','_structure.json')
        execfile(r'F:\Leontiev_Project\mesh_structure_check.py',{'ExtAPI':ExtAPI,'MESH_STRUCTURE_PATH':sp})
        with open(sp) as f:r['structure']=json.load(f)
        if not r['structure'].get('passed'):raise ValueError('Structured topology validation failed')
    if 'MESH_nozzle' in names:
        check_path=globals().get('MESH_QUALITY_PATH',r'F:\Leontiev_Project\mesh_current_quality.json').replace('_quality.json','_nozzle_check.json')
        execfile(r'F:\Leontiev_Project\mesh_nozzle_check.py',{'ExtAPI':ExtAPI,'MESH_NOZZLE_CHECK_PATH':check_path})
        r['nozzle']=json.load(open(check_path))
        if not r['nozzle'].get('structured') or not r['nozzle'].get('layers_verified'):raise ValueError('Nozzle validation failed: '+str(r['nozzle']))
    lp=r'F:\Leontiev_Project\mesh_layers.json'
    execfile(r'F:\Leontiev_Project\mesh_layers.py',{'ExtAPI':ExtAPI,'MESH_LAYERS_PATH':lp})
    r['layers']=json.load(open(lp))
    profiles=r['layers'].get('profiles',[])
    if not r['layers'].get('passed'):raise ValueError('Boundary layer check failed; expected 20 layers, first height from mesh_run_config.json, growth 1.2 on each long wall')
    wp=globals().get('MESH_QUALITY_PATH',r'F:\Leontiev_Project\mesh_current_quality.json').replace('_quality.json','_wall_layers.json')
    execfile(r'F:\Leontiev_Project\mesh_wall_layers_check.py',{'ExtAPI':ExtAPI,'MESH_WALL_CHECK_PATH':wp})
    r['wall_layers']=json.load(open(wp))
    if not r['wall_layers'].get('passed'):raise ValueError('Boundary-layer connectivity validation failed on one or more physical gas walls')
    from Ansys.Mechanical.DataModel.Enums import PhaseType
    r['body_phases']=[]
    for body in ExtAPI.DataModel.Project.Model.Geometry.GetChildren(DataModelObjectCategory.Body,True):
        name=str(body.Name).split('\\')[-1]
        if name not in ('air_svz','air_dzv','wall_abonite'):continue
        body.FluidSolidPhase=PhaseType.Solid if name=='wall_abonite' else PhaseType.LiquidGas
        r['body_phases'].append({'name':name,'phase':str(body.FluidSolidPhase)})
    mesh.InternalObject.WriteFluentInputFile(globals().get('MESH_EXPORT_PATH',r'F:\Leontiev_Project\mesh_baseline.msh'))
    r['exported']=True
except:r['export_error']=traceback.format_exc()
try:
    layers_path=globals().get('MESH_LAYERS_PATH',r'F:\Leontiev_Project\mesh_layers.json')
    execfile(r'F:\Leontiev_Project\mesh_layers.py',{'ExtAPI':ExtAPI,'MESH_LAYERS_PATH':layers_path})
    r['layers']=json.load(open(layers_path))
except:r['layers_error']=traceback.format_exc()
with open(globals().get('MESH_QUALITY_PATH',r'F:\Leontiev_Project\mesh_baseline_quality.json'),'w') as f:json.dump(r,f,indent=2)



