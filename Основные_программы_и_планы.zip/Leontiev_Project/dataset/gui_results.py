"""31.10.2026 — интерфейс автора, шаг 3: окно «Результаты и датасет» (задание автора 30.10, ШАГ 3). Tkinter, новых пакетов нет.
Таблица всех расчётов: строки результатов всех runs\\**\\*_results.csv + паспорта (runs\\queue\\passports.json; без результата — «нет
результата»): серия, метка, тип, геометрия, режим, эффект, Q, m, статус расчёта, качество (сошёлся / предел + D-12), датасет
(в обучении — та же выборка, что passport.training_points / model_compare; проверочная — A3a, отложенные набора Б, проверочные
точки интерфейса; иначе —). Фильтры, выгрузка в CSV.
Добавление в датасет — по тем же правилам: один сборщик (model_compare.station_points читает runs\\journal\\gui_forecasts.json,
флаг «в_обучение»), только точки серий интерфейса (IF…), только гладкая (накатка и сопло — не входы модели, D-28), D-12
(сошлась или дисбаланс < 1 % Q); после заморозки (runs\\models\\FREEZE.json) — только «проверочная», не в обучение (D-21).
После каждого добавления — сверка (data_audit.py → runs\\models\\data_audit.md) и строка в Журнал_работ.md."""
import csv, json, subprocess, sys, threading, time
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
sys.path.insert(0, r'F:\Leontiev_Project\dataset')

R = Path(r'F:\Leontiev_Project\runs')
D = Path(r'F:\Leontiev_Project\dataset')
PY = sys.executable.replace('pythonw.exe', 'python.exe')
FC = R / 'journal' / 'gui_forecasts.json'
FREEZE = R / 'models' / 'FREEZE.json'
COLS = ('серия', 'метка', 'тип', 't/d', 'L', 'накатка/сопло', 'магистраль', 'потребитель', 'перепад', 'T газа', 'эффект, K', 'Q, Вт',
        'm', 'статус расчёта', 'качество', 'датасет', 'завершён')
WID = (170, 100, 60, 40, 40, 90, 60, 60, 55, 50, 60, 55, 45, 140, 165, 90, 110)
# 01.11 (просьба автора): «завершён» — когда Fluent записал результат (время файла result.cas.h5; нет его — время папки)


def f(v, fmt='{:.3g}'):
    try:
        return fmt.format(float(v))
    except (TypeError, ValueError):
        return ''


def quality(r):
    if not r:
        return ''
    if str(r.get('status', '')).startswith('сошёлся'):
        return 'сошёлся'
    try:
        q, net = abs(float(r['Q'])), abs(float(r['net_W']))
    except (KeyError, TypeError, ValueError):
        return 'нет баланса'
    return 'предел, D-12 выполнено' if net < 0.01 * q else 'предел, D-12 НЕ выполнено'


def collect(with_training=True):
    """Все расчёты одной таблицей. with_training: отметить точки обучения (медленно — сборщик читает отчёты всех точек)."""
    import passport as PS
    pas = json.loads((R / 'queue' / 'passports.json').read_text(encoding='utf-8'))
    res = {}
    for fcsv in R.rglob('*_results.csv'):
        if 'архив' in fcsv.name:
            continue
        try:
            for r in csv.DictReader(open(fcsv, encoding='utf-8')):
                if r.get('tag'):
                    res[str(fcsv.parent / r['tag'])] = r      # последняя строка тега
        except Exception:
            pass
    fc = json.loads(FC.read_text(encoding='utf-8')) if FC.exists() else {}
    gui_res = {(v.get('result_tag') or t): (t, v) for t, v in fc.items()}
    train = set()
    if with_training:
        import contextlib, io
        with contextlib.redirect_stdout(io.StringIO()):
            train = {str(p) for _, p, _ in PS.training_points()}
    held = set()
    try:
        held = {str(R / 'setB' / t) for p in csv.DictReader(open(R / 'setB' / 'setB_design.csv', encoding='utf-8')) if p.get('set') == 'отложенная'
                for t in (p['id'], p['id'] + 'c', p['id'] + 'cc')}
    except Exception:
        pass
    rows = []
    for key in sorted(set(res) | {k for k in pas if not k.startswith('queue:')}):
        r, pp = res.get(key), pas.get(key) or {}
        d = Path(key)
        try:
            ser = pp.get('series') or PS.series_of(d)[0]
        except Exception:
            ser = d.parent.name
        g, rg = pp.get('geometry') or {}, pp.get('regime') or {}
        kind = pp.get('kind') or ''
        kn = g.get('knurl')
        extra = (f"h {kn['h_mm']} / шаг {kn['pitch_mm']}" if kn else (f"A/A* {g['area_ratio']}" if kind == 'сопло' and g.get('area_ratio') else ''))
        gt = gui_res.get(d.name) if d.parent == R / 'station' else None
        if gt:
            ser, kind = f"интерфейс {gt[1].get('job', '')}", gt[1].get('kind', kind)
        if key in train:
            ds = 'в обучении'
        elif 'A3a' in ser or key in held or (gt and gt[1].get('проверочная')):
            ds = 'проверочная'
        else:
            ds = '—'
        pm = rg.get('p_main') or (r or {}).get('p0_svz')
        dp = rg.get('dp_dzv_kPa')
        if dp is None and r and r.get('p0_dzv'):
            dp = 1000 * (float(r['p0_dzv']) - float(r['p_out_dzv']))
        m = (float(r['G_dzv']) / float(r['G_svz'])) if r and r.get('G_dzv') and r.get('G_svz') else None
        try:
            mt = d.stat().st_mtime
        except OSError:
            mt = 0.0
        try:
            done_t = (d / 'result.cas.h5').stat().st_mtime
        except OSError:
            done_t = mt if r else 0.0
        rows.append(dict(key=key, gui_tag=gt[0] if gt else None, mtime=mt, done_t=done_t, vals=(
            ser, d.name, kind, f(g.get('t_d')), f(g.get('L_mm'), '{:.0f}'), extra, f(pm), f(rg.get('p_cons') or (r or {}).get('p_out_svz')),
            f(dp, '{:.1f}'), f(rg.get('T0_dzv') if rg.get('T0_dzv') is not None else (r or {}).get('T0_dzv_C'), '{:.1f}'),
            f((r or {}).get('dT_svz_vs_throttle'), '{:+.2f}'), f((r or {}).get('Q'), '{:.0f}'), f(m, '{:.2f}'),
            (r or {}).get('status') or 'нет результата', quality(r), ds,
            time.strftime('%d.%m.%Y %H:%M', time.localtime(done_t)) if done_t else '')))
    rows.sort(key=lambda x: -x['mtime'])   # сначала новые расчёты
    return rows


class ResultsFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding=8)
        self.rows, self.view = [], []
        top = ttk.Frame(self); top.pack(fill='x')
        self.flt = {}
        for name, w in (('серия', 30), ('статус расчёта', 18), ('датасет', 14), ('тип', 10)):
            ttk.Label(top, text=name + ':').pack(side='left')
            v = tk.StringVar(value='все'); cb = ttk.Combobox(top, textvariable=v, width=w, state='readonly'); cb.pack(side='left', padx=3)
            cb.bind('<<ComboboxSelected>>', lambda e: self.apply()); self.flt[name] = (v, cb)
        ttk.Label(top, text='метка содержит:').pack(side='left')
        self.q = tk.StringVar(); e = ttk.Entry(top, textvariable=self.q, width=12); e.pack(side='left', padx=3); e.bind('<Return>', lambda ev: self.apply())
        bar = ttk.Frame(self); bar.pack(fill='x', pady=4)
        for txt, cmd in (('Обновить', self.load), ('Выгрузить в CSV', self.export), ('Добавить в датасет', self.add),
                         ('Сверка данных', self.audit), ('Пересобрать паспорта', self.rebuild)):
            ttk.Button(bar, text=txt, command=cmd).pack(side='left', padx=3)
        self.state = ttk.Label(bar, text=''); self.state.pack(side='left', padx=10)
        tw = ttk.Frame(self); tw.pack(fill='both', expand=True)
        self.tree = ttk.Treeview(tw, columns=COLS, show='headings', height=24, selectmode='extended')
        for c, w in zip(COLS, WID):
            self.tree.heading(c, text=c, command=lambda c=c: self.sort(c)); self.tree.column(c, width=w, anchor='w')
        sb = ttk.Scrollbar(tw, orient='vertical', command=self.tree.yview)
        sx = ttk.Scrollbar(tw, orient='horizontal', command=self.tree.xview)
        self.tree.configure(yscrollcommand=sb.set, xscrollcommand=sx.set)
        self.tree.grid(row=0, column=0, sticky='nsew'); sb.grid(row=0, column=1, sticky='ns'); sx.grid(row=1, column=0, sticky='ew')
        tw.rowconfigure(0, weight=1); tw.columnconfigure(0, weight=1)
        self.out = tk.Text(self, height=6, wrap='word'); self.out.pack(fill='x', pady=4)
        self.loaded = False
        self._todo = []; self.after(200, self._pump)

    def _pump(self):   # Tk — только из главного потока: фоновые потоки кладут сюда, окно выполняет
        while self._todo:
            try:
                self._todo.pop(0)()
            except Exception as e:
                self.state.config(text=f'ошибка окна: {e!r}')
        self.after(200, self._pump)

    def ensure(self):
        if not self.loaded:
            self.loaded = True; self.load()

    def say(self, s):
        self.out.insert('end', time.strftime('%H:%M:%S ') + s + '\n'); self.out.see('end')

    def load(self):
        fr = FREEZE.exists()
        self.state.config(text='читаю расчёты и выборку обучения… (≈ 0,5–2 мин)' + ('; данные ЗАМОРОЖЕНЫ' if fr else ''))

        def work():
            try:
                rows = collect(True)
                self._todo.append(lambda: self.fill(rows))
            except Exception as e:
                import traceback; traceback.print_exc()
                self._todo.append(lambda: self.state.config(text=f'ошибка: {e!r}'))
        threading.Thread(target=work, daemon=True).start()

    def fill(self, rows):
        self.rows = rows
        for name, idx in (('серия', 0), ('статус расчёта', 13), ('датасет', 15), ('тип', 2)):
            v, cb = self.flt[name]
            cb.configure(values=['все'] + sorted({r['vals'][idx] for r in rows if r['vals'][idx]}))
        n_tr = sum(1 for r in rows if r['vals'][15] == 'в обучении')
        fr = json.loads(FREEZE.read_text(encoding='utf-8')) if FREEZE.exists() else None
        self.state.config(text=f'расчётов {len(rows)}; в обучении {n_tr}' + (f"; данные заморожены {fr.get('time', '')} — новое только «проверочная»" if fr else '; данные не заморожены'))
        self.apply()

    def apply(self):
        sel = {name: v.get() for name, (v, cb) in self.flt.items()}
        idx = {'серия': 0, 'статус расчёта': 13, 'датасет': 15, 'тип': 2}
        q = self.q.get().strip().lower()
        self.view = [r for r in self.rows if all(sel[n] in ('все', '') or r['vals'][i] == sel[n] for n, i in idx.items()) and (not q or q in r['vals'][1].lower())]
        for i in self.tree.get_children():
            self.tree.delete(i)
        for k, r in enumerate(self.view):
            self.tree.insert('', 'end', iid=str(k), values=r['vals'])

    def sort(self, col):
        i = COLS.index(col)
        def key(r):
            if col == 'завершён':   # по времени, новые сверху
                return (0, -r.get('done_t', 0.0))
            v = r['vals'][i]
            try:
                return (0, float(v.replace('+', '')))
            except ValueError:
                return (1, v)
        self.view.sort(key=key)
        for j in self.tree.get_children():
            self.tree.delete(j)
        for k, r in enumerate(self.view):
            self.tree.insert('', 'end', iid=str(k), values=r['vals'])

    def export(self):
        if not self.view:
            return
        fn = filedialog.asksaveasfilename(defaultextension='.csv', filetypes=[('CSV', '*.csv')], initialdir=str(R),
                                          initialfile=f'результаты_{time.strftime("%Y%m%d_%H%M")}.csv')
        if not fn:
            return
        with open(fn, 'w', newline='', encoding='utf-8-sig') as fo:
            w = csv.writer(fo, delimiter=';'); w.writerow(COLS + ('папка',))
            for r in self.view:
                w.writerow(list(r['vals']) + [r['key']])
        self.say(f'выгружено {len(self.view)} строк: {fn}')

    def add(self):
        sel = [self.view[int(i)] for i in self.tree.selection()]
        if not sel:
            messagebox.showinfo('Добавить в датасет', 'Выберите строки (точки серий интерфейса IF…).'); return
        frozen = FREEZE.exists()
        fc = json.loads(FC.read_text(encoding='utf-8')) if FC.exists() else {}
        ok, why = [], []
        for r in sel:
            t, v = r['gui_tag'], fc.get(r['gui_tag'] or '')
            if not v:
                why.append(f"{r['vals'][1]}: не точка серии интерфейса — в датасет по правилам своей серии (сборщик), отсюда не добавляется"); continue
            if v.get('kind') != 'гладкая':
                why.append(f"{t}: {v.get('kind')} — не вход модели (D-28), отдельное исследование"); continue
            qv = r['vals'][14]
            if qv not in ('сошёлся', 'предел, D-12 выполнено'):
                why.append(f"{t}: качество «{qv or 'нет результата'}» — не годна (D-12)"); continue
            if r['vals'][15] == 'в обучении' or v.get('в_обучение'):
                why.append(f'{t}: уже в обучении'); continue
            ok.append(t)
        if not ok:
            messagebox.showinfo('Добавить в датасет', '\n'.join(why) or 'нечего добавлять'); return
        what = 'ПРОВЕРОЧНЫЕ (данные заморожены — в обучение не идут, D-21)' if frozen else 'в ОБУЧЕНИЕ'
        if not messagebox.askyesno('Добавить в датасет', f"{len(ok)} точек → {what}:\n" + ', '.join(ok) + ('\n\nНе добавлены:\n' + '\n'.join(why) if why else '')):
            return
        for t in ok:
            fc[t].update(**({'проверочная': True} if frozen else {'в_обучение': True}), added=time.strftime('%d.%m.%Y %H:%M:%S'))
        FC.write_text(json.dumps(fc, ensure_ascii=False, indent=1), encoding='utf-8')
        with open(r'F:\Leontiev_Project\Журнал_работ.md', 'a', encoding='utf-8') as fj:
            fj.write(f"- {time.strftime('%d.%m.%Y %H:%M')} — интерфейс, окно 3: {', '.join(ok)} → {'проверочные' if frozen else 'в обучение'} "
                     f"(runs\\journal\\gui_forecasts.json; сверка data_audit.py)\n")
        self.say(f"{', '.join(ok)} → {'проверочные' if frozen else 'в обучение'}; запускаю сверку…")
        self.audit(); self.load()

    def run_bg(self, script, title):
        self.say(f'{title}: запущено…')

        def work():
            try:
                p = subprocess.run([PY, '-u', script], cwd=str(D), capture_output=True, text=True, encoding='utf-8', errors='replace',
                                   creationflags=subprocess.CREATE_NO_WINDOW, env=dict(__import__('os').environ, PYTHONIOENCODING='utf-8'))
                tail = '\n'.join((p.stdout or '').strip().splitlines()[-12:]) or (p.stderr or '')[-600:]
                self._todo.append(lambda: self.say(f'{title}: код {p.returncode}\n{tail}'))
            except Exception as e:
                self._todo.append(lambda: self.say(f'{title}: ошибка {e!r}'))
        threading.Thread(target=work, daemon=True).start()

    def audit(self):
        self.run_bg('data_audit.py', 'сверка данных (runs\\models\\data_audit.md)')

    def rebuild(self):
        self.run_bg('passport.py', 'паспорта (runs\\queue\\passports.json, паспорта_сверка.md)')
