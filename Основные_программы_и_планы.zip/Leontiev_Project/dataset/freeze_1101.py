"""01.11.2026 — D-32, п. 6 и D-33 (решения автора 31.10 вечер и 01.11): после добора В — новая (последняя) заморозка.
Данные: замороженные 152 точки (FREEZE.json 31.10, хеш сверяется) + сошедшиеся точки добора В (runs\\dobor_v; сходимость — как
в серии: критерии или D-12a, results.json → ok; значения — среднее окна D-12a; метка «скачок» — x_shock_m). Проверочные точки
(VD1–VD5, runs\\verify) и A3a в обучение НЕ входят (D-33, п. 2б).
Считает то же, что freeze_1031: ошибка эффекта по геометриям (ГП, GroupKFold 5), σ-множитель (D-25), классификатор по D-11
(вложенная проверка по геометриям; по D-33 — CatBoost), сверка A3a; плюс кривая обучения 106 → 152 → n.
  python freeze_1101.py          — черновик (runs\\models\\заморозка_20261101_черновик.md), FREEZE.json не меняется;
                                   в черновике 01.11 13:46 были и VD (178 точек) — по D-33 их не берём
  python freeze_1101.py final    — окончательная заморозка: прежний FREEZE.json — в FREEZE_архив_20261031.json (копия),
                                   новый FREEZE.json с extra_points (model_compare.frozen_extra берёт точки добора В оттуда),
                                   runs\\models\\заморозка_20261101.md, строка в Журнал_работ.md. Повторно не перезаписывает."""
import contextlib, hashlib, io, json, math, shutil, sys, time
from pathlib import Path
import numpy as np
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import model_compare as MC
import freeze_1031 as F0

R = MC.R
FZ = R / 'models' / 'FREEZE.json'
FZ_OLD = R / 'models' / 'FREEZE_архив_20261031.json'
DOBOR = R / 'plans' / 'добор_В_1031.json'
VERIFY = R / 'plans' / 'проверка_выданных_1031.json'


def series_points(pf, src):
    """Сошедшиеся точки серии: dict(tag, src, x[7], effect, Q, G_svz, G_dzv, shock, geo, folder)."""
    plan = json.loads(pf.read_text(encoding='utf-8'))
    res = json.loads((Path(plan['base']) / 'results.json').read_text(encoding='utf-8'))
    out = []
    for p in plan['points']:
        r = res.get(p['tag'], {})
        if r.get('ok') and r.get('effect') is not None:
            out.append(dict(tag=p['tag'], src=src, x=[p['td'], p['L'] / 6.6, math.log(p['dp']), p['pc'], p['T'], p['heat'], p['pm']],
                            effect=float(r['effect']), Q=float(r['Q']), G_svz=float(r['G_svz']), G_dzv=float(r['G_dzv']),
                            shock=bool(r.get('shock')), geo=f"{p['td']}/{float(p['L'])}", folder=r['folder'],
                            by='критерии' if r.get('converged') else 'D-12a'))
    return out


def compute(X, y, w, g, Xc, wc, gc):
    mu, sd = F0.gp_cv(X, y, g); e = mu - y
    z = np.abs(e) / np.maximum(sd, 1e-9)
    q68, q95 = float(np.quantile(z, 0.68)), float(np.quantile(z, 0.95)); k = round(max(q68, q95 / 1.96), 2)
    cov = lambda kk: [round(float(np.mean(z <= kk)), 3), round(float(np.mean(z <= 2 * kk)), 3)]
    with contextlib.redirect_stdout(io.StringIO()):
        import classifier_final as CF
    cl = {}
    for name, (fr, fc, pr, pc) in MC.models().items():
        p = CF.oof(Xc, wc, gc, fc, pc); t = CF.threshold(p, wc)
        dn, an = CF.nested(Xc, wc, gc, fc, pc)
        cl[name] = dict(p_hi=round(float(t), 3), acc=int(((p >= t) & (wc == 1)).sum()), nested_danger=int(dn), nested_acc=int(an))
    best = min(cl, key=lambda kk: (cl[kk]['nested_danger'], -cl[kk]['acc']))
    return dict(e=e, rmse=float(np.sqrt(np.mean(e ** 2))), mae=float(np.mean(np.abs(e))), q68=q68, q95=q95, k=k, cov_raw=cov(1.0), cov_k=cov(k),
                cl=cl, best=best, n_sh=int((wc == 0).sum()), n_wk=int(wc.sum()), n_c=len(wc), aa=F0.a3a(X, y))


def report(title, note, fz0, n0, newp, c, X, y, g, src, h):
    k = c['k']
    L = [f"# {title}", '', note, '',
         f"Точек: **{len(y)}** = {n0} (FREEZE 31.10, хеш совпал) + {len(newp)} новых ({', '.join(f'{s} {src.count(s)}' for s in sorted(set(src)))}); "
         f"геометрий {len(set(g))} (было {fz0['n_geometries']}); хеш {h[:16]}…", '',
         'Новые точки (сходимость): ' + ', '.join(f"{p['tag']}{' (скачок)' if p['shock'] else ''} — {p['by']}" for p in newp) + '.', '',
         '## Ошибка эффекта — проверка по геометриям (ГП, отложена целая геометрия, 5 частей)', '',
         f"RMSE **{c['rmse']:.3f} K**, MAE {c['mae']:.3f} K. Кривая обучения: 106 точек — 0,221 K (27.10) → 152 — "
         f"{fz0['effect_geometry_cv']['rmse_K']:.3f} K (31.10) → {len(y)} — {c['rmse']:.3f} K. "
         f"На новых точках (в той же проверке) RMSE {float(np.sqrt(np.mean(c['e'][n0:] ** 2))):.3f} K.", '',
         '## Калибровка σ (D-25)', '',
         f"квантиль 68 % |z| — {c['q68']:.2f}, 95 % — {c['q95']:.2f}; без множителя ±1σ / ±2σ — {100 * c['cov_raw'][0]:.0f} / {100 * c['cov_raw'][1]:.0f} %; "
         f"множитель **k = {k:.2f}** (было {fz0['sigma_mult']}); покрытие ±kσ / ±2kσ — {100 * c['cov_k'][0]:.0f} / {100 * c['cov_k'][1]:.0f} % (цель 68 / 95 %).", '',
         f"## Классификатор «рабочий / скачок» по D-11 ({c['n_c']} точек, скачков {c['n_sh']}; вложенная проверка по геометриям)", '',
         '| модель | p_hi | опасных «скачок → рабочий», вложенная CV | рабочих признано (CV) |', '|---|---|---|---|']
    L += [f"| {nm} | {o['p_hi']:.3f} | {o['nested_danger']} из {c['n_sh']} | {o['acc']} из {c['n_wk']} |" for nm, o in c['cl'].items()]
    L += ['', f"Выбор по D-11: **{c['best']}**, p_hi **{c['cl'][c['best']]['p_hi']:.3f}** (было {fz0['classifier']}, {fz0['p_hi']}).", '',
          '## Независимая сверка — A3a (3 новые трубы, в обучение не входят)', '']
    if c['aa']:
        aa = c['aa']; ea = np.array([r['mu'] - r['fact'] for r in aa]); za = np.array([abs(r['fact'] - r['mu']) / r['sd'] for r in aa])
        L += [f"RMSE {np.sqrt(np.mean(ea ** 2)):.3f} K на {len(aa)} точках; в ±kσ — {int(np.sum(za <= k))} из {len(aa)} (31.10 — 2 из 7)."]
    return L


if __name__ == '__main__':
    final = len(sys.argv) > 1 and sys.argv[1] == 'final'
    t0 = time.time()
    fz0 = json.loads((FZ_OLD if final and FZ_OLD.exists() else FZ).read_text(encoding='utf-8'))
    if final and json.loads(FZ.read_text(encoding='utf-8')).get('extra_points'):
        sys.exit('FREEZE.json уже содержит добор В — окончательная заморозка сделана; повторно не перезаписываю')
    X0, y0, w0, g0, src0 = MC.load()
    h0 = hashlib.sha256(np.round(np.column_stack([X0, y0]), 6).tobytes()).hexdigest().upper()
    assert h0 == fz0['data_sha256'], 'данные 152 не совпадают с FREEZE.json 31.10 — стоп'
    n0 = len(y0)
    if not final:   # черновик: как 01.11 13:46 (добор В + проверка выданных), FREEZE.json не трогаем
        newp = series_points(DOBOR, 'добор В') + series_points(VERIFY, 'проверка выданных')
        X = np.vstack([X0, [p['x'] for p in newp]]); y = np.concatenate([y0, [p['effect'] for p in newp]])
        w = np.concatenate([w0, [0 if p['shock'] else 1 for p in newp]]); g = np.concatenate([g0, [p['geo'] for p in newp]])
        src = list(src0) + [p['src'] for p in newp]
        with contextlib.redirect_stdout(io.StringIO()):
            import classifier_final as CF
        Xc = np.vstack([CF.X, X[n0:]]); wc = np.concatenate([CF.w, w[n0:]]); gc = np.concatenate([CF.g, g[n0:]])
    else:
        if not FZ_OLD.exists():
            shutil.copy2(FZ, FZ_OLD)
        newp = series_points(DOBOR, 'добор В')
        FZ.write_text(json.dumps(dict(fz0, extra_points=newp, decision='D-32 / D-33: окончательная заморозка — В ПРОЦЕССЕ'),
                                 ensure_ascii=False, indent=1), encoding='utf-8')
        X, y, w, g, src = MC.load()   # теперь с добором В (frozen_extra)
        assert len(y) == n0 + len(newp)
        with contextlib.redirect_stdout(io.StringIO()):
            import classifier_final as CF   # CF.X = heldout_check (MC.load) + B00/B03/B21 + автопополнение «а»
        Xc, wc, gc = CF.X, CF.w, CF.g
    h = hashlib.sha256(np.round(np.column_stack([X, y]), 6).tobytes()).hexdigest().upper()
    c = compute(X, y, w, g, Xc, wc, gc)
    tm = time.strftime('%d.%m.%Y %H:%M:%S')
    if not final:
        L = report(f"Заморозка после добора В — ЧЕРНОВИК ({tm}, D-32, п. 6)", 'Черновик: FREEZE.json и программа НЕ изменены.', fz0, n0, newp, c, X, y, g, src, h)
        out = R / 'models' / 'заморозка_20261101_черновик.md'
    else:
        import passport as PS
        q = c['cl'][c['best']]
        fz = dict(time=tm, decision='D-32 / D-33 (решения автора 31.10 вечер и 01.11): окончательная (последняя) заморозка после добора В',
                  previous='FREEZE_архив_20261031.json', n_points=len(y), sources={s: src.count(s) for s in sorted(set(src))},
                  n_geometries=int(len(set(g))), folders=[str(p) for _, p, _ in PS.training_points()], station_tags=fz0['station_tags'],
                  base_sha256=h0, data_sha256=h, effect_geometry_cv=dict(rmse_K=round(c['rmse'], 3), mae_K=round(c['mae'], 3), folds='GroupKFold 5 по геометриям'),
                  learning_curve=[[106, 0.221], [n0, fz0['effect_geometry_cv']['rmse_K']], [len(y), round(c['rmse'], 3)]],
                  classifier=c['best'], p_hi=q['p_hi'], classifier_nested=dict(danger=q['nested_danger'], accepted=q['nested_acc']),
                  classifier_all=c['cl'], sigma_mult=c['k'], sigma_cal=dict(q68=round(c['q68'], 3), q95=round(c['q95'], 3), cov_raw=c['cov_raw'], cov_k=c['cov_k']),
                  a3a=c['aa'], extra_points=newp)
        FZ.write_text(json.dumps(fz, ensure_ascii=False, indent=1, default=float), encoding='utf-8')
        L = report(f"Окончательная заморозка после добора В ({tm}, D-32 п. 6, D-33)",
                   'Последняя заморозка (D-32). Прежний снимок — runs\\models\\FREEZE_архив_20261031.json. Проверочные точки VD1–VD5 и A3a — не в обучении (D-33).',
                   fz0, n0, newp, c, X, y, g, src, h)
        if c['best'] != 'CatBoost':
            L += ['', f"**ВНИМАНИЕ:** по D-11 на окончательных данных выбран {c['best']}, а не CatBoost (D-33, п. 1) — нужно решение автора."]
        out = R / 'models' / 'заморозка_20261101.md'
    L += ['', f'Время {time.time() - t0:.0f} с. Скрипт dataset\\freeze_1101.py{" final" if final else ""}.']
    out.write_text('\n'.join(L) + '\n', encoding='utf-8')
    print('\n'.join(L))
    if final:
        with open(r'F:\Leontiev_Project\Журнал_работ.md', 'a', encoding='utf-8') as fj:
            fj.write(f"- {time.strftime('%d.%m.%Y %H:%M')} — ОКОНЧАТЕЛЬНАЯ ЗАМОРОЗКА (D-32 п. 6, D-33): {len(y)} точек ({n0} + добор В {len(newp)}), "
                     f"{len(set(g))} геометрий; ошибка эффекта по геометриям RMSE {c['rmse']:.3f} K (кривая 0,221 → {fz0['effect_geometry_cv']['rmse_K']:.3f} → {c['rmse']:.3f}); "
                     f"классификатор по D-11 — {c['best']}, p_hi {c['cl'][c['best']]['p_hi']:.3f} (фиксирован); σ × {c['k']:.2f} (было {fz0['sigma_mult']}); "
                     f"runs\\models\\FREEZE.json (прежний — FREEZE_архив_20261031.json), заморозка_20261101.md\n")
