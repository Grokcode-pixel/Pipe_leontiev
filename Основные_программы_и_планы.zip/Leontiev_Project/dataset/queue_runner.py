"""30.10.2026 — единственный исполнитель общей очереди (runs\\queue\\jobs.json). Правила автора: один Fluent за раз; переход на
общую очередь только между расчётами — исполнитель ждёт, пока доработают старые цепочки (queue_1030b/c и серии, которые они
запускают) и закроется Fluent; текущий расчёт не прерывается. Задания — строго по порядку, по одному.
--dry: проверка вхолостую — без Fluent и без подпроцессов, на копии очереди (jobs_dry.json); показывает, что и когда было бы запущено.
Стоп: файл runs\\queue\\STOP (исполнитель доделывает текущее задание и выходит).
usage: python queue_runner.py [--dry]"""
import os, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import jobqueue as JQ

PY = r'C:\Users\Roman\AppData\Local\Programs\Python\Python314\python.exe'
D = Path(r'F:\Leontiev_Project\dataset')
LOG = JQ.Q / 'runner_log.txt'
PIDF = JQ.Q / 'runner.pid'
STOP = JQ.Q / 'STOP'
# старые цепочки и серии, которые нельзя прерывать: пока жив хотя бы один такой процесс — исполнитель ждёт
LEGACY = ('queue_10', 'knurl_eqflow.py', 'knurl_shallow.py', 'nozzle_series.py', 'a3a_check.py', 'confirm_runner.py', 'auto_enrich.py',
          'run_journal_points.py', 'run_tri_flow.py', 'ru_series2.py', 'run_queue_', 'bundle3d_run.py')


def log(s):
    JQ.Q.mkdir(parents=True, exist_ok=True)
    with open(LOG, 'a', encoding='utf-8') as f:
        f.write(time.strftime('%d.%m %H:%M:%S ') + s + '\n')
    print(s, flush=True)


def python_procs():
    out = subprocess.run(['powershell', '-NoProfile', '-Command',
                          "Get-CimInstance Win32_Process -Filter \"name='python.exe'\" | ForEach-Object { \"$($_.ProcessId)`t$($_.CommandLine)\" }"],
                         capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW).stdout
    res = []
    for ln in out.splitlines():
        if '\t' in ln:
            pid, cmd = ln.split('\t', 1)
            res.append((int(pid), cmd))
    return res


def legacy_busy(own=()):
    return [(p, c) for p, c in python_procs() if p != os.getpid() and p not in own and any(k in c for k in LEGACY)]


def fluent_running():
    import gui_runner as G
    return G.fluent_running()


def alive(pid):
    out = subprocess.run(['tasklist', '/FI', f'PID eq {pid}', '/NH'], capture_output=True, text=True,
                         creationflags=subprocess.CREATE_NO_WINDOW).stdout
    return str(pid) in out


def command(j):
    if j['kind'] == 'script':
        return [PY, '-u', j['script']] + [str(a) for a in j.get('args', [])]
    return [PY, '-u', 'job_point.py', j['id']]


def main(dry=False):
    path = JQ.Q / 'jobs_dry.json' if dry else JQ.JOBS
    if dry:
        JQ.save(JQ.load(JQ.JOBS), path) if JQ.JOBS.exists() and not path.exists() else None
    elif PIDF.exists() and alive(int(PIDF.read_text() or 0)):
        print('исполнитель уже работает'); return
    if not dry:
        PIDF.write_text(str(os.getpid()))
    log(f'=== исполнитель очереди запущен{" (ВХОЛОСТУЮ)" if dry else ""}, PID {os.getpid()}')
    said = None
    while not STOP.exists():
        jobs = JQ.load(path)
        nxt = next((j for j in jobs if j['status'] == 'ждёт'), None)
        if nxt is None:
            if dry:
                log('  очередь пуста — проверка вхолостую закончена'); break
            time.sleep(60); continue
        busy = legacy_busy()
        fl = fluent_running()
        if busy or fl:
            names = sorted({Path(t.strip('"')).name for _, c in busy for t in c.split() if t.strip('"').endswith('.py')})
            why = (f'старая цепочка: {", ".join(names)}' if busy else '') + \
                  ('; Fluent занят' if fl else '')
            if why != said:
                log(f'  ждём ({why}) — следующее задание {nxt["id"]}'); said = why
            if dry:
                log(f'  ВХОЛОСТУЮ: в реальном режиме {nxt["id"]} ждало бы освобождения; дальше — как если бы освободилось')
            else:
                time.sleep(60); continue
        said = None
        cmd = command(nxt)
        out = Path(r'F:\Leontiev_Project') / nxt.get('stdout', f'runs\\queue\\{nxt["id"]}_stdout.txt')
        JQ.update(nxt['id'], path, status='идёт', started=time.strftime('%d.%m.%Y %H:%M:%S'))
        log(f'=== {nxt["id"]} старт: «{nxt.get("series")}» — {" ".join(cmd[2:])} → {out.name}')
        if not dry:
            JQ.journal(f'{nxt["id"]} запущен исполнителем: серия «{nxt.get("series")}» ({nxt.get("plan")})')
        if dry:
            rc = 0; time.sleep(0.5)
        else:
            out.parent.mkdir(parents=True, exist_ok=True)
            with open(out, 'a', encoding='utf-8') as fo:
                rc = subprocess.run(cmd, cwd=str(D), stdout=fo, stderr=subprocess.STDOUT,
                                    env=dict(os.environ, PYTHONIOENCODING='utf-8')).returncode
        JQ.update(nxt['id'], path, status='готово' if rc == 0 else 'сбой', finished=time.strftime('%d.%m.%Y %H:%M:%S'), rc=rc)
        log(f'=== {nxt["id"]} конец (код {rc})')
        if not dry:
            JQ.journal(f'{nxt["id"]} закончен (код {rc})')
    log('=== исполнитель остановлен' + (' (STOP)' if STOP.exists() else ''))
    if not dry:
        PIDF.unlink(missing_ok=True)


if __name__ == '__main__':
    main('--dry' in sys.argv)
