"""Build known three-zone knurl topology by semantic names.
v9 (03.11.2026: select final wall names by adjacent material, preserving the historical report convention).
Original v6 is preserved. No solver settings or geometry are changed.
v6 (03.11.2026, решение автора «проверять балансом тепла», D-47): покрытие несогласованного стыка газ–стенка ЗАПИСЫВАЕТСЯ
(interface_audit.json), но не блокирует расчёт; допуск стыка — баланс энергии полного окна D-12a (< 1 % Q). Остальные проверки
(роли пар по именам и материалам, обе пары найдены, итоговый mesh check, все зоны) — без изменений."""
import re,json
from pathlib import Path
import leontiev_pipeline as L
import build_fluent_case as BASE

def wall_roles(text,prefix):
    roles={}
    for line in text.splitlines():
        m=re.match(r'^\s*(\d+)\s+(\S+)\s+wall\s+(\S+)\s+face\s*$',line)
        if not m:continue
        ident,name,material=m.groups()
        if not name.startswith(prefix) or '::' not in name:continue
        channel='svz' if 'wall-air_svz-wall_abonite' in name else 'dzv' if 'interior-air_dzv-wall_abo' in name else None
        if channel:
            role=channel+('_shadow' if name.endswith('-shadow') else '')
            if role in roles and roles[role]['name']!=name:raise RuntimeError('Ambiguous interface role '+role)
            roles[role]=dict(id=int(ident),name=name,material=material)
    if set(roles)!={'svz','svz_shadow','dzv','dzv_shadow'}:raise RuntimeError('Incomplete native wall pairs: '+str(roles))
    return roles

def final_names(roles):
    """Both historical base wall names belong to solid; -shadow belongs to gas.
    Coupled-side suffixes and numeric IDs may change, so inspect materials.
    """
    names={}
    for channel,base in [('svz','wall-air_svz-wall_abonite'),('dzv','interior-air_dzv-wall_abonite')]:
        pair=[roles[channel],roles[channel+'_shadow']]
        solid=[r for r in pair if r['material']=='latun']
        gas=[r for r in pair if r['material'] in ('air','methane','ch4','ch4_pr')]
        if len(solid)!=1 or len(gas)!=1:
            raise RuntimeError('Cannot prove solid/gas sides for '+channel+': '+str(pair))
        names[solid[0]['name']]=base
        names[gas[0]['name']]=base+'-shadow'
    if len(names)!=4: raise RuntimeError('Duplicate native wall side')
    return names


def final_side_check(text):
    rows={}
    for line in text.splitlines():
        m=re.match(r'^\s*\d+\s+(\S+)\s+wall\s+(\S+)\s+face\s*$',line)
        if m: rows[m[1]]=m[2]
    for base in ('wall-air_svz-wall_abonite','interior-air_dzv-wall_abonite'):
        if rows.get(base)!='latun' or rows.get(base+'-shadow') not in ('air','methane','ch4','ch4_pr'):
            raise RuntimeError('Final wall report convention is not proven: '+base+' '+str(rows))
    return {k:v for k,v in rows.items() if k in ('wall-air_svz-wall_abonite','wall-air_svz-wall_abonite-shadow','interior-air_dzv-wall_abonite','interior-air_dzv-wall_abonite-shadow')}


def coverage(text):
    pairs={}
    for m in re.finditer(r'^\s*(grs_native:\d+:\S+)\s+\d+\s+[\d.eE+-]+\s+(\d+\.\d+)%\s*/\s*(\d+\.\d+)%',text,re.M):
        tag='svz' if 'wall-air_svz-wall_ab' in m[1] else 'dzv' if 'interior-air_dzv-wall_ab' in m[1] else None
        if tag:pairs[tag]=[float(m[2]),float(m[3])]
    if set(pairs)!={'svz','dzv'}:raise RuntimeError('Cannot identify both interface area pairs')
    return pairs

def final_mesh_ok(text):
    bad=[x for x in text.splitlines() if re.search(r'Error:|mesh check failed|unassigned interface|left.handed|negative (?:cell|volume)',x,re.I)]
    if bad:raise RuntimeError('Final native mesh check failed: '+str(bad[:8]))
    for n in ('air_svz','air_dzv','wall_abonite','inlet_svz','outlet_svz','inlet_dzv','outlet_dzv','axis'):
        if not re.search(r'^\s*\d+\s+'+re.escape(n)+r'\s+',text,re.M):raise RuntimeError('Missing prepared zone: '+n)

def build(msh,outdir,p0_svz_MPa=5.5,interpolate=False):
    if interpolate:raise RuntimeError('Cross-geometry reference interpolation prohibited')
    out=Path(outdir)
    # Reuse the established journal generation, intercepting execution and checks.
    # BASE's final fixed-ID assertion is intentionally not used: checks below use roles and actual coverage.
    calls=[];original=L.run_fluent
    L.run_fluent=lambda j,**kw:calls.append(Path(j))
    try:
        try:BASE.build(msh,out,p0_svz_MPa=p0_svz_MPa,interpolate=False)
        except FileNotFoundError:pass  # journals exist; transcripts do not exist before real sessions
    finally:L.run_fluent=original
    if len(calls)!=5:raise RuntimeError('Unexpected base journal protocol')
    targets=dict(svz='wall-air_svz-wall_abonite',svz_shadow='wall-air_svz-wall_abonite-shadow',
                 dzv='interior-air_dzv-wall_abonite',dzv_shadow='interior-air_dzv-wall_abonite-shadow')
    original(calls[0],threads=6);original(calls[1],threads=6)
    r2=wall_roles((out/'s2.trn').read_text(errors='replace'),'contact_region')
    s=calls[2].read_text(encoding='utf-8')
    for old,role in [(31,'svz'),(34,'svz_shadow'),(38,'dzv'),(37,'dzv_shadow')]:
        s=s.replace('/mesh/modify-zones/zone-name '+str(old)+' ', '/mesh/modify-zones/zone-name '+r2[role]['name']+' ')
    calls[2].write_text(s,encoding='utf-8');original(calls[2],threads=6);original(calls[3],threads=6)
    t4=(out/'s4.trn').read_text(errors='replace');r4=wall_roles(t4,'grs_native:');cov=coverage(t4)
    (out/'interface_audit.json').write_text(json.dumps(dict(roles=r4,area_percent=cov,final_names=final_names(r4)),indent=2),encoding='utf-8')
    # v6: покрытие только в отчёт (у всех прежних сеток накатки 99,5–99,7 %; допуск — баланс энергии на результате)
    final_mesh_ok(t4)
    # Rewrite only the generated role names in the initialization journal.
    lines=calls[4].read_text(encoding='utf-8').splitlines();renames=[]
    old_renames=[line for line in lines if line.startswith('/mesh/modify-zones/zone-name grs_native:')]
    if len(old_renames)!=4: raise RuntimeError('Unexpected initialization rename protocol')
    for line in lines:
        if line in old_renames: continue
        renames.append(line)
    i=renames.index('/mesh/check')
    renames[i:i]=['/mesh/modify-zones/zone-name '+source+' '+target for source,target in final_names(r4).items()]
    # Save a final zone listing after rename and initialization, without solver iterations.
    i=renames.index('/mesh/check');renames.insert(i,'/define/boundary-conditions/list-zones')
    calls[4].write_text('\n'.join(renames)+'\n',encoding='utf-8');original(calls[4],threads=6)
    t5=(out/'s5.trn').read_text(errors='replace');final_mesh_ok(t5);final_side_check(t5)
    case=out/'initial.cas.h5';data=out/'initial.dat.h5'
    if not all(f.is_file() and f.stat().st_size for f in (case,data)):raise RuntimeError('Incomplete native template')
    return dict(initial_case=str(case),interface_percent=[x for p in cov.values() for x in p],interface_roles=r4)
