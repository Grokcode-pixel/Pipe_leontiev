"""31.10.2026 — D-12a (принято автором 31.10): сходимость при колебаниях. Окно — последние 1000 итераций, результат = среднее
по окну (отчёты мониторов — каждые 500 итераций у продолжений, 100 — у первых стадий). Сошлась, если:
 средний дисбаланс энергии (со знаком) < 1 % Q;  колебание эффекта ≤ ± 0,05 K;  Q ≤ ± 1 %;  расходы СВЗ и ДЗВ ≤ ± 0,5 %;
 нет сползания — средние половин окна отличаются меньше половины допусков (0,025 K; 0,5 %; 0,25 %).
Максимум |дисбаланса| в окне — для информации. Предел итераций — не критерий. Колебание = (максимум − минимум) / 2 в окне.
usage: python d12a.py <папка расчёта> [...]  |  python d12a.py --frozen  (проверка 152 замороженных точек → runs\\models\\D-12a_проверка.md)"""
import json, sys, time
from pathlib import Path
import numpy as np
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import gui_runner as G
import passport as PS
import grs_temps

WINDOW = 1000
TOL = dict(imb_pct=1.0, eff_K=0.05, Q_pct=1.0, G_pct=0.5)


def evaluate(d, window=WINDOW):
    d = Path(d)
    st = G.status(d) or {}
    S = st.get('samples') or []
    if not S:
        return dict(ok=None, why='нет отчётов мониторов', n=0)
    r = PS.resolve(d)['regime']
    last = S[-1]['iteration']
    W = [s for s in S if s['iteration'] >= last - window]
    eff = np.array([grs_temps.outlet_temps(s['Q'], s['m_svz'], s['m_dzv'], 273.15 + r['T0_svz'], r['p_main'], r['p_cons'], r['p_out_dzv'],
                                           r['p0_dzv'], T0_dzv_K=273.15 + r['T0_dzv'])['dT_svz_vs_throttle'] for s in W])
    Q, Gs, Gd, net = (np.array([s[k] for s in W], float) for k in ('Q', 'm_svz', 'm_dzv', 'net'))
    out = dict(n=len(W), it=(W[0]['iteration'], last), effect=float(eff.mean()), Q=float(Q.mean()), G_svz=float(Gs.mean()), G_dzv=float(Gd.mean()),
               imb_pct=float(100 * net.mean() / Q.mean()), imb_max_pct=float(100 * np.max(np.abs(net / Q))))
    if len(W) < 2:
        return dict(out, ok=None, why=f'в окне {window} итераций меньше 2 отчётов')
    amp = lambda a: (a.max() - a.min()) / 2
    out.update(eff_amp=float(amp(eff)), Q_amp_pct=float(100 * amp(Q) / Q.mean()), Gs_amp_pct=float(100 * amp(Gs) / Gs.mean()),
               Gd_amp_pct=float(100 * amp(Gd) / Gd.mean()))
    h1 = [k for k, s in enumerate(W) if s['iteration'] <= last - window / 2] or list(range(len(W) // 2))
    h2 = [k for k in range(len(W)) if k not in h1] or [len(W) - 1]
    m = lambda a, ix: float(np.mean(a[ix]))
    out.update(drift_eff=abs(m(eff, h1) - m(eff, h2)), drift_Q_pct=100 * abs(m(Q, h1) - m(Q, h2)) / Q.mean(),
               drift_Gs_pct=100 * abs(m(Gs, h1) - m(Gs, h2)) / Gs.mean(), drift_Gd_pct=100 * abs(m(Gd, h1) - m(Gd, h2)) / Gd.mean())
    checks = dict(imb=abs(out['imb_pct']) < TOL['imb_pct'], eff=out['eff_amp'] <= TOL['eff_K'], Q=out['Q_amp_pct'] <= TOL['Q_pct'],
                  G=max(out['Gs_amp_pct'], out['Gd_amp_pct']) <= TOL['G_pct'],
                  drift=(out['drift_eff'] < TOL['eff_K'] / 2 and out['drift_Q_pct'] < TOL['Q_pct'] / 2
                         and max(out['drift_Gs_pct'], out['drift_Gd_pct']) < TOL['G_pct'] / 2))
    return dict(out, checks=checks, ok=all(checks.values()), why='; '.join(k for k, v in checks.items() if not v))


def rows_table(e):
    """Для интерфейса: критерий | сейчас | нужно | ✓/✗."""
    if not e or e.get('n', 0) == 0:
        return [('D-12a: отчётов мониторов пока нет', '—', '', None)]
    if e.get('ok') is None:
        return [(f"D-12a: {e.get('why')}", f"отчётов {e.get('n')}", '≥ 2 в окне 1000 итераций', None)]
    c = e['checks']
    return [('D-12a: средний дисбаланс (со знаком), % Q', f"{e['imb_pct']:+.2f}", '< 1', c['imb']),
            ('D-12a: колебание эффекта в окне, K', f"± {e['eff_amp']:.3f}", '≤ ± 0,05', c['eff']),
            ('D-12a: колебание Q, %', f"± {e['Q_amp_pct']:.2f}", '≤ ± 1', c['Q']),
            ('D-12a: колебание расходов СВЗ / ДЗВ, %', f"± {e['Gs_amp_pct']:.2f} / {e['Gd_amp_pct']:.2f}", '≤ ± 0,5', c['G']),
            ('D-12a: сползание (половины окна): эффект K / Q % / расход %',
             f"{e['drift_eff']:.3f} / {e['drift_Q_pct']:.2f} / {max(e['drift_Gs_pct'], e['drift_Gd_pct']):.2f}", '< 0,025 / 0,5 / 0,25', c['drift']),
            ('D-12a: максимум |дисбаланса| в окне, % Q (для информации)', f"{e['imb_max_pct']:.2f}", '—', None)]


def frozen():
    fz = json.loads((PS.R / 'models' / 'FREEZE.json').read_text(encoding='utf-8'))
    res = []
    for f in fz['folders']:
        try:
            e = evaluate(f)
        except Exception as ex:
            e = dict(ok=None, why=f'ошибка чтения: {ex!r}', n=0)
        res.append((Path(f), e))
    bad = [(p, e) for p, e in res if e.get('ok') is False]
    unk = [(p, e) for p, e in res if e.get('ok') is None]
    from collections import Counter
    cnt = Counter(k for p, e in bad for k, v in e['checks'].items() if not v)
    names = dict(imb='средний дисбаланс ≥ 1 % Q', eff='колебание эффекта > ± 0,05 K', Q='колебание Q > ± 1 %', G='колебание расходов > ± 0,5 %',
                 drift='сползание')
    nodrift = sum(1 for p, e in res if e.get('checks') and all(v for k, v in e['checks'].items() if k != 'drift'))
    reps = [e['n'] for p, e in res if e.get('n')]
    L = [f'# D-12a на замороженных 152 точках — проверка, данные не меняются ({time.strftime("%d.%m.%Y %H:%M")})', '',
         f"Точек: {len(res)}; прошли бы D-12a: **{sum(1 for p, e in res if e.get('ok'))}**; не прошли бы: **{len(bad)}**; "
         f"нельзя оценить (в окне 1000 итераций меньше 2 отчётов или нет отчётов): {len(unk)}.", '',
         'Почему не прошли бы (точка может не пройти по нескольким): ' + ('; '.join(f'{names[k]} — {v}' for k, v in cnt.most_common()) or '—') + '.', '',
         f"**Оговорка:** отчёты мониторов — раз в 500 итераций, в окне 1000 итераций у большинства точек {int(np.median(reps)) if reps else 0} отчёта; "
         'сползание сравнивает 2 отчёта первой половины с 1 отчётом второй — колебание выглядит как сползание. '
         f"Без проверки сползания прошли бы {nodrift} из {len(res)}.", '',
         '| точка | средний дисбаланс, % Q | макс. \\|дисбаланс\\|, % Q | колебание эффекта, K | Q, % | расходы, % | сползание эффекта, K | не выполнено |',
         '|---|---|---|---|---|---|---|---|']
    for p, e in sorted(bad, key=lambda t: -abs(t[1]['imb_pct'])):
        L.append(f"| {p.parent.name}/{p.name} | {e['imb_pct']:+.2f} | {e['imb_max_pct']:.2f} | ± {e['eff_amp']:.3f} | ± {e['Q_amp_pct']:.2f} | "
                 f"± {max(e['Gs_amp_pct'], e['Gd_amp_pct']):.2f} | {e['drift_eff']:.3f} | {e['why']} |")
    if unk:
        L += ['', 'Нельзя оценить: ' + ', '.join(f'{p.parent.name}/{p.name} ({e.get("why")})' for p, e in unk[:40]) + ('…' if len(unk) > 40 else '')]
    L += ['', 'Окно — последние 1000 итераций; отчёты мониторов каждые 500 (продолжения) или 100 итераций. Скрипт dataset\\d12a.py --frozen.']
    out = PS.R / 'models' / 'D-12a_проверка.md'
    out.write_text('\n'.join(L) + '\n', encoding='utf-8')
    print('\n'.join(L[:8]))
    return len(res), len(bad), len(unk)


if __name__ == '__main__':
    if sys.argv[1:] == ['--frozen']:
        n, b, u = frozen()
        with open(r'F:\Leontiev_Project\Журнал_работ.md', 'a', encoding='utf-8') as f:
            f.write(f"- {time.strftime('%d.%m.%Y %H:%M')} — D-12a (принято автором 31.10) прогнано как проверка на замороженных {n} точках: "
                    f"не прошли бы {b}, нельзя оценить {u} (runs\\models\\D-12a_проверка.md); данные не менялись\n")
    else:
        for a in sys.argv[1:]:
            print(a, json.dumps(evaluate(a), ensure_ascii=False, default=float))
