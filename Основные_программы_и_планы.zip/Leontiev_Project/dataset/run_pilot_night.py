"""Night 11->12.10.2026 (22:15).  CFL 100 was stable in the 1000-it. test but blew up slowly over a long stage (cell a p5:
energy imbalance 625 -> 4530 W, continuity 1e-4 -> 7e-2 between 29 500 and 31 000 it.) -> p5 stopped.
Now: every continuation stage runs at CFL 50 with an energy guard (cont_util.GUARD_ENERGY_W = 300 W after 1500 it.);
a stage that fails is repeated once at CFL 20 from the same source.  Point a from cell_a_cfl100 (saved at 28 500 it.,
energy 2.3 W), to convergence (LIMIT 8000) + one m correction, then the neighbour chain c -> d -> e -> b.
Author 21:20: if the transferred point c takes 6+ h -> early stop by extrapolation (to be added then); DZV mesh unchanged."""
import sys, time, traceback
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_pilot_fast as F
import cont_util as U

P, log = F.P, F.log
U.NPROC, U.LIMIT, U.GUARD_ENERGY_W = 7, 8000, 300.0
REG = (5.5, 0.3, 5.5, 5.49663)
G_T = 0.3 * 0.162438
_cont = F.cont


def cont(src_case, tag, regime, extra, g_target, start):
    t0 = time.time()
    # 12.10 01:00: CFL 50 also blew up after ~5000 it. (cell a p6: energy 36 -> 837 W at m ~0.25) -> CFL 20 first,
    # CFL 10 as the fallback
    U.CFL = 20.0
    r = _cont(src_case, tag, regime, extra, g_target, start + ' (CFL 20)')
    if not (P.BASE / tag / 'result.cas.h5').exists():
        log(f'  {tag}: при CFL 20 нет результата — повтор при CFL 10')
        U.CFL = 10.0
        r = _cont(src_case, tag + 'c10', regime, extra, g_target, start + ' (CFL 10)')
        tag = tag + 'c10'
    log(f'  {tag}: этап занял {(time.time() - t0) / 3600:.1f} ч')
    return r


F.cont = cont   # point() of run_pilot_fast uses it


def last(*tags):
    return next((t for t in tags if F.ok(t) and F.rows(t).get('G_dzv')), None)


def main():
    log('=== ночь 11→12.10: пилот, CFL 50 со страховкой по энергии; точка a от cell_a_cfl100')
    t0 = time.time()
    r = cont(P.BASE / 'cell_a_cfl100' / 'result.cas.h5', 'cell_a_t12_m03_p03_p8', REG, [], G_T, 'продолжение cell_a_cfl100')
    a = last('cell_a_t12_m03_p03_p8', 'cell_a_t12_m03_p03_p8c10')
    if a:
        r = F.rows(a)
        mc = float(r['G_dzv']) / float(r['G_svz'])
        log(f'  {a}: m {mc:.3f} (цель 0,3), сошёлся {r.get("converged")}')
        if abs(mc - 0.3) / 0.3 > 0.05:
            dp = (5.5 - REG[3]) * (0.3 / mc) ** 1.8
            cont(P.BASE / a / 'result.cas.h5', 'cell_a_t12_m03_p03_p7', (5.5, 0.3, 5.5, round(5.5 - dp, 6)), [], G_T,
                 f'продолжение {a}')
    a = last('cell_a_t12_m03_p03_p7', 'cell_a_t12_m03_p03_p7c10', 'cell_a_t12_m03_p03_p8', 'cell_a_t12_m03_p03_p8c10',
             'cell_a_cfl100')
    log(f'  точка a итог: {a}; всего {(time.time() - t0) / 3600:.1f} ч')
    gap_a, gap14 = F.params(1.2, 0.3)[1], F.params(1.4, 0.3)[1]
    t1 = time.time()
    c = F.point('cell_c_t14_m10_p03', 1.4, 1.0, 0.3, a, gap_a, False)
    log(f'=== точка c (перенос поля) заняла {(time.time() - t1) / 3600:.1f} ч — порог решения автора 6 ч')
    if c:
        F.point('cell_d_t14_m01_p03', 1.4, 0.1, 0.3, c, gap14, True)
        F.point('cell_e_t14_m03_p12', 1.4, 0.3, 1.2, c, gap14, True)
        F.point('cell_b_t16_m03_p03', 1.6, 0.3, 0.3, c, gap14, False)
    else:
        F.point('cell_b_t16_m03_p03', 1.6, 0.3, 0.3, a, gap_a, False)


if __name__ == '__main__':
    P.qlog('=== ночь 11→12.10: пилот (CFL 50 + страховка) — начат')
    try:
        main()
    except Exception:
        log('пилот: ОШИБКА программы: ' + traceback.format_exc())
    P.qlog('=== ночь 11→12.10: пилот — закончен')
