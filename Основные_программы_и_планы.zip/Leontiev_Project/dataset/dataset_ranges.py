"""30.10.2026 — вопрос автора: по датасету (152 точки обучения) — охлаждение ДЗВ (K) и тепло на трубку (Вт): минимум и максимум,
при каких перепаде ДЗВ и расходах; режим задачи 2 (лучший вариант — CFD ST13c); доля ДЗВ в расходе G_ДЗВ/(G_ДЗВ + G_СВЗ)
против примера патента RU 2162190 (20 %). Вывод: runs\\models\\dataset_ranges.md."""
import csv, math, sys
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import passport as PS

R = Path(r'F:\Leontiev_Project\runs')
FILES = ('a9/a9_results.csv', 'setA/setA_results.csv', 'setB/setB_results.csv', 'station/station_results.csv', 'station/window0_results.csv',
         'station/task2_results.csv', 'station/auto_results.csv', 'station/confirm_results.csv')
RR = {}
for f in FILES:
    if (R / f).exists():
        for r in csv.DictReader(open(R / f, encoding='utf-8')):
            RR[(f.split('/')[0], r['tag'])] = r


def pts():
    out = []
    for src, d, x in PS.training_points():
        r = RR.get((d.parent.name, d.name))
        if not r or not r.get('dT_dzv_h'):
            continue
        Gs, Gd = float(r['G_svz']), float(r['G_dzv'])
        out.append(dict(src=src, tag=d.name, td=x[0], L=x[1], dp=math.exp(x[2]), pc=x[3], T=x[4], heat=x[5], pm=x[6],
                        dT_dzv=-float(r['dT_dzv_h']), dT_svz=float(r['dT_svz_h']), eff=float(r['dT_svz_vs_throttle']), Q=float(r['Q']),
                        Gs=Gs, Gd=Gd, share=Gd / (Gs + Gd), status=r['status']))
    return out


def line(p):
    return (f"{p['tag']} ({p['src']}): t/d {p['td']:g}, L {p['L']:.0f}, перепад ДЗВ {p['dp']:.1f} кПа, магистраль {p['pm']:g} МПа, "
            f"G СВЗ {p['Gs']:.4f} / ДЗВ {p['Gd']:.4f} кг/с (доля ДЗВ {100 * p['share']:.0f} %); охлаждение ДЗВ {p['dT_dzv']:.2f} K, Q {p['Q']:.0f} Вт")


if __name__ == '__main__':
    P = pts()
    L = [f'# Диапазоны датасета ({len(P)} точек обучения с результатом)', '']
    for key, nm in (('dT_dzv', 'Охлаждение ДЗВ (по энтальпии), K'), ('Q', 'Тепло на трубку, Вт'), ('share', 'Доля ДЗВ G_ДЗВ/(G_ДЗВ+G_СВЗ)')):
        lo, hi = min(P, key=lambda p: p[key]), max(P, key=lambda p: p[key])
        L += [f'**{nm}:**', f'- минимум: {line(lo)}', f'- максимум: {line(hi)}', '']
    sh = sorted(p['share'] for p in P)
    L += [f'Доля ДЗВ: медиана {100 * sh[len(sh) // 2]:.0f} %, 10–90 %: {100 * sh[len(sh) // 10]:.0f}–{100 * sh[9 * len(sh) // 10]:.0f} %; '
          f'точек с долей ≤ 25 %: {sum(s <= 0.25 for s in sh)} из {len(sh)}.', '']
    st = RR.get(('station', 'ST13c'))
    if st:
        Gs, Gd = float(st['G_svz']), float(st['G_dzv'])
        L += ['## Задача 2, лучший вариант (t/d 1,6, L 660, перепад 5 кПа; магистраль 4,0 МПа, газ 0 °C, потребитель 0,6 МПа) — CFD ST13c', '',
              f"- охлаждение ДЗВ {-float(st['dT_dzv_h']):.2f} K; нагрев СВЗ против дросселя (эффект) {float(st['dT_svz_vs_throttle']):+.2f} K "
              f"(полное изменение T СВЗ по энтальпии {float(st['dT_svz_h']):+.2f} K, дроссель {float(st['dT_svz_throttle']):+.2f} K);",
              f"- тепло на трубку {float(st['Q']):.0f} Вт; расход СВЗ {Gs:.4f} кг/с, ДЗВ {Gd:.4f} кг/с; доля ДЗВ {100 * Gd / (Gs + Gd):.0f} %; "
              f"статус {st['status']}."]
    (R / 'models' / 'dataset_ranges.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
    print('\n'.join(L))
