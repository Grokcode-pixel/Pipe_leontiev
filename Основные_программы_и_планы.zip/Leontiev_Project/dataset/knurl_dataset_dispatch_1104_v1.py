"""Queue entry gates and zero-iteration native audit; no source-case changes."""
import sys,re,json,traceback
from pathlib import Path
import knurl_dataset_queue_1104_v1 as S
F=S.F;A=S.A;R=S.R;OUT=S.OUT;P=R/'runs/plans/knurl_dataset_dispatch_1104_v1.json'
def registered():
 if A.sha(P)!=P.with_suffix('.sha256').read_text().strip():raise RuntimeError('Dispatch plan changed')
 p=F.load(P)
 for f,h in p['protected'].items():
  if A.sha(f)!=h:raise RuntimeError('Dispatch source changed '+f)
 S.registered();return p

def audit():
 registered();S.require(OUT/'grid/summary.json','passed');o=OUT/'audit';S.once(o);r={}
 for tag in ('F05','F06'):
  src=R/'runs/family_1103_v7_cfd'/tag;trn=o/(tag+'.trn');settings=o/(tag+'.set');jou=o/(tag+'.jou')
  jou.write_text('\n'.join(['/file/confirm-overwrite? no','/file/start-transcript "'+S.L.fl(trn)+'"','/file/read-case-data "'+S.L.fl(src/'result.cas.h5')+'"','/file/write-settings "'+S.L.fl(settings)+'"','/file/stop-transcript','/exit yes'])+'\n',encoding='utf-8')
  F.checked(jou);t=settings.read_text(encoding='utf-8');walls={}
  if 'real-gas-peng-robinson' not in t:raise RuntimeError('PR methane not found '+tag)
  for m in re.finditer(r'\(bc \(([^ ]+) wall mixture\) \(\n(.*?)\n\)\)',t,re.S):
   if 'non-overlapping' not in m[1]:continue
   b=m[2];mode=re.search(r'\(thermal-bc \. ([\d]+)\)',b);q=re.search(r'\(q-dot \(constant \. ([\deE.+-]+)\)',b)
   walls[m[1]]=dict(thermal_bc=int(mode[1]) if mode else None,heat_flux=float(q[1]) if q else None)
  if len(walls)<4 or not all(v['thermal_bc']==1 and v['heat_flux']==0 for v in walls.values()):raise RuntimeError('Unmatched thermal boundaries require interpretation '+tag+str(walls))
  status=F.V.evaluate(src);r[tag]=dict(PR=True,nonoverlap_walls=walls,physical_raw=status['physical'],reverse_location='outlet_svz zone15 in source coupled transcripts; DZV is outlet14',source_case_sha256=A.sha(src/'result.cas.h5'),settings_sha256=A.sha(settings))
 F.save(o/'summary.json',dict(time=A.now(),passed=True,results=r,limitation='Non-overlap zones are zero-heat-flux walls in these exact saved cases. Global balance does not prove interface accuracy; reverse-flow outlet location alone does not prove artifact. No CFD iterations or source writes.'))
 (o/'report_ru.md').write_text('# Аудит стыка, газа и обратного тока\n\n'+json.dumps(r,ensure_ascii=False,indent=2)+'\n\nНеперекрытые участки — адиабатические стенки, не тепловой контакт. Численная сходимость не доказывает точность стыка и физическую работоспособность.\n',encoding='utf-8')

if __name__=='__main__':
 mode=sys.argv[1]
 try:
  registered()
  if mode=='check':S.check();print('Dispatch/audit hashes OK; no native launch')
  elif mode=='audit':audit()
  else:
   if mode in ('pilot','series','final'):S.require(OUT/'audit/summary.json','passed')
   getattr(S,mode)()
 except Exception as e:
  o=OUT/mode;o.mkdir(parents=True,exist_ok=True);F.save(o/'BLOCK.json',dict(time=A.now(),error=repr(e),traceback=traceback.format_exc(),no_retry=True));raise
