﻿"""A9 — the reference dataset (14.10.2026, author approved the plan План_А9_датасет_20261014.md, consumer pressure
0.3-1.6 MPa).  Design: runs\\a9\\a9_design.csv (make_a9_design.py).  Unit cell, counterflow, symmetry, methane PR,
brass 110, wall 1.5 mm, 5.5 MPa before the nozzle; global pseudo step (Conservative x1, fallback x0.5); auto-stop
(continuity 1.5e-4), watchdog, energy guard (growing > 300 W).
Order: L 400 mm (fields of the pilot) -> 200 mm -> 660 mm (one from-scratch start per length, at t/d 1.4; other t/d by
field transfer at the same length); inside a geometry the points go by rising consumer pressure, each from the previous
one; a jump of the consumer pressure > 0.35 MPa is made in 0.3-MPa steps (auxiliary stages, a9_aux.csv).
Repeats 'с нуля' at the end.  Rows -> runs\\a9\\a9_results.csv (training / control / repeat marked by the design id)."""
import csv, math, subprocess, sys, time, traceback
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_night1213 as R          # Conservative global pseudo step in L.SOLVER_HEADER
import cont_util as U
import leontiev_pipeline as L
import gui_runner as G
import run_a3 as A3
import run_pilot_cell as PC

BASE = Path(r'F:\Leontiev_Project\runs\a9')
CSV = BASE / 'a9_results.csv'
AUX = BASE / 'a9_aux.csv'
DESIGN = BASE / 'a9_design.csv'
PILOT = Path(r'F:\Leontiev_Project\runs\pilot')
SRC400 = {1.2: PILOT / 'cell_a_t12_m03_p03_pg', 1.4: PILOT / 'cell_smooth_dp93', 1.6: PILOT / 'cell_b_t16_dp5_p03_pg2'}
SRC400_P = 0.3
CONS = '/solve/set/pseudo-time-method/global-time-step-settings yes 1 1 yes 1'
HALF = '/solve/set/pseudo-time-method/global-time-step-settings yes 1 0.5 yes 1'
ATM = 0.101325
U.NPROC, U.CFL, U.GUARD_ENERGY_W = 6, 20.0, 300.0   # 27.10: 6 Fluent processes on the new PC (was 7)


def log(s):
    line = time.strftime('%H:%M:%S ') + s
    print(line, flush=True)
    BASE.mkdir(parents=True, exist_ok=True)
    with (BASE / 'a9_log.txt').open('a', encoding='utf-8') as f:
        f.write(line + '\n')


def qlog(s):
    PC.qlog(s)


def set_step(line):
    i = L.SOLVER_HEADER.index(next(x for x in L.SOLVER_HEADER if 'global-time-step-settings' in x))
    L.SOLVER_HEADER[i] = line


def ok(d):
    return (Path(d) / 'result.cas.h5').exists()


def done_dir(pid):
    """The latest saved result of a design point (resume after a pause): id, idh, idc, idch."""
    for t in (pid + 'ch', pid + 'c', pid + 'h', pid):
        if ok(BASE / t):
            return BASE / t
    return None


def converged(d):
    import gui_convergence as C
    rows = C.closed_samples(d)
    return C.decision(rows) if rows else False


def regime(pt):
    return (5.5, float(pt['p_cons']), 5.5, round(5.5 - float(pt['dp_dzv_kPa']) / 1000.0, 6))


POINT_LIMIT = 6000   # 16.10 author: cap per design point (run_a9_l660 sets 3000); unconverged -> reviewed later
RESUME_CONT = True   # 16.10: False -> a saved unconverged point is reused as is (no continuation on resume)


def cont(src_case, tag, reg, extra, t0s, t0d, start, csv_path, limit=None, l_mm=400.0):
    """One continuation stage with the half-step fallback; returns the output dir that has a result (or None)."""
    for step, suffix in ((CONS, ''), (HALF, 'h')):
        set_step(step)
        U.LIMIT = min(limit, POINT_LIMIT) if limit else POINT_LIMIT
        out = BASE / (tag + suffix)
        mins = U.continue_case(src_case, out, list(extra), reg, log, tag + suffix, t0_C=t0s, t0_dzv_C=t0d)
        U.record(csv_path, tag + suffix, 'work_v2', 'ch4_pr', reg, out, mins, log, start=start + (' (шаг ×0,5)' if suffix else ''),
                 t0_C=t0s, t0_dzv_C=t0d, l_heat_mm=l_mm)
        if ok(out):
            set_step(CONS)
            return out
        log(f'  {tag + suffix}: нет результата' + (' — повтор с половинным псевдошагом' if not suffix else ''))
    set_step(CONS)
    return None


def to_regime(src_dir, src_p, pt, start):
    """Ramp the consumer pressure in 0.3-MPa steps if the jump is large, then the design point itself."""
    reg = regime(pt)
    t0d, t0s = float(pt['t0_dzv']), float(pt['t0_svz'])
    cur, p = Path(src_dir), src_p
    k = 0
    while abs(reg[1] - p) > 0.35:
        p = round(p + math.copysign(0.3, reg[1] - p), 3)
        k += 1
        done_aux = [BASE / f'{pt["id"]}_r{k}{s}' for s in ('', 'h') if ok(BASE / f'{pt["id"]}_r{k}{s}')]
        if not done_aux and (BASE / f'{pt["id"]}_r{k}h').exists():   # 16.10: this step already failed twice (full + half)
            log(f'  {pt["id"]}: ступень {p} МПа уже не прошла (оба псевдошага) — точка с прежнего поля')
            break
        aux = done_aux[0] if done_aux else cont(cur / 'result.cas.h5', f'{pt["id"]}_r{k}', (reg[0], p, reg[2], reg[3]), [], t0s, t0d,
                   f'ступень давления потребителя {p} МПа к {pt["id"]}', AUX, limit=1500, l_mm=float(pt['L_mm']))   # 16.10: reuse a saved step
        if not aux:
            log(f'  {pt["id"]}: ступень {p} МПа не прошла — точка с прежнего поля')
            break
        cur = aux
    return cont(cur / 'result.cas.h5', pt['id'], reg, [], t0s, t0d, start, CSV, l_mm=float(pt['L_mm']))


def cell_params(td, l_mm, run_id, pt, gas, startup, coupled):
    cell = L.cell_geometry(td, 1.5, 4.8, 3.3)
    reg = regime(pt)
    p = dict(G.DEFAULTS)
    p.update(A3.MESHES['work_v2'], prt=0.85, mesh_custom=True, wait_free=True, dzv_counterflow=True,
             dzv_layers=PC.dzv_layers(cell['gap_mm']), p_out_svz_MPa=reg[1], p_out_dzv_MPa=reg[3], gas=gas,
             extra_lines=[L.SYMMETRY_DZV_LINE] + U.t0_lines(float(pt['t0_svz']), float(pt['t0_dzv'])),
             retries=1 if coupled > 10 else 0, startup_iters=startup, coupled_iters=coupled, cfl=5.0, l_heat_mm=l_mm,
             run_id=run_id, **{k: cell[k] for k in ('gap_mm', 'wall_thickness_inlet_mm', 'wall_thickness_end_mm')})
    return p, cell


def scratch(pt, tag):
    """From scratch: ideal methane (FMG, startup 1000, 5500 coupled), then PR at the design regime."""
    G.RUNS = BASE
    p, _ = cell_params(float(pt['t_d']), float(pt['L_mm']), f'{tag}_ideal', pt, 'ch4_ideal', 1000, 5500)
    log(f'=== {tag}: С НУЛЯ (идеальный метан → ПР), t/d {pt["t_d"]}, L {pt["L_mm"]} мм')
    t0 = time.time()
    G.run(p, lambda s: log('  ' + s), lambda: False)
    U.record(AUX, f'{tag}_ideal', 'work_v2', 'ch4_ideal', regime(pt), BASE / p['run_id'], round((time.time() - t0) / 60, 1),
             log, start='с нуля (FMG)', t0_C=float(pt['t0_svz']), t0_dzv_C=float(pt['t0_dzv']), l_heat_mm=float(pt['L_mm']))
    if not ok(BASE / p['run_id']):
        return None
    return cont(BASE / p['run_id'] / 'result.cas.h5', tag, regime(pt), list(L.CH4_PR_LINES), float(pt['t0_svz']),
                float(pt['t0_dzv']), f'с нуля: продолжение {tag}_ideal (ПР)', CSV, l_mm=float(pt['L_mm']))


def write_ip(case, ip):
    jou = ip.with_suffix('.jou')
    jou.write_text('\n'.join([f'/file/read-case-data "{L.fl(case)}"', f'/file/interpolate/write-data "{L.fl(ip)}" yes yes',
                              '/exit yes']) + '\n', encoding='ascii')
    t = time.time()
    try:
        subprocess.Popen([L.FLUENT, '2ddp', '-t1', '-g', '-i', str(jou)], cwd=str(ip.parent)).wait(900)
    finally:
        G.kill_since(t)
    return ip.exists()


def transfer(src_dir, pt, reg=None):
    """New t/d at the same length: template (10 it.) + interpolation of the neighbour's field, DZV started moving.
    reg: (p_svz_in, p_svz_out, p_dzv_in, p_dzv_out) — 30.10: для станционных режимов (магистраль ≠ 5,5 МПа, sppr --confirm)."""
    G.RUNS = BASE
    td, l_mm = float(pt['t_d']), float(pt['L_mm'])
    tag = pt['id']
    p, cell = cell_params(td, l_mm, f'{tag}_tpl', pt, 'ch4_ideal', 10, 10)
    log(f'=== {tag}: шаблон новой геометрии t/d {td}, L {l_mm} мм; перенос поля {Path(src_dir).name}')
    G.run(p, lambda s: log('  ' + s), lambda: False)
    tpl = BASE / f'{tag}_tpl' / 'result.cas.h5'
    if not tpl.exists() and (BASE / f'{tag}_tpl' / 'initial.cas.h5').exists():
        # 30.10: FMG шаблона на мелкой сетке накатки (0,1–0,2 мм) расходится (T до 5000 K) — шаблону нужны только сетка и зоны,
        # поле всё равно заменяется переносом, поэтому берётся кейс после гибридной инициализации
        tpl = BASE / f'{tag}_tpl' / 'initial.cas.h5'
        log(f'  {tag}: FMG шаблона не прошла — шаблон из initial.cas.h5 (гибридная инициализация)')
    ip = BASE / 'ip' / f'{Path(src_dir).name}.ip'
    ip.parent.mkdir(exist_ok=True)
    if not tpl.exists() or not (ip.exists() or write_ip(Path(src_dir) / 'result.cas.h5', ip)):
        log(f'  {tag}: нет шаблона или файла переноса'); return None
    reg = reg or regime(pt)
    t0d, t0s = float(pt['t0_dzv']), float(pt['t0_svz'])
    area = math.pi * (cell['cell_r_eq_mm'] ** 2 - cell['cell_r_outer_mm'] ** 2) * 1e-6
    u = -float(pt['m_target']) * 0.162 / (42.0 * area)
    init = [f'/file/interpolate/read-data "{L.fl(ip)}"', f'/solve/patch air_dzv () pressure {reg[3] / ATM:.5f}',
            f'/solve/patch air_dzv () temperature {t0d:g}', f'/solve/patch air_dzv () x-velocity ok {u:.2f}',
            '/solve/patch air_dzv () y-velocity ok 0', '/solve/patch air_dzv () k 0.1', '/solve/patch air_dzv () omega 1000',
            f'/solve/patch wall_abonite () temperature {(t0d + t0s) / 2:g}']
    return cont(tpl, tag, reg, list(L.CH4_PR_LINES) + init, t0s, t0d,
                f'перенос поля {Path(src_dir).name} на t/d {td}; ДЗВ с {u:.1f} м/с', CSV, l_mm=l_mm)


def run_geometry(points, first_src=None, first_p=None):
    """points of one geometry sorted by consumer pressure; first_src: a field of THIS geometry (pilot) or None."""
    cur, cur_p = first_src, first_p
    for pt in points:
        t0 = time.time()
        try:
            done = done_dir(pt['id'])
            if done:   # resume after a pause: converged -> reuse; saved but not converged -> continue it (tag ...c)
                if RESUME_CONT and not converged(done):
                    log(f'  {pt["id"]}: возобновление — досчёт сохранённого {done.name}')
                    done = cont(done / 'result.cas.h5', pt['id'] + 'c', regime(pt), [], float(pt['t0_svz']),
                                float(pt['t0_dzv']), f'досчёт {done.name} после паузы', CSV, l_mm=float(pt['L_mm'])) or done
                cur, cur_p = done, float(pt['p_cons'])
                continue
            if cur is None:
                res = None
            else:
                res = to_regime(cur, cur_p, pt, f'продолжение {Path(cur).name}')
            if res:
                cur, cur_p = res, float(pt['p_cons'])
            log(f'  {pt["id"]}: {"готово" if res else "НЕТ РЕЗУЛЬТАТА"} за {(time.time() - t0) / 3600:.1f} ч')
        except Exception:
            log(f'{pt["id"]}: ОШИБКА программы: ' + traceback.format_exc())
    return cur, cur_p


def main():
    pts = list(csv.DictReader(open(DESIGN, encoding='utf-8')))
    work = [p for p in pts if p['set'] != 'повтор с нуля']
    rep = [p for p in pts if p['set'] == 'повтор с нуля']
    by_geo = {}
    for p in work:
        by_geo.setdefault((float(p['L_mm']), float(p['t_d'])), []).append(p)
    for k in by_geo:
        by_geo[k].sort(key=lambda p: float(p['p_cons']))
    log(f'=== А9: {len(work)} точек (обучение + контроль) + {len(rep)} повтора; порядок 400 → 200 → 660 мм')
    # L 400 mm: pilot fields of each t/d
    for td in (1.4, 1.2, 1.6):
        run_geometry(by_geo[(400.0, td)], SRC400[td], SRC400_P)
    # L 200 / 660: scratch at t/d 1.4 (first point), transfer to 1.2 / 1.6 from the first t/d-1.4 result
    for l_mm in (200.0, 660.0):
        pts14 = by_geo[(l_mm, 1.4)]
        first = done_dir(pts14[0]['id']) or scratch(pts14[0], pts14[0]['id'])
        log(f'  {pts14[0]["id"]}: с нуля — {"готово" if first else "НЕТ РЕЗУЛЬТАТА"}')
        run_geometry(pts14[1:], first, float(pts14[0]['p_cons']) if first else None)
        for td in (1.2, 1.6):
            g = by_geo[(l_mm, td)]
            res = done_dir(g[0]['id']) or (transfer(first, g[0]) if first else None)
            log(f'  {g[0]["id"]}: перенос — {"готово" if res else "НЕТ РЕЗУЛЬТАТА"}')
            run_geometry(g[1:], res, float(g[0]['p_cons']) if res else None)
    for pt in rep:
        try:
            if not done_dir(pt['id']):
                scratch(pt, pt['id'])
        except Exception:
            log(f'{pt["id"]}: ОШИБКА программы: ' + traceback.format_exc())


if __name__ == '__main__':
    qlog('=== А9 датасет-эталон — начат')
    try:
        main()
    except Exception:
        log('А9: ОШИБКА программы: ' + traceback.format_exc())
    qlog('=== А9 датасет-эталон — закончен')

