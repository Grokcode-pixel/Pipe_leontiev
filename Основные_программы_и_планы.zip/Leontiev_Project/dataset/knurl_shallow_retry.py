"""30.10.2026 — повтор мелкой накатки 0,2 и 0,3 мм (KM02, KM03): 30.10 14:25–14:38 оба разошлись на 30–120-й итерации после
переноса поля ГЛАДКОЙ A9_19 (обе попытки, полный и половинный псевдошаг), тогда как KM01 (0,1 мм) от того же старта сошёлся.
Повтор — ступенькой по высоте выступа: KM02r — перенос поля сошедшейся 0,1 мм (KM01_eq1c, иначе KM01_eq1) на сетку 0,2 мм;
KM03r — перенос поля KM02r (если сошёлся) на 0,3 мм; старт с перепада 0,1 мм (14,91 кПа), затем ≤ 2 расчёта подбора перепада
под расход гладкой (как knurl_shallow). Каждый расчёт — одна попытка (без повтора с половинным шагом; решение автора 30.10).
Стоп: оба первых расчёта (KM02r, KM03r) не сошлись — стоп, решение автора."""
import json, math, sys
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import knurl_shallow as KSH

A, K = KSH.A, KSH.K
DP0 = 14.91


def cont_one(src_case, tag, reg_, extra, t0s, t0d, start, csv_path, limit=None, l_mm=400.0):
    """30.10 (решение автора: KM02 и KM03 — по одной попытке): как run_a9.cont, но без повтора с половинным псевдошагом."""
    A.set_step(A.CONS)
    A.U.LIMIT = min(limit, A.POINT_LIMIT) if limit else A.POINT_LIMIT
    out = A.BASE / tag
    mins = A.U.continue_case(src_case, out, list(extra), reg_, A.log, tag, t0_C=t0s, t0_dzv_C=t0d)
    A.U.record(csv_path, tag, 'work_v2', 'ch4_pr', reg_, out, mins, A.log, start=start, t0_C=t0s, t0_dzv_C=t0d, l_heat_mm=l_mm)
    if A.ok(out):
        return out
    A.log(f'  {tag}: нет результата (одна попытка — без повтора)')
    return None


A.cont = cont_one   # transfer() вызывает cont() модуля run_a9 — тоже одна попытка
TS, TD, PM, PC = 13.46, 8.63, 5.5, 0.59


def reg(dp):
    return (PM, PC, PM, round(PM - dp / 1000, 6))


def variant(h, pre, src):
    K.KN.update(dzv=h, svz=None, pitch=2.0, width=0.67)
    pt = dict(next(p for p in KSH.csv.DictReader(open(K.A9 / 'a9_design.csv', encoding='utf-8')) if p['id'] == 'A9_19'), id=f'{pre}r')
    first = A.done_dir(pt['id']) or A.transfer(src, pt, reg(DP0))
    r = KSH.row(pt['id'])
    ok = bool(first) and r is not None and A.converged(first)
    if not r:
        A.log(f'  {pt["id"]}: нет результата'); return None, False
    pts, cur = [(DP0, float(r['G_dzv']))], first
    best = dict(tag=pt['id'], dp=DP0, G_dzv=float(r['G_dzv']), Q=float(r['Q']), G_svz=float(r['G_svz']), effect=float(r['dT_svz_vs_throttle']), converged=ok)
    for k in (1, 2):
        if abs(pts[-1][1] / KSH.G_SMOOTH - 1) <= 0.03:
            break
        if len(pts) >= 2:
            (d0, g0), (d1, g1) = pts[-2], pts[-1]
            n = min(max(math.log(g1 / g0) / math.log(d1 / d0), 0.3), 0.8)
            dp = d1 * (KSH.G_SMOOTH / g1) ** (1 / n)
        else:
            dp = pts[-1][0] * (KSH.G_SMOOTH / pts[-1][1]) ** 2
        dp = round(min(max(dp, 2.0), 300.0), 2)
        tag = f'{pre}r_eq{k}'
        A.log(f'  {tag}: перепад ДЗВ {dp} кПа (оценка до расчёта; цель — расход гладкой {KSH.G_SMOOTH:.4f} кг/с)')
        d = A.done_dir(tag) or A.cont(cur / 'result.cas.h5', tag, reg(dp), [], TS, TD, f'мелкая накатка {h} мм при равном расходе ДЗВ (повтор)', A.CSV)
        rr = KSH.row(tag)
        if not d or not rr:
            continue
        pts.append((dp, float(rr['G_dzv']))); cur = d
        best = dict(tag=tag, dp=dp, G_dzv=float(rr['G_dzv']), Q=float(rr['Q']), G_svz=float(rr['G_svz']),
                    effect=float(rr['dT_svz_vs_throttle']), converged=A.converged(d))
    best.update(h=h, pitch=2.0, target=KSH.G_SMOOTH, miss_pct=100 * (best['G_dzv'] / KSH.G_SMOOTH - 1), m=best['G_dzv'] / best['G_svz'], start=str(src))
    s = json.loads(KSH.OUTJ.read_text(encoding='utf-8')) if KSH.OUTJ.exists() else {}
    s[pre] = best
    KSH.OUTJ.write_text(json.dumps(s, ensure_ascii=False, indent=1), encoding='utf-8')
    A.log(f"=== {pre} (h {h}, повтор): перепад {best['dp']} кПа, G ДЗВ {best['G_dzv']:.4f} ({best['miss_pct']:+.1f} %), Q {best['Q']:.0f} Вт, эффект {best['effect']:+.2f} K")
    return cur, ok


if __name__ == '__main__':
    A.qlog('=== мелкая накатка 0,2 / 0,3 мм — повтор ступенькой по высоте (от поля 0,1 мм) — начат')
    src = next(A.BASE / t for t in ('KM01_eq1c', 'KM01_eq1') if (A.BASE / t / 'result.cas.h5').exists())
    d2, ok2 = variant(0.2, 'KM02', src)
    d3, ok3 = variant(0.3, 'KM03', d2 if d2 else src)
    if not ok2 and not ok3:
        A.qlog('=== мелкая накатка, повтор: оба первых расчёта не сошлись — СТОП, нужно решение автора')
    A.qlog('=== мелкая накатка 0,2 / 0,3 мм — повтор закончен')
