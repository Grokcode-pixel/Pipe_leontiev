"""16.10.2026 — этап 5: честная проверка быстрой модели и многоуровневая модель (multi-fidelity).
1) Скользящий контроль калибровки: для каждой точки А9 множители fast1d калибруются БЕЗ неё (старт — общая калибровка),
   затем прогноз этой точки.
2) Многоуровневая модель: ГП по невязке «CFD − быстрая (LOO)» по 6 факторам; её скользящий контроль сравнивается
   с ГП только по CFD (как эталон А8) — та же выборка, те же точки.
3) Выборка быстрой модели: 2000 точек латинского гиперкуба по НЕПРЕРЫВНЫМ t/d 1,2–1,6 и L/d 30–100 и режиму
   (перепад ДЗВ 0,5–139 кПа, p потр. 0,3–1,6 МПа, T0 ДЗВ −10…+20 °C, подогрев 0–20 K) + поправка ГП и её σ.
Вывод: runs\\fast1d\\loo.csv, mf_summary.md, fast_2000.csv.  Запускать с пониженным приоритетом (Fluent считает)."""
import csv, json, math, sys, time
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
from scipy.stats import qmc
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import fast1d as F
import fast1d_calib as C
import a8_strategies as S

OUT = Path(r'F:\Leontiev_Project\runs\fast1d')
GLOBAL = json.load(open(OUT / 'calib.json', encoding='utf-8'))['params']


def X_of(r):
    return [r['td'], r['L'] / 6.6, math.log(r['dp']), r['pc'], r['t0'], r['heat']]


if __name__ == '__main__':
    rows = C.data()
    t0 = time.time()
    loo = []
    v0 = [GLOBAL[k] for k in C.NAMES]
    for i, r in enumerate(rows):
        rest = rows[:i] + rows[i + 1:]
        fit = least_squares(C.resid, v0, args=(rest,), bounds=([0.85, 0.2, 0.2, 0.0, 0.1], [1.10, 5, 5, 20, 5]),
                            diff_step=0.05, max_nfev=20)
        o = F.run(r['td'], r['L'], r['dp'], r['pc'], r['t0'], r['heat'], par=dict(zip(C.NAMES, fit.x)))
        loo.append(dict(id=r['id'], eff_cfd=r['eff'], eff_fast=round(o['effect_K'], 3), m_cfd=round(r['m'], 3),
                        m_fast=round(o['m'], 3), work_cfd=r['work'], work_fast=o['working']))
        print(f"{i + 1}/{len(rows)} {r['id']} cfd {r['eff']:.2f} fast {o['effect_K']:.2f} ({time.time() - t0:.0f} s)", flush=True)
    with open(OUT / 'loo.csv', 'w', newline='', encoding='utf-8') as f:
        wr = csv.DictWriter(f, fieldnames=list(loo[0])); wr.writeheader(); wr.writerows(loo)
    X = np.array([X_of(r) for r in rows])
    y = np.array([r['eff'] for r in rows])
    yf = np.array([l['eff_fast'] for l in loo])
    e_fast = yf - y
    # ГП только по CFD и многоуровневая (ГП по невязке), скользящий контроль
    e_gp, e_mf = [], []
    for i in range(len(rows)):
        k = np.arange(len(rows)) != i
        e_gp.append(float(S.gpr(X[k], y[k]).predict(S.z(X[i:i + 1]))[0] - y[i]))
        e_mf.append(float(yf[i] + S.gpr(X[k], (y - yf)[k]).predict(S.z(X[i:i + 1]))[0] - y[i]))
    rm = lambda e: round(float(np.sqrt(np.mean(np.square(e)))), 3)
    w_c = np.array([l['work_cfd'] for l in loo]); w_f = np.array([l['work_fast'] for l in loo])
    lines = ['# Многоуровневая модель: проверка (скользящий контроль по точкам А9, 16.10.2026)', '',
             f'Точек CFD: {len(rows)}; калибровка быстрой модели в каждом шаге — без проверяемой точки.', '',
             '| Модель | RMSE эффекта, K | макс. ошибка, K |', '|---|---|---|',
             f'| Быстрая 1D (калибровка без точки) | {rm(e_fast)} | {np.max(np.abs(e_fast)):.2f} |',
             f'| ГП только по CFD | {rm(e_gp)} | {np.max(np.abs(e_gp)):.2f} |',
             f'| Многоуровневая: быстрая + ГП по невязке | {rm(e_mf)} | {np.max(np.abs(e_mf)):.2f} |', '',
             f'Рабочий/скачок по быстрой модели (без точки): совпадение {100 * np.mean(w_c == w_f):.0f} %.', '']
    # выборка 2000 точек
    rng = np.random.default_rng(20261016)
    s = qmc.LatinHypercube(d=6, seed=rng).random(2000)
    lo = np.array([1.2, 30, math.log(0.5), 0.3, -10, 0]); hi = np.array([1.6, 100, math.log(139), 1.6, 20, 20])
    P = lo + s * (hi - lo)
    corr = S.gpr(X, y - np.array([F.run(r['td'], r['L'], r['dp'], r['pc'], r['t0'], r['heat'], par=GLOBAL)['effect_K'] for r in rows]))
    t1 = time.time()
    out = []
    for p in P:
        o = F.run(p[0], p[1] * 6.6, math.exp(p[2]), p[3], p[4], p[5], par=GLOBAL)
        c, sd = corr.predict(S.z(p[None, :]), return_std=True)
        out.append(dict(t_d=round(p[0], 4), L_d=round(p[1], 2), L_mm=round(p[1] * 6.6, 1), dp_dzv_kPa=round(math.exp(p[2]), 3),
                        p_cons=round(p[3], 4), t0_dzv=round(p[4], 3), heater=round(p[5], 3), m_fast=round(o['m'], 4),
                        Q_fast=round(o['Q'], 1), effect_fast=round(o['effect_K'], 3), dT_dzv_fast=round(o['dT_dzv_K'], 3),
                        working_fast=o['working'], effect_mf=round(o['effect_K'] + float(c[0]), 3), effect_mf_sd=round(float(sd[0]), 3),
                        in_m_range=int(0.2 <= o['m'] <= 1.0)))
    with open(OUT / 'fast_2000.csv', 'w', newline='', encoding='utf-8') as f:
        wr = csv.DictWriter(f, fieldnames=list(out[0])); wr.writeheader(); wr.writerows(out)
    lines += [f'Выборка быстрой модели: 2000 точек за {(time.time() - t1) / 60:.1f} мин (fast_2000.csv); '
              f'в проверенной области m 0,2–1,0: {sum(o["in_m_range"] for o in out)}; рабочих по быстрой модели: {sum(o["working_fast"] for o in out)}.']
    (OUT / 'mf_summary.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))
