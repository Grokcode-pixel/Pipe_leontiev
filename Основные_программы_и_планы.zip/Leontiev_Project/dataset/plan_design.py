"""29.10.2026 — решение автора: новые серии собираются по методу работы (положение 2: «план по гиперкубу, потом адресное
пополнение»), не вручную. Здесь — планы трёх серий; раннеры читают их из runs\\plans\\*.json.
 1) Сопло (D-26): срезанный латинский гиперкуб (Qian 2012; Ba et al. 2015; make_a9_design.sliced_lhs, максимин) — срезы =
    сопло (A/A* 1,44 / 2,15 / 2,92) × длина (L 200 / 400 мм; добавленные точки с L 200 по решению автора), по 3 режима в срезе:
    каждый срез — ЛГК, объединение 18 точек — ЛГК по 4 режимным факторам; t/d 1,4.
 2) A3a: новые трубы — в наибольшие пробелы по (t/d, L) среди 16 рассчитанных геометрий (последовательный максимин в нормированных
    координатах); режимы — срезанный ЛГК (срез = труба, по 3 режима).
 3) Полная серия по накатке (только если разведка покажет выгоду): 9 вариантов «высота × шаг» — ЛГК с максимином в пределах
    Калинина — Дрейцера — Ярхо для зазора ячейки t/d 1,4 (D_г ≈ 5,9 мм: шаг 0,25–0,5 D_г = 1,5–3,0 мм; высота 1,5–5 % D_г = 0,09–0,30 мм).
Режимные факторы (правило автора — перепад ДЗВ ≥ 15 кПа): ln перепада ДЗВ 15–60 кПа, давление магистрали 3,0–5,5 МПа,
давление потребителя 0,4–1,0 МПа, T газа −5…+15 °C. Вывод: runs\\plans\\*.json и plans.md."""
import json, math
from pathlib import Path
import numpy as np
from scipy.stats import qmc
from make_a9_design import sliced_lhs

OUT = Path(r'F:\Leontiev_Project\runs\plans'); OUT.mkdir(parents=True, exist_ok=True)
SEED = 20261029
REG = (('dp', math.log(15.0), math.log(60.0), True), ('pm', 3.0, 5.5, False), ('pc', 0.4, 1.0, False), ('t0', -5.0, 15.0, False))


def to_regime(u):
    out = {}
    for (k, lo, hi, lg), v in zip(REG, u):
        x = lo + (hi - lo) * v
        out[k] = round(math.exp(x), 1) if lg else round(x, 2)
    return out


def nozzle_plan(rng):
    slices = [(noz, ar, re_, L) for noz, ar, re_ in (('NZ144', 1.44, 2.70), ('NZ215', 2.15, 3.30), ('NZ292', 2.92, 3.843))
              for L in (200.0, 400.0)]
    x, dmin = sliced_lhs(len(slices), 3, 4, rng)
    pts = []
    for s, (noz, ar, re_, L) in enumerate(slices):
        for k in range(3):
            pts.append(dict(id=f'{noz}_L{int(L)}_{k + 1}', nozzle=noz, ar=ar, r_exit=re_, td=1.4, L=L, **to_regime(x[s * 3 + k])))
    return dict(plan='срезанный ЛГК (Qian 2012; Ba 2015), максимин; срезы — сопло × L, по 3 режима', min_dist=float(dmin), points=pts)


def a3a_plan(rng, existing):
    lo, hi = np.array([1.2, 200.0]), np.array([1.6, 660.0])
    E = (np.array(existing) - lo) / (hi - lo)
    cand = np.array([(t, L) for t in np.arange(1.2, 1.6001, 0.025) for L in np.arange(200, 660.1, 10)])
    C = (cand - lo) / (hi - lo)
    chosen = []
    for _ in range(3):   # последовательный максимин: точка, наиболее удалённая от рассчитанных и уже выбранных
        ref = np.vstack([E] + ([np.array(chosen)] if chosen else []))
        d = np.sqrt(((C[:, None] - ref[None]) ** 2).sum(-1)).min(1)
        chosen.append(C[int(np.argmax(d))])
    geos = [tuple(np.round(lo + c * (hi - lo), 3)) for c in chosen]
    x, dmin = sliced_lhs(3, 3, 4, rng)
    pts = []
    for s, (td, L) in enumerate(geos):
        for k in range(3):
            pts.append(dict(id=f'N{s + 1}_{k + 1}', td=float(td), L=float(L), **to_regime(x[s * 3 + k])))
    return dict(plan='трубы — последовательный максимин в пробелах (t/d, L); режимы — срезанный ЛГК (срез = труба, по 3)',
                min_dist=float(dmin), geometries=[list(map(float, g)) for g in geos], points=pts)


def knurl_plan(rng):
    best, bd = None, -1
    for _ in range(400):   # ЛГК 9 точек с максимином
        u = qmc.LatinHypercube(d=2, seed=rng).random(9)
        d = min(np.linalg.norm(a - b) for i, a in enumerate(u) for b in u[i + 1:])
        if d > bd:
            best, bd = u, d
    pts = [dict(id=f'KL{i + 1}', h=round(0.09 + 0.21 * u[0], 3), pitch=round(1.5 + 1.5 * u[1], 2)) for i, u in enumerate(best)]
    return dict(plan='ЛГК 9 точек, максимин; Калинин — Дрейцер — Ярхо для D_г ≈ 5,9 мм (h 0,09–0,30, шаг 1,5–3,0 мм)',
                min_dist=float(bd), points=pts)


if __name__ == '__main__':
    import model_compare as MC
    X, y, w, g, src = MC.load()
    existing = sorted({(round(a[0], 3), round(a[1] * 6.6, 1)) for a in X})
    rng = np.random.default_rng(SEED)
    plans = {'nozzle': nozzle_plan(rng), 'a3a': a3a_plan(rng, existing), 'knurl_full': knurl_plan(rng)}
    L = ['# Планы новых серий (метод работы: ЛГК / срезанный ЛГК / максимин)', '']
    for k, p in plans.items():
        (OUT / f'{k}.json').write_text(json.dumps(p, ensure_ascii=False, indent=1), encoding='utf-8')
        L += [f'## {k}: {p["plan"]} (мин. расстояние {p["min_dist"]:.3f})', '']
        if 'geometries' in p:
            L.append('Трубы: ' + '; '.join(f't/d {a}, L {b:.0f}' for a, b in p['geometries']) +
                     f'. Рассчитанные геометрии: {len(existing)}.')
            L.append('')
        keys = [k2 for k2 in p['points'][0] if k2 != 'id']
        L += ['| ' + ' | '.join(['id'] + keys) + ' |', '|' + '---|' * (len(keys) + 1)]
        L += ['| ' + ' | '.join([q['id']] + [str(q[k2]) for k2 in keys]) + ' |' for q in p['points']]
        L.append('')
    (OUT / 'plans.md').write_text('\n'.join(L), encoding='utf-8')
    print('\n'.join(L))
