"""31.10.2026 — сутки без автора, п. 6: полный цикл на Fluent. Новая задача (лето, магистраль 4,5 МПа, потребитель 1,2 МПа):
система сама заказывает расчёты Fluent до «выдать». Цикл — на КОПИИ модели в памяти (после каждого расчёта ГП и классификатор
дообучаются копией; файлы обучения и FREEZE.json не меняются); итоговые числа — по замороженной модели. Каждый расчёт — одна
попытка; точки вне Ω и с перепадом < 5 кПа не считаются (цикл останавливается с записью). Не больше 6 расчётов.
Итог: runs\\cycle\\полный_цикл.md, запись в журнал решений, строка в Журнал_работ.md."""
import contextlib, io, json, math, sys, time
from pathlib import Path
import numpy as np
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
sys.path.insert(0, r'F:\Leontiev_Project\program')

OUT = Path(r'F:\Leontiev_Project\runs\cycle')
MAX_CALC = 6


WINTER = 'zima' in sys.argv[1:]   # 01.11 (D-33, п. 5): зима — газ −5 °C, магистраль 4,0 МПа, потребитель 1,0 МПа, на выходе ≥ 0 °C


def card():
    import sppr, gui_task as GT
    if WINTER:
        return sppr.TaskCard(title='Полный цикл: зима, газ −5 °C, магистраль 4,0 МПа, потребитель 1,0 МПа', p_main=4.0, T_main=-5.0, flow_nm3h=5000.0,
                             p_cons=1.0, T_min=0.0, kinds=['гладкий'], geometries=GT.geometries(GT.models()), dp_kPa=list(GT.DP_LIST),
                             heater_place=['до сопел', 'после'], dzv_to='СПГ', goal='min топлива')
    return sppr.TaskCard(title='Полный цикл: лето, магистраль 4,5 МПа, потребитель 1,2 МПа', p_main=4.5, T_main=15.0, flow_nm3h=5000.0, p_cons=1.2,
                         T_min=-10.0, kinds=['гладкий'], geometries=GT.geometries(GT.models()), dp_kPa=list(GT.DP_LIST),
                         heater_place=['до сопел', 'после'], dzv_to='СПГ', goal='min топлива')


def refit(M, x, y4, w):
    """Копия модели в памяти: точка Fluent добавляется в ГП (эффект, Q, расходы) и классификатор."""
    import model_compare as MC
    import classifier_final as CF
    G, H = M.G, M.H
    G.X = np.vstack([G.X, x]); G.T = np.vstack([G.T, y4])
    G.lo, G.hi = G.X.min(0), G.X.max(0)
    G.GP = [MC.gp_fit(G.Z(G.X), G.T[:, j]) for j in range(4)]
    M.lo, M.hi = G.lo, G.hi
    CF.X = np.vstack([CF.X, x]); CF.w = np.append(CF.w, w)
    fr, fc, pr, pc = MC.models()[M.clf]
    M.cb = fc(H.Z(CF.X), CF.w)
    M.done_X = np.vstack([M.done_X, x]); M.done_w = np.append(M.done_w, w)
    M.n_train += 1


def main():
    import sppr, job_point as JP, d12a
    OUT.mkdir(parents=True, exist_ok=True)
    c = card()
    M = sppr.Models()
    A = JP.setup(dict(tube='гладкая', mesh=None, base=str(OUT), csv='cycle_results.csv'))
    A.qlog('=== полный цикл на Fluent (п. 6) — начат')
    log, n_calc = [], 0
    with contextlib.redirect_stdout(io.StringIO()):
        base, rows = sppr.evaluate(c, M); d0 = sppr.decide(c, M, base, rows)
    first = dict(status=d0['status'], cat=d0.get('cat'), best=sppr.fmt(d0['best']) if d0.get('best') else '—', N=(d0.get('best') or {}).get('N'))
    d = d0
    while True:
        b = d.get('best')
        log.append(dict(step=n_calc, status=d['status'], cat=d.get('cat'), why=d['why'][:300], best=sppr.fmt(b) if b else '—', N=b['N'] if b else None,
                        lng=b['lng'] if b else None, n_train=M.n_train))
        if d['rule'] == 'П3' or d['rule'] == 'П1' or n_calc >= MAX_CALC:
            break
        cc = d.get('calc') or b
        p = dict(tag=f'CY{n_calc + 1:02d}', td=cc['td'], L=cc['L'], dp=float(cc['dp']), pc=c.p_cons, T=c.T_main,
                 heat=float(cc.get('heat') or 0.0) if cc['z'] == 'до сопел' else 0.0, pm=c.p_main)
        o = M.predict(p['td'], p['L'], p['dp'], p['pc'], p['T'], p['heat'], p['pm'])
        if not (0.2 <= o['m'] <= 0.96) or p['dp'] < 5.0:
            log.append(dict(step=n_calc, status='стоп', why=f"предложенная точка вне правил (m {o['m']:.2f}, перепад {p['dp']} кПа) — не считается")); break
        log[-1].update(calc=dict(p, forecast=o['effect_K'], sigma=o['sigma_K'], m=o['m'], p=o['p']))
        A.log(f"=== {p['tag']} (полный цикл): {sppr.fmt(cc)}; прогноз до расчёта {o['effect_K']:+.2f} ± {o['sigma_K']:.2f} K, m {o['m']:.2f}, p {o['p']:.3f}")
        try:
            dd = JP.run_point(A, dict(tube='гладкая', mesh=None), p, None)
        except Exception as ex:
            A.log(f'  {p["tag"]}: ОШИБКА программы {ex!r}'); dd = None
        n_calc += 1
        e = d12a.evaluate(dd) if dd else {}
        ok = bool(dd) and (A.converged(dd) or bool(e.get('ok')))
        import csv
        row = next((r for r in reversed(list(csv.DictReader(open(A.CSV, encoding='utf-8')))) if dd and r['tag'] == dd.name), None) if A.CSV.exists() else None
        log[-1]['calc'].update(fluent=e.get('effect'), ok=ok, shock=bool(row and row.get('x_shock_m')))
        if not ok or e.get('effect') is None:
            log.append(dict(step=n_calc, status='стоп', why=f"{p['tag']}: расчёт не сошёлся — цикл остановлен (одна попытка)")); break
        refit(M, np.array([o['x']]), np.array([[e['effect'], e['Q'], e['G_svz'], e['G_dzv']]]), 0 if log[-1]['calc']['shock'] else 1)
        with contextlib.redirect_stdout(io.StringIO()):
            base, rows = sppr.evaluate(c, M); d = sppr.decide(c, M, base, rows)
    L = [f'# Полный цикл на Fluent: {c.title} ({time.strftime("%d.%m.%Y %H:%M")})', '',
         f'Газ {c.T_main:+g} °C, {c.flow_nm3h:.0f} м³/ч при стандартных условиях (20 °C), T потребителю ≥ {c.T_min:+.0f} °C, СПГ, цель — min топлива. '
         'Цикл — на копии модели (файлы обучения не меняются); итоговые числа — по замороженной.', '',
         f"Замороженная модель (до цикла): **{first['status']}** ({first['cat']}); лучший — {first['best']}" + (f", {first['N']:.1f} кВт" if first['N'] is not None else '') + '.', '',
         '| шаг | статус | лучший вариант | топливо, кВт | расчёт Fluent: прогноз → факт, K |', '|---|---|---|---|---|']
    for s in log:
        cl = s.get('calc')
        L.append(f"| {s['step']} | {s['status']} ({s.get('cat', '')}) | {s.get('best', '')} | {'' if s.get('N') is None else round(s['N'], 1)} | " +
                 (f"{cl['tag']}: {cl['forecast']:+.2f} ± {cl['sigma']:.2f} → {cl.get('fluent') if cl.get('fluent') is None else round(cl['fluent'], 2)}"
                  f"{' (не сошёлся)' if not cl.get('ok') else ''}" if cl else s.get('why', '')) + ' |')
    final = log[-1]
    L += ['', f"**Расчётов Fluent до решения: {n_calc}**; итог цикла — {final['status']}."]
    (OUT / ('полный_цикл_зима.md' if WINTER else 'полный_цикл.md')).write_text('\n'.join(L) + '\n', encoding='utf-8')
    with open(sppr.JOURNAL, 'a', encoding='utf-8') as f:
        f.write('\n## Полный цикл на Fluent (сутки без автора, п. 6; копия модели)\n\n' + '\n'.join(L[2:]) + '\n')
    with open(r'F:\Leontiev_Project\Журнал_работ.md', 'a', encoding='utf-8') as f:
        f.write(f"- {time.strftime('%d.%m.%Y %H:%M')} — полный цикл на Fluent (п. 6): расчётов до решения {n_calc}, итог — {final['status']} (runs\\cycle\\полный_цикл.md)\n")
    A.qlog(f'=== полный цикл — закончен: {n_calc} расчётов, {final["status"]}')


if __name__ == '__main__':
    main()
