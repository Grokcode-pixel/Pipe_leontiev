"""Труба Леонтьева — окно запуска расчёта (геометрия -> сетка -> Fluent) с живыми результатами.
Запуск:  python F:\\Leontiev_Project\\dataset\\leontiev_gui.py"""
import json, os, queue, sys, threading, time
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import gui_runner as G

FIELDS = [   # (group, key, label, unit)
    ('Геометрия', 'r_end_mm', 'Радиус канала СВЗ на конце r_end', 'мм'),
    ('Геометрия', 'l_heat_mm', 'Длина теплообменного участка', 'мм'),
    ('Геометрия', 'gap_mm', 'Зазор ДЗВ (ширина кольцевого канала)', 'мм'),
    ('Геометрия', 'neck_ratio', 'Шейка выхода / r_end (0,8 = G4; 0,95 = n95)', '—'),
    ('Геометрия', 'r_nozzle_exit_mm', 'Радиус среза сопла (горло 2,25 мм)', 'мм'),
    ('Сетка', 'axial_size_mm', 'Шаг сетки по длине (0,5 мелкая, 1,0 грубая)', 'мм'),
    ('Сетка', 'convergent_div', 'Делений в конфузоре', 'шт'),
    ('Режим', 'p0_svz_MPa', 'СВЗ: полное давление на входе', 'МПа'),
    ('Режим', 'p_out_svz_MPa', 'СВЗ: статическое давление на выходе', 'МПа'),
    ('Режим', 'p0_dzv_MPa', 'ДЗВ: полное давление на входе', 'МПа'),
    ('Режим', 'p_out_dzv_MPa', 'ДЗВ: статическое давление на выходе', 'МПа'),
    ('Решатель', 'prt', 'Турбулентное число Прандтля Prt', '—'),
    ('Решатель', 'ramp_steps', 'Ступеней подъёма давления (минимум)', 'шт'),
    ('Решатель', 'step_ratio', 'Рост давления за ступень (1,15 = +15 %)', '—'),
    ('Решатель', 'ramp_iters', 'Итераций на ступень', 'шт'),
    ('Решатель', 'report_every', 'Отчёт каждые … итераций', 'шт'),
    ('Решатель', 'retries', 'Повторов при расхождении', 'шт'),
    ('Решатель', 'simple_iters', 'Итераций SIMPLE после подъёма', 'шт'),
    ('Решатель', 'coupled_iters', 'Максимум итераций coupled', 'шт'),
    ('Решатель', 'cfl', 'CFL (coupled)', '—'),
    ('Решатель', 'threads', 'Ядер Fluent', 'шт'),
]
PRESETS = {
    'n95 — патентный режим (СВЗ 5,5→0,3; ДЗВ 5,5→5,2)': {},
    'n95 — максимум охлаждения (ДЗВ 5,5→5,45)': dict(p_out_dzv_MPa=5.45),
    'n95 — режим ГРС (СВЗ 1,6→0,3; ДЗВ 5,5→5,2)': dict(p0_svz_MPa=1.6),
    'G4 — исходная геометрия, режим ГРС': dict(neck_ratio=0.8, p0_svz_MPa=1.6),
    'Патент: короткая труба 12 калибров (~115 мм)': dict(l_heat_mm=115.0),
}
CRIT_HINT = 'Строгие критерии: continuity ≤ 1e-4, |Δm| < 1 %, |энергия| ≤ 0,1 Вт, дрейф < 0,02 K, y+ ≤ 1'


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Труба Леонтьева — расчёт')
        self.geometry('1180x760')
        self.state('zoomed')   # full screen: the form is tall on scaled (125–150 %) displays
        self.q = queue.Queue(); self.worker = None; self.stop = False; self.out = None
        self.vars = {}
        left = ttk.Frame(self, padding=8); left.pack(side='left', fill='y')
        right = ttk.Frame(self, padding=8); right.pack(side='left', fill='both', expand=True)

        ttk.Label(left, text='Пресет:').pack(anchor='w')
        self.preset = ttk.Combobox(left, values=list(PRESETS), state='readonly', width=58)
        self.preset.pack(anchor='w', pady=(0, 6)); self.preset.bind('<<ComboboxSelected>>', self.apply_preset)
        row = ttk.Frame(left); row.pack(anchor='w', fill='x')
        ttk.Label(row, text='Имя расчёта:').pack(side='left')
        self.vars['run_id'] = tk.StringVar(value=self.next_id()); ttk.Entry(row, textvariable=self.vars['run_id'], width=18).pack(side='left', padx=4)
        b = ttk.Frame(left); b.pack(fill='x', pady=6)   # buttons on top: never cut off on scaled screens
        self.btn_start = ttk.Button(b, text='▶  Старт', command=self.start); self.btn_start.pack(side='left')
        self.btn_stop = ttk.Button(b, text='■  Стоп', command=self.do_stop, state='disabled'); self.btn_stop.pack(side='left', padx=6)
        ttk.Button(b, text='Папка расчёта', command=self.open_dir).pack(side='left')
        w = ttk.Frame(left); w.pack(fill='x', pady=(0, 6))   # watch any run, also those started by a series script
        ttk.Label(w, text='Наблюдать за:').pack(side='left')
        self.watch = ttk.Combobox(w, state='readonly', width=22, postcommand=self.fill_watch)
        self.watch.pack(side='left', padx=4); self.watch.bind('<<ComboboxSelected>>', self.select_watch)
        self.fill_watch()
        if self.watch['values']:   # show the newest run right away (e.g. one started by a series script)
            self.watch.current(0); self.after(300, self.select_watch)

        group = None
        for g, key, label, unit in FIELDS:
            if g != group:
                group = g; lf = ttk.LabelFrame(left, text=g, padding=4); lf.pack(fill='x', pady=3)
            r = ttk.Frame(lf); r.pack(fill='x')
            ttk.Label(r, text=label, width=44).pack(side='left')
            v = tk.StringVar(value=str(G.DEFAULTS[key])); self.vars[key] = v
            ttk.Entry(r, textvariable=v, width=9).pack(side='left')
            ttk.Label(r, text=unit, width=4).pack(side='left')
        self.reuse = tk.BooleanVar(value=False); self.wait = tk.BooleanVar(value=True); self.soft = tk.BooleanVar(value=True)
        self.auto_stop = tk.BooleanVar(value=True)
        ttk.Checkbutton(left, text='Автостоп: критерии сходимости 2 проверки подряд (y+ — только флаг)', variable=self.auto_stop).pack(anchor='w')
        ttk.Checkbutton(left, text='Мягкий старт (без интерполяции G4, для датасета)', variable=self.soft).pack(anchor='w')
        ttk.Checkbutton(left, text='Использовать готовую сетку с таким именем', variable=self.reuse).pack(anchor='w')
        ttk.Checkbutton(left, text='Ждать, пока освободится Fluent', variable=self.wait).pack(anchor='w')

        self.info = ttk.Label(right, text='Готов к запуску.', font=('Segoe UI', 11, 'bold')); self.info.pack(anchor='w')
        lf = ttk.LabelFrame(right, text='Текущие результаты (по отчётам)', padding=4); lf.pack(fill='x', pady=4)
        self.res = {}
        for i, (k, t) in enumerate([('iter', 'Итерация'), ('dT_svz', 'ΔT СВЗ, K (нагрев)'), ('dT_dzv', 'ΔT ДЗВ, K (охлаждение)'),
                                    ('Q', 'Q через стенку, Вт'), ('m', 'Расход СВЗ / ДЗВ, кг/с'), ('ratio', 'G_дз / G_сз'),
                                    ('dm', 'Дисбаланс массы СВЗ, %'), ('net', 'Дисбаланс энергии, Вт'), ('yp', 'y+ СВЗ / ДЗВ')]):
            ttk.Label(lf, text=t, width=26).grid(row=i // 3, column=(i % 3) * 2, sticky='w')
            v = ttk.Label(lf, text='—', width=16, font=('Consolas', 11)); v.grid(row=i // 3, column=(i % 3) * 2 + 1, sticky='w')
            self.res[k] = v
        cf = ttk.LabelFrame(right, text='Сходимость', padding=4); cf.pack(fill='x', pady=4)
        self.crit = ttk.Label(cf, text=CRIT_HINT, justify='left', font=('Consolas', 10)); self.crit.pack(anchor='w')
        pf = ttk.LabelFrame(right, text='Ход работ (этапы задания; файл progress.json)', padding=4); pf.pack(fill='x', pady=4)
        self.prog = ttk.Label(pf, text='—', justify='left', font=('Consolas', 9)); self.prog.pack(anchor='w')
        hf = ttk.LabelFrame(right, text='История ΔT (последние отчёты)', padding=4); hf.pack(fill='both', expand=True, pady=4)
        self.hist = tk.Canvas(hf, height=180, bg='white'); self.hist.pack(fill='both', expand=True)
        lg = ttk.LabelFrame(right, text='Журнал', padding=4); lg.pack(fill='both', expand=True)
        self.log = tk.Text(lg, height=9, font=('Consolas', 9)); self.log.pack(fill='both', expand=True)
        self.after(500, self.tick)

    def next_id(self):
        n = 1
        while (G.RUNS / f'run{n:02d}').exists():
            n += 1
        return f'run{n:02d}'

    def apply_preset(self, _=None):
        p = dict(G.DEFAULTS); p.update(PRESETS[self.preset.get()])
        for _, key, _, _ in FIELDS:
            self.vars[key].set(str(p[key]))

    def params(self):
        p = dict(G.DEFAULTS)
        for _, key, label, _ in FIELDS:
            s = self.vars[key].get().replace(',', '.').strip()
            try:
                p[key] = float(s)
            except ValueError:
                raise ValueError(f'Неверное число: {label} = "{s}"')
        p['run_id'] = self.vars['run_id'].get().strip() or self.next_id()
        p['reuse_mesh'] = self.reuse.get(); p['wait_free'] = self.wait.get(); p['soft_start'] = self.soft.get()
        p['auto_stop'] = self.auto_stop.get()
        if any(p[k] < 1 or p[k] != int(p[k]) for k in ('ramp_steps', 'ramp_iters', 'report_every', 'coupled_iters', 'threads')):
            raise ValueError('Итерации, ступени, интервал отчёта и число ядер — целые числа не меньше 1.')
        if p['step_ratio'] <= 1:
            raise ValueError('Рост давления за ступень должен быть больше 1.')
        if p['p_out_svz_MPa'] >= p['p0_svz_MPa'] or p['p_out_dzv_MPa'] >= p['p0_dzv_MPa']:
            raise ValueError('Давление на выходе должно быть меньше давления на входе.')
        if not 0.5 <= p['neck_ratio'] <= 1.0:
            raise ValueError('Шейка / r_end: допустимо 0,5–1,0.')
        return p

    def start(self):
        try:
            p = self.params()
        except ValueError as e:
            return messagebox.showerror('Параметры', str(e))
        if (G.RUNS / p['run_id'] / 'axis.csv').exists() and not messagebox.askyesno('Имя занято', 'Расчёт с таким именем уже есть. Перезаписать?'):
            return
        self.stop = False; self.out = G.RUNS / p['run_id']
        self.btn_start['state'] = 'disabled'; self.btn_stop['state'] = 'normal'
        self.msg(f"Старт {p['run_id']}: " + json.dumps({k: p[k] for _, k, _, _ in FIELDS}, ensure_ascii=False))
        self.worker = threading.Thread(target=self.work, args=(p,), daemon=True); self.worker.start()

    def work(self, p):
        try:
            G.run(p, lambda s: self.q.put(s), lambda: self.stop)
        except Exception as e:
            self.q.put(f'ОШИБКА: {e!r}')
        self.q.put('__done__')

    def do_stop(self):
        if messagebox.askyesno('Стоп', 'Остановить расчёт и закрыть его окно Fluent?'):
            self.stop = True; self.msg('Остановка…')

    ROOTS = ('gui', 'a2', 'ref085', 'a3', 'a4', 'a5', 'a6', 'night', 'day0909', 'a5v3')   # 09.10: + day queue, A5 v3   # runs\gui (window, series A1), runs\a2 (calibration A2), runs\a3 (mesh A3)

    def fill_watch(self):
        base = G.RUNS.parent
        runs = [d for r in self.ROOTS if (base / r).exists() for d in (base / r).iterdir()
                if d.is_dir() and not d.name.startswith('_')]
        runs.sort(key=lambda d: max([f.stat().st_mtime for f in d.glob('*.trn')] or [d.stat().st_mtime]), reverse=True)
        self.watch['values'] = [f'{d.parent.name}/{d.name}' for d in runs]

    def follow_newest(self):
        """Series scripts start new runs: switch to the newest run dir unless the user picked one by hand."""
        if getattr(self, 'manual_watch', False) or str(self.btn_stop['state']) == 'normal':
            return
        self.fill_watch()
        vals = self.watch['values']
        if vals and (self.out is None or f'{self.out.parent.name}/{self.out.name}' != vals[0]):
            self.watch.current(0); self.select_watch(auto=True)

    def select_watch(self, _=None, auto=False):
        if _ is not None:
            self.manual_watch = True
        self.out = G.RUNS.parent / self.watch.get()
        self.info['text'] = f'Наблюдаю за расчётом {self.watch.get()}'
        self.show(G.status(self.out))

    def open_dir(self):
        d = self.out or G.RUNS
        d.mkdir(parents=True, exist_ok=True); os.startfile(str(d))

    def msg(self, s):
        self.log.insert('end', time.strftime('%H:%M:%S ') + s + '\n'); self.log.see('end')

    def tick(self):
        while not self.q.empty():
            s = self.q.get()
            if s == '__done__':
                self.btn_start['state'] = 'normal'; self.btn_stop['state'] = 'disabled'
                self.vars['run_id'].set(self.next_id())
                if not self.info['text'].startswith(('ОШИБКА', 'Останов')):
                    self.info['text'] = 'Расчёт завершён.'
            else:
                self.msg(s); self.info['text'] = s[:110]
        try:
            self.follow_newest()
        except Exception:
            pass
        if self.out is not None and str(self.btn_stop['state']) != 'normal':
            try:   # run started elsewhere (series script): show its own messages in the journal pane
                lines = G.run_log_lines(self.out)
                text = '\n'.join(lines) + '\n'
                if text != getattr(self, '_shown_log', None):
                    self._shown_log = text
                    self.log.delete('1.0', 'end'); self.log.insert('end', text); self.log.see('end')
            except Exception:
                pass
        if self.out is not None:
            try:
                self.show(G.status(self.out))
            except Exception:
                pass
        try:
            self.show_progress()
        except Exception as e:
            self.prog['text'] = f'progress.json: {e!r}'
        self.after(15000, self.tick)

    def show_progress(self):
        """Stage list from progress.json (kept up to date by the assistant) + live count of the current series."""
        import re
        root = G.RUNS.parent.parent
        pj = json.loads((root / 'progress.json').read_text(encoding='utf-8'))
        mark = {'done': '✔', 'active': '▶', 'todo': '·'}
        st_lines = [f"{mark.get(s['state'], '·')} {s['id']:7s} {s['name']}" for s in pj['stages']]
        half = (len(st_lines) + 1) // 2      # two columns to keep the panel short
        lines = [f"{a:46s}  {b}" for a, b in zip(st_lines[:half], st_lines[half:] + [''])]
        left_days = sum(s.get('days', 0) for s in pj['stages'] if s['state'] != 'done')
        cur = pj.get('current')
        if cur:
            log = root / cur['log']
            txt = log.read_text(encoding='utf-8', errors='replace') if log.exists() else ''
            # count results only after the last start of this series in the log
            done = len(re.findall(cur['pattern'], txt, re.M))   # '^' in the pattern = start of a log line (08.10)
            total = int(cur['total'])
            rem_h = max(total - done, 0) * cur.get('minutes_each', 30) / 60
            lines += ['', f"Сейчас: {cur['title']}", f"  готово {done} из {total}, осталось ≈ {rem_h:.1f} ч"]
        lines += [f"Осталось по плану ≈ {left_days:.0f} дн. (оценка)", f"обновлено: {pj.get('updated', '')}"]
        self.prog['text'] = '\n'.join(lines)

    def show_criteria(self, st=None):
        """Always list the auto-stop criteria with thresholds; values appear after two closed reports.
        The continuity residual is shown live (written by Fluent every iteration)."""
        c = G.criteria_out(self.out) if self.out is not None else {}
        live = ''
        if st and st.get('iter'):
            cont = st.get('continuity')
            live = f"\nживая невязка continuity на итерации {st['iter']}: {cont:.3g}" if cont == cont else ''
        if c:
            self.crit['text'] = '\n'.join(
                (f"·  {k:48s} сейчас — (нужен 2-й отчёт)" if v is None
                 else f"·  {k:48s} сейчас {v:.3g}" if ok is None
                 else f"{'✔' if ok else '✘'}  {k:48s} сейчас {v:.3g}")
                for k, (v, ok) in c.items()) + live
        else:
            names = list(G.LABELS.values()) + ['y+, — (порог ≤ 1; только флаг сетки)']
            nxt = 1000 if not st or st.get('iter', 0) < 1000 else 1500
            self.crit['text'] = '\n'.join(f"·  {k:48s} сейчас —" for k in names) + \
                f"\n(первый отчёт на итерации 1000, оценка критериев с итерации 1500; ждём {nxt}){live}"

    def show(self, st):
        self.show_criteria(st)
        if not st:
            return
        self.res['iter']['text'] = f"{st['iter']}"
        if str(self.btn_stop['state']) == 'normal':
            self.info['text'] = f"{st['stage']} — итерация {st['iter']}" + (f" — вход СВЗ {st['p_svz']:.2f} МПа" if st.get('p_svz') else '')
        if not st['samples']:
            return
        b = st['samples'][-1]
        self.res['dT_svz']['text'] = f"{b['dT_svz']:+.2f}"; self.res['dT_dzv']['text'] = f"{b['dT_dzv']:+.2f}"
        self.res['Q']['text'] = f"{b['Q']:.0f}"; self.res['m']['text'] = f"{b['m_svz']:.4f} / {b['m_dzv']:.4f}"
        self.res['ratio']['text'] = f"{b['ratio']:.3f}"; self.res['dm']['text'] = f"{b['dm']:+.2f}"
        self.res['net']['text'] = f"{b['net']:+.2f}"; self.res['yp']['text'] = f"{b['yp_svz']:.2f} / {b['yp_dzv']:.2f}"
        self.draw(st['samples'][-40:])

    def draw(self, s):
        cv = self.hist; cv.delete('all')
        w, h = max(cv.winfo_width(), 300), max(cv.winfo_height(), 120)
        vals = [x['dT_svz'] for x in s] + [x['dT_dzv'] for x in s] + [0]
        lo, hi = min(vals), max(vals); hi = hi if hi > lo else lo + 1
        y = lambda v: h - 15 - (v - lo) / (hi - lo) * (h - 30)
        cv.create_line(40, y(0), w - 10, y(0), fill='#bbb', dash=(3, 3))
        for key, col, name in (('dT_svz', '#c0392b', 'ΔT СВЗ'), ('dT_dzv', '#2471a3', 'ΔT ДЗВ')):
            pts = []
            for i, x in enumerate(s):
                pts += [40 + i * (w - 50) / max(len(s) - 1, 1), y(x[key])]
            if len(pts) >= 4:
                cv.create_line(*pts, fill=col, width=2)
            cv.create_text(w - 10, y(s[-1][key]) - 8, text=f'{name} {s[-1][key]:+.2f}', anchor='e', fill=col)
        cv.create_text(5, y(hi), text=f'{hi:+.1f}', anchor='w'); cv.create_text(5, y(lo), text=f'{lo:+.1f}', anchor='w')


if __name__ == '__main__':
    App().mainloop()
