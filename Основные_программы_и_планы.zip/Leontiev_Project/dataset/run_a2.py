"""Stage A2: calibration by the recovery factor r on an adiabatic wall (task A2).
n95 geometry, patent regime (case runs\\var_n95\\pat55c), wall between channels made adiabatic (brass k = 1e-5),
Prt 0.85 / 0.90 / 0.75 / 0.65 applied through the Viscous dialog OK, coupled with auto-stop, then
r(x) = (T_wall - T) / (T0 - T) on the steady supersonic part, T and T0 taken on the axis at the same x.
usage: python run_a2.py [prt ...]       results: runs\\a2\\a2_results.csv, log runs\\a2\\a2_log.txt"""
import csv, json, math, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import leontiev_pipeline as L
import gui_runner as G
import gui_convergence as C
from make_gui_prt_journal import GUI_PRT

BASE = Path(r'F:\Leontiev_Project\runs\a2')
CASE = r'F:/Leontiev_Project/runs/var_n95/pat55c.cas.h5'
WALL = 'wall-air_svz-wall_abonite-contact_region-src'   # gas side of the SVZ wall (interface zone holds the data)
L_CH = 0.400
R_EXP, R_TOL = 0.885, 0.015
COUPLED_LIMIT = 5500


def log(s):
    line = time.strftime('%H:%M:%S ') + s
    print(line, flush=True)
    with (BASE / 'a2_log.txt').open('a', encoding='utf-8') as f:
        f.write(line + '\n')


def journal(prt, out):
    q = L.fl(out)
    p = dict(coupled_iters=COUPLED_LIMIT, report_every=500, cfl=20.0)
    lines = ['/file/confirm-overwrite? no', f'/file/start-transcript "{q}/run.trn"', f'/file/read-case-data "{CASE}"']
    lines += [g.format(prt=prt) for g in GUI_PRT]
    lines += ['/define/materials/change-create latun latun no no yes constant 1e-05',   # adiabatic wall
              '/define/materials/list-properties latun']
    lines += C.coupled_journal(p, out)
    lines += [f'/file/write-case-data "{q}/result.cas.h5"',
              f'/file/export/ascii "{q}/axis.csv" axis () yes mach-number pressure total-pressure temperature '
              'total-temperature axial-velocity () yes',
              f'/file/export/ascii "{q}/wall.csv" {WALL} () yes temperature heat-flux () yes',
              '/file/stop-transcript']
    jou = out / 'a2.jou'
    jou.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return jou


def read_csv(path):
    rows = list(csv.reader(open(path)))
    head = [h.strip() for h in rows[0]]
    return [dict(zip(head, map(float, r))) for r in rows[1:] if r]


def recovery(out):
    ax = sorted(read_csv(out / 'axis.csv'), key=lambda r: r['x-coordinate'])
    wall = sorted(read_csv(out / 'wall.csv'), key=lambda r: r['x-coordinate'])
    xs = [a['x-coordinate'] for a in ax]

    def at(x, key):
        i = max(1, min(len(xs) - 1, next((k for k, v in enumerate(xs) if v >= x), len(xs) - 1)))
        a, b = ax[i - 1], ax[i]
        t = 0 if b['x-coordinate'] == a['x-coordinate'] else (x - a['x-coordinate']) / (b['x-coordinate'] - a['x-coordinate'])
        return a[key] + t * (b[key] - a[key])
    pts = []
    for w in wall:
        x = w['x-coordinate']
        if not 0.05 <= x <= 0.85 * L_CH:          # steady supersonic part, away from nozzle and exit
            continue
        M = at(x, 'mach-number')
        if M < 1.5:
            continue
        T, T0 = at(x, 'temperature'), at(x, 'total-temperature')
        if T0 - T > 1:
            pts.append(((w['temperature'] - T) / (T0 - T), x, M, w['temperature'], w.get('heat-flux', float('nan'))))
    r = [p[0] for p in pts]
    mean = sum(r) / len(r)
    sd = math.sqrt(sum((v - mean) ** 2 for v in r) / max(len(r) - 1, 1))
    return dict(r_mean=round(mean, 4), r_sd=round(sd, 4), r_min=round(min(r), 4), r_max=round(max(r), 4), n=len(r),
                M_mean=round(sum(p[2] for p in pts) / len(pts), 3), Tw_mean_K=round(sum(p[3] for p in pts) / len(pts), 2),
                q_wall_abs_max=round(max(abs(p[4]) for p in pts), 3))


def run(prt):
    out = BASE / f'prt{int(round(prt * 100)):03d}'
    out.mkdir(parents=True, exist_ok=True)
    for f in list(out.glob('*.trn')) + list(out.glob('*.csv')):
        f.unlink()
    jou = journal(prt, out)
    log(f'=== Prt {prt}: запуск Fluent (окно), стенка адиабатная, режим патентный (pat55c)')
    t0 = time.time()
    subprocess.Popen([L.FLUENT, '2ddp', '-t7', '-i', str(jou)], cwd=str(out), stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True)
    first, said = None, False
    while not (out / 'wall.csv').exists():
        rows = C.closed_samples(out)
        if rows and first is None:
            first = rows[0]['iteration'] - 500
        limit = first + COUPLED_LIMIT if first is not None else None
        c = C.update_control(out, True, max_iter=limit)
        if c['stop_requested'] and not said:
            log('критерии сходимости выполнены в двух проверках подряд — Fluent сохранит кейс'); said = True
        st = G.status(out)
        if st and (st['fpe'] or st['error']):
            G.kill_since(t0)
            return log(f'Prt {prt}: СБОЙ (расходимость) на итерации {st["iter"]}')
        if time.time() - t0 > 4 * 3600:
            G.kill_since(t0); return log(f'Prt {prt}: СБОЙ (время)')
        time.sleep(10)
    time.sleep(10)
    G.kill_since(t0)
    conv = C.decision(C.closed_samples(out))
    res = dict(prt=prt, converged=conv, minutes=round((time.time() - t0) / 60, 1), **recovery(out))
    res['in_corridor'] = abs(res['r_mean'] - R_EXP) <= R_TOL
    new = not (BASE / 'a2_results.csv').exists()
    with (BASE / 'a2_results.csv').open('a', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(res))
        if new:
            w.writeheader()
        w.writerow(res)
    log(f"Prt {prt}: {'сошёлся' if conv else 'НЕ сошёлся (предел)'}; r = {res['r_mean']} ± {res['r_sd']} "
        f"(мин {res['r_min']}, макс {res['r_max']}, точек {res['n']}, M ср {res['M_mean']}); "
        f"в коридоре 0,885±0,015: {'да' if res['in_corridor'] else 'нет'}")


if __name__ == '__main__':
    for prt in [float(a) for a in sys.argv[1:]] or [0.85, 0.90, 0.75, 0.65]:
        try:
            run(prt)
        except Exception:
            import traceback; log('ОШИБКА программы: ' + traceback.format_exc())
    log('=== А2 закончен')
