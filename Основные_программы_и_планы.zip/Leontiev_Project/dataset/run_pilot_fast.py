"""Pilot of the unit cell, remaining points b..e with the speed-up agreed by the author (11.10.2026 ~10:40):
(1) no start from scratch — a new geometry starts from the converged field of the neighbour interpolated onto its mesh
    (a 'template' case of the new mesh is built by a 10-iteration G.run, the neighbour's field is written as an .ip file
    and read with /file/interpolate/read-data); the same geometry with another regime is a plain continuation;
(2) the DZV outlet pressure is estimated from the neighbour (G_dzv ~ dp^(1/1.8), and for another gap dp ~ gap^-2.7 at
    equal G) so that m comes close at once; at most one correction if |m - target| > 5 %.
Order (neighbour chain, small steps): a (t/d 1.2, done by run_night1112c) -> c (t/d 1.4, m 1.0) -> d (m 0.1, same mesh)
-> e (p_out 1.2, same mesh) -> b (t/d 1.6, from c).  Each row records its start in 'start' (review: start traceable).
Interpolation quality: the number of cells limited after read-data is logged (DZV zone id mismatch -> patch, as in A5).
Waits until run_night1112c.py finishes point a (it logs '=== cell_b_t16'), then stops it."""
import csv, subprocess, sys, time, traceback
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_pilot_cell as P
import cont_util as U
import leontiev_pipeline as L
import gui_runner as G
import run_a3 as A3

U.NPROC = 7
U.CFL = 5.0
U.LIMIT = 5500
G.RUNS = P.BASE
log = P.log
FLUENT = L.FLUENT
ATM = 0.101325


def rows(tag):
    if not P.CSV.exists():
        return {}
    r = [x for x in csv.DictReader(open(P.CSV, encoding='utf-8')) if x.get('tag') == tag]
    return r[-1] if r else {}


def ok(tag):
    return (P.BASE / tag / 'result.cas.h5').exists()


def last_good(prefix):
    """The last converged-or-finished stage of a point: _p2, _p1, _pr."""
    for s in ('_p2', '_p1', '_pr'):
        if ok(prefix + s) and rows(prefix + s).get('G_dzv'):
            return prefix + s
    return None


def params(td, pout):
    cell = L.cell_geometry(td, 1.5, 4.8, 3.3)
    p = dict(G.DEFAULTS)
    p.update(A3.MESHES['work_v2'], prt=0.85, mesh_custom=True, wait_free=True, dzv_counterflow=True,
             dzv_layers=P.dzv_layers(cell['gap_mm']), p_out_svz_MPa=pout, p_out_dzv_MPa=5.45, gas='ch4_ideal',
             extra_lines=[L.SYMMETRY_DZV_LINE, U.t0_line(15.0)], retries=0, startup_iters=10, coupled_iters=10, cfl=5.0,
             **{k: cell[k] for k in ('gap_mm', 'wall_thickness_inlet_mm', 'wall_thickness_end_mm')})
    return p, cell['gap_mm']


def template(tag, td, pout):
    p, gap = params(td, pout)
    p['run_id'] = f'{tag}_tpl'
    log(f'=== {tag}: шаблон кейса новой геометрии (сетка + 10 итераций, без расчёта)')
    G.run(p, lambda s: log('  ' + s), lambda: False)
    return P.BASE / p['run_id'] / 'result.cas.h5', gap


def write_ip(src_tag, ip):
    q = L.fl(ip.parent)
    jou = ip.with_suffix('.jou')
    jou.write_text('\n'.join([f'/file/start-transcript "{q}/{ip.stem}_w.trn"',
                              f'/file/read-case-data "{L.fl(P.BASE / src_tag / "result.cas.h5")}"',
                              f'/file/interpolate/write-data "{L.fl(ip)}" yes yes', '/file/stop-transcript', '/exit yes']) + '\n',
                   encoding='ascii')
    t = time.time()
    try:
        subprocess.Popen([FLUENT, '2ddp', '-t1', '-g', '-i', str(jou)], cwd=str(ip.parent)).wait(900)
    finally:
        G.kill_since(t)
    return ip.exists()


def interp_lines(ip, p_dzv_MPa, t0_C=15.0):
    # same initialisation as A5 b5 (checked 10.10): after read-data the DZV zone may get no donor -> patch it to rest
    # zone ids of air_dzv / wall_abonite swap between meshes (6/7, seen 10.10) -> always re-initialise them
    return [f'/file/interpolate/read-data "{L.fl(ip)}"',
            f'/solve/patch air_dzv () pressure {p_dzv_MPa / ATM:.5f}',
            f'/solve/patch air_dzv () temperature {t0_C:g}',
            '/solve/patch air_dzv () x-velocity ok 0',
            '/solve/patch air_dzv () y-velocity ok 0',
            '/solve/patch air_dzv () k 0.1',
            '/solve/patch air_dzv () omega 1000',
            f'/solve/patch wall_abonite () temperature {t0_C:g}']


def cont(src_case, tag, regime, extra, g_target, start):
    out = P.BASE / tag
    m = U.continue_case(src_case, out, list(extra), regime, log, tag, t0_C=15.0)
    r = U.record(P.CSV, tag, 'work_v2', 'ch4_pr', regime, out, m, log, start=start, t0_C=15.0, g_dzv_target=g_target)
    try:
        txt = ''.join(f.read_text(encoding='utf-8', errors='ignore') for f in out.glob('fluent-*.trn'))
        lim = [l.strip() for l in txt.splitlines() if 'limited to' in l and 'interpolat' not in l][:4]
        if 'interpolate/read-data' in txt:
            log(f'  {tag}: перенос поля — ограничения после чтения: {lim if lim else "нет"}')
    except Exception:
        pass
    return r


def point(tag, td, m, pout, src_tag, src_gap, same_mesh):
    """src_tag: neighbour's final stage.  Returns final stage tag or None."""
    s = rows(src_tag)
    g_svz, g_src = float(s['G_svz']), float(s['G_dzv'])
    dp_src = 5.5 - float(s['p_out_dzv'])
    g_t = m * g_svz
    _, gap = params(td, pout)
    dp = dp_src * (g_t / g_src) ** 1.8 * (src_gap / gap) ** 2.7
    dp = max(min(dp, 5.499 - pout - 0.1), 0.0005)
    reg = (5.5, pout, 5.5, round(5.5 - dp, 5))
    if same_mesh:
        case, extra, start = P.BASE / src_tag / 'result.cas.h5', [], f'продолжение {src_tag}'
    else:
        tpl, _ = template(tag, td, pout)
        ip = P.BASE / 'ip' / f'{src_tag}.ip'
        ip.parent.mkdir(exist_ok=True)
        if not tpl.exists() or not (ip.exists() or write_ip(src_tag, ip)):
            log(f'  {tag}: нет шаблона или файла переноса — точка пропущена'); return None
        case, extra, start = tpl, list(L.CH4_PR_LINES) + interp_lines(ip, reg[3]), f'перенос поля {src_tag} на сетку {tag}'
    log(f'=== {tag}: t/d {td}, цель m {m}, p потр {pout}; оценка перепада ДЗВ {dp:.5f} МПа от {src_tag}')
    cur = f'{tag}_pr'
    r = cont(case, cur, reg, extra, g_t, start)
    if not ok(cur) or not r.get('G_dzv'):
        return None
    mc = float(r['G_dzv']) / float(r['G_svz'])
    log(f'  {cur}: m {mc:.3f} (цель {m})')
    if mc > 0 and abs(mc - m) / m > 0.05:
        dp = max(min(dp * (m / mc) ** 1.8, 5.499 - pout - 0.1), 0.0005)
        nt = f'{tag}_p1'
        r = cont(P.BASE / cur / 'result.cas.h5', nt, (5.5, pout, 5.5, round(5.5 - dp, 5)), [], g_t, f'продолжение {cur}')
        if ok(nt) and r.get('G_dzv'):
            log(f'  {nt}: m {float(r["G_dzv"]) / float(r["G_svz"]):.3f} (цель {m})')
            cur = nt
    return cur


def wait_and_stop_old():
    while True:
        txt = (P.BASE / 'pilot_log.txt').read_text(encoding='utf-8', errors='ignore')
        if '=== cell_b_t16' in txt:
            break
        if not P.running('run_night1112c'):
            break
        time.sleep(20)
    t = time.time() - 120
    subprocess.run(['powershell', '-NoProfile', '-Command',
                    "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | ? {$_.CommandLine -match 'run_night1112c'} | "
                    "% { Stop-Process -Id $_.ProcessId -Force }"])
    time.sleep(10)
    # the old runner may have just started Workbench for point b
    subprocess.run(['powershell', '-NoProfile', '-Command',
                    "Get-Process | ? { $_.Path -like '*ANSYS Inc*' -and $_.StartTime -gt (Get-Date).AddSeconds(-150) -and "
                    "$_.Name -notmatch 'ansysli|ansyscl|lmgrd|ansyslmd' } | Stop-Process -Force"])
    G.kill_since(t)
    log('=== пилот (ускоренный): старая очередь остановлена после точки a')


def main():
    wait_and_stop_old()
    a = last_good('cell_a_t12_m03_p03')
    if not a:
        return log('точка a не дала результата — ускоренный пилот не начат')
    gap_a = params(1.2, 0.3)[1]
    c = point('cell_c_t14_m10_p03', 1.4, 1.0, 0.3, a, gap_a, False)
    gap14 = params(1.4, 0.3)[1]
    if c:
        point('cell_d_t14_m01_p03', 1.4, 0.1, 0.3, c, gap14, True)
        # e: other consumer pressure, m 0.3 — DZV drop scaled from c to m 0.3 (same mesh)
        point('cell_e_t14_m03_p12', 1.4, 0.3, 1.2, c, gap14, True)
        point('cell_b_t16_m03_p03', 1.6, 0.3, 0.3, c, gap14, False)
    else:
        point('cell_b_t16_m03_p03', 1.6, 0.3, 0.3, a, gap_a, False)


if __name__ == '__main__':
    P.qlog('=== пилот ячейки (ускоренный: перенос поля соседа, давление ДЗВ по оценке) — ждёт точку a')
    try:
        main()
    except Exception:
        log('пилот (ускоренный): ОШИБКА программы: ' + traceback.format_exc())
    P.qlog('=== пилот ячейки (ускоренный) — закончен')
