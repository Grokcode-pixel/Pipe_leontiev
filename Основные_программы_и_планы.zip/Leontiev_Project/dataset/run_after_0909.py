"""Queue after run_resume_0909.py (09.10.2026, agreed by the author 10:15: run items 3-7 of the pre-dataset list back to
back, no idle machine).  Waits for run_resume_0909.py to finish.  Rows -> runs\\day0909\\day0909_results.csv, log
day0909_log.txt (cont_util.record: Fluent total temperatures + enthalpy-based temperatures for methane).
  P1 L700 coarse (methane PR) continuation: the night run stopped on the iteration limit by continuity only
  P2 brass wall k = 110 W/(m K) on the anchor (work_v2, methane PR, continuation of a6_ch4_pr, wall 234 -> 110)
  P3 targeted mass flow at the DZV outlet (Fluent 'targeted-mf' at outlet_dzv, syntax checked 09.10 10:33 on a -t1 probe):
     a) target = anchor G_dzv 0.049462 kg/s (must reproduce p_out_dzv ~ 5.2 MPa = 51.32 atm),
     b) target 0.095 kg/s (m ~ 0.6) from a); the actual outlet pressure is read back by a short -t1 report session
  P4 start boundary on the consumer pressure: chamber case (air) 1.2 -> 1.6 -> 2.0 -> 2.5 MPa until the shock enters
     the channel (run_a4.back_pressure, same stop rule as run_a4.main)
The night series wall (234) is kept for P1/P3 (comparison with their bases); P2 sets 110 explicitly."""
import re, subprocess, sys, time, traceback
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import leontiev_pipeline as L
import gui_runner as G
import cont_util as U

BASE = Path(r'F:\Leontiev_Project\runs\day0909')
CSV = BASE / 'day0909_results.csv'
QLOG = Path(r'F:\Leontiev_Project\runs\queue_log.txt')
ANCHOR = (5.5, 0.3, 5.5, 5.2)
WORK_PR = Path(r'F:\Leontiev_Project\runs\a6\a6_ch4_pr\result.cas.h5')
L700_PR = Path(r'F:\Leontiev_Project\runs\night\pair_L700_coarse_pr\result.cas.h5')
CHAMBER_120 = Path(r'F:\Leontiev_Project\runs\a4\a4_chamber_p120\result.cas.h5')
ATM = 0.101325   # MPa


def log(s):
    line = time.strftime('%H:%M:%S ') + s
    print(line, flush=True)
    BASE.mkdir(parents=True, exist_ok=True)
    with (BASE / 'day0909_log.txt').open('a', encoding='utf-8') as f:
        f.write(line + '\n')


def qlog(s):
    with QLOG.open('a', encoding='utf-8') as f:
        f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + s + '\n')


def running(name):
    out = subprocess.run(['powershell', '-NoProfile', '-Command',
                          f"Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | ? {{$_.CommandLine -match '{name}'}} | Measure-Object | % Count"],
                         capture_output=True, text=True).stdout.strip()
    return out not in ('', '0')


def tmf_lines(g):
    # pmin/pmax are absolute pressures in the case units (atm): 5 atm (0.51 MPa) .. 54 atm (5.47 MPa < p0 5.5 MPa)
    return [f'/define/boundary-conditions/set/pressure-outlet outlet_dzv () targeted-mf-boundary? yes targeted-mf no {g:g} '
            'targeted-mf-pmin no 5 targeted-mf-pmax no 54 q']


def outlet_pressures(out):
    """Short -t1 session: area-weighted static pressure at outlet_dzv / outlet_svz (atm, operating pressure 0)."""
    out = Path(out); trn = out / 'report_p.trn'
    jou = out / 'report_p.jou'
    jou.write_text('\n'.join([f'/file/start-transcript "{L.fl(out)}/report_p.trn"',
                              f'/file/read-case-data "{L.fl(out)}/result.cas.h5"',
                              '/report/surface-integrals/area-weighted-avg outlet_dzv outlet_svz () pressure no',
                              '/file/stop-transcript', '/exit yes', 'yes', '']), encoding='ascii')
    while G.fluent_running():
        time.sleep(30)
    with open(jou, 'rb') as stdin:
        subprocess.run([L.FLUENT, '2ddp', '-t1', '-g'], cwd=str(out), stdin=stdin, stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=600)
    txt = trn.read_text(errors='ignore') if trn.exists() else ''
    vals = dict(re.findall(r'^\s*(outlet_dzv|outlet_svz)\s+([-\d.eE+]+)\s*$', txt, re.M))
    return {k: float(v) * ATM for k, v in vals.items()}


def cont(tag, mesh, src, regime, extra=(), wall_k=None, l_heat_mm=400.0, gas='ch4_pr', tmf=False):
    out = BASE / tag
    m = U.continue_case(src, out, list(extra), regime, log, tag, wall_k=wall_k)
    if tmf and (out / 'result.cas.h5').exists():
        try:
            p = outlet_pressures(out)
            if 'outlet_dzv' in p:
                log(f'  {tag}: давление на выходе ДЗВ при заданном расходе {p["outlet_dzv"]:.4f} МПа '
                    f'(СВЗ {p.get("outlet_svz", float("nan")):.4f} МПа)')
                regime = (regime[0], regime[1], regime[2], round(p['outlet_dzv'], 4))
        except Exception:
            log(f'  {tag}: давление на выходе ДЗВ не прочитано: ' + traceback.format_exc().splitlines()[-1])
    U.record(CSV, tag, mesh, gas, regime, out, m, log, start=f'продолжение {Path(src).parent.name}', l_heat_mm=l_heat_mm)
    return out / 'result.cas.h5' if (out / 'result.cas.h5').exists() else None


def step(name, fn):
    qlog(f'день 09.10: {name} — начат'); t0 = time.time()
    try:
        fn(); qlog(f'день 09.10: {name} — скрипт завершён за {(time.time() - t0) / 60:.0f} мин (приёмка — по результатам)')
    except Exception:
        qlog(f'день 09.10: {name} — ОШИБКА программы:\n' + traceback.format_exc())


def boundary():
    import run_a4
    prev = CHAMBER_120
    if not prev.exists():
        return log('P4: нет кейса камеры 1,2 МПа — пропуск')
    for pout in (1.6, 2.0, 2.5):
        res, case = run_a4.back_pressure(prev, pout, 'chamber')
        if (res.get('status') == 'сбой' or res.get('x_shock_m') not in ('', None)
                or 'нет сверхзвука' in str(res.get('reason')) or not case.exists()):
            run_a4.log(f'chamber: при {pout} МПа канал уже не сверхзвуковой по всей длине (или сбой) — граница запуска найдена')
            break
        prev = case


if __name__ == '__main__':
    G.DEFAULTS['wall_k'] = None
    qlog('=== день 09.10 (P1–P4): жду окончания run_resume_0909')
    while running('run_resume_0909'):
        time.sleep(60)
    step('P1 L700 грубая (метан ПР), доводка', lambda: cont('L700_coarse_pr_cont', 'coarse_v2', L700_PR, ANCHOR, l_heat_mm=700.0))
    step('P2 стенка латунь 110 (якорь, рабочая)', lambda: cont('brass110_work_pr', 'work_v2', WORK_PR, ANCHOR, wall_k=110))

    def tmf():
        a = cont('tmf_0495_work_pr', 'work_v2', WORK_PR, ANCHOR, extra=tmf_lines(0.049462), tmf=True)
        if a:
            cont('tmf_0950_work_pr', 'work_v2', a, ANCHOR, extra=tmf_lines(0.095), tmf=True)
    step('P3 заданный расход на выходе ДЗВ (метан ПР, рабочая)', tmf)
    step('P4 граница запуска: камера 1,6 / 2,0 / 2,5 МПа (воздух)', boundary)
    qlog('=== день 09.10 (P1–P4): очередь закончена')
