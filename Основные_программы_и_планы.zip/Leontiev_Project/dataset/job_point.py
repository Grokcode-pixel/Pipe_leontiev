"""31.10.2026 — исполнитель заданий «серия точек» из интерфейса автора (окно 2 «Новая серия»); вызывается общей очередью:
python job_point.py <id задания> (queue_runner.command). Каждый расчёт — одна попытка (без повтора с половинным шагом), одно окно Fluent.
 гладкая: есть сошедшийся кейс той же L — как confirm_runner.run_point (та же t/d — продолжение со ступенями магистрали 0,75 МПа,
          другая t/d — перенос поля); такой L нет или своя сетка — с нуля (scratch_one) при магистрали 5,5 МПа, затем ступени;
 накатка: 31.10 (D-30) — с нуля одинаковой инициализацией (scratch_one, старт «как на стенде») при магистрали 5,5 МПа и заданном
          перепаде (без подбора под расход), затем ступени магистрали; перенос поля с других труб не используется;
 сопло:   срез сопла (nozzle_series.cell_params), перенос поля гладкой той же L при 5,5 МПа, затем ступени (nozzle_series.walk).
Стоп: первые 2 расчёта серии не сошлись. Результаты — runs\\station\\gui_results.csv (папки runs\\station\\IFnnn_kk); статусы —
runs\\journal\\gui_forecasts.json; строка в Журнал_работ.md. В обучение — только через окно 3 (гладкая, D-12; после заморозки — проверочная)."""
import json, math, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import jobqueue as JQ

FC = Path(r'F:\Leontiev_Project\runs\journal\gui_forecasts.json')
ST = Path(r'F:\Leontiev_Project\runs\station')


def _d12a(d):
    try:
        import d12a
        return d12a.evaluate(d).get('ok')
    except Exception:
        return None


def journal(s):
    with open(r'F:\Leontiev_Project\Журнал_работ.md', 'a', encoding='utf-8') as f:
        f.write(f'- {time.strftime("%d.%m.%Y %H:%M")} — {s}\n')


def setup(job):
    """Модули под тип трубы (накатка и сопло меняют cell_params run_a9 — поэтому импорт только нужного) + своя сетка поверх."""
    kind = job['tube']
    if kind == 'накатка':
        import knurl_shallow_retry as KR       # осевой шаг 0,25 мм, одна попытка (A.cont заменён)
        A = KR.A
    elif kind == 'сопло':
        import nozzle_series as NS
        A = NS.A
    else:
        import run_a9 as A
    # 31.10: проверочные серии (повторяемость, проверка выданных решений, вслепую, полный цикл) — своя папка и файл результатов
    base = Path(job.get('base') or ST)
    base.mkdir(parents=True, exist_ok=True)
    A.BASE, A.CSV, A.AUX = base, base / (job.get('csv') or 'gui_results.csv'), base / 'aux_results.csv' if job.get('base') else ST / 'station_aux.csv'
    A.G.RUNS = base

    def cont_one(src_case, tag, reg_, extra, t0s, t0d, start, csv_path, limit=None, l_mm=400.0):
        A.set_step(A.CONS)
        A.U.LIMIT = min(limit, A.POINT_LIMIT) if limit else A.POINT_LIMIT
        out = A.BASE / tag
        mins = A.U.continue_case(src_case, out, list(extra), reg_, A.log, tag, t0_C=t0s, t0_dzv_C=t0d)
        A.U.record(csv_path, tag, 'work_v2', 'ch4_pr', reg_, out, mins, A.log, start=start, t0_C=t0s, t0_dzv_C=t0d, l_heat_mm=l_mm)
        return out if A.ok(out) else None
    A.cont = cont_one                           # одна попытка и в transfer()
    if job.get('mesh'):
        _cp = A.cell_params

        def cell_params(*a, **k):
            p, cell = _cp(*a, **k)
            p.update(job['mesh'])
            return p, cell
        A.cell_params = cell_params
    return A


def steps(A, cur, pm_from, p, tag, ts, td_):
    """Ступени магистрали 0,75 МПа от pm_from к p['pm'], затем точка."""
    k, p0 = 0, pm_from
    while abs(p['pm'] - p0) > 0.8:
        k += 1; p0 = round(p0 + (0.75 if p['pm'] > p0 else -0.75), 2)
        cur = A.cont(cur / 'result.cas.h5', f'{tag}_r{k}', (p0, p['pc'], p0, round(p0 - p['dp'] / 1000, 6)), [], ts, td_,
                     f'{tag}: ступень магистрали {p0}', A.AUX, limit=1500, l_mm=p['L']) or cur
    reg = (p['pm'], p['pc'], p['pm'], round(p['pm'] - p['dp'] / 1000, 6))
    return A.cont(cur / 'result.cas.h5', tag, reg, [], ts, td_, f'{tag}: от {cur.name} (интерфейс)', A.CSV, l_mm=p['L'])


def design(p, tag, ts, td_):
    return dict(id=tag, t_d=p['td'], L_mm=p['L'], p_cons=p['pc'], dp_dzv_kPa=p['dp'], t0_svz=ts, t0_dzv=td_,
                m_target=0.8, heater=p['heat'])


def run_point(A, job, p, prev):
    """Папка результата точки (тег точки или, если магистраль 5,5 МПа и хватило переноса / расчёта с нуля, …_a / …_s) или None."""
    tag, ts, td_ = p['tag'], p['T'] + p['heat'], p['T']
    kind = job['tube']
    if prev:                                    # та же геометрия уже посчитана в этой серии — продолжение от неё
        return steps(A, prev[0], prev[1], p, tag, ts, td_)

    def then(first):                            # после переноса / расчёта с нуля при 5,5 МПа — ступени к магистрали точки
        return steps(A, first, 5.5, p, tag, ts, td_) if first and abs(p['pm'] - 5.5) > 1e-6 else first
    if kind == 'накатка':
        # 31.10, D-30: каждая точка накатки — С НУЛЯ одинаковой инициализацией (старт «как на стенде», без FMG и без переноса
        # поля с других труб), перепад ДЗВ задан, расход и Q — результат
        import knurl_shallow_retry as KR
        import scratch_one as SO
        KR.K.KN.update(dzv=p['h'], svz=None, pitch=p['pitch'], width=0.67 if abs(p['pitch'] - 2.0) < 1e-9 else round(p['pitch'] / 3, 3))
        A.log(f"=== {tag}: накатка h {p['h']} / шаг {p['pitch']}; с нуля по D-30 (старт «как на стенде»)")
        return then(SO.run(A, design(p, tag + '_s', ts, td_), tag + '_s', p['L'], f'{tag}: накатка с нуля (D-30, интерфейс)', startup='ramp'))
    if kind == 'сопло':
        import nozzle_series as NS
        NS.R_E['v'] = p['r_exit']
        sp, sx = NS.smooth_case(p['td'], p['L'])
        A.log(f"=== {tag}: сопло A/A* {p['ar']} (срез ⌀ {2 * p['r_exit']:.2f} мм); старт — перенос поля {Path(sp).name}")
        return then(A.transfer(Path(sp), design(p, tag + '_a', ts, td_), (5.5, p['pc'], 5.5, round(5.5 - p['dp'] / 1000, 6))))
    import auto_enrich as AE
    src = [] if job.get('mesh') else [(q, x) for q, x in AE.sources() if abs(x[1] * 6.6 - p['L']) < 0.5]
    if not src:                                 # новой L нет в данных (или своя сетка) — с нуля
        import scratch_one as SO
        return then(SO.run(A, design(p, tag + '_s', ts, td_), tag + '_s', p['L'], f'{tag}: с нуля (интерфейс)'))
    same = [(q, x) for q, x in src if abs(x[0] - p['td']) < 1e-6]
    key = lambda t: (abs(t[1][0] - p['td']) * 10 + abs(t[1][6] - p['pm']) + abs(math.log(math.exp(t[1][2]) / p['dp']))
                     + abs(t[1][4] - p['T']) / 10 + abs(t[1][3] - p['pc']) + t[1][5] / 10)
    sp, sx = min(same or src, key=key)
    A.log(f"=== {tag}: гладкая; старт от {Path(sp).name} (t/d {sx[0]}, магистраль {sx[6]} МПа)")
    if same:
        return steps(A, Path(sp), sx[6], p, tag, ts, td_)
    return then(A.transfer(Path(sp), design(p, tag + '_a', ts, td_), (5.5, p['pc'], 5.5, round(5.5 - p['dp'] / 1000, 6))))


if __name__ == '__main__':
    jid = sys.argv[1]
    job = next(j for j in JQ.load() if j['id'] == jid)
    A = setup(job)
    A.qlog(f"=== интерфейс: {jid} «{job['series']}» ({job['tube']}, {len(job['points'])} точек) — начата")
    n_calc = n_fail = 0
    prev_geo, done = {}, []
    for i, p in enumerate(job['points']):
        g = (p['td'], p['L'], p.get('h'), p.get('pitch'), p.get('ar'))
        A.log(f"=== {p['tag']} ({jid}): t/d {p['td']}, L {p['L']:g}, магистраль {p['pm']}, потребитель {p['pc']}, перепад {p['dp']} кПа, "
              f"T {p['T']} °C, подогрев {p['heat']} K")
        try:
            d = A.done_dir(p['tag']) or run_point(A, job, p, prev_geo.get(g))
        except Exception as ex:
            A.log(f"  {p['tag']}: ОШИБКА программы {ex!r}"); d = None
        ok = bool(d) and (A.converged(d) or bool(_d12a(d)))   # 31.10: сошлась по критериям или по D-12a (колебания, окно 1000)
        n_calc += 1; n_fail += not ok
        fc = json.loads(FC.read_text(encoding='utf-8')) if FC.exists() else {}
        if p['tag'] in fc:
            fc[p['tag']].update(status='сошёлся' if ok else ('предел итераций' if d else 'нет результата'), result_tag=d.name if d else None)
            FC.write_text(json.dumps(fc, ensure_ascii=False, indent=1), encoding='utf-8')
        if d:
            prev_geo[g] = (d, p['pm']); done.append(f"{p['tag']} {'сошёлся' if ok else 'предел'}")
        if n_calc == 2 and n_fail == 2:
            A.qlog(f'=== интерфейс {jid}: первые 2 расчёта не сошлись — СТОП, нужно решение автора')
            for q in job['points'][i + 1:]:
                if q['tag'] in fc:
                    fc[q['tag']]['status'] = 'снят (стоп-правило)'
            FC.write_text(json.dumps(fc, ensure_ascii=False, indent=1), encoding='utf-8')
            journal(f"интерфейс {jid} «{job['series']}»: первые 2 расчёта не сошлись — стоп по правилу, нужно решение автора")
            sys.exit(1)
    journal(f"интерфейс {jid} «{job['series']}» ({job['tube']}): посчитано {len(done)} из {len(job['points'])} — " + (', '.join(done) or '—')
            + ' (runs\\station\\gui_results.csv; в обучение — окно 3)')
    A.qlog(f'=== интерфейс {jid} — закончена')
