"""30.10.2026 — задание автора: метки точек датасета раздельно — «скачок» / «вне Ω» / «качество расчёта» (раньше статус расчёта
«сошёлся_нерабочий» смешивал режим и границу: у A9_19 «нерабочий» = обратный ток на выходе СВЗ, а не скачок).
 скачок — по профилю оси (x_shock_m): это и только это — метка классификатора «рабочий / скачок» (model_compare, heldout_check);
 Ω — 0,2 ≤ m ≤ 0,96 (D-08), m = G_ДЗВ / G_СВЗ;
 качество — сошёлся по критериям / предел итераций с дисбалансом энергии < 1 % Q (D-12) / не выполнено;
 обратный ток на выходе СВЗ — справочно (проверка «граница или режим» — A9_19 с удлинённым выходом, очередь J0006).
Вывод: runs\\models\\метки_точек.md + метки_точек.csv (точки обучения, как dataset_ranges)."""
import csv, sys
from collections import Counter
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import passport as PS
import dataset_ranges as DR

OUT = Path(r'F:\Leontiev_Project\runs\models')


def quality(r):
    if str(r.get('status', '')).startswith('сошёлся'):
        return 'сошёлся'
    try:
        q, net = float(r['Q']), abs(float(r['net_W']))
    except (KeyError, ValueError, TypeError):
        return 'нет баланса'
    return 'предел, D-12 выполнено' if net < 0.01 * q else 'предел, D-12 НЕ выполнено'


if __name__ == '__main__':
    rows = []
    for src, d, x in PS.training_points():
        r = DR.RR.get((d.parent.name, d.name))
        if not r or not r.get('G_dzv'):
            continue
        m = float(r['G_dzv']) / float(r['G_svz'])
        rows.append(dict(tag=d.name, src=src, m=round(m, 3), скачок='да' if r.get('x_shock_m') else 'нет',
                         Ω='в Ω' if 0.2 <= m <= 0.96 else 'вне Ω', качество=quality(r),
                         обратный_ток_выход_СВЗ_pct=r.get('reversed_max_pct') or '0', статус_расчёта=r.get('status', '')))
    with open(OUT / 'метки_точек.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    c = Counter((r['скачок'], r['Ω'], r['качество']) for r in rows)
    rev = [r for r in rows if float(r['обратный_ток_выход_СВЗ_pct'] or 0) > 1.0]
    mixed = [r for r in rows if r['статус_расчёта'] == 'сошёлся_нерабочий' and r['скачок'] == 'нет']
    L = [f'# Метки точек обучения раздельно: скачок / Ω / качество расчёта ({len(rows)} точек)', '',
         'Классификатор «рабочий / скачок» обучается только по метке «скачок» (профиль оси); «вне Ω» и «качество» — отдельные метки, '
         'в класс не входят. Обратный ток на выходе СВЗ — справочно, не метка режима.', '',
         '| скачок | Ω | качество расчёта | точек |', '|---|---|---|---|']
    L += [f'| {k[0]} | {k[1]} | {k[2]} | {v} |' for k, v in sorted(c.items(), key=lambda kv: -kv[1])]
    L += ['', f'Обратный ток на выходе СВЗ > 1 % площади: {len(rev)} точек; из них со статусом расчёта «сошёлся_нерабочий» без скачка '
          f'(смешение «режим / граница» в старом статусе): {len(mixed)} — ' + ', '.join(r['tag'] for r in mixed[:20]) + ('…' if len(mixed) > 20 else '') + '.',
          '', 'Полный список — метки_точек.csv.']
    (OUT / 'метки_точек.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
    print('\n'.join(L))
