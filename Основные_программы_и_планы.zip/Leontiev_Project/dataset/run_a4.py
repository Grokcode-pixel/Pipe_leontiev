"""Stage A4: SVZ exit (author: try both chamber and diffuser; permission to start after A3 given 07.10.2026 22:30).
n95 geometry, work mesh of A3 (y+ <= 1), SST + Prt 0.85, patent regime SVZ 5.5 -> p_out, DZV 5.5 -> 5.2 MPa.
  K (chamber): the neck (0.95 r_end) is followed by an abrupt widening to r_out = 3 r_end over 3 mm and a 150 mm
     cylinder; outlet 0.3 MPa.  Compared with the A3 work run (same mesh settings, standard exit, same regime).
  D (diffuser): the standard exit (neck 0.95 + 4.6 deg recovery) with a rising back pressure 0.6 ... 2.5 MPa, each point
     continued from the previous one; stops after the first point where the shock enters the heat-exchange channel.
     Answers: up to which consumer pressure the channel stays supersonic, and what that does to dT and Q.
Starts after the A3 pairs (waits for their final log line).
usage: python run_a4.py [K] [D]     results: runs\\a4\\a4_results.csv, log runs\\a4\\a4_log.txt"""
import csv, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import leontiev_pipeline as L
import gui_runner as G
import gui_convergence as C
import run_a3 as A3
from make_gui_prt_journal import GUI_PRT

BASE = Path(r'F:\Leontiev_Project\runs\a4')
WORK = A3.BASE / 'a3_work_v2'   # 08.10: geometry v2 + mesh v2 + k(T)
LIMIT = 5500
BACK = [0.6, 1.2]   # 08.10 (agreed plan): consumer pressure levels of the dataset plan 0.3 / 0.6 / 1.2 MPa
COLS = ['variant', 'p_out_svz', 'status', 'reason', 'iter', 'dT_svz', 'dT_dzv', 'Q', 'm_svz', 'ratio', 'M_mean_channel',
        'M_outlet', 'x_shock_m', 'reversed_max_pct', 'yp_svz', 'minutes']


def log(s):
    line = time.strftime('%H:%M:%S ') + s
    print(line, flush=True)
    BASE.mkdir(parents=True, exist_ok=True)
    with (BASE / 'a4_log.txt').open('a', encoding='utf-8') as f:
        f.write(line + '\n')


def record(variant, p, out, minutes):
    st = G.status(out)
    res = dict(variant=variant, p_out_svz=p['p_out_svz_MPa'], minutes=minutes)
    if st and st['samples'] and (out / 'axis.csv').exists():
        b = st['samples'][-1]
        closed = C.closed_samples(out)
        status_, reason, info = G.classify(out, p, G.converged(out))
        res.update(info, status=status_, reason=reason, iter=st['iter'], dT_svz=round(b['dT_svz'], 3),
                   dT_dzv=round(b['dT_dzv'], 3), Q=round(b['Q'], 1), m_svz=round(closed[-1]['m_svz'], 6) if closed else '',
                   ratio=round(b['ratio'], 4), yp_svz=round(b['yp_svz'], 3))
        log(f"{variant}: {status_} ({reason}); ΔT СВЗ {res['dT_svz']:+.3f} K, ΔT ДЗВ {res['dT_dzv']:+.3f} K, Q {res['Q']:.1f} Вт, "
            f"G СВЗ {res['m_svz']} кг/с, M канал ср. {info.get('M_mean_channel')}, M выход {info.get('M_outlet')}")
    else:
        res.update(status='сбой', reason='нет результата')
        log(f'{variant}: нет результата (сбой)')
    new = not (BASE / 'a4_results.csv').exists()
    with (BASE / 'a4_results.csv').open('a', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=COLS, extrasaction='ignore')
        if new:
            w.writeheader()
        w.writerow(res)
    return res


def chamber(l_rec=3.0):
    p = dict(G.DEFAULTS)
    p.update(A3.MESHES['work_v2'], run_id=f'a4_chamber_rec{l_rec:g}', prt=0.85, mesh_custom=True, wait_free=True,
             r_outlet_mm=3 * p['r_end_mm'], l_exit_recovery_mm=l_rec, l_exit_tail_mm=150.0)
    G.RUNS = BASE
    log(f'=== камера: шейка 0,95 r_end → расширение до {3 * p["r_end_mm"]:.1f} мм на {l_rec:g} мм, цилиндр 150 мм; '
        f'СВЗ 5,5→0,3, ДЗВ 5,5→5,2 МПа')
    t0 = time.time()
    G.run(p, lambda s: log('  ' + s), lambda: False)
    return record(f'камера (расширение {l_rec:g} мм)', p, BASE / p['run_id'], round((time.time() - t0) / 60, 1))


def back_pressure(prev_case, pout, kind='diff'):
    """kind 'diff' = standard exit, 'chamber' = exit chamber; the same back pressures for both (08.10, review:
    the variants are compared at equal conditions)."""
    out = BASE / f'a4_{kind}_p{int(round(pout * 100)):03d}'
    out.mkdir(parents=True, exist_ok=True)
    for f in list(out.glob('*.trn')) + list(out.glob('*.csv')):
        f.unlink()
    q = L.fl(out)
    target = {'inlet_svz': 5.5e6, 'outlet_svz': pout * 1e6, 'pressure_inlet_dzv': 5.5e6, 'outlet_dzv': 5.2e6}
    lines = ['/file/confirm-overwrite? no', f'/file/start-transcript "{q}/run.trn"', f'/file/read-case-data "{L.fl(prev_case)}"']
    lines += [g.format(prt=0.85) for g in GUI_PRT] + [L.AIR_K_LINE] + G.bc_lines(target)   # 08.10: k(T) explicitly
    lines += C.coupled_journal(dict(coupled_iters=LIMIT, report_every=500, cfl=20.0), out)
    lines += [f'/file/write-case-data "{q}/result.cas.h5"',
              f'/file/export/ascii "{q}/axis.csv" axis () yes mach-number pressure total-pressure temperature '
              'total-temperature axial-velocity () yes',
              # wall pressure along the SVZ channel and the exit unit: shock positions off the axis (08.10, review)
              f'/file/export/ascii "{q}/wall_svz_p.csv" wall_outer-air_svz {A3.WALL} () yes pressure mach-number () yes',
              '/file/stop-transcript']
    (out / 'a4.jou').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    title = 'диффузор' if kind == 'diff' else 'камера'
    log(f'=== {title}: давление на выходе СВЗ {pout} МПа (продолжение с {Path(prev_case).parent.name})')
    while G.fluent_running():
        time.sleep(60)
    t0 = time.time()
    subprocess.Popen([L.FLUENT, '2ddp', '-t7', '-i', str(out / 'a4.jou')], cwd=str(out), stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True)
    first, said = None, False
    while not (out / 'axis.csv').exists():
        rows = C.closed_samples(out)
        if rows and first is None:
            first = rows[0]['iteration'] - 500
        c = C.update_control(out, True, max_iter=first + LIMIT if first is not None else None)
        if c['stop_requested'] and not said:
            log('  критерии сходимости выполнены в двух проверках подряд — Fluent сохранит кейс'); said = True
        st = G.status(out)
        if st and (st['fpe'] or st['error']):
            G.kill_since(t0)
            log(f'  СБОЙ (расходимость) на итерации {st["iter"]}')
            break
        if time.time() - t0 > 4 * 3600:
            G.kill_since(t0); log('  СБОЙ (время)'); break
        time.sleep(10)
    time.sleep(10)
    G.kill_since(t0)
    p = dict(G.DEFAULTS, p_out_svz_MPa=pout, prt=0.85, run_id=out.name, startup=f'продолжение от {Path(prev_case).parent.name}')
    res = record(f'{title}, p_вых {pout} МПа', p, out, round((time.time() - t0) / 60, 1))
    if res.get('status') != 'сбой' and (out / 'axis.csv').exists():
        G.append_result(dict(p, **A3.MESHES['work_v2']), G.status(out), out, G.converged(out), '', res['minutes'])
    return res, out / 'result.cas.h5'


def main(parts=None):
    parts = parts or ['K', 'D']

    def sweep(start_case, kind):
        prev = start_case
        for pout in BACK:
            try:
                res, case = back_pressure(prev, pout, kind)
            except Exception:
                import traceback; log('ОШИБКА программы: ' + traceback.format_exc()); break
            # reversed flow at the outlet after a shock in the exit unit is possible and is recorded (reversed_max_pct);
            # stop only when the shock has entered the heat-exchange channel, the channel is not supersonic, or failure
            if (res.get('status') == 'сбой' or res.get('x_shock_m') not in ('', None)
                    or 'нет сверхзвука' in str(res.get('reason')) or not case.exists()):
                log(f'{kind}: при {pout} МПа канал уже не сверхзвуковой по всей длине (или сбой) — дальше не повышаю')
                break
            prev = case

    if 'K' in parts:
        try:
            l_rec = 20.0   # 08.10: 3 mm widening split the SVZ (extra zone wall-air_svz, no flow); 20 mm (~26 deg) meshes like work_v2
            r = chamber(l_rec)
            if r.get('reason') == 'нет результата':   # mesh / start failure of the abrupt widening -> 45 deg widening
                l_rec = 30.0
                r = chamber(l_rec)
            start = BASE / f'a4_chamber_rec{l_rec:g}' / 'result.cas.h5'
            if r.get('reason') != 'нет результата' and start.exists():
                sweep(start, 'chamber')
        except Exception:
            import traceback; log('ОШИБКА программы: ' + traceback.format_exc())
    if 'D' in parts:
        sweep(WORK / 'result.cas.h5', 'diff')
    log('=== А4 закончен')


if __name__ == '__main__':
    logf = A3.BASE / 'a3_log.txt'
    while '=== А3, пары «грубая — рабочая»: закончено' not in (logf.read_text(encoding='utf-8') if logf.exists() else ''):
        time.sleep(60)
    time.sleep(30)
    main(sys.argv[1:])
