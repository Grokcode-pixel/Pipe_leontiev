"""П. 3.2 плана 18.10: внешняя проверка на отложенных геометриях добора Б (B5x, B6x) — модели обучены на всех
остальных сошедшихся точках (как в model_compare.load), отложенные в обучение не входят.
Выход: runs\\models\\heldout.md."""
import csv, math
import numpy as np
import model_compare as MC
from scipy.stats import norm

R = MC.R
X, y, w, g, src = MC.load()
lo, hi = X.min(0), X.max(0)
Z = lambda A: (A - lo) / np.where(hi > lo, hi - lo, 1)
import gui_convergence as C
D = {p['id']: p for p in csv.DictReader(open(R / 'setB/setB_design.csv', encoding='utf-8'))}
RR = {r['tag']: r for r in csv.DictReader(open(R / 'setB/setB_results.csv', encoding='utf-8'))}
Xh, yh, wh, tags = [], [], [], []
for pid, d in D.items():
    if d.get('set') != 'отложенная':
        continue
    # 27.10: досчитанные точки (…c, …cc) тоже берём — последний сошедшийся результат
    tag = next((t for t in (pid + 'cc', pid + 'c', pid) if t in RR and (lambda rows: bool(rows) and C.decision(rows))(
        C.closed_samples(R / 'setB' / t))), None)
    if tag is None:
        continue
    r = RR[tag]
    Xh.append([float(d['t_d']), float(d['L_mm']) / 6.6, math.log(float(d['dp_dzv_kPa'])), float(d['p_cons']),
               float(d['t0_dzv']), float(d.get('heater') or 0.0), float(d.get('p_main') or 5.5)])
    yh.append(float(r['dT_svz_vs_throttle'])); wh.append(0 if r.get('x_shock_m') else 1); tags.append(tag)
Xh, yh, wh = np.array(Xh), np.array(yh), np.array(wh)
span = y.max() - y.min()
L = ['# Внешняя проверка на отложенных геометриях добора Б', '',
     f'Обучение: {len(y)} точек; проверка: {len(yh)} сошедшихся точек отложенных геометрий ({", ".join(tags)}).', '',
     '| Модель | RMSE, K | % размаха | MAE, K | max |e|, K | верно рабочих/нерабочих, % |', '|---|---|---|---|---|---|']
for name, (fr, fc, pr, pc) in MC.models().items():
    m, c = fr(Z(X), y), fc(Z(X), w)
    e = pr(m, Z(Xh)) - yh; hit = (pc(c, Z(Xh)) >= 0.5) == (wh == 1)
    L.append(f'| {name} | {np.sqrt(np.mean(e ** 2)):.3f} | {100 * np.sqrt(np.mean(e ** 2)) / span:.1f} | {np.mean(np.abs(e)):.3f} | '
             f'{np.max(np.abs(e)):.3f} | {100 * hit.mean():.0f} |')
(R / 'models' / 'heldout.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
print('\n'.join(L))
