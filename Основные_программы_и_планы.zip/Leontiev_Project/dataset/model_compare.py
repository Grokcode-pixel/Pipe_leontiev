"""П. 4.1–4.2 плана 18.10: сравнение моделей и достаточность данных.
Данные: все сошедшиеся CFD (А9 без исключённых, набор А, станция, проверка А8, добор Б без отложенных геометрий B5x/B6x).
Факторы (7): t/d, L/d, ln перепада ДЗВ, давление потребителя, T0 ДЗВ, подогрев, давление магистрали.
Выход: эффект к дросселю (K); класс «рабочий» (нет скачка в канале).
Модели: ГП (текущая), CatBoost, квадратичная регрессия (Ridge на полиноме 2-й степени; логистическая для класса).
Проверка: GroupKFold по геометриям (отложена целая геометрия). Ошибка эффекта — K и % размаха; доля верно
распознанных рабочих режимов. Достаточность: кривая обучения (доля геометрий 40–100 %) + степенная аппроксимация
(Figueroa и др., 2012); критерий п. 4.2: e_avg < 0,1 размаха и RMSE ≤ 0,5 K; объём ≥ 10·d = 70.
Вывод: runs\\models\\compare.md."""
import csv, math, warnings
from pathlib import Path
import numpy as np
from scipy.optimize import curve_fit
from sklearn.model_selection import GroupKFold
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel as Ck, WhiteKernel
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import RidgeCV, LogisticRegression
from catboost import CatBoostRegressor, CatBoostClassifier
from scipy.stats import norm
warnings.filterwarnings('ignore')

R = Path(r'F:\Leontiev_Project\runs')
OUT = R / 'models'; OUT.mkdir(exist_ok=True)


STATION = True   # 27.10 18:20 (К3): сошедшиеся проверочные станционные точки ST4–ST12 (прогноз был записан до расчёта) — в обучение;
                 # ST1–ST3 остаются проверкой (station_gp.py)


def station_points():
    """[(x[7], строка результата, геометрия)] для сошедшихся ST4–ST12: x из прогнозов, записанных до расчёта."""
    import json
    import gui_convergence as C
    xs = {'ST4': [1.4, 400 / 6.6, math.log(10.0), 0.6, 0.0, 0.0, 3.0]}
    for f in ('forecasts.json', 'window_forecasts.json', 'task2_forecast.json', 'auto_forecasts.json', 'confirm_forecasts.json'):   # 27.10: + автопополнение
        p = R / 'journal' / f
        if p.exists():
            js = json.loads(p.read_text(encoding='utf-8'))
            if 'tag' in js:   # task2_forecast.json — одна точка ST13; досчёт сошёлся как ST13c
                xs[js['tag'] + 'c'] = js['x']
            else:
                xs.update({t: v['x'] for t, v in js.items()})
    # 31.10 (интерфейс автора, окно 3): точки серий интерфейса — только гладкие и только добавленные автором («в_обучение»);
    # годна, если сошлась по критериям или предел итераций с дисбалансом < 1 % Q (D-12); тег — фактическая папка результата
    gui, gp = set(), R / 'journal' / 'gui_forecasts.json'
    if gp.exists():
        for t, v in json.loads(gp.read_text(encoding='utf-8')).items():
            if v.get('в_обучение') and v.get('kind') == 'гладкая' and v.get('x'):
                tt = v.get('result_tag') or t
                xs[tt] = v['x']; gui.add(tt)
    RR = {}
    for f in ('station_results.csv', 'window0_results.csv', 'task2_results.csv', 'auto_results.csv', 'confirm_results.csv', 'gui_results.csv'):
        if (R / 'station' / f).exists():
            RR.update({r['tag']: r for r in csv.DictReader(open(R / 'station' / f, encoding='utf-8'))})
    d12 = lambda r: bool(r.get('net_W')) and abs(float(r['net_W'])) < 0.01 * abs(float(r['Q']))
    # 31.10 (D-30, заморозка): после заморозки в обучение идут только замороженные станционные точки (D-21) — новые расчёты
    # (sppr --confirm, интерфейс, автопополнение) — только проверка
    fz = R / 'models' / 'FREEZE.json'
    frozen = set(json.loads(fz.read_text(encoding='utf-8'))['station_tags']) if fz.exists() else None
    out = []
    for t0, x in xs.items():
        for t in (t0, t0 + 'c'):   # 29.10: досчёт группы «б» пишется как AUxxc (queue_1029.group_b)
            rows = C.closed_samples(R / 'station' / t) if (R / 'station' / t).exists() else []
            if frozen is not None and t not in frozen:
                continue
            if t in RR and rows and (C.decision(rows) or (t in gui and d12(RR[t]))) and RR[t].get('dT_svz_vs_throttle'):
                out.append((x, RR[t], f"{x[0]}/{round(x[1] * 6.6, 1)}"))   # та же запись, что у наборов А/Б: '1.4/400.0'
                break
    return out


def frozen_extra():
    """01.11 (D-32, D-33): точки добора В из окончательной заморозки — значения хранятся в самом FREEZE.json (extra_points:
    tag, x[7], эффект/Q/расходы — среднее окна D-12a, скачок); проверочные точки и A3a сюда не входят."""
    import json
    fz = R / 'models' / 'FREEZE.json'
    return json.loads(fz.read_text(encoding='utf-8')).get('extra_points', []) if fz.exists() else []


def load():
    X, y, w, g, src = [], [], [], [], []

    def add(d, r, geo, s):
        p_main = float(d.get('p_main') or 5.5)
        X.append([float(d['t_d']), float(d['L_mm']) / 6.6, math.log(float(d['dp_dzv_kPa'])), float(d['p_cons']),
                  float(d['t0_dzv']), float(d.get('heater') or 0.0), p_main])
        y.append(float(r['dT_svz_vs_throttle'])); w.append(0 if r.get('x_shock_m') else 1); g.append(geo); src.append(s)
    D = {p['id']: p for p in csv.DictReader(open(R / 'a9/a9_design.csv', encoding='utf-8'))}
    res = {r['tag']: r for r in csv.DictReader(open(R / 'a9/a9_results.csv', encoding='utf-8'))}
    for s in csv.DictReader(open(R / 'a9/a9_points_status.csv', encoding='utf-8')):
        if s['num_status'] == 'сошлась' and s['id'] not in ('A9_11', 'A9_35', 'A9_36'):
            d = D[s['id']]; add(d, res[s['result']], f"{d['t_d']}/{d['L_mm']}", 'А9')
    import gui_convergence as C
    def conv(dirp):
        rows = C.closed_samples(dirp)
        return bool(rows) and C.decision(rows)
    for ser, des, resf in (('setA', 'setA_design.csv', 'setA_results.csv'), ('setB', 'setB_design.csv', 'setB_results.csv')):
        if not (R / ser / resf).exists():
            continue
        DD = {p['id']: p for p in csv.DictReader(open(R / ser / des, encoding='utf-8'))}
        RR = {r['tag']: r for r in csv.DictReader(open(R / ser / resf, encoding='utf-8'))}
        for pid, d in DD.items():
            if d.get('set') == 'отложенная':
                continue
            for t in (pid + 'cc', pid + 'c', pid):   # 27.10: досчёт после паузы пишется как …cc (B04cc)
                if t in RR and conv(R / ser / t):
                    add(d, RR[t], f"{d['t_d']}/{d['L_mm']}", ser); break
    if STATION:
        for x, r, geo in station_points():
            X.append(list(x)); y.append(float(r['dT_svz_vs_throttle'])); w.append(0 if r.get('x_shock_m') else 1)
            g.append(geo); src.append('станция')
    for p in frozen_extra():
        X.append(list(p['x'])); y.append(float(p['effect'])); w.append(0 if p['shock'] else 1); g.append(p['geo']); src.append(p['src'])
    return np.array(X), np.array(y), np.array(w), np.array(g), src


def gp_fit(X, y):
    k = Ck(1.0) * Matern(length_scale=np.ones(X.shape[1]), length_scale_bounds=(0.05, 50), nu=2.5) + WhiteKernel(1e-3, (1e-6, 1e-1))
    return GaussianProcessRegressor(k, normalize_y=True, n_restarts_optimizer=1, random_state=0).fit(X, y)


def models():
    return {
        'ГП (текущая)': (lambda X, y: gp_fit(X, y), lambda X, w: gp_fit(X, 2.0 * w - 1.0),
                         lambda m, X: m.predict(X), lambda c, X: norm.cdf(c.predict(X) / np.maximum(c.predict(X, return_std=True)[1], 1e-6))),
        'CatBoost': (lambda X, y: CatBoostRegressor(iterations=600, depth=4, learning_rate=0.05, verbose=0, random_seed=0).fit(X, y),
                     lambda X, w: CatBoostClassifier(iterations=400, depth=4, verbose=0, random_seed=0).fit(X, w) if w.min() != w.max() else float(w[0]),
                     lambda m, X: m.predict(X), lambda c, X: np.full(len(X), c) if isinstance(c, float) else c.predict_proba(X)[:, 1]),
        'Квадратичная регрессия': (lambda X, y: make_pipeline(PolynomialFeatures(2), StandardScaler(), RidgeCV(alphas=np.logspace(-3, 3, 13))).fit(X, y),
                                   lambda X, w: make_pipeline(PolynomialFeatures(2), StandardScaler(), LogisticRegression(C=1.0, max_iter=2000)).fit(X, w) if w.min() != w.max() else float(w[0]),
                                   lambda m, X: m.predict(X), lambda c, X: np.full(len(X), c) if isinstance(c, float) else c.predict_proba(X)[:, 1]),
    }


def cv(X, y, w, g, name, frac=1.0, seed=0):
    fr, fc, pr, pc = models()[name]
    lo, hi = X.min(0), X.max(0); Z = (X - lo) / np.where(hi > lo, hi - lo, 1)
    G = np.unique(g); n = min(5, len(G))
    e, hit = [], []
    rng = np.random.default_rng(seed)
    for tr, te in GroupKFold(n_splits=n).split(Z, y, g):
        if frac < 1:
            keep_g = rng.choice(np.unique(g[tr]), max(2, int(round(frac * len(np.unique(g[tr]))))), replace=False)
            tr = tr[np.isin(g[tr], keep_g)]
        m, c = fr(Z[tr], y[tr]), fc(Z[tr], w[tr])
        e += list(pr(m, Z[te]) - y[te]); hit += list((pc(c, Z[te]) >= 0.5) == (w[te] == 1))
    return np.array(e), np.array(hit)


if __name__ == '__main__':
    X, y, w, g, src = load()
    span = y.max() - y.min()
    L = [f'# Сравнение моделей и достаточность данных (п. 4.1–4.2)', '',
         f'Точек CFD в обучении/проверке: {len(y)} ({", ".join(f"{s} {src.count(s)}" for s in sorted(set(src)))}); геометрий {len(set(g))}; '
         f'факторов 7 → нужно ≥ 70; размах эффекта {y.min():.2f}…{y.max():.2f} K; рабочих {int(w.sum())}, со скачком {int(len(w) - w.sum())}.', '',
         '| Модель | RMSE эффекта, K | % размаха | MAE, K | верно распознано рабочих/нерабочих, % |', '|---|---|---|---|---|']
    res = {}
    for name in models():
        e, hit = cv(X, y, w, g, name)
        res[name] = (e, hit)
        L.append(f'| {name} | {np.sqrt(np.mean(e ** 2)):.3f} | {100 * np.sqrt(np.mean(e ** 2)) / span:.1f} | {np.mean(np.abs(e)):.3f} | {100 * hit.mean():.0f} |')
    # learning curve for the GP (share of geometries), power-law fit
    fracs = (0.4, 0.55, 0.7, 0.85, 1.0)
    curve = []
    for f in fracs:
        es = [cv(X, y, w, g, 'ГП (текущая)', f, s)[0] for s in range(3 if f < 1 else 1)]
        curve.append(np.sqrt(np.mean(np.concatenate(es) ** 2)))
    n_pts = np.array(fracs) * len(y)
    try:
        (a, b, c), _ = curve_fit(lambda n, a, b, c: a * n ** (-b) + c, n_pts, curve, p0=(5, 0.5, 0.05), maxfev=20000)
        fit = f'RMSE ≈ {a:.2f}·n^(−{b:.2f}) + {c:.3f}; прогноз при 1,5n: {a * (1.5 * len(y)) ** (-b) + c:.3f} K, при 2n: {a * (2 * len(y)) ** (-b) + c:.3f} K'
    except Exception as ex:
        fit = f'аппроксимация не сошлась ({ex})'
    e = res['ГП (текущая)'][0]
    ok = (np.mean(np.abs(e)) < 0.1 * span) and (np.sqrt(np.mean(e ** 2)) <= 0.5) and len(y) >= 70
    L += ['', '## Кривая обучения (ГП, отложенная геометрия; доля геометрий в обучении)', '',
          '| доля геометрий | ~точек | RMSE, K |', '|---|---|---|'] + [f'| {f:.2f} | {n:.0f} | {r:.3f} |' for f, n, r in zip(fracs, n_pts, curve)]
    L += ['', fit, '', f'Критерий достаточности п. 4.2 (e_avg < 0,1 размаха, RMSE ≤ 0,5 K, n ≥ 70): {"ВЫПОЛНЕН" if ok else "НЕ выполнен"}.']
    # by main pressure
    pm = X[:, 6] < 5.4
    if pm.any():
        L.append(f'Отдельно по пониженному давлению магистрали ({int(pm.sum())} точек): RMSE ГП {np.sqrt(np.mean(e[pm[:len(e)]] ** 2)) if len(e) == len(pm) else float("nan"):.3f} K.')
    (OUT / 'compare.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
    print('\n'.join(L))
