"""16.10.2026 — А8: comparison of CFD-point selection strategies on the A9 reference (author: S3 alpha 10 %, eps 0.5 K;
reference + many repeats + confirming CFD; metric = effect in K).

Reference ("truth"): GP regression of the effect (heating vs throttle, K) + GP classifier "channel working" (no shock in
the channel), both fitted on ALL converged A9 points (A9_11, A9_35, A9_36 excluded by the author 16.10).
Factors (6): t/d, L/d (designer X0, 3x3 grid) and dp_dzv (log), p_cons, t0_dzv, heater (dispatcher U).
Decision of the LPR: the point of the candidate pool with the largest predicted effect among points with
P(working) >= 1 - alpha.  Same model and same recommendation rule for every strategy; they differ only in which
points they ask for (and S3 in when it stops):
  S1  maximin Latin hypercube, the whole budget at once;
  S2  sequential GP, next point = largest predictive std of the effect;
  S3  decision rule: next point where the recommendation may change (classifier uncertain AND effect could exceed the
      current best, or the current best is itself uncertain); statuses 'выдать' / 'досчитать' / 'вернуть'; stop when
      P(recommended point is not working) < alpha and the expected gain of one more CFD < eps.
Metrics per run: regret (K) = true effect at the reference optimum - true effect at the recommendation; recommending a
non-working regime; number of CFD used.  Output: runs\\a8\\a8_runs.csv, a8_summary.md."""
import csv, json, math, sys, time, warnings
from pathlib import Path
import numpy as np
from scipy.stats import norm, qmc
from sklearn.gaussian_process import GaussianProcessRegressor, GaussianProcessClassifier
from sklearn.gaussian_process.kernels import Matern, ConstantKernel as Ck, WhiteKernel
warnings.filterwarnings('ignore')

A9 = Path(r'F:\Leontiev_Project\runs\a9')
OUT = Path(r'F:\Leontiev_Project\runs\a8')
EXCL = {'A9_11', 'A9_35', 'A9_36'}
ALPHA, EPS = 0.10, 0.5
N0, BUDGET, REPEATS, NOISE_K = 8, 24, 50, 0.05      # NOISE_K: repeat-from-scratch spread (A9_43/44: 0.00 / 0.01 K)
LEVELS = (8, 12, 16, 20, 24)   # budgets at which all strategies are compared (regret curve)
STABLE_K = 3                   # S3 'выдать': the recommendation unchanged over the last 3 CFD
TD, LD = (1.2, 1.4, 1.6), (30.0, 60.0, 100.0)
LO = np.array([1.2, 30.0, math.log(0.5), 0.3, -10.0, 0.0])
HI = np.array([1.6, 100.0, math.log(139.0), 1.6, 20.0, 20.0])
NAMES = ['t/d', 'L/d', 'ln dp_dzv', 'p_cons', 'T0_dzv', 'heater']


def load():
    design = {p['id']: p for p in csv.DictReader(open(A9 / 'a9_design.csv', encoding='utf-8'))}
    res = {r['tag']: r for r in csv.DictReader(open(A9 / 'a9_results.csv', encoding='utf-8'))}
    X, y, w, ids = [], [], [], []
    global LOGM
    LOGM = []
    for s in csv.DictReader(open(A9 / 'a9_points_status.csv', encoding='utf-8')):
        if s['id'] in EXCL or s['num_status'] != 'сошлась':
            continue
        p, r = design[s['id']], res[s['result']]
        LOGM.append(math.log(float(s['m'])))
        X.append([float(p['t_d']), float(p['L_d']), math.log(float(p['dp_dzv_kPa'])), float(p['p_cons']),
                  float(p['t0_dzv']), float(p['heater'])])
        y.append(float(r['dT_svz_vs_throttle']))
        w.append(0 if r.get('x_shock_m') else 1)
        ids.append(s['id'])
    return np.array(X), np.array(y), np.array(w), ids


def z(X):
    return (np.asarray(X) - LO) / (HI - LO)


def gpr(X, y):
    k = Ck(1.0) * Matern(length_scale=np.ones(6), length_scale_bounds=(0.05, 20), nu=2.5) + WhiteKernel(1e-3, (1e-6, 1e-1))
    return GaussianProcessRegressor(k, normalize_y=True, n_restarts_optimizer=2, random_state=0).fit(z(X), y)


def gpc(X, w):
    """'Working' classifier: GP regression of the label +1 / -1, P(working) = Phi(mean / std).  (sklearn's Laplace GPC
    was tried first: its probabilities never exceed ~0.92 even deep inside the working region, so the alpha = 10 %
    rule could not be met at all.)  Confident far inside a class, uncertain at the boundary and far from data."""
    k = Ck(1.0) * Matern(length_scale=np.ones(6), length_scale_bounds=(0.05, 20), nu=2.5) + WhiteKernel(1e-2, (1e-4, 0.3))
    return GaussianProcessRegressor(k, normalize_y=False, n_restarts_optimizer=1, random_state=0).fit(z(X), 2.0 * w - 1.0)


def p_work(c, X):
    mu, sd = c.predict(z(X), return_std=True)
    return norm.cdf(mu / np.maximum(sd, 1e-6))


M_RANGE = (0.2, 1.0)   # 16.10 v2: validated m range (A5, author 11.10); v1 searched up to m ~3-4 (t/d 1.6, dp 100 kPa)
M_MODEL = None


def pool(rng, n_per_geo=250):
    """Candidates: 9 geometries x LHS of the regime; kept only where the predicted m = G_DZV/G_SVZ is inside the validated
    range (GP of ln m fitted on all A9 points) — the decision space of the LPR is the validated region."""
    global M_MODEL
    if M_MODEL is None:
        Xa, _, _, _ = load()
        M_MODEL = gpr(Xa, np.array(LOGM))
    s = qmc.LatinHypercube(d=4, seed=rng.integers(1 << 31)).random(n_per_geo * 9 * 4)
    U = LO[2:] + s * (HI[2:] - LO[2:])
    G = np.array([(t, l) for t in TD for l in LD]).repeat(n_per_geo * 4, axis=0)
    P = np.hstack([G, U])
    m = np.exp(M_MODEL.predict(z(P)))
    P = P[(m >= M_RANGE[0]) & (m <= M_RANGE[1])]
    keep = []
    for t in TD:
        for l in LD:   # equal number of candidates per geometry
            idx = np.where((P[:, 0] == t) & (P[:, 1] == l))[0]
            keep.extend(rng.permutation(idx)[:n_per_geo])
    return P[np.array(keep)]


def recommend(m, c, P):
    mu = m.predict(z(P))
    pw = p_work(c, P)
    ok = pw >= 1 - ALPHA
    i = int(np.argmax(np.where(ok, mu, -1e9))) if ok.any() else int(np.argmax(pw))
    return i, ok.any()


def maximin_lhs(P, n, rng, tries=30):
    best, bd = None, -1
    for _ in range(tries):
        idx = rng.choice(len(P), n, replace=False)
        Z = z(P[idx]); d = np.sqrt(((Z[:, None] - Z[None]) ** 2).sum(-1)); d[np.diag_indices(n)] = 9
        if d.min() > bd:
            best, bd = idx, d.min()
    return list(best)


def run_one(strategy, ref_m, ref_c, P, true_mu, true_w, rng, start_seed=0):
    """One strategy, one start; the 'CFD' answer is the reference (+ repeat noise)."""
    def ask(i):
        return true_mu[i] + rng.normal(0, NOISE_K), int(true_w[i])
    best_true = float(true_mu[np.argmax(np.where(true_w, true_mu, -1e9))])
    curve = {}   # n CFD -> (regret K, recommended point not working)
    if strategy == 'S1':   # a separate maximin LHS for every budget level
        for n in LEVELS:
            obs = {i: ask(i) for i in maximin_lhs(P, n, rng)}
            Xo = P[list(obs)]; yo = np.array([v[0] for v in obs.values()]); wo = np.array([v[1] for v in obs.values()])
            rec, feasible = recommend(gpr(Xo, yo), gpc(Xo, wo), P)
            curve[n] = (best_true - float(true_mu[rec]), int(not true_w[rec]))
    start = maximin_lhs(P, N0, np.random.default_rng(start_seed))   # the same start set for S2 and S3 in one repeat
    obs = {i: ask(i) for i in start}
    status, stop_reason, hist, stop = 'досчитать', 'бюджет', [], None
    while strategy != 'S1':
        Xo = P[list(obs)]; yo = np.array([v[0] for v in obs.values()]); wo = np.array([v[1] for v in obs.values()])
        m, c = gpr(Xo, yo), gpc(Xo, wo)
        rec, feasible = recommend(m, c, P)
        if len(obs) in LEVELS:
            curve[len(obs)] = (best_true - float(true_mu[rec]), int(not true_w[rec]))
        hist.append((tuple(P[rec][:2]), float(m.predict(z(P[rec:rec + 1]))[0])))
        if len(obs) >= BUDGET:
            break
        mu, sd = m.predict(z(P), return_std=True)
        pw = p_work(c, P)
        if strategy == 'S2':
            cand = sd.copy(); cand[list(obs)] = -1
            nxt = int(np.argmax(cand))
        else:   # S3
            best = mu[rec]
            ei = (mu - best) * norm.cdf((mu - best) / np.maximum(sd, 1e-9)) + sd * norm.pdf((mu - best) / np.maximum(sd, 1e-9))
            gain = ei * pw                                  # expected improvement of the decision, feasible part
            bound = pw * (1 - pw) * 4 * np.maximum(mu - best + 2 * sd, 0)   # boundary points that could flip the choice
            risk_rec = 1 - pw[rec]
            confirmed = rec in obs and obs[rec][1] == 1   # 'выдать' only after the recommended point itself is computed
            stable = len(hist) >= STABLE_K and len({h[0] for h in hist[-STABLE_K:]}) == 1 and \
                max(h[1] for h in hist[-STABLE_K:]) - min(h[1] for h in hist[-STABLE_K:]) < EPS
            if stop is None and confirmed and stable and risk_rec < ALPHA and gain.max() < EPS and feasible:
                # the decision rule stops here; the run goes on only to draw the same regret curve as S2
                status, stop_reason = 'выдать', 'подтверждена CFD, устойчива, P(ошибки) < α, выигрыш < ε'
                stop = (len(obs), best_true - float(true_mu[rec]), int(not true_w[rec]))
            score = np.maximum(gain, bound)
            if rec not in obs:        # the recommended point itself not computed -> compute it (confirming CFD)
                score[rec] = score.max() + 1
            score[list(obs)] = -1
            nxt = int(np.argmax(score))
        obs[nxt] = ask(nxt)
    if strategy == 'S1':
        n_used, reg_used, bad_used = BUDGET, *curve[BUDGET]
        rec_txt = ''
    else:
        if not feasible and stop is None:
            status = 'вернуть'
        n_used, reg_used, bad_used = stop if stop else (len(obs), best_true - float(true_mu[rec]), int(not true_w[rec]))
        rec_txt = f'{P[rec][0]:.1f}/{P[rec][1]:.0f}'
    row = dict(strategy=strategy, n_cfd=n_used, regret_K=round(reg_used, 3), rec_not_working=bad_used, status=status,
               stop=stop_reason, rec_geometry=rec_txt)
    for n in LEVELS:
        row[f'regret_{n}'] = round(curve[n][0], 3)
        row[f'bad_{n}'] = curve[n][1]
    return row


def loo(X, y, w):
    """Accuracy of the reference itself: leave-one-out."""
    e, hit = [], []
    for i in range(len(X)):
        k = np.arange(len(X)) != i
        e.append(float(gpr(X[k], y[k]).predict(z(X[i:i + 1]))[0] - y[i]))
        hit.append(int((p_work(gpc(X[k], w[k]), X[i:i + 1])[0] >= 0.5) == w[i]))
    return np.array(e), np.array(hit)


if __name__ == '__main__':
    OUT.mkdir(exist_ok=True)
    X, y, w, ids = load()
    t0 = time.time()
    e, hit = loo(X, y, w)
    ref_m, ref_c = gpr(X, y), gpc(X, w)
    info = dict(points=len(X), working=int(w.sum()), effect_range=[float(y.min()), float(y.max())],
                loo_rmse_K=round(float(np.sqrt((e ** 2).mean())), 3), loo_mae_K=round(float(np.abs(e).mean()), 3),
                loo_class_acc=round(float(hit.mean()), 3), kernel=str(ref_m.kernel_))
    print(json.dumps(info, ensure_ascii=False, indent=1), flush=True)
    rows = []
    for rep in range(REPEATS):
        rng = np.random.default_rng(1000 + rep)
        P = pool(rng)
        true_mu, true_w = ref_m.predict(z(P)), p_work(ref_c, P) >= 0.5
        for s in ('S1', 'S2', 'S3'):
            r = run_one(s, ref_m, ref_c, P, true_mu, true_w, np.random.default_rng(rep * 10 + int(s[1])), 5000 + rep)
            r['repeat'] = rep
            rows.append(r)
        print(f'{rep + 1}/{REPEATS} {time.time() - t0:.0f} s', flush=True)
        with open(OUT / 'a8_runs.csv', 'w', newline='', encoding='utf-8') as f:
            wr = csv.DictWriter(f, fieldnames=list(rows[0])); wr.writeheader(); wr.writerows(rows)
    lines = ['# А8 — итог сравнения стратегий на эталоне А9', '', f'Эталон: {json.dumps(info, ensure_ascii=False)}', '',
             f'N0 = {N0}, бюджет ≤ {BUDGET}, повторов {REPEATS}, α = {ALPHA}, ε = {EPS} K, шум повтора {NOISE_K} K', '',
             '## Недобор эффекта рекомендации (K), среднее / 90 % по повторам, при числе CFD',
             '| Стратегия | ' + ' | '.join(str(n) for n in LEVELS) + ' |', '|---|' + '---|' * len(LEVELS)]
    for s in ('S1', 'S2', 'S3'):
        rr = [r for r in rows if r['strategy'] == s]
        cells = []
        for n in LEVELS:
            reg = np.array([r[f'regret_{n}'] for r in rr]); bad = np.mean([r[f'bad_{n}'] for r in rr])
            cells.append(f'{reg.mean():.2f} / {np.quantile(reg, 0.9):.2f}' + (f' (недоп. {100 * bad:.0f} %)' if bad else ''))
        lines.append(f'| {s} | ' + ' | '.join(cells) + ' |')
    rr = [r for r in rows if r['strategy'] == 'S3']
    st = [r for r in rr if r['status'] == 'выдать']
    lines += ['', '## S3 — остановка по правилу ЛПР (α, ε, подтверждение CFD, устойчивость)',
              f"- «выдать»: {100 * len(st) / len(rr):.0f} % повторов; «вернуть»: {100 * np.mean([r['status'] == 'вернуть' for r in rr]):.0f} %; "
              f"не остановился до бюджета {BUDGET}: {100 * np.mean([r['status'] == 'досчитать' for r in rr]):.0f} %"]
    if st:
        reg = np.array([r['regret_K'] for r in st])
        lines.append(f"- при «выдать»: CFD {np.mean([r['n_cfd'] for r in st]):.1f} (мин {min(r['n_cfd'] for r in st)}, "
                     f"макс {max(r['n_cfd'] for r in st)}); недобор {reg.mean():.2f} K (90 % — {np.quantile(reg, 0.9):.2f}); "
                     f"доля с недобором < ε: {100 * np.mean(reg < EPS):.0f} %; недопустимый режим: "
                     f"{100 * np.mean([r['rec_not_working'] for r in st]):.0f} %")
    (OUT / 'a8_summary.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))
