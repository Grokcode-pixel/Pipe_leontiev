"""Two already prepared h1 meshes; same-shape source, no cold startup."""
import sys,traceback
from pathlib import Path
import knurl_family_1103_v7_cfd as F
F.PLAN=Path(__file__).resolve().parent.parent/'runs/plans/grid_h1_cfd_1104_v1.json'
F.OUT=F.R/'runs/grid_h1_cfd_1104_v1'
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='check':
  p=F.registered()
  for c in p['cases']:F.same_shape(c['params'],F.load(c['source_params']))
  print('CHECK OK: two same-shape prepared meshes, PR, unchanged own-source regime, no cold startup')
 else:
  try:F.run()
  except Exception as e:
   F.OUT.mkdir(exist_ok=True);F.save(F.OUT/'BLOCK.json',dict(time=F.A.now(),error=str(e),traceback=traceback.format_exc()));raise
