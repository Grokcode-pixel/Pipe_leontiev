"""Offline report correction; no Fluent/Workbench calls, no changes to CFD inputs.
A timestamped hash plan is required before each read-only analysis.
"""
import hashlib,json,math,re,statistics,subprocess,sys
from pathlib import Path
D=Path(__file__).resolve().parent
R=D.parent
sys.path.insert(0,str(D))
import leontiev_pipeline as L
import grs_temps,passport,gui_runner as G

def now(fmt='o'):
    return subprocess.check_output(['powershell','-NoProfile','-Command','Get-Date -Format '+fmt],text=True).strip()
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest().upper()
def save(p,v):
    Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def sides(template):
    rows={}
    for filename in ('s4.trn','s5.trn'):
        for line in (Path(template)/filename).read_text(errors='replace').splitlines():
            m=re.match(r'^\s*\d+\s+(\S+)\s+wall\s+(\S+)\s+face\s*$',line)
            if m:rows[m[1]]=m[2]
            m=re.match(r'^>?\s*/mesh/modify-zones/zone-name\s+(\S+)\s+(\S+)\s*$',line)
            if m and m[1] in rows:rows[m[2]]=rows[m[1]]
    out={}
    for ch,base in [('svz','wall-air_svz-wall_abonite'),('dzv','interior-air_dzv-wall_abonite')]:
        pair={n:rows.get(n) for n in (base,base+'-shadow')}
        sol=[n for n,v in pair.items() if v=='latun']
        gas=[n for n,v in pair.items() if v in ('air','methane','ch4','ch4_pr')]
        if len(sol)!=1 or len(gas)!=1:raise RuntimeError('Unproven gas/solid pair '+str(pair))
        out[ch]=dict(solid=sol[0],gas=gas[0],materials=pair)
    return out

def samples(folder,side):
    out=[]
    for b in sorted(Path(folder).glob('coupled_*.trn')):
        ss,res=L.parse_trn(b)
        if not ss:continue
        if not res:raise RuntimeError('No iteration evidence '+str(b))
        for s in ss:
            f=s['flux'];q=f[side['dzv']['solid']]
            if not all(math.isfinite(x) for x in (q,s['net'],s['inlet_mass_flow_rate_svz'],s['inlet_mass_flow_rate_dzv'])):raise RuntimeError('Nonfinite sample')
            out.append(dict(iteration=res[-1]['it'],Q=q,raw_Q=f['interior-air_dzv-wall_abonite'],G_svz=s['inlet_mass_flow_rate_svz'],G_dzv=s['inlet_mass_flow_rate_dzv'],net=s['net'],
                svz_pair_sum=f[side['svz']['solid']]+f[side['svz']['gas']],dzv_pair_sum=f[side['dzv']['solid']]+f[side['dzv']['gas']],
                solid_through_difference=f[side['svz']['solid']]+q,
                svz_channel_balance=f['inlet_svz']+f['outlet_svz']+f[side['svz']['gas']],
                dzv_channel_balance=f['inlet_dzv']+f['outlet_dzv']+f[side['dzv']['gas']],
                yp_svz=s.get('yp_svz'),yp_dzv_raw=s.get('yp_dzv')))
    if not out or len({r['iteration'] for r in out})!=len(out):raise RuntimeError('No/duplicate sample iterations')
    return out

def evaluate(rows,regime):
    last=rows[-1]['iteration'];w=[dict(r) for r in rows if r['iteration']>=last-1000]
    for r in w:
        r['effect']=grs_temps.outlet_temps(r['Q'],r['G_svz'],r['G_dzv'],273.15+regime['T0_svz'],regime['p_main'],regime['p_cons'],regime['p_out_dzv'],regime['p0_dzv'],T0_dzv_K=273.15+regime['T0_dzv'])['dT_svz_vs_throttle']
    mean=lambda k:statistics.mean(r[k] for r in w)
    amp=lambda k:(max(r[k] for r in w)-min(r[k] for r in w))/2
    a=[r for r in w if r['iteration']<=last-500];b=[r for r in w if r['iteration']>last-500]
    drift=lambda k:abs(statistics.mean(r[k] for r in a)-statistics.mean(r[k] for r in b)) if a and b else math.inf
    q=mean('Q')
    if abs(q)<1e-9:raise RuntimeError('Mean Q near zero')
    o=dict(n=len(w),it=[w[0]['iteration'],last],full_window=len(w)>=3 and last-w[0]['iteration']>=1000,Q=q,effect=mean('effect'),G_svz=mean('G_svz'),G_dzv=mean('G_dzv'),imb_pct=100*mean('net')/abs(q),imb_max_pct=max(100*abs(r['net']/r['Q']) for r in w),eff_amp=amp('effect'),Q_amp_pct=100*amp('Q')/abs(q),Gs_amp_pct=100*amp('G_svz')/abs(mean('G_svz')),Gd_amp_pct=100*amp('G_dzv')/abs(mean('G_dzv')),drift_eff=drift('effect'),drift_Q_pct=100*drift('Q')/abs(q),drift_Gs_pct=100*drift('G_svz')/abs(mean('G_svz')),drift_Gd_pct=100*drift('G_dzv')/abs(mean('G_dzv')),
        max_pair_mismatch_W=max(abs(r[k]) for r in w for k in ('svz_pair_sum','dzv_pair_sum')),max_solid_difference_W=max(abs(r['solid_through_difference']) for r in w),channel_mean_balance_W={ch:mean(ch+'_channel_balance') for ch in ('svz','dzv')},raw_Q_mean=mean('raw_Q'),samples=w)
    o['checks']=dict(imb=abs(o['imb_pct'])<1,eff=o['eff_amp']<=.05,Q=o['Q_amp_pct']<=1,G=max(o['Gs_amp_pct'],o['Gd_amp_pct'])<=.5,drift=o['drift_eff']<.025 and o['drift_Q_pct']<.5 and max(o['drift_Gs_pct'],o['drift_Gd_pct'])<.25)
    o['accepted']=o['full_window'] and all(o['checks'].values())
    return o

def audit(item):
    folder=Path(item['folder']);side=sides(item['template']);rr=samples(folder,side)
    o=evaluate(rr,passport.regime_from_jou((folder/'cont.jou').read_text(encoding='utf-8')));o['sides']=side
    o['files_complete']=all((folder/f).is_file() and (folder/f).stat().st_size>0 for f in ('result.cas.h5','result.dat.h5','axis.csv'))
    st=G.status(folder) or {};o['no_solver_error']=not st.get('fpe') and not st.get('error')
    o['accepted'] &= o['files_complete'] and o['no_solver_error']
    valid=side['dzv']['gas']=='interior-air_dzv-wall_abonite-shadow'
    o['yplus']=dict(svz=rr[-1]['yp_svz'],dzv=rr[-1]['yp_dzv_raw'] if valid else None,dzv_valid=valid,raw_dzv=rr[-1]['yp_dzv_raw'])
    o['physical']=G.classify(folder,{'l_heat_mm':400.},G.converged(folder))
    return o

def make_plan():
    out=R/'runs'/('grid_1103_report_audit_'+now('yyyyMMdd_HHmmss'));out.mkdir(exist_ok=False)
    items=[dict(tag='W1',folder=str(R/'runs/knurl_cont/W1'),template=str(R/'runs/patents/KM01_A9_19_tpl'))]
    for tag in ('G1','G2'):
        f=R/'runs/grid_1103_v8'/tag
        if all((f/n).is_file() for n in ('result.cas.h5','result.dat.h5','axis.csv')):items.append(dict(tag=tag,folder=str(f),template=str(f.parent/(tag+'_template'))))
    files=[]
    for item in items:
        f=Path(item['folder']);t=Path(item['template'])
        files+=list(f.glob('coupled_*.trn'))+list(f.glob('fluent-*.trn'))+[f/n for n in ('cont.jou','result.cas.h5','result.dat.h5','axis.csv')]+[t/n for n in ('s4.trn','s5.trn')]
    codes=[Path(__file__),D/'leontiev_pipeline.py',D/'grs_temps.py',D/'passport.py',D/'gui_runner.py']
    p=out/'plan.json';save(p,dict(made=now(),authorization='Author: continue handover and correct reporting; D47 unchanged; offline only.',items=items,expected=['W1','G1','G2'],output=str(out),source_sha256={str(f):sha(f) for f in files},code_sha256={str(f):sha(f) for f in codes},thresholds=dict(effect_K=.1,Q_pct=2,G_svz_pct=2,G_dzv_pct=2),rule='Trace material through actual rename commands. Q is measured solid-DZV flux, never abs(Q) chosen as correction. Recompute enthalpy per sample, unchanged D12a tolerances with magnitude denominators. No solver calls.'))
    p.with_suffix('.sha256').write_text(sha(p),encoding='ascii');print(p)

def run(p):
    p=Path(p);plan=json.loads(p.read_text(encoding='utf-8'))
    if sha(p)!=p.with_suffix('.sha256').read_text().strip():raise RuntimeError('Changed plan')
    for f,h in {**plan['code_sha256'],**plan['source_sha256']}.items():
        if sha(f)!=h:raise RuntimeError('Changed input '+f)
    out=Path(plan['output'])
    if (out/'results.json').exists():raise RuntimeError('Already completed, use new timestamped plan')
    res={i['tag']:audit(i) for i in plan['items']};checks=[]
    for a,b in [('W1','G1'),('W1','G2'),('G1','G2')]:
        if a not in res or b not in res:continue
        x,y=res[a],res[b];d=dict(effect_K=abs(y['effect']-x['effect']))
        d.update({k+'_pct':100*abs(y[k]/x[k]-1) for k in ('Q','G_svz','G_dzv')})
        checks.append(dict(pair=[a,b],delta=d,passed=all(d[k]<=v for k,v in plan['thresholds'].items())))
    complete=set(res)==set(plan['expected'])
    summary=dict(finished=now(),complete=complete,pending=[k for k in plan['expected'] if k not in res],comparisons=checks,local_mesh_sensitivity_passed=complete and all(r['accepted'] for r in res.values()) and len(checks)==3 and all(c['passed'] for c in checks),limitation='Local nonuniform mesh sensitivity only. Not GCI, all shapes, or physics validation. New mesh DZV y+ needs correct gas-side measurement without iterations.')
    save(out/'results.json',res);save(out/'summary.json',summary)
    lines=['# Исправленная проверка отчёта по сторонам стыка','',summary['finished'],'','Только сохранённые данные: CFD, исходные отчёты и настройки не изменялись.','',
        '| Сетка | Q, Вт | Эффект, K | GСВЗ, кг/с | GДЗВ, кг/с | Дисбаланс, % Q | Окно | y+ ДЗВ |','|---|---:|---:|---:|---:|---:|---|---|']
    for tag,r in res.items():lines.append(f"| {tag} | {r['Q']:.4f} | {r['effect']:.4f} | {r['G_svz']:.8f} | {r['G_dzv']:.8f} | {r['imb_pct']:+.4f} | {r['it']} | {r['yplus']['dzv'] if r['yplus']['dzv_valid'] else 'не измерен корректно'} |")
    lines+=['','Положительный Q — тепло из ДЗВ через стенку в СВЗ. Сторона доказана материалом и журналом переименования. Эффект заново вычислен по энтальпии, а не простым удалением минуса.',
        'Старый монитор y+ ДЗВ на новых сетках выбрал твёрдую сторону: служебное −1e20 было скрыто нулём внешней симметрии. Нулевой y+ не является результатом измерения; нужно чтение сохранённого поля без итераций.', '',json.dumps(summary,ensure_ascii=False,indent=2)]
    (out/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({k:{n:v[n] for n in ('Q','effect','imb_pct','accepted')} for k,v in res.items()},ensure_ascii=False));print(out/'report.md')
if __name__=='__main__':
    if sys.argv[1:]==['make-plan']:make_plan()
    elif len(sys.argv)==3 and sys.argv[1]=='run':run(sys.argv[2])
    else:raise SystemExit('make-plan | run PLAN')