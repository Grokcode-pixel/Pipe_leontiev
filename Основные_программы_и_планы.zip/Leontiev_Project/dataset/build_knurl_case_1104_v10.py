"""v9 native builder plus quality evidence from the FINAL prepared mesh.

Old raw-stage warnings remain evidence, but cannot describe final contact topology.
No geometry, mesh, material, solver or initialization setting is changed.
"""
import json,re
from pathlib import Path
import leontiev_pipeline as L
import build_knurl_case_1103_v9 as B

def final_quality(text):
    B.final_mesh_ok(text)
    B.final_side_check(text)
    found=re.findall(r'Minimum Orthogonal Quality\s*=\s*([\d.eE+-]+).*?zone\s+(\d+).*?location\s*\(\s*([\d.eE+-]+),\s*([\d.eE+-]+)',text)
    if len(found)!=1:raise RuntimeError('Exactly one FINAL mesh quality record is required')
    q,zone,x,y=found[0];q=float(q)
    if not 0<q<=1:raise RuntimeError('Invalid FINAL orthogonal quality')
    return dict(stage='final_prepared_mesh',minimum_orthogonal_quality=q,zone_id=int(zone),location_m=[float(x),float(y)],native_warning_below_001=bool(re.search(r'minimum Orthogonal Quality below 0.01',text,re.I)),physical_accuracy_proven=False)

def add_final_quality_command(text):
    if text.count('/mesh/check')!=1 or text.count('/solve/initialize/hyb-initialization')!=1:
        raise RuntimeError('Unexpected final initialization journal protocol')
    if '/mesh/quality' in text:raise RuntimeError('Quality command already present')
    return text.replace('/mesh/check','/mesh/check\n/mesh/quality',1)

def build(msh,outdir,p0_svz_MPa=5.5,interpolate=False):
    """Same v9 preparation; record native quality after final contacts and names."""
    out=Path(outdir);run=L.run_fluent;insertions=[]
    def audited(journal,**kwargs):
        p=Path(journal)
        text=p.read_text(encoding='utf-8')
        if '/solve/initialize/hyb-initialization' in text:
            if insertions:raise RuntimeError('Repeated final initialization session')
            p.write_text(add_final_quality_command(text),encoding='utf-8')
            insertions.append(str(p))
        return run(journal,**kwargs)
    L.run_fluent=audited
    try:result=B.build(msh,out,p0_svz_MPa=p0_svz_MPa,interpolate=interpolate)
    finally:L.run_fluent=run
    if len(insertions)!=1:raise RuntimeError('Missing final-stage quality inspection')
    evidence=final_quality((out/'s5.trn').read_text(errors='replace'))
    (out/'final_quality.json').write_text(json.dumps(evidence,indent=2)+'\n',encoding='utf-8')
    result['final_quality']=evidence
    return result
