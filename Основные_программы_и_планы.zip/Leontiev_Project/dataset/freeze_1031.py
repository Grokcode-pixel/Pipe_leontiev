"""31.10.2026 — решение автора (D-30, п. 2): заморозка гладкого датасета СЕЙЧАС (A9_19 проверен, накатка в датасет не входит).
1) Снимок обучения: точки (папки), станционные метки, хеш данных → runs\\models\\FREEZE.json; после него сборщик
   (model_compare.station_points) берёт только замороженные станционные точки; новые расчёты — только проверка (D-21).
2) Главная ошибка эффекта — проверка по геометриям (GroupKFold по t/d / L, 5 частей), ГП (MC.gp_fit), на замороженных данных.
3) Классификатор по D-11 (classifier_final: минимум опасных «скачок → рабочий» на вложенной проверке по геометриям, при равенстве —
   меньше в «досчитать»), порог p_hi — ФИКСИРУЕТСЯ (в программе больше не пересчитывается).
4) Калибровка σ (D-25) заново на финальной модели: |z| = |факт − прогноз| / σ на проверке по геометриям; множитель
   k = max(квантиль 68 % |z|; квантиль 95 % |z| / 1,96); независимая сверка — A3a (3 новые трубы, в обучение не входят).
Вывод: FREEZE.json, runs\\models\\заморозка_20261031.md; строка в Журнал_работ.md."""
import csv, contextlib, hashlib, io, json, math, sys, time
import numpy as np
from sklearn.model_selection import GroupKFold
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import model_compare as MC
import passport as PS

R = MC.R
FZ = R / 'models' / 'FREEZE.json'


def gp_cv(X, y, g):
    lo, hi = X.min(0), X.max(0); Z = (X - lo) / np.where(hi > lo, hi - lo, 1)
    mu, sd = np.zeros(len(y)), np.zeros(len(y))
    for tr, te in GroupKFold(n_splits=5).split(Z, y, g):
        m = MC.gp_fit(Z[tr], y[tr])
        mu[te], sd[te] = m.predict(Z[te], return_std=True)
    return mu, sd


def a3a(X, y):
    """A3a: сошедшиеся точки трёх новых труб — прогноз модели на всех замороженных данных (σ без множителя)."""
    lo, hi = X.min(0), X.max(0); Z = lambda A: (A - lo) / np.where(hi > lo, hi - lo, 1)
    m = MC.gp_fit(Z(X), y)
    fc = json.loads((R / 'a3a' / 'forecasts.json').read_text(encoding='utf-8'))
    res = {r['tag']: r for r in csv.DictReader(open(R / 'a3a' / 'a3a_results.csv', encoding='utf-8'))}
    out = []
    for pid, f in fc.items():
        t = next((t for t in (pid + 'c', pid) if t in res and str(res[t]['status']).startswith('сошёлся') and res[t].get('dT_svz_vs_throttle')), None)
        if not t:
            continue
        x = np.array([[f['td'], f['L'] / 6.6, math.log(f['dp']), f['pc'], f['t0'], 0.0, f['pm']]])
        mu, s = m.predict(Z(x), return_std=True)
        mm = float(res[t]['G_dzv']) / float(res[t]['G_svz'])
        out.append(dict(tag=t, fact=float(res[t]['dT_svz_vs_throttle']), mu=float(mu[0]), sd=float(s[0]), m=mm, omega=0.2 <= mm <= 0.96))
    return out


if __name__ == '__main__':
    if FZ.exists():
        sys.exit('FREEZE.json уже есть — заморозка сделана; повторно не перезаписываю')
    t0 = time.time()
    tp = PS.training_points()
    st = [r['tag'] for x, r, geo in MC.station_points()]
    X, y, w, g, src = MC.load()
    h = hashlib.sha256(np.round(np.column_stack([X, y]), 6).tobytes()).hexdigest().upper()
    # 2) главная ошибка — по геометриям
    mu, sd = gp_cv(X, y, g)
    e = mu - y
    rmse, mae = float(np.sqrt(np.mean(e ** 2))), float(np.mean(np.abs(e)))
    z = np.abs(e) / np.maximum(sd, 1e-9)
    q68, q95 = float(np.quantile(z, 0.68)), float(np.quantile(z, 0.95))
    k = round(max(q68, q95 / 1.96), 2)
    cov = lambda kk: (float(np.mean(z <= kk)), float(np.mean(z <= 2 * kk)))
    # 3) классификатор по D-11
    with contextlib.redirect_stdout(io.StringIO()):
        import classifier_final as CF
    best, q = CF.best, CF.out[CF.best]
    # 4) независимая сверка A3a
    aa = a3a(X, y)
    inn = [r for r in aa if r['omega']]
    za = np.array([abs(r['fact'] - r['mu']) / r['sd'] for r in aa]) if aa else np.array([])
    fz = dict(time=time.strftime('%d.%m.%Y %H:%M:%S'), decision='D-30 (решение автора 31.10): заморозка гладкого датасета', n_points=len(y),
              sources={s: src.count(s) for s in sorted(set(src))}, n_geometries=int(len(set(g))), folders=[str(p) for _, p, _ in tp],
              station_tags=st, data_sha256=h, effect_geometry_cv=dict(rmse_K=round(rmse, 3), mae_K=round(mae, 3), folds='GroupKFold 5 по геометриям'),
              classifier=best, p_hi=round(float(q['p_hi']), 3), classifier_nested=dict(danger=int(q['nested_danger']), accepted=int(q['acc'])),
              sigma_mult=k, sigma_cal=dict(q68=round(q68, 3), q95=round(q95, 3), cov_raw=[round(v, 3) for v in cov(1.0)], cov_k=[round(v, 3) for v in cov(k)]),
              a3a=aa)
    FZ.write_text(json.dumps(fz, ensure_ascii=False, indent=1), encoding='utf-8')
    n_sh = int((CF.w == 0).sum())
    L = [f"# Заморозка гладкого датасета ({fz['time']}, решение автора D-30)", '',
         f"Точек в обучении: **{len(y)}** ({', '.join(f'{s} {c}' for s, c in fz['sources'].items())}); геометрий {fz['n_geometries']}; "
         f"хеш данных SHA256 {h[:16]}…; список — runs\\models\\FREEZE.json. Накатка, сопло, A3a, проверочные точки — не в обучении.", '',
         '## Главная ошибка эффекта — проверка по геометриям (ГП, отложена целая геометрия, 5 частей)', '',
         f"RMSE **{rmse:.3f} K**, MAE {mae:.3f} K (было 0,221 K на 106 точках 27.10).", '',
         '## Классификатор «рабочий / скачок» по D-11 (вложенная проверка по геометриям)', '',
         '| модель | p_hi | опасных «скачок → рабочий», вложенная CV | рабочих признано (CV) |', '|---|---|---|---|']
    L += [f"| {nm} | {o['p_hi']:.3f} | {o['nested_danger']} из {n_sh} | {o['acc']} из {int(CF.w.sum())} |" for nm, o in CF.out.items()]
    L += ['', f"Выбран по D-11: **{best}**, порог p_hi = **{q['p_hi']:.3f}** — фиксирован (программа берёт его из FREEZE.json, не пересчитывает).", '',
          '## Калибровка σ (D-25) на финальной модели', '',
          f"|факт − прогноз| / σ на проверке по геометриям ({len(y)} точек): квантиль 68 % — {q68:.2f}, квантиль 95 % — {q95:.2f}. "
          f"Покрытие без множителя ±1σ / ±2σ: {100 * cov(1.0)[0]:.0f} / {100 * cov(1.0)[1]:.0f} %. "
          f"Множитель **k = {k:.2f}** (было 1,6): покрытие ±kσ / ±2kσ — {100 * cov(k)[0]:.0f} / {100 * cov(k)[1]:.0f} % (цель 68 / 95 %).", '',
          '## Независимая сверка — A3a (3 новые трубы, в обучение не входят)', '',
          '| точка | Fluent, K | прогноз ± kσ, K | разница, K | в ±kσ | m (Ω) |', '|---|---|---|---|---|---|']
    L += [f"| {r['tag']} | {r['fact']:+.2f} | {r['mu']:+.2f} ± {k * r['sd']:.2f} | {r['mu'] - r['fact']:+.2f} | {'да' if abs(r['mu'] - r['fact']) <= k * r['sd'] else 'нет'} | "
          f"{r['m']:.2f} ({'в Ω' if r['omega'] else 'вне Ω'}) |" for r in aa]
    if aa:
        ea = np.array([r['mu'] - r['fact'] for r in aa])
        L += ['', f"A3a: RMSE {np.sqrt(np.mean(ea ** 2)):.3f} K на {len(aa)} точках (в Ω — {len(inn)}); в ±kσ — {int(np.sum(za <= k))} из {len(aa)}."]
    L += ['', f'Время {time.time() - t0:.0f} с. Скрипт dataset\\freeze_1031.py.']
    (R / 'models' / 'заморозка_20261031.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
    print('\n'.join(L))
    with open(r'F:\Leontiev_Project\Журнал_работ.md', 'a', encoding='utf-8') as fj:
        fj.write(f"- {time.strftime('%d.%m.%Y %H:%M')} — ЗАМОРОЗКА гладкого датасета (D-30): {len(y)} точек, {fz['n_geometries']} геометрий; ошибка эффекта по геометриям "
                 f"RMSE {rmse:.3f} K; классификатор по D-11 — {best}, p_hi {q['p_hi']:.3f} (фиксирован); σ × {k:.2f} (было 1,6); "
                 f"runs\\models\\FREEZE.json, заморозка_20261031.md\n")
