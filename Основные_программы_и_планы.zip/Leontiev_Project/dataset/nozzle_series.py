"""29.10.2026 — D-26: сопло как фактор, план — срезанный ЛГК (runs\\plans\\nozzle.json, plan_design.py; решение автора: серии
собирать по методу работы). Срезы — сопло (A/A* 1,44 / 2,15 / 2,92) × L (200 / 400 мм), по 3 режима; t/d 1,4.
Первая точка среза: текущее сопло — продолжение от гладкого кейса той же геометрии; новое сопло — шаблон новой сетки (Workbench,
срез сопла P26) + перенос поля гладкой трубы той же длины при магистрали 5,5 МПа, затем продолжение (ступени магистрали 0,75 МПа).
Стоп-правило: первые 2 расчёта серии не сошлись — стоп. Ждёт окончания разведки мелкой накатки; A3a — после неё.
Итог: runs\\nozzle\\nozzle_results.csv, журнал runs\\nozzle\\a9_log.txt."""
import json, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_a9 as A
import leontiev_pipeline as L

R = Path(r'F:\Leontiev_Project\runs')
OUT = R / 'nozzle'; OUT.mkdir(exist_ok=True)
A.BASE, A.CSV, A.AUX = OUT, OUT / 'nozzle_results.csv', OUT / 'nozzle_aux.csv'
A.POINT_LIMIT = 6000
PLAN = json.loads((R / 'plans' / 'nozzle.json').read_text(encoding='utf-8'))
_cp = A.cell_params
R_E = {'v': 3.3}


def cell_params(td, l_mm, run_id, pt, gas, startup, coupled):
    p, cell = _cp(td, l_mm, run_id, pt, gas, startup, coupled)
    c2 = L.cell_geometry(td, 1.5, 4.8, R_E['v'])
    p.update(r_nozzle_exit_mm=R_E['v'], wall_thickness_inlet_mm=c2['wall_thickness_inlet_mm'])
    return p, cell


A.cell_params = cell_params


def wait_prev():
    import auto_enrich as AE
    while A.G.fluent_running() or any(AE._task_running(t) for t in ('Leontiev_queue_1029', 'Leontiev_knurl_eqflow', 'Leontiev_knurl_shallow')):
        time.sleep(120)


def smooth_case(td, L_mm):
    import auto_enrich as AE
    cands = [(p, x) for p, x in AE.sources() if abs(x[0] - td) < 1e-6 and abs(x[1] * 6.6 - L_mm) < 0.5]
    return min(cands, key=lambda t: abs(t[1][6] - 5.5) + abs(t[1][3] - 0.6))


def reg(pm, pc, dp):
    return (pm, pc, pm, round(pm - dp / 1000, 6))


def walk(cur, pm_cur, q, tag, L_mm):
    k = 0
    while abs(q['pm'] - pm_cur) > 0.8:
        k += 1; pm_cur = round(pm_cur + (0.75 if q['pm'] > pm_cur else -0.75), 2)
        cur = A.cont(cur / 'result.cas.h5', f'{tag}_s{k}', reg(pm_cur, q['pc'], q['dp']), [], q['t0'], q['t0'],
                     f'сопло: ступень магистрали {pm_cur}', A.AUX, limit=1500, l_mm=L_mm) or cur
    d = A.cont(cur / 'result.cas.h5', tag, reg(q['pm'], q['pc'], q['dp']), [], q['t0'], q['t0'], f'сопло: план ЛГК, от {cur.name}', A.CSV, l_mm=L_mm)
    return d


if __name__ == '__main__':
    wait_prev()
    A.qlog(f"=== D-26: сопло как фактор — начата ({PLAN['plan']}, {len(PLAN['points'])} точек)")
    n_calc = n_fail = 0
    slices = {}
    for q in PLAN['points']:
        slices.setdefault((q['nozzle'], q['L']), []).append(q)
    for (noz, L_mm), pts in slices.items():
        pts.sort(key=lambda q: -q['pm'])
        R_E['v'] = pts[0]['r_exit']
        sp, sx = smooth_case(1.4, L_mm)
        if noz == 'NZ215':
            cur, pm_cur = Path(sp), sx[6]
        else:
            q = pts[0]
            anchor = dict(id=f'{noz}_L{int(L_mm)}_a', t_d=1.4, L_mm=L_mm, p_cons=q['pc'], dp_dzv_kPa=q['dp'], t0_svz=q['t0'], t0_dzv=q['t0'],
                          m_target=0.8, heater=0.0)
            cur = A.done_dir(anchor['id']) or A.transfer(Path(sp), anchor)
            pm_cur = 5.5
            if not cur:
                n_calc += 1; n_fail += 1
                A.log(f'  {noz} L {L_mm}: перенос поля не удался — срез пропущен')
                if n_calc == 2 and n_fail == 2:
                    A.qlog('=== сопло: первые 2 расчёта не сошлись — СТОП, нужно решение автора'); sys.exit(1)
                continue
        for q in pts:
            if A.done_dir(q['id']):
                cur, pm_cur = A.done_dir(q['id']), q['pm']; continue
            d = walk(cur, pm_cur, q, q['id'], L_mm)
            n_calc += 1; n_fail += not (d and A.converged(d))
            if n_calc == 2 and n_fail == 2:
                A.qlog('=== сопло: первые 2 расчёта не сошлись — СТОП, нужно решение автора'); sys.exit(1)
            if d:
                cur, pm_cur = d, q['pm']
    A.qlog('=== D-26: сопло как фактор — закончена')
