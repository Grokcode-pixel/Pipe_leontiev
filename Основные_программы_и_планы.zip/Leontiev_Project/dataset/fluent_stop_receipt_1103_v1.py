"""Read native Scheme acknowledgements with or without Fluent's command echo."""
import re

def parse(text):
    values={}
    for marker,expression,value in [('GRS_COUPLED_COMPLETED','grs-completed',r'(\d+)'),('GRS_STOP_REQUESTED','grs-stop?',r'(#t|#f)')]:
        pattern=r'^'+marker+r'[ \t]+(?:\(write '+re.escape(expression)+r'\)\s*)?'+value+r'(?:\(\))?[ \t]*$'
        found=re.findall(pattern,text,re.M)
        if len(found)!=1:raise ValueError('Missing or ambiguous native '+marker+' acknowledgement: '+str(found))
        values[marker]=found[0]
    return dict(iterations=int(values['GRS_COUPLED_COMPLETED']),stop_requested=values['GRS_STOP_REQUESTED']=='#t')