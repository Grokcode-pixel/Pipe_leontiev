"""31.10.2026 — решение автора по ночи 31.10 (п. 4 J0006, п. 5 сопло M 2,5): расчёт «с нуля, без переноса поля», одна попытка.
Как run_a9.scratch (идеальный метан: FMG, 1000 стартовых + 5500 связанных итераций → метан ПР при режиме точки), но без повторов:
retries 0 у стадии идеального газа и без повтора с половинным псевдошагом у стадии ПР."""
import time
import leontiev_pipeline as L


def run(A, pt, tag, l_mm, start, **over):
    """A — модуль run_a9 с заданными BASE / CSV / AUX (и, если нужно, своим cell_params); pt — точка (t_d, p_cons, dp_dzv_kPa,
    t0_svz, t0_dzv). over — замены параметров стадии идеального газа (31.10, D-30: startup='ramp' — старт «как на стенде»
    с почти нулевого перепада и подъёмом давления, без FMG; FMG на сетках накатки расходится). Возвращает папку ПР или None."""
    A.G.RUNS = A.BASE
    td, t0s, t0d = float(pt['t_d']), float(pt['t0_svz']), float(pt['t0_dzv'])
    p, _ = A.cell_params(td, l_mm, f'{tag}_ideal', pt, 'ch4_ideal', 1000, 5500)
    p['retries'] = 0
    p.update(over)
    A.log(f'=== {tag}: С НУЛЯ (идеальный метан → ПР), одна попытка; t/d {td}, L {l_mm:g} мм')
    t0 = time.time()
    A.G.run(p, lambda s: A.log('  ' + s), lambda: False)
    A.U.record(A.AUX, f'{tag}_ideal', 'work_v2', 'ch4_ideal', A.regime(pt), A.BASE / p['run_id'], round((time.time() - t0) / 60, 1),
               A.log, start='с нуля (FMG), одна попытка', t0_C=t0s, t0_dzv_C=t0d, l_heat_mm=l_mm)
    if not A.ok(A.BASE / p['run_id']):
        A.log(f'  {tag}_ideal: нет результата (одна попытка)')
        return None
    A.set_step(A.CONS)
    A.U.LIMIT = A.POINT_LIMIT
    out = A.BASE / tag
    mins = A.U.continue_case(A.BASE / p['run_id'] / 'result.cas.h5', out, list(L.CH4_PR_LINES), A.regime(pt), A.log, tag,
                             t0_C=t0s, t0_dzv_C=t0d)
    A.U.record(A.CSV, tag, 'work_v2', 'ch4_pr', A.regime(pt), out, mins, A.log, start=start, t0_C=t0s, t0_dzv_C=t0d, l_heat_mm=l_mm)
    return out if A.ok(out) else None
