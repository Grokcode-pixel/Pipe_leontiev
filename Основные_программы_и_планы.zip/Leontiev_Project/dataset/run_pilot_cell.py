"""Queue for the night 09->10.10.2026 (author 22:45: keep the machine busy until ~12:00).  Waits for run_a5v3b.py.
Q1  anchor re-check with a RESOLVED DZV mesh (old n95 geometry, gap 0.3 mm, wall 234 as the old anchor a6_ch4_pr):
    how much the DZV mesh changes Q and the effect (old: Q 1506.8 W, +4.33 K).  Ideal methane from scratch -> PR.
Q2  pilot portion of the dataset unit cell (geometry v4: cell of the RU 2162190 bundle, thin brass wall 1.5 mm, k 110,
    COUNTERFLOW, outer cell boundary = symmetry, DZV layers filling the gap, methane, T0 15 C both inlets, p0 5.5 MPa):
      a) t/d 1.2, m 0.3, p_out 0.3     b) t/d 1.6, m 0.3, p_out 0.3     c) t/d 1.4, m 1.0, p_out 0.3
      d) t/d 1.4, m 0.1, p_out 0.3     e) t/d 1.4, m 0.3, p_out 1.2
    each: ideal methane from scratch (DZV outlet pressure BC) -> Peng-Robinson continuation with the targeted DZV flow
    m*G_svz (pmin = consumer pressure + 0.1 MPa, pmax = 5.499 MPa).  NOTE: started before the A5 v3b verdict — if the
    experiment check fails, these runs show the behaviour of the cell geometry and mesh, not final numbers.
Rows -> runs\\pilot\\pilot_results.csv, log pilot_log.txt."""
import math, subprocess, sys, time, traceback
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import leontiev_pipeline as L
import gui_runner as G
import run_a3 as A3
import cont_util as U

BASE = Path(r'F:\Leontiev_Project\runs\pilot')
CSV = BASE / 'pilot_results.csv'
QLOG = Path(r'F:\Leontiev_Project\runs\queue_log.txt')
G_SVZ_EST = 0.160   # kg/s, methane PR, d_cr 4.5 mm, p0 5.5 MPa, T0 15 C (anchor 0.158 at 25 C)
U.CFL = 10.0        # 09.10 22:55: fine DZV layers were unstable at CFL 20 (A5 v3b first attempt)
CFL_SCRATCH = 5.0


def log(s):
    line = time.strftime('%H:%M:%S ') + s
    print(line, flush=True)
    BASE.mkdir(parents=True, exist_ok=True)
    with (BASE / 'pilot_log.txt').open('a', encoding='utf-8') as f:
        f.write(line + '\n')


def qlog(s):
    with QLOG.open('a', encoding='utf-8') as f:
        f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + s + '\n')


def running(name):
    out = subprocess.run(['powershell', '-NoProfile', '-Command',
                          f"Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | ? {{$_.CommandLine -match '{name}'}} | Measure-Object | % Count"],
                         capture_output=True, text=True).stdout.strip()
    return out not in ('', '0')


def dzv_layers(gap_mm, h1_mm=1e-4, g=1.2):
    """09.10: inflation layers from both DZV walls that fill the gap (A5 diagnosis: a coarse core killed the DZV heat
    transfer).  Per side: h1*(g^n-1)/(g-1) <= gap/2."""
    return int(math.floor(math.log(gap_mm / 2 * (g - 1) / h1_mm + 1) / math.log(g)))


def scratch_then_pr(tag, p, regime, t0_C, extra_pr=(), g_target=None, l_heat_mm=400.0):
    G.RUNS = BASE
    p = dict(p, run_id=f'{tag}_ideal', gas='ch4_ideal', cfl=CFL_SCRATCH, startup_iters=1000)
    log(f'=== {tag}: метан идеальный с нуля; сетка ДЗВ {p.get("dzv_layers")} слоёв; ' +
        ', '.join(f'{k}={p[k]}' for k in ('gap_mm', 'wall_thickness_inlet_mm', 'wall_thickness_end_mm', 'dzv_counterflow') if k in p))
    t0 = time.time()
    G.run(p, lambda s: log('  ' + s), lambda: False)
    src = BASE / p['run_id'] / 'result.cas.h5'
    U.record(CSV, f'{tag}_ideal', 'work_v2', 'ch4_ideal', regime, BASE / p['run_id'], round((time.time() - t0) / 60, 1), log,
             start='с нуля (FMG)', t0_C=t0_C, l_heat_mm=l_heat_mm)
    if not src.exists():
        return None
    out = BASE / f'{tag}_pr'
    m = U.continue_case(src, out, list(L.CH4_PR_LINES) + list(extra_pr), regime, log, f'{tag}_pr', t0_C=t0_C)
    return U.record(CSV, f'{tag}_pr', 'work_v2', 'ch4_pr', regime, out, m, log, start=f'продолжение {tag}_ideal',
                    t0_C=t0_C, l_heat_mm=l_heat_mm, g_dzv_target=g_target)


def step(name, fn):
    qlog(f'ночь 09→10.10: {name} — начат'); t0 = time.time()
    try:
        fn(); qlog(f'ночь 09→10.10: {name} — скрипт завершён за {(time.time() - t0) / 60:.0f} мин (приёмка — по результатам)')
    except Exception:
        qlog(f'ночь 09→10.10: {name} — ОШИБКА программы:\n' + traceback.format_exc())


def anchor_recheck():
    p = dict(G.DEFAULTS); p.update(A3.MESHES['work_v2'], prt=0.85, mesh_custom=True, wait_free=True, wall_k=None,
                                   dzv_layers=dzv_layers(0.3))
    scratch_then_pr('anchor_dzvfix', p, (5.5, 0.3, 5.5, 5.2), 25.0)


def pilot():
    pts = [('cell_a_t12_m03_p03', 1.2, 0.3, 0.3), ('cell_b_t16_m03_p03', 1.6, 0.3, 0.3), ('cell_c_t14_m10_p03', 1.4, 1.0, 0.3),
           ('cell_d_t14_m01_p03', 1.4, 0.1, 0.3), ('cell_e_t14_m03_p12', 1.4, 0.3, 1.2)]
    for tag, td, m, pout in pts:
        try:
            cell = L.cell_geometry(td, 1.5, 4.8, 3.3)
            p = dict(G.DEFAULTS)
            p.update(A3.MESHES['work_v2'], prt=0.85, mesh_custom=True, wait_free=True, dzv_counterflow=True,
                     dzv_layers=dzv_layers(cell['gap_mm']), p_out_svz_MPa=pout, p_out_dzv_MPa=5.2,
                     extra_lines=[L.SYMMETRY_DZV_LINE, U.t0_line(15.0)],
                     **{k: cell[k] for k in ('gap_mm', 'wall_thickness_inlet_mm', 'wall_thickness_end_mm')})
            g = m * G_SVZ_EST
            tmf = U.tmf_lines(g, pout + 0.1, 5.499)
            scratch_then_pr(tag, p, (5.5, pout, 5.5, 5.2), 15.0, extra_pr=tmf, g_target=g)
        except Exception:
            log(f'{tag}: ОШИБКА программы: ' + traceback.format_exc())


if __name__ == '__main__':
    qlog('=== ночь 09→10.10 (якорь с сеткой ДЗВ, пилот ячейки): жду окончания run_a5v3b')
    while running('run_a5v3b'):
        time.sleep(60)
    step('Q1 якорь с разрешённой сеткой ДЗВ (метан, n95, зазор 0,3)', anchor_recheck)
    step('Q2 пилот ячейки пучка (противоток, symmetry, латунь 110)', pilot)
    qlog('=== ночь 09→10.10: очередь закончена')
