"""Continue remaining registered dataset after proven MPI startup failure; preserve accepted P1."""
import sys,shutil,traceback
from pathlib import Path
import knurl_dataset_queue_1104_v1 as S
F=S.F;R=S.R;A=S.A
P=R/'runs/plans/knurl_dataset_resume_1104_v2.json';OUT=R/'runs/knurl_dataset_resume_1104_v2'
ORIGINAL_SOLVE=S.solve

def registered():
 if A.sha(P)!=P.with_suffix('.sha256').read_text().strip():raise RuntimeError('Resume plan changed')
 p=F.load(P)
 for f,h in p['protected'].items():
  if A.sha(f)!=h:raise RuntimeError('Resume source changed '+f)
 S.registered();return p

def solve(c,folder,dp,tpl):
 p=registered()
 if c['tag']=='F01_P1':
  e=F.load(p['accepted_receipt'])
  if not e['accepted'] or abs(e['dp_kPa']-dp)>1e-9:raise RuntimeError('Accepted P1 receipt mismatch')
  folder.mkdir(parents=True,exist_ok=True);F.save(folder/'reused_receipt.json',dict(time=A.now(),source=p['accepted_receipt'],sha256=A.sha(p['accepted_receipt']),no_CFD_repeat=True))
  return e
 return ORIGINAL_SOLVE(c,folder,dp,tpl)

if __name__=='__main__':
 mode=sys.argv[1]
 try:
  p=registered()
  if mode=='check':S.check();print('RESUME CHECK OK: acceptedP1 reused, P2 startup0iterations, old BLOCK preserved')
  else:
   S.OUT=OUT
   if mode=='series':
    (OUT/'pilot').mkdir(parents=True,exist_ok=True)
    if (OUT/'pilot/summary.json').exists():raise RuntimeError('Resume stage already prepared')
    S.require(Path(p['pilot_receipt']),'passed');shutil.copy2(p['pilot_receipt'],OUT/'pilot/summary.json');S.solve=solve;S.series()
   elif mode=='final':S.final()
   else:raise RuntimeError('Unknown resume mode')
 except Exception as e:
  o=OUT/mode;o.mkdir(parents=True,exist_ok=True);F.save(o/'BLOCK.json',dict(time=A.now(),error=repr(e),traceback=traceback.format_exc(),no_retry=True));raise
