"""02.11.2026 — следующий этап (D-37), п. 5: две пробы построения сетки h 1 / s 2 (геометрия KS1_04), без CFD, не одновременно с Fluent.
Установлено: проект Workbench сохранялся после каждой сборки (wb_build_variant.wbjn: Save()), т. е. каждая сборка начиналась с
состояния после предыдущей (накопление «Contact Region 2» — до 20 записей). Исправлено 02.11 (по указанию автора) для ВСЕХ сборок:
Save() убран; run_dataset.build_mesh строит на свежей рабочей копии эталона F:\\Leontiev_Project\\эталон_проекта_20261102
(копия g_08_1.wbpj от 02.11 14:44) и проверяет, что эталон не изменился. Версия 2 плана (v1 — со своими копиями снимка — не запускалась).
M1 — форма и настройки сетки без изменений; запись: тела (подавление, объём, ячейки), named selections, методы/слои, контакты,
сообщения Meshing, память; успех — все тела с ячейками, оба контакта непустые (mesh_variant.py), все обязательные зоны (gui_runner).
M2 — M1 успешна → повтор того же (воспроизводимость); M1 упала, а привязки в порядке → один параметр: слоёв ДЗВ 43 → 30 (первый слой
и остальное — без изменений; диагностика, не утверждённая рабочая сетка); M1 упала и привязки нарушены → M2 не строится, разбор.
  python mesh_m12.py plan | M1 | M2"""
import hashlib, json, shutil, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')

ROOT = Path(r'F:\Leontiev_Project')
OUT = ROOT / 'runs' / 'knurl_diag'
PLAN = ROOT / 'runs' / 'plans' / 'сетка_h1s2_M1M2_1102_v2.json'
SRC_PARAMS = ROOT / 'runs' / 'knurl_ds' / 'KS1_04_s_ideal' / 'params.json'
CODE = ['mesh_m12.py', 'mesh_variant.py', 'run_dataset.py', 'gui_runner.py', 'grs_g2_setup.py', 'wb_build_variant.wbjn']


def sha(f):
    h = hashlib.sha256()
    with open(f, 'rb') as fo:
        for b in iter(lambda: fo.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest().upper()


def load(f):
    return json.loads(Path(f).read_text(encoding='utf-8')) if Path(f).exists() else {}


def save(f, d):
    Path(f).parent.mkdir(parents=True, exist_ok=True)
    Path(f).write_text(json.dumps(d, ensure_ascii=False, indent=1, default=float), encoding='utf-8')


def journal(s):
    with open(r'F:\Leontiev_Project\Журнал_работ.md', 'a', encoding='utf-8') as f:
        f.write(f"- {time.strftime('%d.%m.%Y %H:%M')} — сетка h 1 / s 2, M1/M2 (D-37): {s}\n")


def code_path(c):
    return ROOT / 'dataset' / c


def make_plan():
    if PLAN.exists():
        sys.exit(f'{PLAN} уже есть — не перезаписываю')
    import run_dataset as RD
    plan = dict(name='сетка_h1s2_M1M2_1102_v2', made=time.strftime('%d.%m.%Y %H:%M:%S'), source_params=str(SRC_PARAMS), params_sha256=sha(SRC_PARAMS),
                reference=RD.REFERENCE, reference_sha256=sha(RD.REFERENCE), replaces='сетка_h1s2_M1M2_1102.json (v1, не запускалась)',
                M1='без изменений формы и настроек; свежая рабочая копия эталона (run_dataset.build_mesh)', M2_rule='M1 успешна → повтор; M1 упала при целых привязках → dzv_layers 43→30; привязки нарушены → не строить',
                success='все тела с ячейками + оба контакта непустые (Workbench) + все обязательные зоны (gui_runner.REQUIRED_ZONES)',
                cfd='нет', code_sha256={c: sha(code_path(c)) for c in CODE})
    txt = json.dumps(plan, ensure_ascii=False, indent=1)
    PLAN.write_text(txt, encoding='utf-8')
    h = hashlib.sha256(txt.encode('utf-8')).hexdigest().upper()
    PLAN.with_suffix('.sha256').write_text(h, encoding='utf-8')
    journal(f'план записан ДО запуска: {PLAN}, SHA256 {h}')
    return h


def registered():
    txt = PLAN.read_text(encoding='utf-8')
    if hashlib.sha256(txt.encode('utf-8')).hexdigest().upper() != PLAN.with_suffix('.sha256').read_text(encoding='utf-8').strip():
        raise RuntimeError('SHA256 плана не совпадает')
    plan = json.loads(txt)
    bad = [c for c, h in plan['code_sha256'].items() if sha(code_path(c)) != h]
    if bad:
        raise RuntimeError(f'код изменён после регистрации: {bad}')
    return plan


def bindings_ok(mr):
    """Привязки: все named selections непустые, контактов ровно два вида и оба непустые, без лишних дублей."""
    ns = mr.get('named_selections')
    empty_ns = [n for n, k in ns if k == 0] if isinstance(ns, list) else ['нет данных']
    cr = mr.get('contact_regions_count')
    return dict(ok=not empty_ns and bool(mr.get('contacts_ok')) and cr == 2, empty_named_selections=empty_ns, contact_regions=cr, contacts_ok=mr.get('contacts_ok'))


def build(tag, change=None):
    import gui_runner as G
    import run_dataset as RD
    plan = registered()
    if sha(RD.REFERENCE) != plan['reference_sha256']:
        sys.exit('эталон проекта отличается от записанного в плане — стоп')
    if load(OUT / 'mesh_m12.json').get(tag):
        sys.exit(f'{tag} уже выполнена — проба не повторяется')
    p = dict(load(SRC_PARAMS), run_id=f'{tag}_h1s2')
    if change:
        p.update(change)
    t0 = time.time()
    m = RD.build_mesh(G.mesh_spec(p), timeout=1500)
    msh = G.L.DS / 'variants' / p['run_id'] / 'mesh.msh'
    mr = load(msh.with_name('mesh_result.json'))
    z = G.mesh_zones(msh) if msh.exists() else {}
    miss = [n for n, t in G.REQUIRED_ZONES.items() if z.get(n) != t]
    b = bindings_ok(mr)
    r = dict(tag=tag, change=change, reference_sha256=(m or {}).get('reference_sha256'), reference_unchanged=(m or {}).get('reference_unchanged'),
             start='свежая рабочая копия эталона', wb_passed=bool(m and m.get('passed')),
             elements=mr.get('elements'), gen_seconds=mr.get('gen_seconds'), bodies_after=mr.get('bodies_after_mesh'),
             bodies_without_elements=mr.get('bodies_without_elements'), named_selections=mr.get('named_selections'), mesh_controls=mr.get('mesh_controls'),
             contacts=mr.get('contacts_all'), bindings=b, messages=mr.get('messages_after_mesh'), memory_mb=mr.get('memory_mb'), zones_missing=miss,
             success=bool(m and m.get('passed')) and not miss, seconds=round(time.time() - t0), finished=time.strftime('%d.%m.%Y %H:%M:%S'))
    res = load(OUT / 'mesh_m12.json'); res[tag] = r; save(OUT / 'mesh_m12.json', res)
    journal(f"{tag}{' (' + str(change) + ')' if change else ''}: {'УСПЕХ' if r['success'] else 'сбой'}; тела без ячеек {r['bodies_without_elements']}; нет зон {miss}; "
            f"привязки {'целы' if b['ok'] else 'НАРУШЕНЫ: ' + str({k: v for k, v in b.items() if k != 'ok'})}; память {r['memory_mb']}")
    return r


def m2():
    res = load(OUT / 'mesh_m12.json')
    r1 = res.get('M1')
    if not r1:
        sys.exit('M1 ещё нет')
    if r1['success']:
        return build('M2')
    if not r1['bindings']['ok']:
        journal('M2 не строится: M1 упала при нарушенных привязках — сначала разбор привязок (решение автора)')
        sys.exit(3)
    return build('M2', change=dict(dzv_layers=30))


if __name__ == '__main__':
    {'plan': lambda: print(make_plan()), 'M1': lambda: build('M1'), 'M2': m2}[sys.argv[1]]()
