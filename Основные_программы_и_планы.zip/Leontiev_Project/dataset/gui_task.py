"""31.10.2026 — интерфейс автора, перестройка по шагам решения (задание автора 31.10), этап 1: вкладки главного инженера.
 1 «Задача (главный инженер)» — условия станции, сценарий газа ДЗВ, цель, ограничения; у поля — диапазон данных модели, вне
   диапазона — красное поле и подсказка; «Подобрать» (зима и лето) → программа sppr (evaluate + decide) по всем посчитанным
   геометриям; накатка — только точки CFD (режим A9_19), 0,2 мм исключена до выяснения двух решений (D-29).
 2 «Решение (главный инженер)» — статус ВЫДАТЬ / ДОСЧИТАТЬ / ВЕРНУТЬ ЗАДАЧУ цветом и причина; рекомендация с ± и источником;
   «было → стало»; лучшие варианты рядом; график «тепло Q — потеря давления ДЗВ»; ДОСЧИТАТЬ — точки и «передать расчётчику»
   (в очередь только после подтверждения: sppr.confirm_and_run → прогноз до расчёта и журнал решений, затем задание
   confirm_runner в общей очереди перед запасной работой); ВЕРНУТЬ — какой параметр вне области и ближайшее допустимое;
   уровень ответа К1 карта / К2 модель / К3 нужен Fluent / П1 вне области.
Программа ничем не управляет на станции: только рекомендация; режимная карта — печатная таблица (этап 3).
Где модели нет (накатка вне режима A9_19) — «нет данных», ничего не выдумывается."""
import contextlib, io, json, math, sys, threading, time
from dataclasses import replace, asdict
from pathlib import Path
import numpy as np
import tkinter as tk
from tkinter import ttk, messagebox
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
sys.path.insert(0, r'F:\Leontiev_Project\program')
import matplotlib
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

CARDS = Path(r'F:\Leontiev_Project\program\cards')
DP_LIST = [5, 10, 15, 20, 30, 50]
KNURL_KINDS = ['гладкий (CFD A9_19)', 'накатка 0,1 мм', 'накатка 0,3 мм', 'накатка RU 233137']   # 0,2 мм — исключена (D-29)
KIND_TEXT = {'гладкий': 'гладкая', 'гладкий (CFD A9_19)': 'гладкая (точка CFD A9_19)', 'накатка 0,1 мм': 'накатка: выступ 0,1 мм, шаг 2 мм',
             'накатка 0,2 мм': 'накатка: выступ 0,2 мм, шаг 2 мм', 'накатка 0,3 мм': 'накатка: выступ 0,3 мм, шаг 2 мм',
             'накатка RU 233137': 'накатка RU 233137: выступ 1,0 мм, шаг 4,75 мм'}
STATUS = {'П3': ('ВЫДАТЬ', '#2e7d32'), 'П2': ('ДОСЧИТАТЬ', '#f9a825'), 'П1': ('ВЕРНУТЬ ЗАДАЧУ', '#c62828')}
LEVELS = (('К1', 'карта (посчитано Fluent)'), ('К2', 'модель (прогноз по данным)'), ('К3', 'нужен расчёт Fluent'), ('П1', 'вне области'))
GLOSSARY = """СЛОВАРЬ

Труба Леонтьева — труба, через которую идут два потока газа: сверхзвуковой (СВЗ) внутри и дозвуковой (ДЗВ) снаружи, противотоком. СВЗ нагревается относительно обычного дросселя, ДЗВ охлаждается.
СВЗ — сверхзвуковой поток: идёт через сопло и канал трубы, затем к потребителю.
ДЗВ — дозвуковой поток: обтекает трубы снаружи и охлаждается; его холод можно отдать в установку СПГ, потребителю холода или пустить газ транзитом.
Пучок — несколько одинаковых труб в корпусе; число работающих труб — режимный параметр.
Шаг труб t/d (плотность пучка) — расстояние между осями труб, делённое на наружный диаметр трубы. Чем меньше, тем теснее пучок.
L — длина теплообмена (сверхзвукового канала), мм.
Перепад задвижки ДЗВ — потеря давления газа ДЗВ на задвижке, кПа; ручка диспетчера, задаёт расход ДЗВ.
Допустимая потеря давления ДЗВ — сколько давления газа ДЗВ разрешено потерять (ограничение главного инженера).
m — доля ДЗВ: расход ДЗВ / расход СВЗ. Проверено опытом 2017 г. только при 0,2 ≤ m ≤ 0,96.
Ω (область применимости) — где модель и опыт можно использовать: m 0,2–0,96, параметры в диапазоне посчитанных данных.
Эффект против дросселя, K — насколько газ после трубы теплее, чем после обычного дросселя при тех же давлениях.
Подогреватель — топливный подогреватель газа на ГРС; «всё топливное тепло» = подогрев СВЗ до сопел + догрев после пучка.
T СВЗ перед соплами — температура газа СВЗ после подогрева до сопел (= T газа магистрали + подогрев, K).
T потребителю ≥ −10 °C — норма для ГРС; ≥ 0 °C — при пучинистых грунтах.
СПГ — сжиженный природный газ; холод ДЗВ идёт в установку сжижения (цикл Линде — ограничение работы; реальный аналог — турбодетандер ГРС-4 Екатеринбург).
Транзит — газ ДЗВ уходит дальше при своём давлении (сценарий, если на станции есть такая возможность).
Потребитель холода — внешний потребитель забирает холод ДЗВ и возвращает газ при температуре магистрали.
± (σ) — погрешность прогноза модели (гауссов процесс), умножена на множитель калибровки (D-25; после заморозки 31.10 — 1,51).
Заморозка — 31.10.2026 обучение зафиксировано: 152 точки Fluent; новые расчёты в обучение не идут, только проверка.
ВЫДАТЬ (П3) — рекомендация надёжна: в области, погрешность мала, лучший вариант устойчив.
ДОСЧИТАТЬ (П2) — нужен расчёт Fluent: погрешность велика, режим не уверен или лучший вариант может смениться.
ВЕРНУТЬ ЗАДАЧУ (П1) — условие вне области данных или опыта; решение, возможно, есть, но не доказано.
К1 карта — ответ по посчитанной точке Fluent; К2 модель — ответ по модели в области данных; К3 — нужен новый расчёт Fluent; П1 — вне области.
Режимная карта — печатная таблица для диспетчера: условия → задвижка ДЗВ и мощность подогревателя. Программа ничем на станции не управляет.
Накатка (RU 233137) — выступы на наружной стороне трубы: больше тепла через стенку, но больше потеря давления ДЗВ. Посчитана Fluent только при одном режиме (5,5 → 0,59 МПа, газ 8,63 °C); при других условиях — «нет данных»."""

_M = {}


def models():
    """Модели программы (ГП + классификатор) — одна копия на всё окно; первая загрузка ≈ 1 мин."""
    if 'M' not in _M:
        import sppr
        with contextlib.redirect_stdout(io.StringIO()):
            _M['M'] = sppr.Models()
    return _M['M']


class Tip:
    """Подсказка при наведении."""
    def __init__(self, w, text):
        self.w, self.text, self.top = w, text, None
        w.bind('<Enter>', self.show); w.bind('<Leave>', self.hide)

    def show(self, e=None):
        if self.top or not self.text:
            return
        x, y = self.w.winfo_rootx() + 16, self.w.winfo_rooty() + self.w.winfo_height() + 4
        self.top = tk.Toplevel(self.w); self.top.wm_overrideredirect(True); self.top.wm_geometry(f'+{x}+{y}')
        tk.Label(self.top, text=self.text, justify='left', background='#ffffe0', relief='solid', borderwidth=1, wraplength=460,
                 font=('Segoe UI', 9)).pack(ipadx=4, ipady=2)

    def hide(self, e=None):
        if self.top:
            self.top.destroy(); self.top = None


def glossary(master):
    t = tk.Toplevel(master); t.title('Словарь'); t.geometry('820x640')
    tx = tk.Text(t, wrap='word', font=('Segoe UI', 10)); tx.pack(fill='both', expand=True)
    tx.insert('1.0', GLOSSARY); tx.configure(state='disabled')


def data_ranges(M):
    """Диапазоны посчитанных данных (вход модели): магистраль, потребитель, T газа, перепад ДЗВ, подогрев."""
    return dict(p_main=(M.lo[6], M.hi[6]), p_cons=(M.lo[3], M.hi[3]), T=(M.lo[4], M.hi[4]), dp=(math.exp(M.lo[2]), math.exp(M.hi[2])),
                heat=(M.lo[5], M.hi[5]))


def geometries(M):
    X = np.asarray(M.G.X, float)
    return [[float(a), float(b)] for a, b in sorted({(round(a, 3), round(b * 6.6, 1)) for a, b in X[:, :2]})]


def kind_text(k):
    return KIND_TEXT.get(k, k)


def solve(form, progress):
    """Решение задачи для зимы и лета. form — значения вкладки 1. Возвращает словарь для вкладки 2."""
    import sppr
    import grs_balance2 as B
    progress('загружаю модель программы (первый раз ≈ 1 мин)…')
    M = models()
    KN = sppr.knurl_cfd() if form['knurl'] else {}
    kinds = ['гладкий'] + ([k for k in KNURL_KINDS if k in KN] if form['knurl'] else [])
    hp = {'выбрать программе': ['до сопел', 'после'], 'только до сопел': ['до сопел'], 'только после': ['после']}[form['heater']]
    out = dict(form=form, n_train=M.n_train, p_hi=M.p_hi, seasons={}, time=time.strftime('%d.%m.%Y %H:%M'))
    for season, T in (('зима', form['T_winter']), ('лето', form['T_summer'])):
        progress(f'подбор: {season} (газ {T:+.1f} °C) — ≈ 45 с…')
        card = sppr.TaskCard(title=form['title'] + f' — {season}', p_main=form['p_main'], T_main=T, flow_nm3h=form['flow'], p_cons=form['p_cons'],
                             T_min=form['T_min'], lng_req_kgh=float(form.get('lng_req') or 0.0), kinds=kinds, geometries=geometries(M),
                             dp_kPa=list(DP_LIST), heater_place=hp, dzv_to=form['dzv_to'], goal=form['goal'], dp_max_kPa=form['dp_max'],
                             delta_K=float(form.get('delta') or 0.5))
        with contextlib.redirect_stdout(io.StringIO()):
            base, rows = sppr.evaluate(card, M)
            d = sppr.decide(card, M, base, rows)
        st = B.Station(p_main=card.p_main, T_main=card.T_main, flow_nm3h=card.flow_nm3h, p_cons=card.p_cons, T_min=card.T_min)
        b = d.get('best')
        vb, lng_b, tubes = None, None, None
        if b:
            # «было → стало» всегда тремя строками (поправка автора 31.10): + СПГ без пучка; + СПГ + тот же пучок (для транзита и
            # потребителя холода — тот же пучок при газе ДЗВ в СПГ, расчёт программой на одном варианте)
            vb = B.var_b(st, B.Bundle(), b['o']['G_dzv'] * b['n'])
            if form['dzv_to'] == 'СПГ':
                lng_b = b
            else:
                c2 = replace(card, dzv_to='СПГ', kinds=[b['kind']], geometries=[[b['td'], b['L']]],
                             dp_kPa=[b['dp']] if b['kind'] == 'гладкий' else card.dp_kPa,
                             heater_place=[b['z']] if b['z'] in ('до сопел', 'после') else card.heater_place)
                with contextlib.redirect_stdout(io.StringIO()):
                    b2 = sppr.decide(c2, M, *sppr.evaluate(c2, M)).get('best')
                lng_b = b2
            # число труб: правило grs_balance2.n_rule — целая часть (расход станции / расход одной трубы СВЗ + ДЗВ)
            m_st = card.flow_nm3h * B.RHO_N / 3600
            tubes = dict(flow=card.flow_nm3h, m_st=m_st, g_tube=b['o']['G_svz'] + b['o']['G_dzv'],
                         n_max=B.n_rule(st, b['o']['G_svz'], b['o']['G_dzv']), n=b['n'])
        ok = [r for r in rows if r.get('feasible') and r.get('rule') in ('П2', 'П3')]
        key = (lambda r: (-round(r.get('lng', 0.0), 2), round(r['N'], 3))) if card.goal == 'max СПГ' else (lambda r: (round(r['N'], 3), -r.get('lng', 0.0)))
        ok.sort(key=key)
        tops = []
        sm = [r for r in ok if r['kind'] == 'гладкий']
        kn = [r for r in ok if r['kind'].startswith('накатка')]
        if sm:
            tops.append(('лучший гладкий', sm[0]))
            other = [r for r in sm[1:] if (r['td'], r['L']) != (sm[0]['td'], sm[0]['L'])]
            if other:
                tops.append(('второй гладкий (другая труба)', other[0]))
        tops.append(('лучший с накаткой', kn[0] if kn else None))
        # 31.10 (замечание автора «везде ± 0,0»): погрешность топлива, СПГ и охлаждения ДЗВ — от всех четырёх выходов модели
        lng_, sch_ = sppr.bundle_scheme(card)
        spreads = {id(r): spread(M, card, st, r, lng_, sch_) for r in [b] + [t for _, t in tops] if r}
        if lng_b is not None and lng_b is not b:
            l2, s2 = sppr.bundle_scheme(replace(card, dzv_to='СПГ'))
            spreads[id(lng_b)] = spread(M, replace(card, dzv_to='СПГ'), st, lng_b, l2, s2)
        # график «топливо и СПГ от перепада задвижки» для трубы и места подогревателя выбранного варианта; зоны «вне области» и «скачок»
        if b and b['kind'] == 'гладкий':
            ch = sorted(((r['dp'], r.get('N'), r.get('lng'), r.get('cat', ''), r['o']['m'], r['o']['p']) for r in rows
                         if r['kind'] == 'гладкий' and r['td'] == b['td'] and r['L'] == b['L'] and r['z'] == b['z'] and r.get('o')
                         and isinstance(r['dp'], (int, float))), key=lambda t: t[0])
        else:
            ch = []
        # график «тепло Q — потеря давления ДЗВ»: гладкая — модель для трубы и места подогревателя выбранного варианта; если есть
        # точки накатки (Fluent, t/d 1,4 L 400) — рядом гладкая той же трубы (сравнение на одной трубе)
        def line(td, L, z):
            return sorted({(r['dp'], r['o']['Q'], r['o'].get('sigma_Q', 0.0)) for r in rows if r['kind'] == 'гладкий' and r['td'] == td
                           and r['L'] == L and r['z'] == z and r.get('o') and isinstance(r['dp'], (int, float))})
        zb = b['z'] if b and b['kind'] == 'гладкий' else 'после'
        ref = (b['td'], b['L']) if b and b['kind'] == 'гладкий' else (1.4, 400.0)
        kn_pts = sorted((r['dp'], r['o']['Q'], r['kind']) for r in rows if r['kind'].startswith('накатка') and r.get('o'))
        cfd_s = [(r['dp'], r['o']['Q']) for r in rows if r['kind'] == 'гладкий (CFD A9_19)' and r.get('o')]
        sm_line = (ref, zb, line(ref[0], ref[1], zb))
        sm_ref = ((1.4, 400.0), 'после', line(1.4, 400.0, 'после')) if kn_pts and ref != (1.4, 400.0) else None
        rule = d['rule']
        lvl = 'П1' if rule == 'П1' else 'К3' if rule == 'П2' else ('К1' if b and b['o'].get('cfd') else 'К2')
        # ВЕРНУТЬ: какие условия вне данных и ближайшее допустимое
        rg = data_ranges(M)
        outside = []
        for nm, v, (lo, hi), u in (('давление магистрали', card.p_main, rg['p_main'], 'МПа'), ('давление потребителя', card.p_cons, rg['p_cons'], 'МПа'),
                                   (f'T газа из магистрали ({season})', card.T_main, rg['T'], '°C')):
            if not lo - 1e-9 <= v <= hi + 1e-9:
                outside.append(f'{nm} {v:g} {u} вне данных {lo:.3g}–{hi:.3g} {u} → ближайшее допустимое {min(max(v, lo), hi):.3g} {u}')
        for s in d.get('series') or []:
            outside.append(f"{s['factor']}: лучший вариант на краю данных ({s['at']:g}) → нужна серия Fluent за краем при {s['beyond']:g}")
        if rule == 'П1' and not outside:
            p1 = [r for r in rows if r.get('rule') == 'П1' and r.get('o')]
            if p1:
                r = min(p1, key=lambda r: abs(r['o']['m'] - 0.58))
                outside.append(f"доля ДЗВ m {r['o']['m']:.2f} вне проверенной опытом области 0,2–0,96 (лучшее, что есть: {kind_text(r['kind'])}, "
                               f"t/d {r['td']}, L {r['L']:.0f} мм, перепад {r['dp']} кПа) → допустимо m 0,2–0,96: нужен опыт или другой режим")
        todo = []   # «что сделать» при ВЕРНУТЬ (поправка автора 31.10)
        for x in d.get('series') or []:
            todo.append(f"нужны расчёты Fluent при {x['factor']} {'<' if x['beyond'] < x['at'] else '>'} {x['at']:g} (край данных) — решение автора")
        for nm_, v, w_, x in d.get('edges') or []:
            if x is None:
                todo.append(f'{nm_} {v:g}: {sppr.PHYS_EDGES[(nm_, w_.split()[0])]}')
        if rule == 'П1' and d.get('cat') == 'П1 опыт':
            todo.append('нужна опытная проверка при доле ДЗВ m вне 0,2–0,96 — решение автора')
        if rule == 'П1' and d.get('cat') == 'П1 данные':
            todo.append('нужны расчёты Fluent при условиях задачи (вне посчитанных данных) — решение автора')
        out['seasons'][season] = dict(card=asdict(card), base=base, d=d, vb=vb, lng_b=lng_b, tubes=tubes, todo=todo, tops=tops, sm_line=sm_line,
                                      spreads=spreads, chart=ch,
                                      sm_ref=sm_ref, kn_pts=kn_pts, cfd_s=cfd_s, simple=simple_why(d, M, card),
                                      level=lvl, outside=outside, kinds=kinds, knurl_at=KN != {} and any(r['kind'].startswith('накатка') and r.get('o') for r in rows))
    return out


def spread(M, card, st, r, lng, sch):
    """± топлива, СПГ и охлаждения ДЗВ варианта: каждый из четырёх выходов модели (эффект, Q, расходы СВЗ и ДЗВ) по очереди сдвигается
    на ± σ (с множителем калибровки), полуразмахи складываются квадратично. Точка Fluent (накатка, A9_19) — σ модели нет."""
    import grs_balance2 as B
    o = r.get('o') or {}
    if o.get('cfd') or r['kind'] != 'гладкий':
        return dict(N=None, lng=None, Tdzv=None, cfd=True)
    keys = (('effect_K', 'sigma_K'), ('Q', 'sigma_Q'), ('G_svz', 'sigma_Gs'), ('G_dzv', 'sigma_Gd'))

    def run(k, s):
        def tube(bd, st_, heat):
            q = M.predict(r['td'], r['L'], r['dp'], card.p_cons, card.T_main, heat, card.p_main)
            v = dict(effect_K=q['effect_K'], Q=q['Q'], G_svz=q['G_svz'], G_dzv=q['G_dzv'])
            v[k[0]] += s * q.get(k[1], 0.0)
            return dict(v, m=v['G_dzv'] / v['G_svz'], working=True)
        B.tube = tube
        return B.var_v(st, B.Bundle(td=r['td'], L_mm=r['L'], dp_kPa=r['dp'], n_on=r['n'], heater_place=r['z'], lng=lng, scheme=sch, T_ext=card.T_ext_C))
    h = dict(N=[], lng=[], T=[])
    for k in keys:
        try:
            a, c = run(k, 1.0), run(k, -1.0)
        except ValueError:
            continue
        h['N'].append((a['Q_heater_kW'] - c['Q_heater_kW']) / 2); h['lng'].append((a['lng_kgh'] - c['lng_kgh']) / 2)
        h['T'].append((a['T_dzv_C'] - c['T_dzv_C']) / 2)
    q = lambda v: float(np.sqrt(np.sum(np.square(v)))) if v else 0.0
    return dict(N=q(h['N']), lng=q(h['lng']), Tdzv=q(h['T']), cfd=False)


def pmv(v, e, nd=1):
    """«значение ± погрешность»: погрешность меньше единицы последнего знака — двумя знаками, чтобы не было «± 0,0»."""
    if v is None:
        return 'нет данных'
    if e is None:
        return f'{v:.{nd}f} (точка Fluent)'
    if e < 0.5 * 10 ** -(nd + 1):
        return f'{v:.{nd}f} ± < {10 ** -(nd + 1):g}'
    return f'{v:.{nd}f} ± {e:.{nd if e >= 10 ** -nd else nd + 1}f}'


def simple_why(d, M, card):
    """Причина решения одной строкой простыми словами (подробная формулировка программы — в подсказке)."""
    b, cat = d.get('best'), d.get('cat') or d['rule']
    o = (b or {}).get('o') or {}
    if cat == 'П3' and b:
        src = f"посчитано Fluent ({o.get('src')})" if o.get('cfd') else f"режим трубы рабочий (p = {o['p']:.3f} при пороге {M.p_hi:.3f})"
        return (f"надёжно: погрешность эффекта ± {o['sigma_K']:.2f} K меньше допуска {card.delta_K:g} K, {src}, "
                'лучший вариант не меняется в пределах погрешности')
    if cat == 'нет экономии':
        return 'пучок не уменьшает топливо заметно: без потребителя холода тепло трубы возвращается при смешении потоков'
    if cat == 'П2 σ':
        return f"погрешность прогноза ± {o.get('sigma_K', 0):.2f} K больше допуска {card.delta_K:g} K — нужен расчёт Fluent"
    if cat == 'П2 класс':
        return (f"программа не уверена, что режим трубы рабочий (p = {o.get('p', 0):.3f} при пороге {M.p_hi:.3f}) — "
                'нужен расчёт Fluent')
    if cat == 'П2 граница Ω':
        return (f"оптимум на границе применимости: доля ДЗВ m + σ_m = {o.get('m', 0):.2f} + {o.get('sigma_m', 0):.2f} > 0,96 (D-31) — "
                'нужен расчёт Fluent')
    if cat == 'П2 граница скачка':
        return ('у этой трубы рядом по перепаду есть точки с другим режимом (' +
                ', '.join(f'{a:g} кПа — {b}' for a, b in o.get('conflict') or []) + ') — граница скачка не ясна, нужен расчёт Fluent (D-32)')
    if cat == 'П2 мало данных':
        return (f"рядом мало посчитанных точек: расстояние до ближайшей {o.get('nn', 0):.2f} больше обычного "
                f"(90 % точек — не дальше {M.nn_p90:.2f}) — нужен расчёт Fluent (D-32)")
    if cat == 'П2 устойчивость':
        return f"лучший вариант может смениться: {len(d.get('rivals') or [])} соперник(а) в пределах погрешности — нужен расчёт Fluent"
    if cat == 'П1 край данных':
        s = '; '.join(f"{x['factor']} {x['at']:g} — край посчитанных данных" for x in d.get('series') or [])
        return f'лучший вариант на краю посчитанных данных ({s}); лучшее может быть за краем — нужна серия расчётов Fluent за краем'
    if cat == 'П1 опыт':
        return 'варианты есть только при доле ДЗВ m вне проверенной опытом области 0,2–0,96 — нужна опытная проверка'
    if cat == 'П1 данные':
        return 'условия задачи вне посчитанных данных — нужна серия расчётов Fluent'
    if cat == 'ограничение СПГ':
        return 'ни один вариант не выполняет задания'
    return d['why']


FIELDS = [   # ключ, подпись, по умолчанию, ключ диапазона данных, единицы, подсказка
    ('p_main', 'Давление магистрали', 5.5, 'p_main', 'МПа', 'Давление газа на входе ГРС. Модель посчитана в этом диапазоне.'),
    ('p_cons', 'Давление потребителя', 0.6, 'p_cons', 'МПа', 'Давление газа, которое нужно потребителю (выход ГРС).'),
    ('flow', 'Расход потребителя', 5000, None, 'м³/ч (ст. усл. 20 °C)',
     'Отпуск газа потребителю, м³/ч при стандартных условиях (20 °C, 101,325 кПа): 5000 м³/ч = 0,928 кг/с. Определяет число труб пучка.'),
    ('lng_req', 'Требуемый СПГ (0 — не задан)', 0, None, 'кг/ч', 'Сколько сжиженного газа нужно получить; варианты с меньшим выходом не выдаются.'),
    ('T_winter', 'T газа из магистрали (= T ДЗВ на входе), зима', 0.0, 'T', '°C', 'Температура газа на входе ГРС зимой.'),
    ('T_summer', 'T газа из магистрали (= T ДЗВ на входе), лето', 10.0, 'T', '°C', 'Температура газа на входе ГРС летом.'),
    ('dp_max', 'Допустимая потеря давления ДЗВ (пусто — без ограничения)', '', 'dp', 'кПа',
     'Сколько давления газа ДЗВ разрешено потерять на задвижке и в пучке. Варианты с большей потерей не выдаются.'),
]


class TaskFrame(ttk.Frame):
    """Вкладка 1 «Задача (главный инженер)»."""
    def __init__(self, master, on_result):
        super().__init__(master, padding=10)
        self.on_result = on_result
        ttk.Label(self, text='Задача главного инженера: условия станции, куда идёт газ ДЗВ, цель и ограничения. Программа только рекомендует — '
                             'на станции она ничем не управляет.', wraplength=1200).pack(anchor='w')
        body = ttk.Frame(self); body.pack(fill='x', pady=8)
        f = ttk.LabelFrame(body, text='Условия станции', padding=8); f.pack(side='left', fill='y')
        self.e, self.rng_lab = {}, {}
        self.title_v = tk.StringVar(value='Задача главного инженера')
        ttk.Label(f, text='Название задачи').grid(row=0, column=0, sticky='w')
        ttk.Entry(f, textvariable=self.title_v, width=34).grid(row=0, column=1, columnspan=3, sticky='w', pady=2)
        for i, (k, lab, dv, rk, u, tip) in enumerate(FIELDS, start=1):
            l = ttk.Label(f, text=lab); l.grid(row=i, column=0, sticky='w', pady=2)
            e = tk.Entry(f, width=10, relief='solid', borderwidth=1); e.insert(0, str(dv)); e.grid(row=i, column=1, sticky='w', padx=4)
            ttk.Label(f, text=u).grid(row=i, column=2, sticky='w')
            rl = ttk.Label(f, text='', foreground='#555'); rl.grid(row=i, column=3, sticky='w', padx=8)
            self.e[k], self.rng_lab[k] = e, rl
            e.bind('<KeyRelease>', lambda ev: self.check())
            Tip(l, tip); Tip(e, tip)
        g = ttk.Frame(body); g.pack(side='left', fill='both', expand=True, padx=14)
        self.v = {}
        for title, key, opts, dv, tip in (
                ('Куда идёт газ ДЗВ (сценарий)', 'dzv_to', ('СПГ', 'транзит', 'потребитель холода'), 'СПГ',
                 'СПГ — основная схема (холод ДЗВ в установку сжижения). Транзит и потребитель холода — если на станции есть такая возможность.'),
                ('Цель', 'goal', ('min топлива', 'max СПГ'), 'min топлива', 'Минимум топлива на подогрев газа или максимум сжиженного газа (только для сценария СПГ).'),
                ('T газа потребителю не ниже', 'T_min', ('−10 °C (норма ГРС)', '0 °C (пучинистые грунты)'), '−10 °C (норма ГРС)',
                 '−10 °C — норма для ГРС (СТО Газпром 2-3.5-051); 0 °C — если грунты пучинистые.'),
                ('Место подогревателя', 'heater', ('выбрать программе', 'только до сопел', 'только после'), 'выбрать программе',
                 'До сопел — подогрев газа СВЗ перед трубами; после — догрев смеси после пучка до уставки T потребителю.')):
            lf = ttk.LabelFrame(g, text=title, padding=6); lf.pack(fill='x', pady=3)
            var = tk.StringVar(value=dv); self.v[key] = var
            for o in opts:
                rb = ttk.Radiobutton(lf, text=o, value=o, variable=var, command=self.check); rb.pack(side='left', padx=6); Tip(rb, tip)
        lf = ttk.LabelFrame(g, text='Транзит: восстанавливать давление газа ДЗВ', padding=6); lf.pack(fill='x', pady=3)
        self.restore = tk.StringVar(value='нет')
        for o in ('нет', 'да'):
            rb = ttk.Radiobutton(lf, text=o, value=o, variable=self.restore); rb.pack(side='left', padx=6)
            Tip(rb, 'Только для сценария «транзит»: нужно ли поднимать давление газа ДЗВ после пучка до давления магистрали. '
                    'Энергию на это программа не считает (нет данных) — будет показана только потеря давления.')
        lf = ttk.LabelFrame(g, text='Накатка RU 233137', padding=6); lf.pack(fill='x', pady=3)
        self.knurl = tk.BooleanVar(value=True)
        cb = ttk.Checkbutton(lf, text='разрешена (рассматривать варианты с накаткой)', variable=self.knurl); cb.pack(side='left')
        Tip(cb, 'Накатка посчитана Fluent только при режиме 5,5 → 0,59 МПа, газ 8,63 °C (t/d 1,4, L 400). При других условиях — «нет данных». '
                'Выступ 0,2 мм исключён до выяснения двух решений (D-29).')
        adv = ttk.LabelFrame(self, text='Дополнительно', padding=6); adv.pack(fill='x')
        ttk.Label(adv, text='Допустимая ошибка охлаждения, K').pack(side='left')
        self.delta = tk.Entry(adv, width=6, relief='solid', borderwidth=1); self.delta.insert(0, '0.5'); self.delta.pack(side='left', padx=4)
        Tip(self.delta, 'Допуск δ: если погрешность прогноза эффекта больше — программа скажет «досчитать».')
        bar = ttk.Frame(self); bar.pack(fill='x', pady=6)
        self.btn = ttk.Button(bar, text='Подобрать', command=self.run); self.btn.pack(side='left')
        ttk.Button(bar, text='Пример: условия посчитанной накатки (A9_19)', command=self.example).pack(side='left', padx=8)
        self.msg = ttk.Label(bar, text=''); self.msg.pack(side='left', padx=10)
        self.note = ttk.Label(self, text='', foreground='#c62828', wraplength=1200, justify='left'); self.note.pack(anchor='w')
        self._todo = []; self.after(200, self._pump)
        self.rg = None
        threading.Thread(target=self._load_ranges, daemon=True).start()

    def _pump(self):
        while self._todo:
            try:
                self._todo.pop(0)()
            except Exception as e:
                self.msg.config(text=f'ошибка окна: {e!r}')
        self.after(200, self._pump)

    def _load_ranges(self):
        try:
            rg = data_ranges(models())
            self._todo.append(lambda: self._set_ranges(rg))
        except Exception as e:
            self._todo.append(lambda: self.msg.config(text=f'модель не загрузилась: {e!r}'))

    def _set_ranges(self, rg):
        self.rg = rg
        for k, lab, dv, rk, u, tip in FIELDS:
            if rk:
                lo, hi = rg[rk]
                self.rng_lab[k].config(text=f'данные: {lo:.3g}…{hi:.3g} {u}')
            elif k == 'flow':
                self.rng_lab[k].config(text='баланс станции (любой)')
        self.check()

    def example(self):
        for k, v in (('p_main', 5.5), ('p_cons', 0.59), ('T_winter', 8.63), ('T_summer', 8.63), ('flow', 5000), ('dp_max', '')):
            self.e[k].delete(0, 'end'); self.e[k].insert(0, str(v))
        self.v['T_min'].set('0 °C (пучинистые грунты)'); self.title_v.set('Пример: условия посчитанной накатки (A9_19)')
        self.check()

    def values(self):
        f = {}
        for k, lab, dv, rk, u, tip in FIELDS:
            s = self.e[k].get().strip().replace(',', '.')
            f[k] = None if (k == 'dp_max' and not s) else float(s)
        f.update(dzv_to=self.v['dzv_to'].get(), goal=self.v['goal'].get(), T_min=-10.0 if self.v['T_min'].get().startswith('−10') else 0.0,
                 heater=self.v['heater'].get(), knurl=bool(self.knurl.get()), title=self.title_v.get().strip() or 'Задача',
                 restore=self.restore.get() == 'да', delta=float(self.delta.get().replace(',', '.') or 0.5))
        if f['dzv_to'] != 'СПГ' and f['goal'] == 'max СПГ':
            f['goal'] = 'min топлива'
        return f

    def check(self):
        bad = []
        for k, lab, dv, rk, u, tip in FIELDS:
            e = self.e[k]
            try:
                s = e.get().strip().replace(',', '.')
                v = None if (k == 'dp_max' and not s) else float(s)
            except ValueError:
                e.config(bg='#ffd6d6'); bad.append(f'{lab}: не число'); continue
            out = False
            if v is not None and rk and self.rg:
                lo, hi = self.rg[rk]
                out = not (lo - 1e-9 <= v <= hi + 1e-9)
                if out:
                    bad.append(f'{lab} {v:g} {u} — вне данных модели ({lo:.3g}…{hi:.3g} {u}): программа вернёт задачу (П1)')
            if k == 'flow' and v is not None and v <= 0:
                out = True; bad.append('расход потребителя должен быть > 0')
            e.config(bg='#ffd6d6' if out else 'white')
        if self.v['dzv_to'].get() != 'СПГ' and self.v['goal'].get() == 'max СПГ':
            bad.append('цель «max СПГ» — только для сценария СПГ; будет «min топлива»')
        self.note.config(text='\n'.join(bad))
        return bad

    def run(self):
        try:
            f = self.values()
        except ValueError:
            messagebox.showerror('Задача', 'Проверьте числа в полях (красные).'); return
        self.btn.configure(state='disabled')

        def prog(s):
            self._todo.append(lambda: self.msg.config(text=s))

        def work():
            try:
                res = solve(f, prog)
                self._todo.append(lambda: (self.msg.config(text=f"готово {time.strftime('%H:%M:%S')} — смотрите вкладку «Решение»"), self.on_result(res)))
            except Exception as e:
                import traceback; traceback.print_exc()
                self._todo.append(lambda: self.msg.config(text=f'ошибка подбора: {e!r}'))
            finally:
                self._todo.append(lambda: self.btn.configure(state='normal'))
        threading.Thread(target=work, daemon=True).start()


from gui_decision import DecisionFrame   # 31.10: вкладка «Решение» вынесена в gui_decision.py (поправки автора 31.10)
