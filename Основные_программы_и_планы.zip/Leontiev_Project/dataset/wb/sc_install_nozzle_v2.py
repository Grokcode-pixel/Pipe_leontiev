# Python Script, API Version = V242
# 08.10.2026: publish geometry_script_v2.py (smooth nozzle) as the TubeGeometry script group — same procedure as
# sc_publish_first_layer.py (05.10): proxy script + script group code/Latest/UpdateCode/Save, then rebuild and save.
import json,traceback,clr
from System.Reflection import BindingFlags
from System import Array,Object
r={'groups':[]}
try:
    for assembly in ('SpaceClaim','Stored Selection','ScriptingContextContracts'):clr.AddReference(assembly)
    from SpaceClaim.Scripting import ScriptGroupManager
    flags=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance
    doc=GetRootPart().Document
    inner=doc.GetType().GetField('innerWrapper',flags).GetValue(doc)
    native=inner.GetType().GetProperty('Subject',flags).GetValue(inner,None)
    context=native.GetType().GetProperty('Context',flags).GetValue(native,None)
    src=open(r'F:\Leontiev_Project\geometry_script_v2.py').read()
    if src.startswith('\xef\xbb\xbf'):src=src[3:]
    code='#V242\n'+src
    for d in native.Definitions:
        if d.GetType().FullName!='SpaceClaim.ScriptExecutionProxyDef':continue
        proxy=d.GetEvaluation(context);proxy.Script=code;sg=proxy.ScriptGroup
        sg.ScriptEnvironment.SetApi(242);sg.Code=code
        sg.GetType().GetProperty('Latest',flags).SetValue(sg,code,None)
        sg.ScriptEnvironment.GetType().GetMethod('UpdateCode',flags).Invoke(sg.ScriptEnvironment,Array[Object]([code]))
        sg.Save(False);proxy.Script=sg.Code
        r['groups'].append({'id':str(d.Id),'code_length':len(sg.Code),'smooth':'nozzle_wall=bezier' in sg.Code})
    if not r['groups']:raise ValueError('No native published geometry script')
    Parameters=ScriptGroupManager.Instance.GetParametersObject()
    execfile(r'F:\Leontiev_Project\geometry_script_v2.py')
    r['rebuilt']=True
    r['bodies']=[(b.Name,b.Faces.Count,b.Edges.Count) for b in GetRootPart().GetAllBodies()]
    DocumentSave.Execute(r'F:\Leontiev_Project\g_08_1_files\dp6\SYS-1\DM\SYS-1.scdoc')
    r['saved']=True
    r['updated']=True
except:r['error']=traceback.format_exc()
with open(r'F:\Leontiev_Project\nozzle_v2_install.json','w') as f:json.dump(r,f,indent=2)
