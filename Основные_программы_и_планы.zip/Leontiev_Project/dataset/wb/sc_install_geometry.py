# Python Script, API Version = V242
# 08.10.2026: publish a geometry script (path from install_config.json) as the TubeGeometry script group of the open
# document — same procedure as sc_publish_first_layer.py (05.10) — then rebuild and save to the given path.
import json,traceback,clr
from System.Reflection import BindingFlags
from System import Array,Object
CFG=json.load(open(r'F:\Leontiev_Project\dataset\wb\install_config.json'))
r={'groups':[],'config':CFG}
try:
    for assembly in ('SpaceClaim','Stored Selection','ScriptingContextContracts'):clr.AddReference(assembly)
    from SpaceClaim.Scripting import ScriptGroupManager
    flags=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance
    doc=GetRootPart().Document
    r['document_path']=str(doc.Path)
    inner=doc.GetType().GetField('innerWrapper',flags).GetValue(doc)
    native=inner.GetType().GetProperty('Subject',flags).GetValue(inner,None)
    context=native.GetType().GetProperty('Context',flags).GetValue(native,None)
    src=open(CFG['script']).read()
    if src.startswith('\xef\xbb\xbf'):src=src[3:]
    code='#V242\n'+src
    for d in native.Definitions:
        if d.GetType().FullName!='SpaceClaim.ScriptExecutionProxyDef':continue
        proxy=d.GetEvaluation(context);proxy.Script=code;sg=proxy.ScriptGroup
        sg.ScriptEnvironment.SetApi(242);sg.Code=code
        sg.GetType().GetProperty('Latest',flags).SetValue(sg,code,None)
        sg.ScriptEnvironment.GetType().GetMethod('UpdateCode',flags).Invoke(sg.ScriptEnvironment,Array[Object]([code]))
        sg.Save(False);proxy.Script=sg.Code
        r['groups'].append({'id':str(d.Id),'code_length':len(sg.Code),'marker':CFG.get('marker','') in sg.Code})
    if not r['groups']:raise ValueError('No native published geometry script')
    Parameters=ScriptGroupManager.Instance.GetParametersObject()
    execfile(CFG['script'])
    r['bodies']=[(b.Name,b.Faces.Count,b.Edges.Count) for b in GetRootPart().GetAllBodies()]
    DocumentSave.Execute(CFG['save_path'])
    r['updated']=True
except:r['error']=traceback.format_exc()
with open(CFG['result'],'w') as f:json.dump(r,f,indent=2)
