"""27.10.2026 — замечание (через автора): B00, B03, B21 после досчёта (+4000 ит.) снова «предел итераций».
Мониторы (convergence.json, setB_results.csv): скачка в канале нет (сверхзвук до выхода, M_вых 1,02–1,72, обратного
тока нет), эффект за 4000 ит. не изменился (≤ 0,004 K), дрейфы ≈ 0; не выполнен только баланс энергии 5,4–25 Вт
(порог 5 Вт), у B00 ещё continuity 3,1e-4. Классификатор обучается тремя способами и сравнивается по опасной ошибке
«скачок → рабочий» (GroupKFold по геометриям + отложенные 5–6):
  A — без этих точек (как раньше); B — с ними как «нерабочими» (предложение рецензента); C — с ними как «рабочими»
  (по физике: скачка нет). Вывод: runs\\models\\classifier_variants.md."""
import csv, math
import numpy as np
from sklearn.model_selection import GroupKFold
import model_compare as MC
import heldout_check as H

R = MC.R
D = {p['id']: p for p in csv.DictReader(open(R / 'setB/setB_design.csv', encoding='utf-8'))}
LIMIT = ('B00', 'B03', 'B21')
Xl = np.array([[float(D[t]['t_d']), float(D[t]['L_mm']) / 6.6, math.log(float(D[t]['dp_dzv_kPa'])), float(D[t]['p_cons']),
                float(D[t]['t0_dzv']), float(D[t].get('heater') or 0.0), float(D[t].get('p_main') or 5.5)] for t in LIMIT])
gl = np.array([f"{D[t]['t_d']}/{D[t]['L_mm']}" for t in LIMIT])


def evaluate(X, w, g, name):
    fr, fc, pr, pc = MC.models()[name]
    p = np.zeros(len(w))
    for tr, te in GroupKFold(n_splits=5).split(X, w, g):
        p[te] = pc(fc(H.Z(X[tr]), w[tr]), H.Z(X[te]))
    ph = pc(fc(H.Z(X), w), H.Z(H.Xh))
    shocks = p[w == 0]
    p_hi = float(min(1.0, np.max(shocks) + 1e-3)) if len(shocks) else 0.5
    return dict(danger05=int(((p >= 0.5) & (w == 0)).sum()), n_shock=int((w == 0).sum()), miss05=int(((p < 0.5) & (w == 1)).sum()),
                n_work=int(w.sum()), h_danger05=int(((ph >= 0.5) & (H.wh == 0)).sum()), p_hi=p_hi,
                acc_hi=int(((p >= p_hi) & (w == 1)).sum()), h_danger_hi=int(((ph >= p_hi) & (H.wh == 0)).sum()),
                p_limit=[round(float(v), 3) for v in p[-len(LIMIT):]] if len(w) > len(H.w) else None)


variants = {'A — без трёх точек': (H.X, H.w, H.g),
            'B — три точки как «нерабочие»': (np.vstack([H.X, Xl]), np.concatenate([H.w, np.zeros(3)]), np.concatenate([H.g, gl])),
            'C — три точки как «рабочие»': (np.vstack([H.X, Xl]), np.concatenate([H.w, np.ones(3)]), np.concatenate([H.g, gl]))}
L = ['# Классификатор «рабочий / скачок»: три способа учесть B00, B03, B21', '',
     'B00c / B03c / B21c (+4000 ит.): скачка в канале нет, M на выходе 1,72 / 1,02 / 1,34, обратного тока нет; эффект до → после '
     '2,780 → 2,776 / 2,470 → 2,470 / 0,808 → 0,808 K; дрейфы ≈ 0; не выполнен баланс энергии 12,7 / 25,2 / 5,4 Вт (порог 5), '
     'у B00 continuity 3,1e-4 (порог 2,5e-4). Режим установился и не колеблется.', '',
     f'Отложенные геометрии 5–6: {len(H.wh)} точек ({", ".join(H.tags)}), со скачком {int((H.wh == 0).sum())}.', '',
     '| Вариант | Модель | опасно «скачок→рабочий» при 0,5, CV | рабочий→«скачок» при 0,5, CV | опасно на 5–6 при 0,5 | p_hi | рабочих признано при p_hi | опасно на 5–6 при p_hi | p трёх точек (CV) |',
     '|---|---|---|---|---|---|---|---|---|']
for vname, (X, w, g) in variants.items():
    for name in MC.models():
        r = evaluate(X, w, g, name)
        L.append(f"| {vname} | {name} | {r['danger05']} из {r['n_shock']} | {r['miss05']} из {r['n_work']} | {r['h_danger05']} | "
                 f"{r['p_hi']:.3f} | {r['acc_hi']} из {r['n_work']} | {r['h_danger_hi']} | {r['p_limit'] or '—'} |")
(MC.OUT / 'classifier_variants.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
print('\n'.join(L))
