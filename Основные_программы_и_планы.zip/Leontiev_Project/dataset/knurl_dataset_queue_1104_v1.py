"""Bounded author-approved warm-start dataset; immutable plans and sequential native sessions."""
import sys,json,math,shutil,traceback,subprocess,time,ast
from pathlib import Path
import knurl_family_1103_v7_cfd as F
import build_knurl_case_1104_v10 as B
import gui_runner as G
R=F.R;D=F.D;V=F.V;L=F.L;A=F.A
P=R/'runs/plans/knurl_dataset_queue_1104_v1.json';OUT=R/'runs/knurl_dataset_queue_1104_v1'
sha=A.sha;save=F.save;load=F.load;now=A.now
ORIGINAL_SHAPE=F.same_shape

def registered():
 if sha(P)!=P.with_suffix('.sha256').read_text().strip():raise RuntimeError('Plan changed')
 p=load(P)
 for f,h in p['protected'].items():
  if sha(f)!=h:raise RuntimeError('Protected source changed '+f)
 return p

def require(path,key):
 v=load(path)
 if not v.get(key):raise RuntimeError('Prerequisite failed '+str(path))
 return v

def once(o):
 o.mkdir(parents=True,exist_ok=True)
 if (o/'attempt.json').exists():raise RuntimeError('No blind repeat '+str(o))
 save(o/'attempt.json',dict(time=now(),plan_sha256=sha(P)))

def compatible(t,s):
 t=dict(t,knurl_dzv=s['knurl_dzv']);ORIGINAL_SHAPE(t,s)

def grid():
 p=registered();o=OUT/'grid';once(o);root=R/'runs/grid_h1_cfd_1104_v1'
 require(root/'finished.json','time')
 if (root/'BLOCK.json').exists():raise RuntimeError('Grid CFD BLOCK')
 r=load(root/'results.json');a,b=[r[k] for k in p['grid_tags']]
 if not a['accepted'] or not b['accepted']:raise RuntimeError('Grid numerical failure')
 diff=dict(effect_K=abs(a['effect']-b['effect']),**{k+'_pct':100*abs(a[k]/b[k]-1) for k in ('Q','G_svz','G_dzv')})
 ok=diff['effect_K']<=.1 and max(diff[k+'_pct'] for k in ('Q','G_svz','G_dzv'))<=2
 save(o/'summary.json',dict(time=now(),passed=ok,difference=diff,source_sha256=sha(root/'results.json')))
 if not ok:raise RuntimeError('h1 two-mesh sensitivity outside0.1K/2%')

def solve(c,folder,dp,tpl):
 p=registered();V.idle();folder.mkdir(parents=True,exist_ok=True)
 if (folder/'point_plan.json').exists():raise RuntimeError('Point already attempted')
 case=dict(c['source_case'],tag=c['tag'],params=c['params'],template=str(tpl));case['regime']=dict(case['regime'],p0_dzv=5.5,p_out_dzv=5.5-dp/1000)
 pp=load(R/'runs/plans/устойчивость_накатки_1103_v7_расчёты.json');pp.update(made=now(),cases=[case],code_sha256=p['code_sha256'],limitation='Registered warm cross-shape start; no cold/ideal-gas fallback. Numerical, grid and physical qualification separate; coverage/reverse recorded.')
 files=[Path(case['source_params'])]+[Path(case['source'])/n for n in ('result.cas.h5','result.dat.h5','axis.csv','cont.jou')]+[Path(tpl)/n for n in ('initial.cas.h5','initial.dat.h5','s4.trn','s5.trn','interface_audit.json')]
 pp['source_sha256']={str(f):sha(f) for f in files};plan=folder/'point_plan.json';save(plan,pp);plan.with_suffix('.sha256').write_text(sha(plan),encoding='ascii')
 F.PLAN=plan;F.OUT=folder/'run';F.same_shape=compatible
 try:F.run()
 finally:F.same_shape=ORIGINAL_SHAPE
 e=load(F.OUT/'results.json')[c['tag']];ind=F.STOP.evaluate(F.C.closed_samples(F.OUT/c['tag']),case['regime'])
 if not ind.get('accepted'):raise RuntimeError('Independent full-window acceptance failed')
 e.update(dp_kPa=dp,independent_full_window=ind);save(folder/'accepted.json',e)
 s=load(F.OUT/'summary.json');s['total']=1;save(F.OUT/'summary.json',s)
 return e

def pilot():
 p=registered();require(OUT/'grid/summary.json','passed');o=OUT/'pilot';once(o);c=p['pilot'];e=solve(c,o,c['dp_kPa'][0],c['template']);save(o/'summary.json',dict(time=now(),passed=True,result=e))

def build(c):
 # Reuse only the isolated mesh function, without importing cold-runner side effects.
 source=(D/'knurl_cold_chain_1104_v3.py').read_text(encoding='utf-8');tree=ast.parse(source);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='mesh_gate')
 code='\n'.join(source.splitlines()[node.lineno-1:node.end_lineno]);cfg=c['mesh_config'];o=Path(cfg['output']);o.mkdir(parents=True,exist_ok=True)
 namespace=dict(V=V,G=G,OUT=o,save=save,load=load,sha=sha,now=now,registered=registered,shutil=shutil,subprocess=subprocess,time=time,Path=Path)
 exec(compile(code,'isolated_mesh_gate','exec'),namespace);msh,cells=namespace['mesh_gate'](cfg)
 tpl=o/'template';native=B.build(msh,tpl,p0_svz_MPa=5.5,interpolate=False);V.idle()
 if native['final_quality']['native_warning_below_001']:raise RuntimeError('Final quality warning '+c['tag'])
 save(o/'template_gate.json',dict(cells=cells,result=native));return tpl

def match(samples,target,tol):
 best=min(samples,key=lambda x:abs(x['G_dzv']/target-1))
 if abs(best['G_dzv']/target-1)<=tol:return dict(kind='direct_within1pct',result=best)
 ss=sorted(samples,key=lambda x:x['G_dzv'])
 for a,b in zip(ss,ss[1:]):
  if a['G_dzv']<=target<=b['G_dzv'] and b['G_dzv']>a['G_dzv']:
   t=(target-a['G_dzv'])/(b['G_dzv']-a['G_dzv']);return dict(kind='bracket_interpolation_not_CFD',**{k:a[k]+t*(b[k]-a[k]) for k in ('Q','effect','dp_kPa')})
 return None

def series():
 p=registered();require(OUT/'pilot/summary.json','passed');o=OUT/'series';once(o);r={}
 for c in p['forms']:
  registered();tag=c['tag'];save(o/'state.json',dict(time=now(),phase='mesh' if c.get('mesh_config') else 'native_template',tag=tag))
  tpl=build(c) if c.get('mesh_config') else Path(c['template']);samples=[];schedule=c['dp_kPa'];selected=[schedule[0]]
  for i in range(3):
   if i>=len(selected):break
   point=dict(c,tag=tag+'_P'+str(i+1));save(o/'state.json',dict(time=now(),phase='cfd',tag=point['tag'],dp_kPa=selected[i]))
   samples.append(solve(point,o/tag/('P'+str(i+1)),selected[i],tpl))
   if i==0:
    if c['curve']:selected=list(schedule)
    elif abs(samples[0]['G_dzv']/p['target_G_dzv']-1)>p['equal_flow_tolerance']:selected.append(schedule[1] if samples[0]['G_dzv']>p['target_G_dzv'] else schedule[2])
  r[tag]=dict(split=c['split'],params=c['params']['knurl_dzv'],samples=samples,equal_flow=match(samples,p['target_G_dzv'],p['equal_flow_tolerance']));save(o/'results.json',r)
 save(o/'summary.json',dict(time=now(),passed=True,forms=len(r),accepted_CFD=sum(len(v['samples']) for v in r.values()),equal_flow_available=sum(v['equal_flow'] is not None for v in r.values()),holdout=[k for k,v in r.items() if v['split']=='holdout']))

def final():
 registered();s=require(OUT/'series/summary.json','passed');o=OUT/'final';once(o);r=load(OUT/'series/results.json')
 lines=['# Датасет накатки: фактический итог','',now(),'','|Форма|Выборка|h/шаг/ширина, мм|Численно принятых режимов|Равный расход|','|---|---|---|---|---|']
 for tag,e in r.items():
  q=e['params'];lines.append('|'+tag+'|'+e['split']+'|'+str([q[k] for k in ('h_mm','pitch_mm','width_mm')])+'|'+str(len(e['samples']))+'|'+str(e['equal_flow']['kind'] if e['equal_flow'] else 'не охвачен; не экстраполировать')+'|')
 lines+=['','Независимые формы holdout не использовать при выборе/обучении. Статус сходимости не равен физической работоспособности. Сеточная проверка локальная, не GCI; покрытие и обратный ток записаны по каждому расчёту.','',json.dumps(s,ensure_ascii=False,indent=2)]
 (o/'report_ru.md').write_text('\n'.join(lines)+'\n',encoding='utf-8');save(o/'finished.json',dict(time=now(),passed=True))

def check():
 p=registered();assert len(p['forms'])==15 and sum(c['split']=='holdout' for c in p['forms'])==3
 for c in [p['pilot']]+p['forms']:
  q=c['params']['knurl_dzv'];assert .1<=q['h_mm']<=1 and 1.5<=q['pitch_mm']<=4.75 and .2-1e-8<=q['width_mm']/q['pitch_mm']<=.6+1e-8
  compatible(c['params'],load(c['source_case']['source_params']));assert len(c['dp_kPa'])==3
 assert 'global-time-step-settings' not in '\n'.join(L.SOLVER_HEADER)
 print('CHECK OK:15forms/3holdout/immutable schedules/PR/one writer/no cold header')

if __name__=='__main__':
 mode=sys.argv[1]
 try:
  if mode=='check':check()
  else:globals()[mode]()
 except Exception as e:
  o=OUT/mode;o.mkdir(parents=True,exist_ok=True);save(o/'BLOCK.json',dict(time=now(),error=repr(e),traceback=traceback.format_exc(),no_retry=True));raise
