"""Read-only status adapter for the existing author GUI. Original pinned files unchanged.
Prefer the live Fluent journal command over the mtime of its open transcript.
"""
import datetime,json,math,re,subprocess,sys,time,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D));R=D.parent/'runs'
import author_gui as BASE
import audit_knurl_reports_1103_v3 as AUD
ORIGINAL_CURRENT=BASE.current_run;ORIGINAL_SNAPSHOT=BASE.snapshot;ORIGINAL_ROWS=BASE.conv_rows;ORIGINAL_SHOW=BASE.App.show
PLAN=R/'plans/интерфейс_статуса_1103_v1.json';OUT=R/'ui_status_1103_v1'

def resolve_live(rows):
    if isinstance(rows,dict):rows=[rows]
    rows=rows or []
    candidates=[]
    for row in rows:
        command=row.get('CommandLine') or ''
        m=re.search(r'(?:^|\s)-i\s+(?:"([^"]+\.jou)"|([^\s]+\.jou))',command,re.I)
        if not m:continue
        journal=Path(m[1] or m[2]).resolve()
        if journal.is_relative_to(R.resolve()) and journal.is_file():candidates.append((journal.parent,row))
    return candidates[0] if len(candidates)==1 else None

def live_run():
    command="@(Get-CimInstance Win32_Process -Filter \"Name='cx2420.exe'\" | Select-Object ProcessId,CommandLine) | ConvertTo-Json -Compress"
    raw=subprocess.check_output(['powershell','-NoProfile','-Command',command],text=True,creationflags=subprocess.CREATE_NO_WINDOW).strip()
    return resolve_live(json.loads(raw) if raw else [])

def current_run():
    live=live_run()
    if live:return live[0],time.time()
    return ORIGINAL_CURRENT()

def enrich_passport(folder,pp):
    p=folder/'params.json'
    if not p.exists():return
    q=json.loads(p.read_text(encoding='utf-8'));kn=q.get('knurl_dzv')
    # Own parameter file must not be lost when passport.resolve follows a temporary template.
    pp.update(kind='накатка' if kn else pp.get('kind','гладкая'))
    pp['geometry']=dict(t_d=BASE.PS.td_from_gap(q['gap_mm']) if q.get('gap_mm') else None,L_mm=q.get('l_heat_mm'),gap_mm=q.get('gap_mm'),throat_mm=BASE.PS.THROAT,r_exit_mm=q.get('r_nozzle_exit_mm'),area_ratio=(q['r_nozzle_exit_mm']/BASE.PS.THROAT)**2 if q.get('r_nozzle_exit_mm') else None,wall_in_mm=q.get('wall_thickness_inlet_mm'),wall_end_mm=q.get('wall_thickness_end_mm'),knurl=kn)
    pp['mesh']=dict(preset='своя',axial_mm=q.get('axial_size_mm'),dzv_layers=q.get('dzv_layers'),dzv_h1_mm=q.get('dzv_h1_mm'),cells=None)
    state=folder.parent/'state.json'
    if state.exists():
        state=json.loads(state.read_text(encoding='utf-8'))
        if state.get('tag')==folder.name:pp['mesh']['cells']=state.get('cells')
    pp['regime'].update({k:v for k,v in BASE.PS.regime_from_jou((folder/'cont.jou').read_text(encoding='utf-8')).items() if v is not None})
    pp['regime']['dp_dzv_kPa']=round(1000*(pp['regime']['p0_dzv']-pp['regime']['p_out_dzv']),3)
    pp['regime']['heat_K']=pp['regime']['T0_svz']-pp['regime']['T0_dzv']

def snapshot():
    s=ORIGINAL_SNAPSHOT();folder=s.get('run')
    if not folder:return s
    folder=Path(folder);pp=s['pp'];enrich_passport(folder,pp)
    template=folder.parent/(folder.name+'_template')
    if folder.parent.name=='grid_1103_v8' and (template/'s5.trn').exists():
        side=AUD.sides(template);rows=AUD.samples(folder,side)
        by_it={r['iteration']:r for r in rows}
        for row in s['st'].get('samples',[]):
            if row['iteration'] in by_it:row['Q']=by_it[row['iteration']]['Q']
            if side['dzv']['gas']!='interior-air_dzv-wall_abonite-shadow':row['yp_dzv']=float('nan')
        s['last']=(s['st'].get('samples') or [None])[-1]
        s['eff']=BASE.effect(pp,s['last']) if s['last'] else None
        s['hist']=[(r['iteration'],BASE.effect(pp,r),r['Q'],r['m_dzv'],r['net']) for r in s['st'].get('samples',[])]
        if len(rows)>=3:
            e=AUD.evaluate(rows,pp['regime']);e.update(ok=e['accepted'],why='; '.join(k for k,v in e['checks'].items() if not v));s['d12a']=e
        else:s['d12a']=dict(ok=None,n=len(rows),why='ещё нет полного окна1000итераций')
        s['corrected_wall_sides']=side
    plan=R/'plans/проверка_сетки_1103_v9_автостоп.json'
    state=R/'autostop_d12a_1103_v2/state.json'
    if plan.exists() and state.exists():
        p=json.loads(plan.read_text(encoding='utf-8'))
        if Path(p['target']).resolve()==folder.resolve():
            state=json.loads(state.read_text(encoding='utf-8'));s['d48']=state;s['conv']['d48']=state
    return s

def conv_rows(c,last,it,mx):
    if not (c or {}).get('d48'):return ORIGINAL_ROWS(c,last,it,mx)
    state=c['d48'];windows=state.get('windows',[])
    rows=[('Автостоп: два последних окна',str(sum(bool(w.get('accepted')) for w in windows))+' / 2','2 подряд',state.get('ready',False))]
    for w in windows:
        rows.append(('Средний баланс '+str(w['it'][0])+'–'+str(w['it'][1])+', % Q',BASE.fmt(w['imb_pct'],'{:+.3f}'),'<1 по модулю',w['checks']['imb']))
    rows.append(('Баланс массы СВЗ', 'в допуске' if state.get('actual_mass_balance_ok') else 'не в допуске','≤1%',state.get('actual_mass_balance_ok',False)))
    if it and mx:rows.append(('Реальная итерация',str(it),'≤'+str(mx),it<mx))
    return rows

def show(self):
    ORIGINAL_SHOW(self)
    s=self.data or {}
    if s.get('run'):
        if s.get('d48'):
            label=self.boxes['prog'].cget('text')
            self.boxes['prog'].config(text=label+'\nавтостоп: два полных окна D-12a подряд')
        side=s.get('corrected_wall_sides')
        if side and side['dzv']['gas']!='interior-air_dzv-wall_abonite-shadow':
            label=self.boxes['mesh'].cget('text');self.boxes['mesh'].config(text=label+'\ny+ ДЗВ: нужен замер газовой стороны')
        self.head.config(text='Сейчас: '+str(s['run'].name)+' — Fluent работает; критерии ниже')
        self.fig.tight_layout();self.canvas.draw_idle()

BASE.current_run=current_run;BASE.snapshot=snapshot;BASE.conv_rows=conv_rows;BASE.App.show=show

def make_plan():
    if PLAN.exists():raise RuntimeError('GUI plan exists; do not overwrite')
    files=[Path(__file__),D/'author_gui.py',D/'audit_knurl_reports_1103_v3.py',D/'gui_runner.py',D/'passport.py']
    p=dict(made=AUD.now(),authorization='Author: restore current status and convergence display; reversible UI repair only.',scope='Read-only status UI. No solver/source-script edits, no CFD launches or changes.',root_cause='mtime of a long-open Windows transcript can remain unchanged longer than15min while iterations advance. Old GUI hid the active run by a900s mtime cutoff.',changes=['Identify active folder from exactly one live Fluent cx command journal inside runs. Keep the old discovery fallback for other cases.','Display actual residual iteration and closed-window D48 checks, both recent window balances, physical signed Q and recomputed effect. Mark invalid DZV yplus unknown, not0.','Use own params for geometry/mesh while a continued case points at a temporary template. Keep all other tabs.'],code_sha256={str(f):AUD.sha(f) for f in files})
    AUD.save(PLAN,p);PLAN.with_suffix('.sha256').write_text(AUD.sha(PLAN),encoding='ascii');print(PLAN,AUD.sha(PLAN))

def registered():
    if AUD.sha(PLAN)!=PLAN.with_suffix('.sha256').read_text().strip():raise RuntimeError('GUI plan changed')
    p=json.loads(PLAN.read_text(encoding='utf-8'))
    for f,h in p['code_sha256'].items():
        if AUD.sha(f)!=h:raise RuntimeError('GUI registered source changed '+f)

if __name__=='__main__':
    if sys.argv[1:]==['plan']:make_plan()
    elif sys.argv[1:]==['check']:
        registered();s=snapshot();print(json.dumps(dict(run=str(s.get('run')),iteration=(s.get('res')or{}).get('iter'),closed_iteration=(s.get('conv')or{}).get('checked_iteration'),D48=bool(s.get('d48')),Q=(s.get('last')or{}).get('Q'),effect=s.get('eff'),geometry=(s.get('pp')or{}).get('geometry')),ensure_ascii=False))
    else:
        registered();OUT.mkdir(exist_ok=True,parents=True)
        if sys.stdout is None:sys.stdout=sys.stderr=open(OUT/'gui_log.txt','a',encoding='utf-8',buffering=1)
        app=BASE.App();app.title('Труба Леонтьева — интерфейс автора (текущий статус)')
        # Scroll long convergence tables without hiding the current values.
        parent=app.ctree.master;app.ctree.pack_forget();app.ctree.configure(height=10)
        scroll=BASE.ttk.Scrollbar(parent,orient='vertical',command=app.ctree.yview);scroll.pack(side='right',fill='y');app.ctree.configure(yscrollcommand=scroll.set);app.ctree.pack(side='left',fill='both',expand=True)
        app.geometry('1540x'+str(min(1100,app.winfo_screenheight()-80)))
        app.nb.select(2);app.mainloop()