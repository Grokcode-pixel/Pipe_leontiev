﻿"""Б5 v2 (17.10.2026, по отзыву рецензента 17.10): балансовая модель узла ГРС — честное «было → стало».
Метан, реальный газ (CoolProp HEOS). Устройство (одна труба пучка RU 2162190) — быстрая 1D-модель fast1d,
калиброванная по CFD (runs\\fast1d\\calib.json). Давление магистрали пока только 5,5 МПа (как в CFD).

Варианты (каждая польза — в своих единицах, НЕ складываются):
 (а) дроссель + подогреватель (как на ГРС сейчас);
 (б) СПГ из магистрали без пучка: та же доля газа, что идёт в ДЗВ в (в), подаётся на установку сжижения прямо из
     магистрали; остальное — дроссель;
 (в) пучок: n труб (ручка диспетчера), СВЗ нагрет на Q, ДЗВ охлаждён → сырьё СПГ; остаток — обводная линия;
 (г) регулятор + обычный противоточный теплообменник «газ ДЗВ (сырьё СПГ, давление магистрали) ↔ редуцированный газ
     (давление потребителя)» ТОЙ ЖЕ ПОВЕРХНОСТИ, что стенка трубы; k — Диттус–Бёльтер с обеих сторон + стенка
     (как в fast1d, с теми же калибровочными множителями).  Вклад пучка = (в) − (г).
Место подогревателя (выбор схемы главным инженером): 'до сопел' — на линии СВЗ при давлении магистрали (тёплый газ в
сопло, меньший эффект трубы); 'после' — на редуцированном газе перед потребителем (холодный газ в сопло).
Установка СПГ: дроссельный цикл с рекуператором (Линде), сырьё → давление потребителя, недогрев рекуператора ΔT;
выход y = (h_пар − h_сырьё)/(h_пар − h_жидк); несжиженный пар (T сырья − ΔT) возвращается к потребителю.
Самопроверки: без утилизации холода (нет СПГ, нет внешнего тепла) подогрев (в) и (г) = (а) при любом месте подогревателя.
Программа ничего не регулирует — это расчёт для ЛПР."""
import math
from dataclasses import dataclass, asdict, field
import json
import CoolProp.CoolProp as CP
import fast1d as F

FLUID = 'Methane'
RHO_N = CP.PropsSI('D', 'P', 101325, 'T', 293.15, FLUID)        # кг/нм³ (20 °C, ГОСТ 2939)
CALIB = json.load(open(r'F:\Leontiev_Project\runs\fast1d\calib.json', encoding='utf-8'))['params']


def h(p, T):
    return CP.PropsSI('H', 'P', p * 1e6, 'T', T + 273.15, FLUID)


def T_of(p, hh):
    return CP.PropsSI('T', 'P', p * 1e6, 'H', hh, FLUID) - 273.15


@dataclass
class Station:
    p_main: float = 5.5        # МПа
    T_main: float = 0.0        # °C
    flow_nm3h: float = 5000.0  # отпуск потребителю
    p_cons: float = 0.6        # МПа
    T_min: float = -10.0       # °C: −10 (норма), 0 (пучинистые грунты) — уставка ЛПР
    eta_heater: float = 0.82
    LHV_MJ_nm3: float = 33.5   # 8000 ккал/нм³


@dataclass
class Bundle:
    td: float = 1.4
    L_mm: float = 400.0
    dp_kPa: float = 10.0       # перепад ДЗВ (клапан) — ручка диспетчера
    n_on: int | None = None    # число работающих труб — ручка диспетчера (режимный параметр u_р); None — правило n_rule
    heater_place: str = 'после'   # 'до сопел' / 'после'
    lng: bool = True           # холод ДЗВ → установка СПГ
    dT_rec: float = 5.0        # недогрев рекуператора, K
    # 30.10.2026 (решение автора): схема использования холода ДЗВ. None — как раньше (СПГ, если lng);
    # 'внешнее тепло' — СПГ нет, газ ДЗВ после пучка догревается внешним (не топливным) теплом до T_ext при своём давлении;
    # 'СПГ + внешнее тепло' — СПГ (Линде), несжиженный пар после СПГ догревается внешним теплом до T_ext.
    # 30.10.2026 (задание автора, сценарии ДЗВ): 'транзит' — газ ДЗВ после пучка уходит в транзит при своём давлении (к потребителю
    # не возвращается; цена — потеря давления ДЗВ и охлаждение транзитного газа); потребитель холода = 'внешнее тепло' (холод ДЗВ
    # забирает потребитель холода: его тепло и есть «внешнее тепло»).
    scheme: str | None = None
    T_ext: float | None = None  # цель догрева внешним теплом, °C (None — температура газа магистрали)
    heat_fixed_K: float | None = None   # 30.10: подогрев СВЗ до сопел задан (как в CFD, напр. A9_19 +4,83 K), остальное — после пучка


def linde(p_feed, T_feed, p_low, dT):
    """Доля сжиженного газа и температура возвратного пара (адиабатический цикл с рекуператором)."""
    h_feed = h(p_feed, T_feed)
    T_ret = T_feed - dT
    h_vap = h(p_low, T_ret)
    h_liq = CP.PropsSI('H', 'P', p_low * 1e6, 'Q', 0, FLUID)
    y = max(0.0, (h_vap - h_feed) / (h_vap - h_liq))
    return y, T_ret


def heater_to(st, m_total, h_mix):
    """Тепло подогревателя на смеси у потребителя до T_min (кВт)."""
    return max(0.0, m_total * (h(st.p_cons, st.T_min) - h_mix)) / 1e3


def fuel(st, Q_kW):
    return Q_kW * 3.6 / (st.eta_heater * st.LHV_MJ_nm3)          # нм³/ч


def n_rule(st, G_svz_tube, G_dzv_tube):
    """27.10.2026 — правило числа работающих труб: целая часть (расход станции / расход одной трубы СВЗ + ДЗВ),
    остаток идёт через дроссель (байпас). В программе число труб — режимный параметр u_р в пределах 1…n_rule."""
    return max(1, int(st.flow_nm3h * RHO_N / 3600 // (G_svz_tube + G_dzv_tube)))


def tube(bd, st, heater_K):
    return F.run(bd.td, bd.L_mm, bd.dp_kPa, st.p_cons, st.T_main, heater_K, par=CALIB)


def var_a(st):
    m = st.flow_nm3h * RHO_N / 3600
    hin = h(st.p_main, st.T_main)
    Q = heater_to(st, m, hin)
    return dict(Q_heater_kW=Q, fuel_nm3h=fuel(st, Q), lng_kgh=0.0, T_throttle_C=T_of(st.p_cons, hin))


def _solve_heater_before(st, bd, build):
    """Подогреватель на линии СВЗ до сопел: подбор нагрева так, чтобы смесь у потребителя ≥ T_min (бисекция)."""
    r0 = build(0.0)
    if r0['h_mix'] >= h(st.p_cons, st.T_min):
        return r0, 0.0
    lo, hi = 0.0, 60.0
    for _ in range(30):
        mid = 0.5 * (lo + hi)
        r = build(mid)
        if r['h_mix'] >= h(st.p_cons, st.T_min):
            hi = mid
        else:
            lo = mid
    return build(hi), hi


def var_v(st, bd):
    """(в) пучок."""
    m_cons = st.flow_nm3h * RHO_N / 3600
    hin = h(st.p_main, st.T_main)
    p_dzv = st.p_main - bd.dp_kPa / 1000

    def build(heat_K):
        o = tube(bd, st, heat_K)
        n = bd.n_on or n_rule(st, o['G_svz'], o['G_dzv'])
        G_s, G_d, Q = n * o['G_svz'], n * o['G_dzv'], n * o['Q']
        h_s0 = h(st.p_main, st.T_main + heat_K)
        q_heat_line = G_s * (h_s0 - hin)                          # тепло подогревателя до сопел, Вт
        h_svz = h_s0 + Q / G_s
        h_dzv = hin - Q / G_d
        T_dzv = T_of(p_dzv, h_dzv)
        T_ext = st.T_main if bd.T_ext is None else bd.T_ext
        ext_W = 0.0
        transit = bd.scheme == 'транзит'
        if transit:                                               # 30.10: ДЗВ уходит в транзит, магистраль даёт ещё G_ДЗВ
            y, lng, m_ret, h_ret = 0.0, 0.0, 0.0, h_dzv
        elif bd.scheme == 'внешнее тепло':                        # 30.10: ДЗВ догревается внешним теплом при своём давлении
            y, lng, m_ret = 0.0, 0.0, G_d
            h_ret = max(h_dzv, h(p_dzv, T_ext))
            ext_W = G_d * (h_ret - h_dzv)
        elif bd.lng or bd.scheme == 'СПГ + внешнее тепло':
            y, T_ret = linde(p_dzv, T_dzv, st.p_cons, bd.dT_rec)
            lng = y * G_d
            h_ret = h(st.p_cons, T_ret)
            m_ret = G_d - lng
            if bd.scheme == 'СПГ + внешнее тепло':                # 30.10: несжиженный пар догревается внешним теплом
                h_ext = max(h_ret, h(st.p_cons, T_ext))
                ext_W = m_ret * (h_ext - h_ret)
                h_ret = h_ext
        else:
            y, lng, m_ret, h_ret = 0.0, 0.0, G_d, h_dzv            # ДЗВ просто возвращается (без утилизации холода)
        m_byp = m_cons + lng - G_s - (0.0 if transit else G_d)    # магистраль даёт m_cons + СПГ (+ транзит)
        if m_byp < 0:
            raise ValueError(f'n_on={n}: через трубы идёт больше газа, чем нужно станции')
        h_mix = (G_s * h_svz + m_ret * h_ret + m_byp * hin) / m_cons
        return dict(o=o, n=n, G_svz=G_s, G_dzv=G_d, Q_W=Q, T_dzv_C=T_dzv, y=y, lng_kgh=lng * 3600, h_mix=h_mix,
                    q_line_W=q_heat_line, m_byp=m_byp, ext_W=ext_W, T_ext_C=T_ext, p_dzv=p_dzv)

    if bd.heat_fixed_K is not None:                               # 30.10: до сопел — как в CFD, после пучка — до T_min
        r, heat_K = build(bd.heat_fixed_K), bd.heat_fixed_K
        pre_kW, post_kW = r['q_line_W'] / 1e3, heater_to(st, m_cons, r['h_mix'])
    elif bd.heater_place == 'до сопел':
        r, heat_K = _solve_heater_before(st, bd, build)
        pre_kW, post_kW = r['q_line_W'] / 1e3, 0.0
    else:
        r, heat_K = build(0.0), 0.0
        pre_kW, post_kW = 0.0, heater_to(st, m_cons, r['h_mix'])
    Q_kW = pre_kW + post_kW                                        # 30.10: всё топливное тепло станции
    return dict(Q_heater_kW=Q_kW, pre_kW=pre_kW, post_kW=post_kW, p_dzv_MPa=r['p_dzv'], dzv_loss_kPa=bd.dp_kPa,
                fuel_nm3h=fuel(st, Q_kW), lng_kgh=r['lng_kgh'], heater_svz_K=heat_K,
                T_dzv_C=r['T_dzv_C'], lng_yield_pct_dzv=100 * r['y'], m_dzv_kgs=r['G_dzv'], m_svz_kgs=r['G_svz'],
                Q_tube_W=r['Q_W'] / r['n'], n_on=r['n'], effect_K=r['o']['effect_K'], working=r['o']['working'], m=r['o']['m'],
                ext_kW=r['ext_W'] / 1e3, T_ext_C=r['T_ext_C'])


def var_b(st, bd, m_feed):
    """(б) СПГ из магистрали без пучка: сырьё m_feed (как ДЗВ в (в)) при давлении и температуре магистрали."""
    m_cons = st.flow_nm3h * RHO_N / 3600
    hin = h(st.p_main, st.T_main)
    y, T_ret = linde(st.p_main, st.T_main, st.p_cons, bd.dT_rec)
    lng = y * m_feed
    m_byp = m_cons + lng - m_feed
    h_mix = ((m_feed - lng) * h(st.p_cons, T_ret) + m_byp * hin) / m_cons
    Q = heater_to(st, m_cons, h_mix)
    return dict(Q_heater_kW=Q, fuel_nm3h=fuel(st, Q), lng_kgh=lng * 3600, lng_yield_pct_dzv=100 * y)


def hx_UA(bd, st, m_hot, m_cold):
    """UA обычного теплообменника той же поверхности, что стенка трубы (внутри — редуцированный газ при p_cons,
    снаружи — кольцо ДЗВ того же зазора); Диттус–Бёльтер × те же множители K_svz, K_dzv, что в fast1d."""
    r_in = 0.5 * (F.R_EXIT + F.R_END)
    L = bd.L_mm * 1e-3
    r_eq, gap = F.cell(bd.td)
    T_c = T_of(st.p_cons, h(st.p_main, st.T_main))
    mu_c = CP.PropsSI('viscosity', 'P', st.p_cons * 1e6, 'T', T_c + 273.15, FLUID)
    k_c = CP.PropsSI('conductivity', 'P', st.p_cons * 1e6, 'T', T_c + 273.15, FLUID)
    cp_c = CP.PropsSI('Cpmass', 'P', st.p_cons * 1e6, 'T', T_c + 273.15, FLUID)
    D = 2 * r_in
    Re_c = m_cold * D / (math.pi * r_in ** 2 * mu_c)
    hc = CALIB['K_svz'] * 0.023 * Re_c ** 0.8 * (cp_c * mu_c / k_c) ** 0.4 * k_c / D
    Ad = math.pi * (r_eq ** 2 - F.R_O ** 2); Dh = 2 * gap
    mu_h = CP.PropsSI('viscosity', 'P', st.p_main * 1e6, 'T', st.T_main + 273.15, FLUID)
    k_h = CP.PropsSI('conductivity', 'P', st.p_main * 1e6, 'T', st.T_main + 273.15, FLUID)
    cp_h = CP.PropsSI('Cpmass', 'P', st.p_main * 1e6, 'T', st.T_main + 273.15, FLUID)
    Re_h = m_hot * Dh / (Ad * mu_h)
    hh_ = CALIB['K_dzv'] * 0.023 * max(Re_h, 2300) ** 0.8 * (cp_h * mu_h / k_h) ** 0.4 * k_h / Dh
    R = 1 / (hc * 2 * math.pi * r_in * L) + math.log(F.R_O / r_in) / (2 * math.pi * F.K_WALL * L) + 1 / (hh_ * 2 * math.pi * F.R_O * L)
    return 1 / R, cp_h, cp_c


def var_g(st, bd, G_svz_tube, G_dzv_tube):
    """(г) регулятор + обычный противоточный теплообменник той же поверхности на каждую «трубу»."""
    m_cons = st.flow_nm3h * RHO_N / 3600
    hin = h(st.p_main, st.T_main)
    n = bd.n_on or n_rule(st, G_svz_tube, G_dzv_tube)
    UA, cp_h, cp_c = hx_UA(bd, st, G_dzv_tube, G_svz_tube)
    Ch, Cc = G_dzv_tube * cp_h, G_svz_tube * cp_c
    Cmin, Cr = min(Ch, Cc), min(Ch, Cc) / max(Ch, Cc)
    NTU = UA / Cmin
    eps = (1 - math.exp(-NTU * (1 - Cr))) / (1 - Cr * math.exp(-NTU * (1 - Cr))) if Cr < 0.999 else NTU / (1 + NTU)
    T_c_in = T_of(st.p_cons, hin)                                  # редуцированный газ после регулятора
    Q1 = eps * Cmin * (st.T_main - T_c_in)                         # Вт на одну «трубу»
    p_dzv = st.p_main - bd.dp_kPa / 1000
    G_s, G_d, Q = n * G_svz_tube, n * G_dzv_tube, n * Q1
    h_dzv = h(st.p_main, st.T_main) - Q / G_d
    T_dzv = T_of(st.p_main, h_dzv)
    if bd.lng:
        y, T_ret = linde(st.p_main, T_dzv, st.p_cons, bd.dT_rec)
        lng = y * G_d; m_ret = G_d - lng; h_ret = h(st.p_cons, T_ret)
    else:
        y, lng, m_ret, h_ret = 0.0, 0.0, G_d, h_dzv
    m_byp = m_cons + lng - G_s - G_d
    h_mix = (G_s * (hin + Q / G_s) + m_ret * h_ret + m_byp * hin) / m_cons
    Qh = heater_to(st, m_cons, h_mix)
    return dict(Q_heater_kW=Qh, fuel_nm3h=fuel(st, Qh), lng_kgh=lng * 3600, lng_yield_pct_dzv=100 * y, Q_hx_W=Q1,
                T_dzv_C=T_dzv, UA_W_K=UA, eps=eps)


def compare(st: Station, bd: Bundle):
    a = var_a(st)
    v = var_v(st, bd)
    b = var_b(st, bd, v['m_dzv_kgs'])
    g = var_g(st, bd, v['m_svz_kgs'] / v['n_on'], v['m_dzv_kgs'] / v['n_on'])
    return dict(station=asdict(st), bundle=asdict(bd), а=a, б=b, в=v, г=g)


def self_check():
    """Без утилизации холода (lng=False) пучок адиабатен → подогрев (в) = (а) при обоих местах подогревателя."""
    out = {}
    for place in ('после', 'до сопел'):
        st = Station(T_main=0.0, p_cons=0.6, T_min=-10.0)
        bd = Bundle(td=1.4, L_mm=400, dp_kPa=10, n_on=3, heater_place=place, lng=False)
        a, v = var_a(st), var_v(st, bd)
        assert abs(a['Q_heater_kW'] - v['Q_heater_kW']) < 0.05 * max(a['Q_heater_kW'], 1) + 1e-3, (place, a, v)
        out[place] = (round(a['Q_heater_kW'], 3), round(v['Q_heater_kW'], 3))
    return out


if __name__ == '__main__':
    print('самопроверка (а) против (в) без утилизации холода, кВт:', self_check())

