"""A5 v3b from INTERPOLATED old converged fields (10.10.2026 11:30).  b2/b4 (CFL 5, fixed DZV outlet pressure) are
stable but the SVZ mass balance falls only ~0.15 %/1000 iterations (7.45 % at 13500): the channel shock of the
from-scratch start field leaves far too slowly (CFL 10 is unstable on the resolved DZV layers).  The old series
(coarse DZV mesh, same geometry) has converged shock-free fields (a5v3_m011, m075, m000; m030 at the limit).  Each point
here: read the new-mesh case (a5v3_m011p: settings, 40 DZV layers) -> /file/interpolate/read-data of the old field of the
same m (SVZ zone id 8 matches; the DZV zone does not, so the DZV fluid is patched to rest at the outlet pressure,
25.85 C, k 0.1, omega 1000 — case units atm / C; the brass wall to 23 C) -> CFL 5, LIMIT 8000.  Interpolation files:
runs\\a5v3b\\ip_old\\*.ip (written 11:12 from runs\\a5v3\\*\\result.cas.h5; syntax checked in ip_old\\probe.trn).
Each point is independent (no chain); summary as in b2."""
import sys, traceback
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_a5v3b2 as B
import cont_util as U
import leontiev_pipeline as L

A = B.A
log = B.log
U.CFL = 5.0
U.LIMIT = 8000
TEMPLATE = A.BASE / 'a5v3_m011p' / 'result.cas.h5'
IP = A.BASE / 'ip_old'
ATM = 0.101325


def init_lines(ip, p_dzv_MPa):
    return [f'/file/interpolate/read-data "{L.fl(ip)}"',
            f'/solve/patch air_dzv () pressure {p_dzv_MPa / ATM:.5f}',
            '/solve/patch air_dzv () temperature 25.85',
            '/solve/patch air_dzv () x-velocity ok 0',
            '/solve/patch air_dzv () y-velocity ok 0',
            '/solve/patch air_dzv () k 0.1',
            '/solve/patch air_dzv () omega 1000',
            '/solve/patch wall_abonite () temperature 23']


def run(tag, old, pod):
    out = A.BASE / tag
    mins = U.continue_case(TEMPLATE, out, A.TMF_OFF + init_lines(IP / f'{old}.ip', pod), (B.P0, 0.1, B.P0, pod), log,
                           f'{tag} (поле {old} старой серии, давление на выходе ДЗВ {pod:.5f} МПа)', t0_C=A.T0_C)
    return U.record(A.CSV, tag, 'rig_work_v2', 'air', (B.P0, 0.1, B.P0, pod), out, mins, log,
                    start=f'интерполяция {old} на сетку a5v3_m011p', t0_C=A.T0_C, l_heat_mm=700.0)


def main():
    log(f'=== А5 v3b5: от интерполированных полей старой серии, CFL 5, предел {U.LIMIT}')
    rows = {}
    for m, old in ((0.11, 'a5v3_m011'), (0.75, 'a5v3_m075'), (0.30, 'a5v3_m030')):
        pod = round(B.P0 - B.DP0[m], 6)
        r = run(f'a5v3_m{int(round(m * 100)):03d}i', old, pod)
        if r.get('G_dzv') and r.get('G_svz'):
            log(f'  достигнутый m {float(r["G_dzv"]) / float(r["G_svz"]):.3f} (цель {m})')
        rows[m] = r
    r0 = run('a5v3_m000i', 'a5v3_m000', B.P0)
    B.summary(rows, r0)


if __name__ == '__main__':
    A.qlog('=== А5 v3b5 (от интерполированных полей старой серии) — начат')
    try:
        main()
    except Exception:
        log('ОШИБКА программы: ' + traceback.format_exc())
    A.qlog('=== А5 v3b5 — закончен (приёмка — по результатам)')
