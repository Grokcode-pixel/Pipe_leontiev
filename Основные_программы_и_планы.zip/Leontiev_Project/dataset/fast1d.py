﻿"""16.10.2026 — этап 5 итогового плана: быстрая одномерная модель ячейки трубы Леонтьева (доли секунды на точку).
Нужна для многоуровневой модели: 1000+ точек быстрой модели + поправка и проверка по CFD (А9).

Ячейка как в CFD: сопло (горло r 2,25 мм, срез r 3,3 мм) → конический сверхзвуковой канал r 3,3 → 4,8 мм длиной L,
латунная стенка k 110 (3,0 → 1,5 мм), наружный цилиндр r_o 6,3 мм, кольцо ДЗВ с зазором по t/d, ПРОТИВОТОК.
Газ — метан, РЕАЛЬНЫЙ (CoolProp HEOS):
- ядро СВЗ — изоэнтропическое расширение по таблице p → (h, T, ρ, a) при s0; расход — максимум ρu в горле (×Cd);
- трение — потеря полного давления по Фанно: dπ0/π0 = −K_f·γM²/2·f·dx/D; состояние в сечении — по потоку
  G/(A·π0) на сверхзвуковой ветви; если поток недостижим — запирание (скачок в канале);
- теплообмен: q = (T_ДЗВ − T_aw)/(1/h_СВЗ + ln(r_o/r)/(2πk) + 1/h_ДЗВ), T_aw = T + r·u²/(2cp), r = 0,88;
  h — Диттус–Бёльтер × K_svz, K_dzv (калибруются по CFD);
- ДЗВ: расход из перепада по Дарси (трение + K_loc), противоток решается итерациями;
- выход: прямой скачок на срезе канала (γ на выходе) против давления потребителя × K_shock;
- эффект СВЗ относительно дросселя и охлаждение ДЗВ — по энтальпии (CoolProp), как в CFD.
Модель НИЗКОЙ точности: числа — только для многоуровневой модели, не для выводов."""
import math
from functools import lru_cache
import numpy as np
import CoolProp.CoolProp as CP
from CoolProp.CoolProp import PropsSI

FLUID = 'Methane'
P0 = 5.5e6
R_THROAT, R_EXIT, R_END, R_O = 2.25e-3, 3.3e-3, 4.8e-3, 6.3e-3
K_WALL = 110.0
PAR = dict(Cd=0.97, K_svz=1.0, K_dzv=1.0, K_loc=1.5, K_shock=1.0, K_f=1.0, r=0.88)


def cell(td):
    t = td * 2.0 * R_O
    r_eq = t * math.sqrt(math.sqrt(3.0) / (2.0 * math.pi))
    return r_eq, r_eq - R_O


@lru_cache(maxsize=256)
def table(T0s_r):
    """Isentropic expansion from (P0, T0s): arrays along falling pressure (rounded T0 -> cache)."""
    T0s = T0s_r / 10.0
    h0 = PropsSI('Hmass', 'P', P0, 'T', T0s, FLUID)
    s0 = PropsSI('Smass', 'P', P0, 'T', T0s, FLUID)
    # gas phase forced (metastable vapour below the saturation line): the author excluded condensation (09.10), and the
    # Fluent model (Peng-Robinson, single phase) does the same
    AS = CP.AbstractState('HEOS', FLUID)
    AS.specify_phase(CP.iphase_gas)
    rows = []
    Tlo_prev = T0s
    for p in np.geomspace(P0 * 0.999, 2.0e4, 220):
        lo, hi = 0.6 * Tlo_prev, Tlo_prev + 1.0   # s(p, T) = s0 by bisection with PT inputs (PS flash ignores the phase)
        try:
            for _ in range(45):
                mid = 0.5 * (lo + hi)
                try:
                    AS.update(CP.PT_INPUTS, p, mid)
                    s_mid = AS.smass()
                except ValueError:                 # no gas root (too cold / dense) -> go warmer
                    lo = mid
                    continue
                if s_mid > s0:
                    hi = mid
                else:
                    lo = mid
            AS.update(CP.PT_INPUTS, p, 0.5 * (lo + hi))
            rows.append((p, AS.hmass(), AS.T(), AS.rhomass(), AS.speed_sound(), AS.cpmass(), AS.cpmass() / AS.cvmass()))
            Tlo_prev = AS.T()
        except ValueError:
            break
    ps, h, T, rho, a, cp, g = (np.array(c) for c in zip(*rows))
    u = np.sqrt(np.maximum(2 * (h0 - h), 0.0))
    flux = rho * u
    it = int(np.argmax(flux))
    return dict(h0=h0, p=ps, h=h, T=T, rho=rho, a=a, cp=cp, g=g, u=u, flux=flux, it=it)


def sup_state(tb, target):
    """State on the supersonic branch with mass flux = target (None if target > max flux -> choking)."""
    it = tb['it']
    f = tb['flux'][it:]
    if target > f[0]:
        return None
    j = int(np.searchsorted(-f, -target))         # flux falls along the supersonic branch
    j = min(max(j, 1), len(f) - 1)
    w = (target - f[j - 1]) / (f[j] - f[j - 1])
    return {k: tb[k][it + j - 1] + w * (tb[k][it + j] - tb[k][it + j - 1]) for k in ('p', 'T', 'rho', 'a', 'cp', 'g', 'u')}


def friction(Re):
    Re = max(Re, 2300.0)
    return 0.25 / math.log10(5.74 / Re ** 0.9) ** 2


def run(td, L_mm, dp_kPa, p_cons_MPa, t0_dzv_C, heater_K, par=None, n=80, iters=30):
    par = dict(PAR, **(par or {}))
    L = L_mm * 1e-3
    r_eq, gap = cell(td)
    T0s = t0_dzv_C + heater_K + 273.15
    T0d = t0_dzv_C + 273.15
    tb = table(int(round(T0s * 10)))
    G = par['Cd'] * math.pi * R_THROAT ** 2 * tb['flux'][tb['it']]
    # --- ДЗВ
    Ad = math.pi * (r_eq ** 2 - R_O ** 2)
    Dh = 2 * gap
    dp = dp_kPa * 1e3
    pdz = P0 - dp
    rho_d = PropsSI('Dmass', 'P', pdz, 'T', T0d, FLUID)
    mu_d = PropsSI('viscosity', 'P', pdz, 'T', T0d, FLUID)
    k_d = PropsSI('conductivity', 'P', pdz, 'T', T0d, FLUID)
    cp_d = PropsSI('Cpmass', 'P', pdz, 'T', T0d, FLUID)
    Gd = 0.01
    for _ in range(80):
        Re = Gd * Dh / (Ad * mu_d)
        Gn = Ad * math.sqrt(2 * rho_d * dp / (friction(Re) * L / Dh + par['K_loc']))
        if abs(Gn - Gd) < 1e-10:
            break
        Gd = 0.5 * (Gd + Gn)
    Red = Gd * Dh / (Ad * mu_d)
    hd = par['K_dzv'] * 0.023 * max(Red, 2300) ** 0.8 * (cp_d * mu_d / k_d) ** 0.4 * k_d / Dh
    # --- СВЗ: ядро (не зависит от q в этом приближении) — π0 по Фанно, состояния по длине
    dx = L / n
    xm = (np.arange(n) + 0.5) * dx
    r_in = R_EXIT + (R_END - R_EXIT) * xm / L
    pi0, choked, st = 1.0, False, []
    for i in range(n):
        A = math.pi * r_in[i] ** 2
        s = sup_state(tb, G / (A * pi0))
        if s is None:
            choked = True
            s = st[-1] if st else sup_state(tb, tb['flux'][tb['it']] * 0.999)
        s = dict(s, p=s['p'] * pi0, rho=s['rho'] * pi0)
        mu = PropsSI('viscosity', 'P', max(s['p'], 1e4), 'T', max(s['T'], 92.0), FLUID)
        kk = PropsSI('conductivity', 'P', max(s['p'], 1e4), 'T', max(s['T'], 92.0), FLUID)
        D = 2 * r_in[i]
        s['Re'] = s['rho'] * s['u'] * D / mu
        s['hs'] = par['K_svz'] * 0.023 * s['Re'] ** 0.8 * (s['cp'] * mu / kk) ** 0.4 * kk / D
        s['Taw'] = s['T'] + par['r'] * s['u'] ** 2 / (2 * s['cp'])
        M = s['u'] / s['a']
        st.append(s)
        pi0 *= math.exp(-par['K_f'] * s['g'] * M * M / 2 * friction(s['Re']) * dx / D)
    Rth = np.array([1 / (s['hs'] * 2 * math.pi * r) + math.log(R_O / r) / (2 * math.pi * K_WALL) + 1 / (hd * 2 * math.pi * R_O)
                    for s, r in zip(st, r_in)])
    Taw = np.array([s['Taw'] for s in st])
    # --- противоток: ДЗВ входит при x = L
    Tdz = np.full(n, T0d)
    for _ in range(iters):
        q = (Tdz - Taw) / Rth
        Tn = np.empty(n)
        Tc = T0d
        for i in range(n - 1, -1, -1):
            Tn[i] = Tc - q[i] * dx / (2 * Gd * cp_d)
            Tc -= q[i] * dx / (Gd * cp_d)
        if np.max(np.abs(Tn - Tdz)) < 1e-5:
            Tdz = Tn
            break
        Tdz = 0.5 * Tdz + 0.5 * Tn
    q = (Tdz - Taw) / Rth
    Q = float(q.sum() * dx)
    e = st[-1]
    Me = e['u'] / e['a']
    p2 = e['p'] * (1 + 2 * e['g'] / (e['g'] + 1) * (Me * Me - 1)) if Me > 1 else e['p']
    working = (not choked) and (p_cons_MPa * 1e6 <= par['K_shock'] * p2)
    pc = p_cons_MPa * 1e6
    T_thr = PropsSI('T', 'P', pc, 'H', tb['h0'], FLUID)
    T_hot = PropsSI('T', 'P', pc, 'H', tb['h0'] + Q / G, FLUID)
    hd0 = PropsSI('Hmass', 'P', pdz, 'T', T0d, FLUID)
    T_dzv_out = PropsSI('T', 'P', pdz, 'H', hd0 - Q / Gd, FLUID)
    return dict(G_svz=G, G_dzv=Gd, m=Gd / G, Q=Q, effect_K=T_hot - T_thr, dT_dzv_K=T_dzv_out - T0d, M_exit=Me,
                p_exit_MPa=e['p'] / 1e6, p_shock_MPa=p2 / 1e6, working=int(working), choked=int(choked))


if __name__ == '__main__':
    import time
    t = time.time()
    print(run(1.2, 660, 105.08, 0.709, -8.86, 1.74))   # A8C1: CFD +7,29 K, m 0,962, Q 2784 Вт
    print(run(1.4, 400, 0.5, 0.3, 15.0, 0.0))           # пилот d: CFD +1,44 K, m 0,155, Q 510 Вт
    print(f'{time.time() - t:.1f} s')

