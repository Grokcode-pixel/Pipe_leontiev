"""Build a ready-to-run Fluent case (interfaces, settings, initial field) from an exported Meshing .msh.

Reproduces the verified chain used for G2/G3/G4:
 raw -> contact_region-src wall->interior + one-to-one pairing -> rename + read-settings ->
 create thermal interfaces -> rename gas/solid wall zones -> hybrid init + interpolate from a reference solution.
Zone IDs (31,34,37,38 / 17,22,31,32) were identical for all meshes of this topology; the
function verifies that and raises if the topology changed.
"""
import re, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import leontiev_pipeline as L

SETTINGS = Path(r'F:\Leontiev_Project\runs\grs_g3\boundary_settings.set')
REF_IP = {  # interpolation files of the reference (converged) solution
    8: r'F:\Leontiev_Project\runs\grs_g4\g4_svz.ip',
    7: r'F:\Leontiev_Project\runs\grs_g4\g4_dzv.ip',
    6: r'F:\Leontiev_Project\runs\grs_g4\g4_wall.ip'}


def jou(path, lines):
    Path(path).write_text('\n'.join(lines) + '\n', encoding='utf-8')


def build(msh, outdir, p0_svz_MPa=1.6, interpolate=True):
    out = Path(outdir); out.mkdir(parents=True, exist_ok=True)
    o = L.fl(out)
    (out / 'boundary_settings.set').write_bytes(SETTINGS.read_bytes())
    jou(out / 's1_raw.jou', [
        '/file/confirm-overwrite? no', f'/file/start-transcript "{o}/s1_raw.trn"', f'/file/read-case "{L.fl(msh)}"',
        '/define/models/axisymmetric yes', '/define/boundary-conditions/list-zones', '/mesh/check', '/mesh/quality',
        f'/file/write-case "{o}/raw.cas.h5"', '/file/stop-transcript', '/exit yes'])
    jou(out / 's2_interfaces.jou', [
        f'/file/start-transcript "{o}/s2.trn"', f'/file/read-case "{o}/raw.cas.h5"',
        '/mesh/modify-zones/zone-type contact_region-src wall', '/mesh/modify-zones/zone-type contact_region-src interior',
        '/define/mesh-interfaces/one-to-one-pairing? yes', 'yes', 'no',
        '/define/boundary-conditions/list-zones', '/mesh/check', '/mesh/quality',
        f'/file/write-case "{o}/interfaces.cas.h5"', '/file/stop-transcript', '/exit yes'])
    jou(out / 's3_setup.jou', [
        f'/file/start-transcript "{o}/s3.trn"', f'/file/read-case "{o}/interfaces.cas.h5"',
        '/mesh/modify-zones/zone-name 31 wall-air_svz-wall_abonite', '/mesh/modify-zones/zone-name 34 wall-air_svz-wall_abonite-shadow',
        '/mesh/modify-zones/zone-name 38 interior-air_dzv-wall_abonite', '/mesh/modify-zones/zone-name 37 interior-air_dzv-wall_abonite-shadow',
        '/mesh/modify-zones/zone-type inlet_svz pressure-inlet', '/mesh/modify-zones/zone-type inlet_dzv pressure-inlet',
        f'/file/read-settings "{o}/boundary_settings.set"',
        "(rpsetvar 'keprt 0.75)", "(rpsetvar 'wallprt 0.75)", "(rpsetvar 'viscous-energy-dissipation? #t)",
        "(rpsetvar 'report/energy-flux/include-viscous-work? #t)", '/solve/set/p-v-coupling 20',
        '/solve/set/pseudo-time-method/formulation 0', '/solve/set/poor-mesh-numerics/orthogonality-enhancing-cell-centroids? yes 0.1',
        "(rpsetvar 'pressure/relax 0.2)", "(rpsetvar 'mom/relax 0.3)", "(rpsetvar 'k/relax 0.3)", "(rpsetvar 'omega/relax 0.3)",
        "(rpsetvar 'temperature/relax 0.9)", "(rpsetvar 'mom/scheme 1)", "(rpsetvar 'temperature/scheme 1)",
        "(rpsetvar 'k/scheme 1)", "(rpsetvar 'omega/scheme 1)", "(rpsetvar 'temperature/amg-alpha 0.001)",
        "(rpsetvar 'amg-scalar/max-cycles 100)", '/define/boundary-conditions/list-zones', '/define/mesh-interfaces/list',
        '/mesh/check', f'/file/write-case "{o}/configured.cas.h5"', '/file/stop-transcript', '/exit yes'])
    jou(out / 's4_contacts.jou', [
        f'/file/start-transcript "{o}/s4.trn"', f'/file/read-case "{o}/configured.cas.h5"',
        '/define/mesh-interfaces/create grs_native', 'yes', 'no', '/define/mesh-interfaces/list',
        '/define/boundary-conditions/list-zones', '/mesh/check', f'/file/write-case "{o}/contacts_repaired.cas.h5"',
        '/file/stop-transcript', '/exit yes'])
    init = ['/file/confirm-overwrite? no', f'/file/start-transcript "{o}/s5.trn"', f'/file/read-case "{o}/contacts_repaired.cas.h5"',
            # by zone NAME: the ids differ between variants (17/32/31/22 for G4, 19/35/34/24 for z28)
            '/mesh/modify-zones/zone-name grs_native:02:wall-air_svz-wall_abonite::wall-air_svz-wall_abonite wall-air_svz-wall_abonite',
            '/mesh/modify-zones/zone-name grs_native:02:wall-air_svz-wall_abonite::wall-air_svz-wall_abonite-shadow wall-air_svz-wall_abonite-shadow',
            '/mesh/modify-zones/zone-name grs_native:01:interior-air_dzv-wall_abo::interior-air_dzv-wall_abo-shadow interior-air_dzv-wall_abonite',
            '/mesh/modify-zones/zone-name grs_native:01:interior-air_dzv-wall_abo::interior-air_dzv-wall_abo interior-air_dzv-wall_abonite-shadow',
            '/mesh/check', f'/file/write-case "{o}/configured_verified.cas.h5"', '/solve/initialize/hyb-initialization']
    if interpolate:
        for z, ip in REF_IP.items():
            init += [f'/file/interpolate/zone-selection {z} ()', f'/file/interpolate/read-data "{L.fl(ip)}"']
    init += [f'/define/named-expressions/edit inlet_svz definition "{p0_svz_MPa*1e6:.6g} [Pa]" q', '/define/named-expressions/compute inlet_svz',
             f'/file/write-case-data "{o}/initial.cas.h5"', '/file/stop-transcript', '/exit yes']
    jou(out / 's5_init.jou', init)
    for s in ('s1_raw', 's2_interfaces', 's3_setup', 's4_contacts', 's5_init'):
        for old in out.glob(s.split('_')[0] + '*.trn'):
            old.unlink()
        L.run_fluent(out / f'{s}.jou', threads=4)
    # verification of topology / interface coverage
    t4 = (out / 's4.trn').read_text(errors='replace')
    ids = {int(a) for a in re.findall(r'^\s+(\d+)\s+grs_native:0\d', t4, flags=re.M)}
    need = {17, 22, 31, 32}
    if ids != need:
        raise RuntimeError(f'interface zone ids changed: {sorted(ids)}')
    cov = re.findall(r'(\d+\.\d+)%', t4)
    return dict(initial_case=str(out / 'initial.cas.h5'), interface_percent=cov[:8])


if __name__ == '__main__':
    print(build(sys.argv[1], sys.argv[2]))
