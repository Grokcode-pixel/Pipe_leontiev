"""20.10.2026 — п. 3.3 плана 18.10: патенты, серия «двусторонняя накатка» RU 233137 (гипотеза / вариант конструкции X0,
не подтверждение). Накатка с обеих сторон стенки (ДЗВ — наружу в зазор, СВЗ — внутрь сверхзвукового канала), кольцевые
выступы в 2D вместо винта; h 0,5 и 1,0 мм, шаг 9 мм, ширина 3 мм (как прежняя накатка ДЗВ 13.10; размеров в патенте
для расчёта нет — подбор расчётом по решению автора). Геометрия v6 (geometry_script_v6.py, проверена на копии проекта).
2 базовые геометрии × одинаковые режимы (как гладкие точки А9, с которыми и сравниваем):
  Г1 t/d 1,4, L 400 (база А9 и шейки): A9_19 (p 0,59), A9_41 (0,96), A9_18 (1,44 — якорь серии шейки, скачок);
  Г2 t/d 1,2, L 660:                    A9_28 (0,56), A9_27 (0,96), A9_26 (1,53, скачок).
Первая точка варианта — шаблон новой геометрии + перенос поля гладкой точки того же режима, дальше — продолжение
по давлению потребителя (ступени 0,3 МПа). Осевой шаг сетки 0,5 мм (выступ 3 мм = 6 ячеек), остальное work_v2.
Предел 4000 итераций на точку. Пороги сходимости проекта не меняются. Итог: runs\\patents\\knurl_results.csv."""
import csv, json, re, shutil, subprocess, sys, time, traceback
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_a9 as A
import run_dataset as R

A9 = A.BASE
OUT = Path(r'F:\Leontiev_Project\runs\patents')
A.BASE, A.CSV, A.AUX = OUT, OUT / 'knurl_results.csv', OUT / 'knurl_aux.csv'
A.POINT_LIMIT = 4000
MAIN = Path(r'F:\Leontiev_Project\g_08_1.wbpj')
KN = {'dzv': None, 'svz': None, 'svz_x_mm': 9.0}
_orig = A.cell_params


def cell_params(*a, **k):
    p, cell = _orig(*a, **k)
    # 21.10: шаг/ширина — параметры (серия «шаг патента» S/D 0,72: шаг 4,75 мм, ширина 1,6 мм — та же доля 1/3, что 3/9)
    kn = lambda h, x=None: dict(h_mm=h, pitch_mm=KN.get('pitch', 9.0), width_mm=KN.get('width', 3.0),
                                x_first_mm=x if x is not None else KN.get('pitch', 9.0))
    if KN['dzv']:
        p.update(knurl_dzv=kn(KN['dzv']))
    if KN['svz']:   # внутренние выступы — сетка с осевым шагом 0,5 мм; только наружные — сетка гладкой (как 13.10)
        p.update(knurl_svz=kn(KN['svz'], KN.get('svz_x_mm')), axial_size_mm=0.5)
    return p, cell


A.cell_params = cell_params


def P_alive(pid):
    out = subprocess.run(['tasklist', '/FI', f'PID eq {pid}', '/NH'], capture_output=True, text=True).stdout
    return str(pid) in out


def first_point(pt, smooth):
    """20.10 09:40: «с нуля» тоже не идёт — FMG-инициализация на сетке с выступами даёт NaN на 4-м уровне (K05_A9_19_ideal).
    Поэтому: шаблон новой геометрии + перенос поля гладкой точки того же режима, досчёт на ИДЕАЛЬНОМ метане до
    сходимости, затем реальный газ (ПР) — как transfer() в А9, но с промежуточной ступенью идеального газа."""
    import math
    G, L = A.G, A.L
    G.RUNS = A.BASE
    td, l_mm, tag = float(pt['t_d']), float(pt['L_mm']), pt['id']
    tpl = A.BASE / f'{tag}_tpl' / 'result.cas.h5'
    p, cell = cell_params(td, l_mm, f'{tag}_tpl', pt, 'ch4_ideal', 10, 10)
    if not tpl.exists():
        A.log(f'=== {tag}: шаблон геометрии с накаткой; перенос поля {smooth.name}, затем идеальный метан → ПР')
        G.run(p, lambda s: A.log('  ' + s), lambda: False)
    ip = A.BASE / 'ip' / f'{smooth.name}.ip'
    ip.parent.mkdir(exist_ok=True)
    if not tpl.exists() or not (ip.exists() or A.write_ip(smooth / 'result.cas.h5', ip)):
        A.log(f'  {tag}: нет шаблона или файла переноса'); return None
    reg = A.regime(pt)
    t0d, t0s = float(pt['t0_dzv']), float(pt['t0_svz'])
    area = math.pi * (cell['cell_r_eq_mm'] ** 2 - cell['cell_r_outer_mm'] ** 2) * 1e-6
    u = -float(pt['m_target']) * 0.162 / (42.0 * area)
    init = [f'/file/interpolate/read-data "{L.fl(ip)}"', f'/solve/patch air_dzv () pressure {reg[3] / A.ATM:.5f}',
            f'/solve/patch air_dzv () temperature {t0d:g}', f'/solve/patch air_dzv () x-velocity ok {u:.2f}',
            '/solve/patch air_dzv () y-velocity ok 0', '/solve/patch air_dzv () k 0.1', '/solve/patch air_dzv () omega 1000',
            f'/solve/patch wall_abonite () temperature {(t0d + t0s) / 2:g}']
    # 20.10 10:40: перенос поля оставляет нулевые T/p у входа СВЗ (66 узлов) -> NaN; продолжение прямо от поля шаблона
    # (диагностика K05_A9_19_tplcont) живёт — используем его, перенос не нужен
    diag = A.BASE / f'{tag}_tplcont'
    ideal = diag if A.ok(diag) else A.cont(tpl, f'{tag}_tplcont', reg, [], t0s, t0d, 'от поля шаблона; идеальный метан', A.AUX, l_mm=l_mm)
    # 11:25: за 1500 ит. от шаблона сопло ещё не запустилось (скачок x 0,005 м) — досчёт идеального метана до сходимости
    if ideal and not A.converged(ideal):
        d2 = A.BASE / f'{tag}_tplcont2'
        ideal = d2 if A.ok(d2) else A.cont(ideal / 'result.cas.h5', f'{tag}_tplcont2', reg, [], t0s, t0d,
                                           f'досчёт {ideal.name}; идеальный метан', A.AUX, l_mm=l_mm)
    if not ideal:
        return None
    return A.cont(ideal / 'result.cas.h5', tag, reg, list(L.CH4_PR_LINES), t0s, t0d, f'продолжение {ideal.name} (ПР)', A.CSV, l_mm=l_mm)
SERIES = (('Г1', ('A9_19', 'A9_41', 'A9_18')), ('Г2', ('A9_28', 'A9_27', 'A9_26')))
# 20.10 12:45, решение автора (вариант 2): внутренние выступы 0,5/1,0 мм запирают сверхзвуковой канал (1D Kantrowitz:
# предел сужения 0,774, h 0,5 даёт 0,720; CFD K05_A9_19 — незапущенный канал) -> снаружи 0,5 и 1,0 мм, внутри 0,25 мм.
# K05_A9_19 (0,5 с обеих сторон) оставлен как пример запирания.
# 20.10 17:05, решение автора (вариант 3): K0525_A9_19 тоже не запустился (скачок у первого внутреннего выступа) ->
# основная серия — только наружная накатка (ДЗВ) 0,5 и 1,0 мм против гладкой (перенос поля на сетку гладкой, как 13.10);
# плюс одна проба: внутренние 0,25 мм только во второй половине канала (с 200 мм от входа ДЗВ, канал шире).
# (dzv, svz, x первого внутреннего выступа, префикс, точки)
VARIANTS = ((0.5, None, 9.0, 'KD05', None), (1.0, None, 9.0, 'KD10', None), (0.5, 0.25, 200.0, 'KP0525', ('A9_19',)))


def install_v6():
    """Архив основного проекта и установка geometry_script_v6 (без опции knurl_svz геометрия = v5)."""
    arch = Path(r'F:\Leontiev_Project') / ('архив_проекта_' + time.strftime('%Y%m%d_%H%M'))
    arch.mkdir(exist_ok=True)
    shutil.copy2(MAIN, arch / MAIN.name)
    shutil.copy2(r'F:\Leontiev_Project\g_08_1_files\dp6\SYS-1\DM\SYS-1.scdoc', arch / 'SYS-1.scdoc')
    cfg = Path(r'F:\Leontiev_Project\dataset\wb\install_config.json')
    res = Path(r'F:\Leontiev_Project\geometry_v6_install.json')
    cfg.write_text(json.dumps({'script': r'F:\Leontiev_Project\geometry_script_v6.py', 'marker': 'knurl_svz',
                               'save_path': r'F:\Leontiev_Project\g_08_1_files\dp6\SYS-1\DM\SYS-1.scdoc', 'result': str(res)}))
    for f in (res, Path(str(res) + '.wb.json')):
        if f.exists():
            f.unlink()
    lock = Path(r'F:\Leontiev_Project\g_08_1_files\.lock')
    if lock.exists():
        lock.unlink()
    subprocess.Popen([R.RUNWB, '-F', str(MAIN), '-R', r'F:\Leontiev_Project\dataset\wb\wb_install_geometry.wbjn'])
    t0 = time.time()
    while not Path(str(res) + '.wb.json').exists() and time.time() - t0 < 600:
        time.sleep(5)
    time.sleep(5)
    for name in ('AnsysFWW.exe', 'AnsysWBU.exe', 'SpaceClaim.exe'):
        subprocess.run(['taskkill', '/F', '/IM', name], capture_output=True)
    txt = Path(str(res) + '.wb.json').read_text() if Path(str(res) + '.wb.json').exists() else 'no result'
    A.log(f'=== установка скрипта геометрии v6 (двусторонняя накатка) в основной проект; архив {arch.name}; результат: {txt[:200]}')
    try:
        return bool(json.loads(txt).get('passed'))
    except Exception:
        return False


if __name__ == '__main__':
    OUT.mkdir(parents=True, exist_ok=True)
    A.qlog('=== п. 3.3: двусторонняя накатка — начат')
    flag = OUT / 'v6_installed.txt'
    if not flag.exists():
        if not install_v6():
            A.log('  установка v6 не подтверждена — серия не запущена'); A.qlog('=== п. 3.3: накатка — остановлен (установка)')
            sys.exit(1)
        flag.write_text(time.strftime('%d.%m.%Y %H:%M'))
    design = {p['id']: p for p in csv.DictReader(open(A9 / 'a9_design.csv', encoding='utf-8'))}
    old = int(sys.argv[1]) if len(sys.argv) > 1 else 0   # pid старого раннера: дождаться K05_A9_19 и остановить его
    if old:
        logf = OUT / 'a9_log.txt'
        while True:
            txt = logf.read_text(encoding='utf-8', errors='ignore')
            if re.search(r'K05_A9_19: (готово|НЕТ РЕЗУЛЬТАТА)', txt) or not P_alive(old):
                break
            time.sleep(60)
        t_stop = time.time() - 90   # проверка раз в минуту: следующий Fluent старого раннера мог стартовать до обнаружения
        subprocess.run(['taskkill', '/F', '/T', '/PID', str(old)], capture_output=True)
        time.sleep(20)
        A.G.kill_since(t_stop)   # Fluent, запущенный старым раннером после K05_A9_19 (если успел)
        A.log('=== старый раннер (обе стороны 0,5/1,0) остановлен после K05_A9_19 — серия по решению автора: внутри 0,25 мм')
    for h, hs, xs, pre, only in VARIANTS:
        KN['dzv'], KN['svz'], KN['svz_x_mm'] = h, hs, xs
        for geo, ids in SERIES:
            ids = [i for i in ids if not only or i in only]
            if not ids:
                continue
            pts = [dict(design[i], id=f'{pre}_{i}', src=i) for i in ids]
            pts.sort(key=lambda q: float(q['p_cons']))
            t0 = time.time()
            try:
                first = pts[0]
                done = A.done_dir(first['id'])
                if not done:
                    # 20.10 08:45: перенос поля гладкой трубы сразу на реальный газ расходился за 15–20 итераций (за выступами
                    # в сверхзвуке T ниже спинодали ПР) — неудачные папки в runs\patents\перенос_поля_сбой_20261020;
                    # первая точка — с нуля: идеальный метан до сходимости, затем ПР (как новые геометрии А9)
                    A.log(f"=== накатка ДЗВ {h} / СВЗ {hs} мм, {geo} (t/d {first['t_d']}, L {first['L_mm']}): первая точка {first['id']}")
                    sid = first['src']
                    smooth = next((A9 / t for t in (sid + 'ch', sid + 'c', sid + 'h', sid) if (A9 / t / 'result.cas.h5').exists()), None)
                    done = None
                    if smooth and not hs:   # только наружная накатка: перенос поля гладкой (проверен 13.10)
                        done = A.transfer(smooth, first)
                    if smooth and not done:
                        done = first_point(first, smooth)
                    A.log(f"  {first['id']}: {'готово' if done else 'НЕТ РЕЗУЛЬТАТА'} за {(time.time() - t0) / 3600:.1f} ч")
                if done:
                    A.run_geometry(pts[1:], done, float(first['p_cons']))
            except Exception:
                A.log(f'накатка h {h}, {geo}: ОШИБКА программы: ' + traceback.format_exc())
    A.qlog('=== п. 3.3: двусторонняя накатка — закончен')
