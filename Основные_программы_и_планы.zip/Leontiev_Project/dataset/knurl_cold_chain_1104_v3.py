"""One registered unseen-shape cold pilot: fresh CAD/mesh, final v10 template, PR ramp.
No existing physical field, no retries, no frozen-dataset writes.
"""
import hashlib,json,math,re,shutil,subprocess,sys,time,traceback
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent;sys.path.insert(0,str(D))
import knurl_grid_1103_v8 as V
import build_knurl_case_1104_v10 as B
import leontiev_pipeline as L
import gui_runner as G
import gui_convergence as C
import single_writer_d12a_1103_v1 as STOP
import cont_util as U
CONSERVATIVE_STEP='/solve/set/pseudo-time-method/global-time-step-settings yes 1 1 yes 1'
if CONSERVATIVE_STEP not in L.SOLVER_HEADER:L.SOLVER_HEADER=list(L.SOLVER_HEADER)+[CONSERVATIVE_STEP]
P=R/'runs/plans/cold_pilot_1104_v3.json';OUT=R/'runs/cold_pilot_1104_v3'
sha=V.sha;save=V.save;load=V.load;now=V.now
def registered():
    if sha(P)!=P.with_suffix('.sha256').read_text().strip():raise RuntimeError('Pilot plan hash changed')
    p=load(P)
    for f,h in p['protected'].items():
        if sha(f)!=h:raise RuntimeError('Protected pilot source changed: '+f)
    return p

def check_journal(text,p):
    q=p['params'];n=sum(map(int,re.findall(r'/solve/iterate (\d+)',text)))
    if n!=p['total_iterations'] or G.max_total_iter(q)!=n:raise RuntimeError('Cold iteration schedule mismatch')
    if any(x in text.lower() for x in ('read-case-data','/file/read-data','/file/interpolate','fmg-initialization','ch4_ideal')):raise RuntimeError('Forbidden field transfer/startup')
    if text.count('/solve/initialize/hyb-initialization')!=1:raise RuntimeError('Need one own hybrid cold initialization')
    if text.index('real-gas-peng-robinson')>text.index('/solve/initialize/hyb-initialization'):raise RuntimeError('PR must precede own cold initialization')
    for block in ('mom','temperature','k','omega'):
        if "(rpsetvar '"+block+"/scheme 1)" not in text:raise RuntimeError('Missing final second order')
    if int(q['coupled_iters'])%int(q['report_every']):raise RuntimeError('Incomplete final report block')
    if (int(q['coupled_iters'])//int(q['report_every']))<4:raise RuntimeError('Too few final reports for two full windows')
    return dict(iterations=n,ramp_iterations=q['startup_iters'],coupled_iterations=q['coupled_iters'],source_field=None,PR_before_initialization=True)

def mesh_gate(p):
    V.idle();variant=Path(p['variant']);copy=Path(p['work_copy']);ref=Path(p['reference'])
    if variant.exists() or copy.exists():raise RuntimeError('Fresh isolated paths required; no repeated mesh attempt')
    copy.mkdir();shutil.copy2(ref/'g_08_1.wbpj',copy/'g_08_1.wbpj')
    shutil.copytree(ref/'g_08_1_files',copy/'g_08_1_files',ignore=shutil.ignore_patterns('.lock'))
    save(copy/'geometry_options.json',p['geometry_options']);variant.mkdir()
    save(OUT/'state.json',dict(time=now(),phase='mesh',tag=p['params']['run_id'],iterations=0))
    # -X runs the registered GUI macro and exits normally after it completes.
    # No taskkill, shared scratch deletion, global current_variant or reference save.
    with (OUT/'workbench_stdout.txt').open('wb') as f:
        process=subprocess.Popen([r'C:\Program Files\ANSYS Inc\v242\Framework\bin\Win64\RunWB2.exe','-F',str(copy/'g_08_1.wbpj'),'-R',p['macro'],'-X'],stdout=f,stderr=subprocess.STDOUT,cwd=OUT)
        save(OUT/'workbench_launch.json',dict(time=now(),pid=process.pid,work_copy=str(copy)))
        process.wait(timeout=p['mesh_timeout_seconds'])
    # Give owned native children a short normal shutdown interval; never start a
    # Fluent while an application remains. A timeout preserves everything.
    for unused in range(30):
        try:V.idle();break
        except RuntimeError:time.sleep(2)
    V.idle();registered()
    detail=load(variant/'mesh_result.json');wb=load(variant/'mesh_result.json.wb.json')
    if not detail.get('passed') or not wb.get('passed'):raise RuntimeError('Geometry/mesh native gate failed')
    actual=load(copy/'geometry_options_used.json')
    wanted=p['geometry_options']
    for k in ('knurl_dzv','knurl_svz','dzv_counterflow','l_cone_mm'):
        if actual.get(k)!=wanted.get(k):raise RuntimeError('Actual generated geometry differs: '+k)
    save(variant/'geometry_options_used.json',actual)
    if detail.get('geometry_options_used')!=actual:raise RuntimeError('Native mesh used different CAD options')
    if len(detail.get('bodies_after_mesh',[]))!=3 or any(x.get('ObjectState')!='Meshed' or int(x.get('Elements',0))<=0 for x in detail['bodies_after_mesh']):raise RuntimeError('Incomplete fresh mesh')
    if detail.get('messages_after_mesh') or detail.get('bodies_without_elements'):raise RuntimeError('Native meshing messages/empty body')
    from mesh_m12 import bindings_ok
    if not bindings_ok(detail)['ok'] or detail.get('contact_regions_count')!=2:raise RuntimeError('Named selections/contact gate failed')
    msh=variant/'mesh.msh';cells=G.verify_mesh(p['params'],msh)
    if not 0<cells<=p['max_cells']:raise RuntimeError('Cell count outside registered limit')
    save(OUT/'mesh_gate.json',dict(time=now(),passed=True,cells=cells,mesh_sha256=sha(msh),options=actual,workbench=wb,detail=detail))
    return msh,cells

def accepted_convergence(folder):
    f=Path(folder)/'convergence.json';c=load(f) if f.exists() else {}
    if c.get('stop_basis')=='D48' and c.get('stop_requested') and c.get('d48',{}).get('ready'):return True
    return ORIGINAL_CONVERGED(folder)
ORIGINAL_CONVERGED=G.converged

def run():
    p=registered();V.idle();OUT.mkdir(parents=True,exist_ok=True)
    if (OUT/'attempt.json').exists():raise RuntimeError('One cold physical attempt only; no repeat')
    save(OUT/'attempt.json',dict(time=now(),plan_sha256=sha(P),source_field=None))
    try:
        msh,cells=mesh_gate(p);registered();q=p['params'];target=OUT/q['run_id']
        save(OUT/'state.json',dict(time=now(),phase='native_template',tag=q['run_id'],source_field=None))
        built=B.build(msh,target,p0_svz_MPa=q['p0_svz_MPa'],interpolate=False);V.idle()
        if built['final_quality']['native_warning_below_001']:raise RuntimeError('Final native low-quality warning; stop before CFD')
        save(OUT/'template_gate.json',dict(time=now(),passed=True,template=built))
        save(target/'params.json',q)
        jou=G.journal(q,target);save(OUT/'journal_check.json',check_journal(jou.read_text(encoding='utf-8'),p))
        registered();V.idle()
        G.RUNS=OUT;G.CSV=OUT/'runner_results.csv';G.converged=accepted_convergence
        old_update=STOP.install(p['regime']);started=time.monotonic();last_progress=[started,-1];stop_reason=[None]
        def stop_flag():
            if time.monotonic()-started>p['time_limit_h']*3600:stop_reason[0]='8h CFD limit';return True
            st=G.status(target) or {};it=int(st.get('iter') or 0)
            if it>last_progress[1]:last_progress[:]=[time.monotonic(),it]
            if time.monotonic()-last_progress[0]>40*60:stop_reason[0]='No real iteration progress for40min';return True
            return False
        save(OUT/'state.json',dict(time=now(),phase='cfd',tag=q['run_id'],source_field=None,stop_policy='single writer D48 OR strict; unchanged D12a',max_total_iterations=p['total_iterations']))
        try:G.run(q,lambda s:print(now(),s,flush=True),stop_flag)
        finally:C.update_control=old_update
        V.idle();minutes=(time.monotonic()-started)/60;registered()
        U.record(OUT/'physical_results.csv',q['run_id'],'new cold geometry','ch4_pr',p['pressures'],target,minutes,lambda s:print(now(),s,flush=True),start='new geometry; own cold PR field; zero interpolation',t0_C=p['regime']['T0_svz'],t0_dzv_C=p['regime']['T0_dzv'])
        e=V.evaluate(target);rows=C.closed_samples(target);full=STOP.evaluate(rows,p['regime'])
        e.update(minutes=minutes,cells=cells,mesh_sha256=sha(msh),source_field=None,independent_full_window=full,stop_reason=stop_reason[0],final_quality=built['final_quality'],coverage=built['interface_percent'])
        e['accepted']=bool(e['accepted'] and full.get('accepted') and not stop_reason[0])
        save(OUT/'results.json',e);save(OUT/'summary.json',dict(time=now(),accepted=e['accepted'],physical=e['physical'],cold_pilot_only=True,source_field=None,minutes=minutes,limitation=p['limitation']))
        lines=['# Один пилот новой формы с нуля','',now(),'','Высота0,22мм / шаг3,1мм / ширина1,03333мм; перепадДЗВ19,4кПа.','',
          'Численно принято: '+str(e['accepted'])+'; физический статус: '+str(e['physical'])+'; CFDминут: '+str(round(minutes,1)),
          '',json.dumps(e,ensure_ascii=False,indent=2,default=float),'',p['limitation']]
        (OUT/'report_ru.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        if not e['accepted']:raise RuntimeError('Cold physical pilot not accepted; no repeats or changed settings')
        save(OUT/'finished.json',dict(time=now(),accepted=True));print(str(OUT/'report_ru.md'),flush=True)
    except Exception as e:
        save(OUT/'BLOCK.json',dict(time=now(),error=repr(e),traceback=traceback.format_exc(),no_retry=True));raise
    finally:G.converged=ORIGINAL_CONVERGED
if __name__=='__main__':
    if sys.argv[1:] == ['check']:print('CHECK OK',registered()['total_iterations'],'iterations;one cold point;no native launch')
    elif sys.argv[1:] == ['run']:run()
    else:raise SystemExit('check|run')
