"""Registered three-level mesh sensitivity check; one attempt per new mesh/point.
No changes to existing code, frozen smooth cases, or the running night series.
v6 (03.11.2026, D-47, решение автора «проверять балансом тепла»): как v4 (G0 = принятая W1 550 119 яч.; G1 = исправленная
нативно сетка 735 446 яч.; G2 строится тем же рецептом), но сборка Fluent — по ролям зон (build_knurl_case_1103_v6), покрытие
стыка газ–стенка только записывается; допуск стыка — баланс энергии полного окна D-12a (< 1 % Q, порог прежний), отдельно в отчёте.
"""
import hashlib
import json
import math
import subprocess
import sys
import traceback
from pathlib import Path

ROOT = Path(r'F:\Leontiev_Project')
D = ROOT / 'dataset'
OUT = ROOT / 'runs' / 'grid_1103_v8'
PLAN = ROOT / 'runs' / 'plans' / 'проверка_сетки_1103_v8.json'
# v8 (03.11.2026): J0048/v7 остановилась ДО итераций на проверке переноса: при 6 процессах Fluent не задал вопрос
# «discard data?», и «ok» прочиталось как имя файла. Теперь после каждого чтения поле сохраняется (write-data во временный
# файл) — вопрос не возникает ни при каком числе процессов (проверено 03.11 при 6 процессах, runs\grid_1103_v7_prep\import4.trn).
# v7 (03.11.2026): J0047/v6 разошлась на итерации 29 — перенос поля W1 сопоставлял зоны по НОМЕРАМ, а у новой сетки номера
# другие (G1: air_dzv = 7, у W1 под 7 — стенка) → в ДЗВ попало поле стенки (давление 0 в 41 тыс. ячеек). Теперь поле переносится
# по каждой зоне отдельно и по ИМЕНИ (air_svz, air_dzv, wall_abonite), а перед расчётом проверяется (transfer_gate).
ZONES = ('air_svz', 'air_dzv', 'wall_abonite')
sys.path.insert(0, str(D))


def now():
    return subprocess.check_output(['powershell', '-NoProfile', '-Command', 'Get-Date -Format o'], text=True).strip()


def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest().upper()


def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def save(p, value):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=float), encoding='utf-8')
    tmp.replace(p)


def idle():
    names = subprocess.check_output(['powershell', '-NoProfile', '-Command',
        "Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object { $_.Name -in @('cx2420.exe','fl_mpi2420.exe','RunWB2.exe','AnsysWBU.exe','AnsysFWW.exe','SpaceClaim.exe') } | Select-Object -ExpandProperty Name"],
        text=True).strip()
    if names:
        raise RuntimeError('Другой Fluent/Workbench ещё работает: ' + names)


def registered():
    if sha(PLAN) != PLAN.with_suffix('.sha256').read_text().strip():
        raise RuntimeError('План изменён')
    p = load(PLAN)
    for path, expected in {**p['code_sha256'], **p['source_sha256']}.items():
        if sha(path) != expected:
            raise RuntimeError('Изменён зарегистрированный файл: ' + path)
    return p


def evaluate(folder):
    import d12a
    import gui_runner as G
    e = d12a.evaluate(folder)
    span = e.get('it', [0, 0])
    full = span[1] - span[0] >= 1000 and e.get('n', 0) >= 3
    files = all((Path(folder) / name).is_file() and (Path(folder) / name).stat().st_size > 0
                for name in ('result.cas.h5', 'result.dat.h5', 'axis.csv'))
    st = G.status(folder) or {}
    e.update(full_window=full, files_complete=files, accepted=bool(e.get('ok') and full and files
             and not st.get('fpe') and not st.get('error')))
    e['physical'] = G.classify(Path(folder), {'l_heat_mm': 400.0}, G.converged(folder))
    samples = st.get('samples') or []
    e['yplus'] = {k: samples[-1].get(k) if samples else None for k in ('yp_svz', 'yp_dzv')}
    return e


def make_plan():
    import run_dataset as RD
    if PLAN.exists():
        raise RuntimeError('План уже существует; не перезаписываю')
    src = ROOT / 'runs' / 'knurl_cont' / 'W1'
    params_file = ROOT / 'runs' / 'patents' / 'KM01_A9_19_tpl' / 'params.json'
    base = load(params_file)
    levels = []
    for name, r in [('G1', math.sqrt(2)), ('G2', 2.0)]:
        q = dict(base, run_id=f'GRID1103v8_{name}', p_out_dzv_MPa=5.4811, gas='ch4_pr',
                 retries=0, threads=6, startup_iters=0, coupled_iters=0, mesh_custom=True)
        for k in ('axial_size_mm', 'global_size_mm', 'dzv_h1_mm'):
            q[k] = base[k] / r
        for k in ('convergent_div', 'nozzle_div', 'core_div'):
            q[k] = int(math.ceil(base[k] * r))
        q['layer_div']=2  # Original CAD strip subdivisions;3/4 failed four thin mapped faces.
        # Keep DZV inflation envelope approximately fixed with the existing growth ratio 1.2.
        thick = base['dzv_h1_mm'] * (1.2 ** base['dzv_layers'] - 1) / 0.2
        q['dzv_layers'] = int(math.ceil(math.log(1 + 0.2 * thick / q['dzv_h1_mm'], 1.2)))
        levels.append(dict(tag=name, factor=r, params=q))
    files = [src / 'result.cas.h5', src / 'result.dat.h5', src / 'axis.csv', params_file,
             D / 'variants' / base['run_id'] / 'mesh.msh', Path(RD.REFERENCE),
             ROOT / 'runs' / 'grs_g3' / 'boundary_settings.set']
    prebuilt=ROOT/'runs/grid_ui_20261103_112346'
    files += [prebuilt/n for n in ('mesh_real.msh','mesh_real.json','mesh_real.json.wb.json','geometry_options_real.json')]
    files += [ROOT/'geometry_script_v6.py']
    files += [f for f in (Path(RD.REFERENCE).parent / 'g_08_1_files').rglob('*') if f.is_file() and f.suffix != '.lock']
    code = sorted(list(D.glob('*.py')) + list(D.glob('*.wbjn')))
    p = dict(name=PLAN.stem, made=now(), authorization='Автор 03.11: поставить проверку сетки после ночной серии; 03.11 ≈14:20 — «Проверять балансом тепла» (D-47)',
        replaces='J0047/v6: G1 разошлась на итерации 29 — перенос поля по номерам зон (у G1 air_dzv = 7, у W1 под 7 стенка). '
                 'J0048/v7: остановлена проверкой переноса до итераций (лишний ответ «ok» при 6 процессах). '
                 'v8: перенос по зонам и по именам с сохранением поля после каждого чтения + проверка поля до итераций (давление ±1 %, средняя T ±1 K). '
                 'Остальное как v6: сборщик по ролям зон; покрытие стыка — в отчёт, допуск стыка — баланс энергии D-12a (D-47). Numerical criteria unchanged.',
        prebuilt_G1=dict(folder=str(prebuilt),mesh='mesh_real.msh',detail='mesh_real.json',wb='mesh_real.json.wb.json',options='geometry_options_real.json'),
        mesh_recipe=dict(strip_divisions=2,pinch_m=1e-8,curvature_min_m=1e-8,constrain_boundary=True,limitation='Spatial refinement with fixed SVZ CAD strip subdivisions; not uniform refinement/GCI'),
        base_folder=str(src), base_params=str(params_file), levels=levels,
        regime=[5.5, 0.59, 5.5, 5.4811], T0_svz=13.46, T0_dzv=8.63, wall_k=110.0,
        method='Одна геометрия h0.1/s2/w0.67/L400/t_d1.4. Исходная сетка W1 + две пространственно более мелкие. '
               'Перенос только собственного поля W1 на ту же геометрию, без подстановки нового поля ДЗВ; '
               'пустой шаблон инициализируется без итераций. Все измеряемые итерации: метан ПР, второй порядок, CFL20, шаг как W.',
        limit=6000, time_limit_h=8, nproc=6, max_cells=3000000,
        acceptance='Полное окно1000 (минимум3отчёта), D-12a без изменения порогов; case/data/axis; отсутствие FPE/ошибок. '
                   'Обратный ток и y+ сообщать отдельно; это не подтверждает рабочий режим.',
        comparison=dict(effect_K=0.1, Q_pct=2.0, G_svz_pct=2.0, G_dzv_pct=2.0),
        conclusion='Сопоставить все три пары и рост числа ячеек. Совпадение означает локальную нечувствительность '
                   'этого режима в проверенном диапазоне, не глобальную независимость всех форм; GCI без доказанного асимптотического режима не объявлять.',
        gate='Полные тела/зоны, верные параметры, ровно2 непустых контакта и непустые named selections; '
             'ошибки/предупреждения о провале inflation блокируют CFD. Покрытие стыка газ–стенка записывается (interface_audit.json), '
             'допуск стыка — средний дисбаланс энергии полного окна D-12a < 1 % Q (решение автора 03.11, D-47). '
             'Первый отказ останавливает этап, без повтора и ослабления критериев.',
        interface_rule='report_only; energy imbalance of full D-12a window < 1 % Q is the interface acceptance',
        code_sha256={str(f): sha(f) for f in code}, source_sha256={str(f): sha(f) for f in files})
    p['base_evaluation'] = evaluate(src)
    if not p['base_evaluation']['accepted']:
        raise RuntimeError('Опора W1 не прошла полное окно D-12a')
    save(PLAN, p)
    PLAN.with_suffix('.sha256').write_text(sha(PLAN), encoding='ascii')
    print(sha(PLAN), flush=True)


def checked_session(jou, **kwargs):
    import leontiev_pipeline as L
    idle()
    if not ORIGINAL_RUN(jou, threads=6, timeout=900):
        raise RuntimeError('Служебная сессия Fluent не завершилась: ' + str(jou))
    idle()


def mesh_gate(q, plan):
    import gui_runner as G
    import run_dataset as RD
    idle()
    # RD.fresh_copy recreates only this fixed scratch directory; reject links/other targets.
    if RD.WORK.resolve() != Path(r'F:\Leontiev_wb_work') or RD.WORK.is_symlink():
        raise RuntimeError('Небезопасный путь рабочей копии Workbench')
    variant = D / 'variants' / q['run_id']
    if variant.exists():
        raise RuntimeError('Папка сетки уже есть, повтор запрещён: ' + str(variant))
    RD.MACRO = str(D / 'wb_grid1103_v4.wbjn')   # рецепт v4 (полосы 2, Pinch/Curvature 1e-8, ConstrainBoundary)
    if plan.get('prebuilt_G1') and q['run_id'].endswith('_G1'):
        import shutil
        pre=plan['prebuilt_G1'];src=Path(pre['folder']);variant.mkdir(parents=True)
        for a,b in [(pre['mesh'],'mesh.msh'),(pre['detail'],'mesh_result.json'),(pre['wb'],'mesh_result.json.wb.json')]:shutil.copy2(src/a,variant/b)
        used=load(src/pre['options']);outcome=load(variant/'mesh_result.json')
    else:
        outcome = RD.build_mesh(G.mesh_spec(q), timeout=1500)
        used=load(RD.WORK/'geometry_options_used.json')
        save(variant/'geometry_options_used.json',used)
    wanted=q.get('knurl_dzv') or {}
    actual=used.get('knurl_dzv') or {}
    if set(wanted)!=set(actual) or any(not math.isclose(float(v),float(actual[k]),rel_tol=1e-9,abs_tol=1e-9) for k,v in wanted.items()) or bool(used.get('dzv_counterflow'))!=bool(q.get('dzv_counterflow')):
        raise RuntimeError('Actual CAD geometry options differ from requested knurl/counterflow: '+str(used))
    msh = variant / 'mesh.msh'
    detail = load(variant / 'mesh_result.json')
    save(OUT / q['run_id'] / 'build_result.json', dict(result=outcome, detail=detail, time=now()))
    if not outcome or not outcome.get('passed'):
        raise RuntimeError('Построение сетки не прошло')
    cells = G.verify_mesh(q, msh)
    from mesh_m12 import bindings_ok
    bindings = bindings_ok(detail)
    messages = detail.get('messages_after_mesh', [])
    bad = [s for s in messages if any(t in str(s).lower() for t in
           ('failed', 'failure', 'error', 'exception', 'unable', 'не удалось', 'ошибк'))]
    if not bindings['ok'] or detail.get('bodies_without_elements') or bad:
        raise RuntimeError('Сетка не допущена к CFD: ' + str(dict(bindings=bindings, messages=bad,
                           empty_bodies=detail.get('bodies_without_elements'))))
    if not plan.get('min_cells',550119) < cells <= plan['max_cells']:
        raise RuntimeError('Число ячеек вне зарегистрированного диапазона: ' + str(cells))
    idle()
    return msh, cells


def field_report_lines():
    return ['/report/volume-integrals/minimum air_svz air_dzv () pressure no', '/report/volume-integrals/maximum air_svz air_dzv () pressure no',
            '/report/volume-integrals/volume-avg air_svz air_dzv wall_abonite () temperature no']


def field_report(text):
    """{(min|max|avg, зона): значение} из отчётов volume-integrals журнала."""
    import re
    out, kind = {}, None
    for line in text.splitlines():
        if 'volume-integrals/minimum' in line: kind = 'p_min'
        elif 'volume-integrals/maximum' in line: kind = 'p_max'
        elif 'volume-integrals/volume-avg' in line: kind = 'T_avg'
        m = re.match(r'^\s*(air_svz|air_dzv|wall_abonite)\s+([-+0-9.eE]+)\s*$', line)
        if kind and m:
            out[f'{kind}:{m[1]}'] = float(m[2])
    return out


def transfer_lines(ips, tag='x'):
    """Перенос по зонам и по именам; после каждого чтения поле сохраняется во временный файл, чтобы Fluent не спрашивал
    «discard data?» (при 2 процессах спрашивал, при 6 — нет; v7 из-за этого остановилась)."""
    import leontiev_pipeline as L
    lines = []
    for z, ip in ips.items():
        lines += [f'/file/interpolate/zone-selection {z} ()', f'/file/interpolate/read-data "{L.fl(ip)}"',
                  f'/file/write-data "{L.fl(OUT / f"{tag}_xfer_{z}.dat.h5")}"']
    return lines


def transfer_gate(tpl, reads, ref, tag):
    """Без итераций: прочитать шаблон, перенести поле по зонам, сравнить с W1: давление min/max ±1 %, средняя T ±1 K."""
    import leontiev_pipeline as L
    jou = OUT / f'{tag}_transfer_check.jou'
    trn = OUT / f'{tag}_transfer_check.trn'
    jou.write_text('\n'.join(['/file/confirm-overwrite? no', f'/file/start-transcript "{L.fl(trn)}"',
                              f'/file/read-case-data "{L.fl(tpl / "initial.cas.h5")}"'] + reads + field_report_lines()
                             + ['/file/stop-transcript', '/exit yes']) + '\n', encoding='utf-8')
    checked_session(jou)
    got = field_report(trn.read_text(errors='replace')) if trn.exists() else {}
    bad = {}
    for k, v in ref.items():
        g = got.get(k)
        ok = g is not None and (abs(g - v) <= 1.0 if k.startswith('T_avg') else abs(g - v) <= 0.01 * abs(v) + 1e-6)
        if not ok:
            bad[k] = (v, g)
    save(OUT / f'{tag}_transfer_check.json', dict(reference=ref, transferred=got, mismatch=bad, time=now()))
    if len(got) < len(ref) or bad:
        raise RuntimeError(f'{tag}: перенос поля W1 по зонам не подтверждён: {bad or "нет отчёта"}')


def run():
    global ORIGINAL_RUN
    p = registered()
    OUT.mkdir(exist_ok=True, parents=True)
    if (OUT / 'attempt.json').exists():
        raise RuntimeError('Этап уже пытались выполнять; повтор запрещён')
    idle()
    save(OUT / 'attempt.json', dict(started=now(), plan_sha256=sha(PLAN)))
    import gui_runner as G
    import leontiev_pipeline as L
    import build_knurl_case_1103_v6 as B
    import cont_util as U
    import knurl_cont as K
    A, _ = K.setup()
    A.BASE, A.CSV, A.AUX = OUT, OUT / 'results.csv', OUT / 'aux.csv'
    A.POINT_LIMIT = p['limit']
    A.set_step(A.CONS)
    U.LIMIT = p['limit']
    U.TIME_LIMIT_H, U.NPROC = p['time_limit_h'], p['nproc']
    ORIGINAL_RUN = L.run_fluent
    L.run_fluent = checked_session
    results = dict(base=evaluate(p['base_folder']))
    save(OUT / 'results.json', results)
    ips = {z: OUT / f'W1_{z}.ip' for z in ZONES}
    ip_jou = OUT / 'export_source.jou'
    lines = ['/file/confirm-overwrite? no', f'/file/start-transcript "{L.fl(OUT / "export_source.trn")}"',
             f'/file/read-case-data "{L.fl(Path(p["base_folder"]) / "result.cas.h5")}"']
    for z, ip in ips.items():
        lines += [f'/file/interpolate/zone-selection {z} ()', f'/file/interpolate/write-data "{L.fl(ip)}" yes yes']
    lines += field_report_lines() + ['/file/stop-transcript', '/exit yes']
    ip_jou.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    checked_session(ip_jou)
    if not all(ip.is_file() and ip.stat().st_size for ip in ips.values()):
        raise RuntimeError('Нет файлов переноса поля по зонам')
    ref_field = field_report((OUT / 'export_source.trn').read_text(errors='replace'))
    results['base']['field'] = ref_field
    save(OUT / 'results.json', results)
    for item in p['levels']:
        registered()
        q, tag = item['params'], item['tag']
        save(OUT / 'state.json', dict(time=now(), phase='mesh', tag=tag))
        msh, cells = mesh_gate(q, p)
        tpl = OUT / (tag + '_template')
        topology = B.build(msh, tpl, p0_svz_MPa=5.5, interpolate=False)
        coverage = topology.get('interface_percent', [])
        if not coverage:   # пары стыка должны быть найдены; величина покрытия — только в отчёт (D-47)
            raise RuntimeError('Пары стыка газ–стенка не найдены: ' + str(topology))
        idle()
        target_dir = OUT / tag
        target_dir.mkdir()
        save(target_dir / 'params.json', dict(q, run_id=tag))
        reads = transfer_lines(ips, tag)
        transfer_gate(tpl, reads, ref_field, tag)   # поле на новой сетке совпадает с W1 по зонам — до итераций
        extra = list(L.CH4_PR_LINES) + [L.wall_k_line(110), L.SYMMETRY_DZV_LINE] + reads
        save(OUT / 'state.json', dict(time=now(), phase='cfd', tag=tag, cells=cells, mesh_sha256=sha(msh)))
        minutes = U.continue_case(tpl / 'initial.cas.h5', OUT / tag, extra, p['regime'],
                                 lambda s: print(now(), s, flush=True), tag,
                                 t0_C=p['T0_svz'], t0_dzv_C=p['T0_dzv'])
        U.record(A.CSV, tag, 'grid_1103', 'ch4_pr', p['regime'], OUT / tag, minutes,
                 lambda s: print(now(), s, flush=True), start='W1 same-geometry interpolation',
                 t0_C=p['T0_svz'], t0_dzv_C=p['T0_dzv'])
        e = evaluate(OUT / tag)
        e.update(cells=cells, mesh_sha256=sha(msh), minutes=minutes, settings=q, interface_percent=coverage,
                 energy_ok=e.get('imb_pct') is not None and abs(e['imb_pct']) < 1.0)
        results[tag] = e
        save(OUT / 'results.json', results)
        if not e['accepted']:
            raise RuntimeError(tag + ' не прошла численную приёмку полного окна1000')
        idle()
    checks = []
    for a, b in [('base', 'G1'), ('G1', 'G2'), ('base', 'G2')]:
        ea, eb = results[a], results[b]
        delta = dict(effect_K=abs(eb['effect'] - ea['effect']))
        for key in ('Q', 'G_svz', 'G_dzv'):
            delta[key + '_pct'] = abs(100 * (eb[key] / ea[key] - 1))
        checks.append(dict(pair=[a, b], delta=delta,
                           passed=all(delta[k] <= v for k, v in p['comparison'].items())))
    monotonic = 550119 < results['G1']['cells'] < results['G2']['cells']
    summary = dict(finished=now(), checks=checks, monotonic_cells=monotonic,
                   local_mesh_sensitivity_passed=monotonic and all(c['passed'] for c in checks),
                   limitation=p['conclusion'], physics='Обратный ток и y+ требуют отдельной оценки')
    save(OUT / 'summary.json', summary)
    lines = ['# Проверка сетки накатки h0,1 / шаг2 (v6, допуск стыка — баланс энергии)', '', str(summary['finished']), '',
        '| Сетка | Ячеек | Q, Вт | GСВЗ | GДЗВ | Эффект, K | дисбаланс энергии, % Q | покрытие стыка, % |', '|---|---|---|---|---|---|---|---|']
    for name, e in results.items():
        lines.append(f"| {name} | {e.get('cells',550119)} | {e['Q']:.3f} | {e['G_svz']:.8f} | {e['G_dzv']:.8f} | {e['effect']:.4f} | "
                     f"{e.get('imb_pct', float('nan')):.3f} | {e.get('interface_percent', 'W1: 99,54 / 99,69 (исторически)')} |")
    lines += ['', json.dumps(summary, ensure_ascii=False, indent=2)]
    (OUT / 'report.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else 'check'
    if mode == 'plan':
        make_plan()
    elif mode == 'check':
        p = registered()
        print('CHECK OK; 2 new levels; no Fluent/Workbench launched; base full-window acceptance:',
              evaluate(p['base_folder'])['accepted'])
    elif mode == 'run':
        try:
            run()
        except Exception as ex:
            save(OUT / 'BLOCK.json', dict(time=now(), error=str(ex), traceback=traceback.format_exc()))
            print(traceback.format_exc(), flush=True)
            sys.exit(3)
    else:
        raise SystemExit('plan | check | run')
