"""30.10.2026 — интерфейс автора (решение автора 30.10), на Tkinter + matplotlib (уже установлены; новых пакетов нет).
Окно 1 «Что считается сейчас» — только просмотр: текущий расчёт (серия, точка), паспорт (геометрия, режим, сетка), ход счёта
(итерация, невязки, мониторы, дисбаланс энергии, y+, оценка времени), очередь (старые цепочки + общая очередь jobs.json).
31.10.2026 — шаги 2 и 3: окно 2 «Новая серия» (gui_series.py) и окно 3 «Результаты и датасет» (gui_results.py).
Интерфейс Fluent не запускает: только общая очередь (серии окна 2 считает job_point.py).
usage: python author_gui.py [--snapshot файл.png [номер вкладки 1–3]]; ярлык на рабочем столе — «Труба Леонтьева — интерфейс автора»."""
import json, math, re, sys, threading, time
from pathlib import Path
import tkinter as tk
from tkinter import ttk
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import matplotlib
matplotlib.use('TkAgg')
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import gui_runner as G
import passport as PS
import jobqueue as JQ
import queue_runner as QR
import gui_series
import gui_results
import gui_task
import gui_points

R = Path(r'F:\Leontiev_Project\runs')
LEGACY_LABEL = {'knurl_shallow.py': 'разведка мелкой накатки h 0,1 / 0,2 / 0,3 мм (KM01–KM03)', 'knurl_eqflow.py': 'накатка KS10 при равном расходе',
                'nozzle_series.py': 'сопло как фактор (D-26)', 'a3a_check.py': 'A3a — проверка на новых трубах',
                'confirm_runner.py': 'задача 2 за краем (sppr --confirm, CF…)', 'queue_1030c.py': 'ждёт: задача 2 за краем CF01–CF03 (после накатки)',
                'queue_1030b.py': 'цепочка: мелкая накатка', 'bundle3d_run.py': '3D-проверка'}
RES_COLS = ('iter', 'continuity', 'x-velocity', 'y-velocity', 'energy', 'k', 'omega')


def current_run():
    """Папка расчёта, в которую Fluent пишет сейчас (самый свежий журнал *.trn за последние 15 мин)."""
    best = None
    for pat in ('*/*/coupled_*.trn', '*/*/*.trn', '*/*/*/coupled_*.trn', '*/*/*/*.trn'):
        for f in R.glob(pat):
            m = f.stat().st_mtime
            if best is None or m > best[0]:
                best = (m, f)
    if best and time.time() - best[0] < 900:
        return best[1].parent, best[0]
    return None, best[0] if best else None


def residuals(d):
    bl = sorted(d.glob('coupled_*.trn')) or sorted(d.glob('fluent-*.trn'))
    for f in reversed(bl):
        rows = [ln.split() for ln in f.read_text(encoding='utf-8', errors='replace').splitlines()
                if re.match(r'^\s*\d+\s+\d\.\d+e[-+]\d+', ln)]
        if rows:
            return {k: (int(v) if k == 'iter' else float(v)) for k, v in zip(RES_COLS, rows[-1])}
    return {}


def res_history(d, n_max=2000):
    """31.10: история невязок по каждой итерации (подъём run.trn + блоки coupled_*.trn; если их нет — полный журнал fluent-*.trn):
    видна с первых минут счёта, когда отчётов мониторов (раз в 500–1500 итераций) ещё один-два."""
    files = ([d / 'run.trn'] if (d / 'run.trn').exists() else []) + sorted(d.glob('coupled_*.trn'))
    if len(files) <= 1:
        files = sorted(d.glob('fluent-*.trn'), key=lambda f: f.stat().st_mtime) or files
    rows = {}
    for f in files:
        for ln in f.read_text(encoding='utf-8', errors='replace').splitlines():
            if re.match(r'^\s*\d+\s+\d\.\d+e[-+]\d+', ln):
                v = ln.split()
                try:
                    r6 = [float(x) for x in v[1:7]]
                except ValueError:
                    continue
                if len(r6) == 6:   # только полные строки (непрерывность, x, y, энергия, k, ω); у шаблона/FMG столбцов меньше
                    rows[int(v[0])] = r6
    it = sorted(rows)
    step = max(1, len(it) // n_max)
    return [(i, *rows[i]) for i in it[::step]]


def speed_eta(d):
    """с/итерацию — по времени записи блоков coupled_*.trn (по 500 итераций); оценка до предела итераций."""
    bl = sorted(d.glob('coupled_*.trn'), key=lambda f: f.stat().st_mtime)
    cj = d / 'convergence.json'
    c = json.loads(cj.read_text(encoding='utf-8')) if cj.exists() else {}
    sp = None
    if len(bl) >= 3:
        t = [f.stat().st_mtime for f in bl[:-1]]
        sp = (t[-1] - t[-2]) / 500.0
    return sp, c


def effect(pp, s):
    try:
        import grs_temps
        r = pp['regime']
        o = grs_temps.outlet_temps(s['Q'], s['m_svz'], s['m_dzv'], 273.15 + r['T0_svz'], r['p_main'], r['p_cons'], r['p_out_dzv'], r['p0_dzv'],
                                   T0_dzv_K=273.15 + r['T0_dzv'])
        return o.get('dT_svz_vs_throttle')
    except Exception:
        return None


def queue_view():
    rows, tot = [], 0.0
    for pid, cmd in QR.python_procs():
        for t in cmd.split():
            nm = Path(t.strip('"')).name
            if nm in LEGACY_LABEL:
                est = None
                if nm == 'knurl_shallow.py':
                    left = [v for v in ('KM01', 'KM02', 'KM03') if not any((R / 'patents').glob(f'{v}_eq*')) or v == 'KM01']
                    est = 2.5 * len([v for v in ('KM02', 'KM03') if not (R / 'patents' / f'{v}_A9_19').exists()]) + 1.0
                if nm == 'queue_1030c.py':
                    fc = json.loads((R / 'journal' / 'confirm_forecasts.json').read_text(encoding='utf-8'))
                    n = sum(1 for v in fc.values() if v.get('status') == 'в очереди')
                    est = 0.4 + 0.8 * n
                rows.append(('идёт' if nm not in ('queue_1030c.py', 'queue_1030b.py') else 'ждёт', 'старая цепочка', LEGACY_LABEL[nm], est))
                tot += est or 0
    for j in JQ.load():
        if j['status'] in ('ждёт', 'идёт'):
            rows.append((j['status'], j['id'], f"{j.get('series')} ({j.get('plan')})", float(j.get('est_h') or 0)))
            tot += float(j.get('est_h') or 0)
    return [r for r in rows if r[2] != LEGACY_LABEL['queue_1030b.py']], tot


def _d12a(d):
    """31.10 (D-12a, принято автором): сходимость при колебаниях — окно 1000 итераций, средние; для таблицы сходимости."""
    try:
        import d12a
        return d12a.evaluate(d)
    except Exception as e:
        return dict(ok=None, why=f'не оценено: {e!r}', n=0)


def snapshot():
    """Всё для окна 1 — одним словарём (считается в фоне)."""
    d, t_last = current_run()
    out = dict(time=time.strftime('%d.%m.%Y %H:%M:%S'), run=None, t_last=t_last)
    if d:
        pp = PS.resolve(d)
        st = G.status(d) or {}
        res = residuals(d)
        sp, conv = speed_eta(d)
        s = (st.get('samples') or [None])[-1]
        out.update(run=d, pp=pp, st=st, res=res, speed=sp, conv=conv, last=s, eff=effect(pp, s) if s else None, rh=res_history(d),
                   hist=[(x['iteration'], effect(pp, x), x['Q'], x['m_dzv'], x['net']) for x in st.get('samples') or []],
                   every=st.get('every'), d12a=_d12a(d))
    out['queue'], out['queue_h'] = queue_view()
    return out


def fmt(v, f='{:.4g}', none='—'):
    return none if v is None or (isinstance(v, float) and math.isnan(v)) else f.format(v)


CONV = (('continuity', 'невязка неразрывности', '{:.1e}'), ('mass_svz_pct', 'баланс массы СВЗ, %', '{:.3f}'),
        ('energy_W', 'дисбаланс энергии, Вт (порог автостопа)', '{:.2f}'), ('drift_K_per_100', 'изменение эффекта за 100 итераций, K', '{:.4f}'),
        ('drift_Q_W_per_100', 'изменение Q за 100 итераций, Вт', '{:.3f}'), ('drift_flow_pct_per_100', 'изменение расхода СВЗ за 100 итераций, %', '{:.4f}'),
        ('drift_flow_dzv_pct_per_100', 'изменение расхода ДЗВ за 100 итераций, %', '{:.4f}'))


def conv_rows(c, last, it, mx):
    """31.10 (задание автора): таблица сходимости — критерий | сейчас | нужно | ✓/✗ (критерии автостопа из convergence.json,
    D-12 — дисбаланс энергии < 1 % Q, y+, лимит итераций)."""
    rows = []
    chk, lim = (c or {}).get('checks') or {}, (c or {}).get('limits') or {}
    for k, name, f in CONV:
        if k in chk:
            v = chk[k].get('value')
            rows.append((name, fmt(abs(v) if isinstance(v, (int, float)) else v, f), f"≤ {fmt(lim.get(k), '{:g}')}", bool(chk[k].get('passed'))))
    if last and last.get('Q'):
        pct = 100 * abs(last['net']) / abs(last['Q'])
        rows.append(('дисбаланс энергии, % Q (D-12: точка годна)', f'{pct:.2f}', '< 1', pct < 1.0))
        yp = max(last.get('yp_svz') or 0, last.get('yp_dzv') or 0)
        rows.append(('y+ max (СВЗ / ДЗВ)', f"{fmt(last.get('yp_svz'), '{:.2f}')} / {fmt(last.get('yp_dzv'), '{:.2f}')}", '≤ 1', yp <= 1.0))
    if it and mx:
        rows.append(('итерация', f'{it}', f'≤ {mx} (лимит)', it < mx))
    return rows


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Труба Леонтьева — интерфейс автора')
        self.geometry('1320x900')
        st = ttk.Style(self); st.configure('H.TLabel', font=('Segoe UI', 12, 'bold')); st.configure('V.TLabel', font=('Consolas', 10))
        # 31.10 (перестройка по шагам решения, этап 1): вкладки главного инженера — первыми; «Словарь» и оговорка — над вкладками
        hb = ttk.Frame(self, padding=(8, 4)); hb.pack(fill='x')
        ttk.Label(hb, text='Программа только рекомендует: на станции она ничем не управляет (нет датчиков, онлайн-режима, автоматики); '
                           'режимная карта — печатная таблица.', foreground='#555').pack(side='left')
        ttk.Button(hb, text='Словарь', command=lambda: gui_task.glossary(self)).pack(side='right')
        nb = ttk.Notebook(self); nb.pack(fill='both', expand=True)
        self.nb = nb
        self.decision = gui_task.DecisionFrame(nb)
        self.task = gui_task.TaskFrame(nb, on_result=lambda r: (self.decision.set_result(r), nb.select(self.decision)))
        nb.add(self.task, text='1. Задача (главный инженер)')
        nb.add(self.decision, text='2. Решение (главный инженер)')
        t1 = ttk.Frame(nb, padding=8); nb.add(t1, text='Что считается сейчас (расчётчик)')
        self.series = gui_points.PointsFrame(nb); nb.add(self.series, text='Новая серия (расчётчик)')   # 31.10: таблица расчётных точек
        self.results = gui_results.ResultsFrame(nb); nb.add(self.results, text='Результаты и датасет')
        nb.bind('<<NotebookTabChanged>>', lambda e: self.results.ensure() if nb.select() == str(self.results) else None)
        top = ttk.Frame(t1); top.pack(fill='x')
        self.head = ttk.Label(top, text='…', style='H.TLabel'); self.head.pack(side='left')
        self.upd = ttk.Label(top, text=''); self.upd.pack(side='right')
        ttk.Button(top, text='Обновить', command=self.refresh).pack(side='right', padx=6)
        body = ttk.Frame(t1); body.pack(fill='both', expand=True, pady=6)
        left = ttk.Frame(body); left.pack(side='left', fill='y')
        self.boxes = {}
        for key, title in (('geo', 'Геометрия'), ('reg', 'Режим'), ('mesh', 'Сетка'), ('prog', 'Ход счёта')):
            lf = ttk.LabelFrame(left, text=title, padding=6); lf.pack(fill='x', pady=3)
            lb = ttk.Label(lf, text='—', style='V.TLabel', justify='left'); lb.pack(anchor='w')
            self.boxes[key] = lb
        cf = ttk.LabelFrame(left, text='Сходимость: критерий | сейчас | нужно', padding=4); cf.pack(fill='x', pady=3)
        self.ctree = ttk.Treeview(cf, columns=('k', 'now', 'need', 'ok'), show='headings', height=17)
        for c, w, h in (('k', 290, 'критерий'), ('now', 90, 'сейчас'), ('need', 110, 'нужно'), ('ok', 32, '')):
            self.ctree.heading(c, text=h); self.ctree.column(c, width=w, anchor='w')
        self.ctree.tag_configure('ok', background='#dff0d8'); self.ctree.tag_configure('bad', background='#f8d7da')
        self.ctree.tag_configure('hdr', background='#dde3ea')
        self.ctree.pack(fill='x')
        right = ttk.Frame(body); right.pack(side='left', fill='both', expand=True, padx=8)
        self.fig = Figure(figsize=(7.6, 5.0), dpi=90)
        self.ax = [self.fig.add_subplot(2, 1, i + 1) for i in range(2)]   # 31.10: два графика — невязки и изменение результата
        self.canvas = FigureCanvasTkAgg(self.fig, master=right); self.canvas.get_tk_widget().pack(fill='both', expand=True)
        qf = ttk.LabelFrame(right, text='Очередь: что дальше', padding=6); qf.pack(fill='x', pady=4)
        self.qtree = ttk.Treeview(qf, columns=('st', 'id', 'what', 'h'), show='headings', height=6)
        for c, w, h in (('st', 70, 'статус'), ('id', 110, 'задание'), ('what', 560, 'что'), ('h', 70, 'часов')):
            self.qtree.heading(c, text=h); self.qtree.column(c, width=w, anchor='w')
        self.qtree.pack(fill='x')
        self.qsum = ttk.Label(qf, text=''); self.qsum.pack(anchor='w')
        self.data, self.fresh, self.busy = None, False, False
        if '--snapshot' not in sys.argv:
            self.refresh(); self.after(1000, self.poll); self.after(30000, self.loop)

    def loop(self):
        try:
            self.refresh()
        finally:
            self.after(30000, self.loop)

    def poll(self):   # Tk — только из главного потока: фон кладёт данные, окно их забирает
        try:
            if self.fresh:
                self.fresh = False; self.show()
        except Exception as e:   # 31.10: ошибка отрисовки не должна останавливать обновление окна
            import traceback; traceback.print_exc()
            self.head.config(text=f'Ошибка отрисовки: {e!r} (окно продолжает обновляться)')
        finally:
            self.after(1000, self.poll)

    def refresh(self, sync=False):
        def work():
            try:
                self.data = snapshot()
            except Exception as e:
                self.data = dict(error=repr(e), time=time.strftime('%H:%M:%S'))
            self.fresh, self.busy = True, False
        if sync:
            work(); self.fresh = False; self.show()
        elif not self.busy:
            self.busy = True
            threading.Thread(target=work, daemon=True).start()

    def show(self):
        s = self.data or {}
        self.upd.config(text=f"обновлено {s.get('time', '')}; обновление раз в 30 с")
        if s.get('error'):
            self.head.config(text='Ошибка чтения: ' + s['error']); return
        if not s.get('run'):
            self.head.config(text='Fluent сейчас ничего не пишет (последний журнал ' +
                             (time.strftime('%d.%m %H:%M', time.localtime(s['t_last'])) if s.get('t_last') else '—') + ')')
        else:
            pp, st, res, c, last = s['pp'], s['st'], s['res'], s['conv'], s['last']
            g, r, m = pp.get('geometry') or {}, pp.get('regime') or {}, pp.get('mesh') or {}
            self.head.config(text=f"Сейчас: {pp.get('series')} — точка {pp['tag']}  ({pp.get('how')}; план: {pp.get('plan')})")
            kn = g.get('knurl')
            self.boxes['geo'].config(text=(
                f"тип трубы        {pp.get('kind')}\n"
                f"t/d              {fmt(g.get('t_d'), '{:.3g}')}\n"
                f"L (теплообмен)   {fmt(g.get('L_mm'), '{:.0f}')} мм\n"
                f"сопло: горло ⌀   {fmt(2 * g['throat_mm'] if g.get('throat_mm') else None, '{:.2f}')} мм, срез ⌀ {fmt(2 * g['r_exit_mm'] if g.get('r_exit_mm') else None, '{:.2f}')} мм\n"
                f"  отношение площадей A/A* {fmt(g.get('area_ratio'), '{:.2f}')}\n"
                f"накатка          " + (f"h {kn['h_mm']} мм, шаг {kn['pitch_mm']} мм, ширина {kn['width_mm']} мм" if kn else 'гладкая') + '\n'
                f"зазор ДЗВ (2D)   {fmt(g.get('gap_mm'), '{:.2f}')} мм; стенка {fmt(g.get('wall_in_mm'), '{:.1f}')} → {fmt(g.get('wall_end_mm'), '{:.1f}')} мм"))
            self.boxes['reg'].config(text=(
                f"магистраль       {fmt(r.get('p_main'), '{:.3g}')} МПа\n"
                f"потребитель      {fmt(r.get('p_cons'), '{:.3g}')} МПа\n"
                f"перепад ДЗВ      {fmt(r.get('dp_dzv_kPa'), '{:.3g}')} кПа" + ('   ⚠ < 15 кПа — риск сбоя' if (r.get('dp_dzv_kPa') or 99) < 15 else '') + '\n'
                f"газ на входе     {fmt(r.get('T0_dzv'), '{:+.2f}')} °C;  подогрев СВЗ {fmt(r.get('heat_K'), '{:+.2f}')} K\n"
                f"модель газа      {r.get('gas', '—')}"))
            yps = last['yp_svz'] if last else None; ypd = last['yp_dzv'] if last else None
            self.boxes['mesh'].config(text=(
                f"версия           {m.get('preset', '—')} (шаг по оси {fmt(m.get('axial_mm'), '{:g}')} мм, слоёв ДЗВ {m.get('dzv_layers', '—')})\n"
                f"ячеек            {fmt(m.get('cells'), '{:,}').replace(',', ' ')}\n"
                f"y+ max           СВЗ {fmt(yps, '{:.2f}')},  ДЗВ {fmt(ypd, '{:.2f}')}"))
            sp, it, mx = s['speed'], res.get('iter') or st.get('iter'), c.get('max_iter')
            eta = (mx - it) * sp / 3600 if sp and mx and it else None
            chk = c.get('checks') or {}
            bad = [k for k, v in chk.items() if not v.get('passed')]
            self.boxes['prog'].config(text=(
                f"итерация         {it} из ≤ {mx or '—'}\n"
                f"невязки          непр. {fmt(res.get('continuity'), '{:.2e}')}  энерг. {fmt(res.get('energy'), '{:.2e}')}\n"
                f"                 k {fmt(res.get('k'), '{:.2e}')}  ω {fmt(res.get('omega'), '{:.2e}')}\n"
                f"эффект (против дросселя) {fmt(s.get('eff'), '{:+.2f}')} K\n"
                f"расход СВЗ / ДЗВ {fmt(last['m_svz'] if last else None, '{:.5f}')} / {fmt(last['m_dzv'] if last else None, '{:.5f}')} кг/с\n"
                f"тепло Q          {fmt(last['Q'] if last else None, '{:.1f}')} Вт;  дисбаланс энергии {fmt(last['net'] if last else None, '{:.2f}')} Вт\n"
                f"скорость         {fmt(sp, '{:.2f}')} с/итер.;  до предела ≈ {fmt(eta, '{:.1f}')} ч" +
                ('\nавтостоп: критерии выполнены — Fluent сохраняет кейс' if c.get('stop_requested') else '')))
            for i in self.ctree.get_children():   # 31.10: таблица сходимости
                self.ctree.delete(i)
            for name, now, need, ok in conv_rows(c, last, it, mx):
                self.ctree.insert('', 'end', values=(name, now, need, '✓' if ok else '✗'), tags=('ok' if ok else 'bad',))
            import d12a as D12   # 31.10: критерии D-12a (окно 1000 итераций) — той же таблицей
            e = s.get('d12a') or {}
            self.ctree.insert('', 'end', values=('— D-12a (окно 1000 итераций): ' + ('СОШЛАСЬ' if e.get('ok') else 'не сошлась' if e.get('ok') is False
                                                                                   else 'пока не оценить'), '', '', ''), tags=('hdr',))
            for name, now, need, ok in D12.rows_table(e):
                self.ctree.insert('', 'end', values=(name, now, need, '' if ok is None else '✓' if ok else '✗'),
                                  tags=('' if ok is None else 'ok' if ok else 'bad',))
            h, rh = s['hist'], s.get('rh') or []
            for a in self.ax:
                a.clear(); a.tick_params(labelsize=7)
            a = self.ax[0]   # невязки по каждой итерации — видны сразу
            if rh:
                for k, nm in ((1, 'непрерывность'), (4, 'энергия'), (5, 'k'), (6, 'ω')):
                    a.semilogy([x[0] for x in rh], [max(x[k], 1e-20) for x in rh], lw=0.8, label=nm)
                a.legend(fontsize=6, loc='upper right')
            a.set_title('Невязки (каждая итерация)', fontsize=9)
            # 31.10 (задание автора): «Изменение результата» — эффект, Q, расход ДЗВ в % от последнего значения; дисбаланс энергии
            # в % Q и красная линия 1 % (D-12); серая полоса допуска ±1 % (D-12); ось фиксирована ±2 %
            a = self.ax[1]
            a.axhspan(-1.0, 1.0, color='0.88', zorder=0, label='допуск ±1 % (D-12)')
            a.axhline(1.0, color='red', lw=1.2, label='дисбаланс 1 % Q (D-12)')
            a.axhline(0.0, color='0.5', lw=0.6)
            pts = [x for x in h if x[1] is not None and x[2]]
            if pts:
                it_ = [x[0] for x in pts]
                for k, nm, col in ((1, 'эффект', 'tab:blue'), (2, 'тепло Q', 'tab:orange'), (3, 'расход ДЗВ', 'tab:green')):
                    lastv = pts[-1][k]
                    a.plot(it_, [100 * (x[k] / lastv - 1) if lastv else 0 for x in pts], 'o-', ms=4, lw=1, color=col, label=f'{nm}, % от последнего')
                a.plot(it_, [100 * abs(x[4]) / abs(x[2]) for x in pts], 's--', ms=4, lw=1, color='tab:red', label='дисбаланс энергии, % Q')
            a.set_ylim(-2, 2)
            a.set_ylabel('%', fontsize=8)
            ev = (pts[-1][0] - pts[-2][0]) if len(pts) >= 2 else None   # фактический шаг отчётов
            a.set_title(f"Изменение результата (отчёты {len(pts)}" + (f', каждые {ev} итераций' if ev else '') + '; ось ±2 %, за пределами — обрезано)', fontsize=9)
            a.legend(fontsize=6, loc='lower left', ncol=3)
            self.fig.tight_layout(); self.canvas.draw_idle()
        for i in self.qtree.get_children():
            self.qtree.delete(i)
        for st_, jid, what, h in s.get('queue', []):
            self.qtree.insert('', 'end', values=(st_, jid, what, fmt(h, '{:.1f}')))
        self.qsum.config(text=f"всего в очереди ≈ {s.get('queue_h', 0):.1f} ч; общая очередь: runs\\queue\\jobs.json "
                              f"(исполнитель queue_runner.py — переход после старых цепочек)")


if __name__ == '__main__':
    if sys.stdout is None:   # 31.10: запуск ярлыком (pythonw) — консоли нет; вывод и ошибки фоновых потоков — в файл
        sys.stdout = sys.stderr = open(R / 'queue' / 'author_gui_log.txt', 'a', encoding='utf-8', buffering=1)
        print(time.strftime('=== %d.%m.%Y %H:%M:%S запуск интерфейса'))
    app = App()
    if '--snapshot' in sys.argv:
        app.refresh(sync=True); app.update(); time.sleep(1.0); app.update()
        k = sys.argv.index('--snapshot')
        if len(sys.argv) > k + 2:
            app.nb.select(int(sys.argv[k + 2]) - 1); app.update(); time.sleep(1.0); app.update()
        from PIL import ImageGrab
        x, y, w, h = app.winfo_rootx(), app.winfo_rooty(), app.winfo_width(), app.winfo_height()
        ImageGrab.grab(bbox=(x, y, x + w, y + h)).save(sys.argv[sys.argv.index('--snapshot') + 1])
        app.destroy()
    else:
        app.mainloop()
