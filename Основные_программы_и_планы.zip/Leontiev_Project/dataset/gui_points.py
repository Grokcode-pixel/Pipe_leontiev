"""31.10.2026 — задание автора «Новая серия — как таблица расчётных точек в Workbench»: вместо диапазонов и плана — одна таблица.
Строка = один расчёт. Слева входы (тип трубы, t/d, L, давления, перепад ДЗВ, T газа, T СВЗ перед соплами, накатка: высота и шаг,
сопло: выход / горло); клетки, не нужные для типа трубы, серые; вне пределов — красные с подсказкой «можно от … до …».
Внизу всегда пустая строка; «Копировать строку», «Удалить строку», вставка нескольких строк из Excel (Ctrl+V).
Справа программа: «в области ✓/✗» и «прогноз эффекта ± σ» сразу после ввода (модель — замороженная, D-30); «статус»
(черновик / в очереди / идёт / готово / сбой); после расчёта — эффект, Q, расход ДЗВ, «сошлось ✓/✗». Строки с ✗ в очередь не идут.
Под таблицей — «Зачем эти расчёты (что изменит в тексте)» (обязательно, стоп-кран D-28), итог «N расчётов, ≈ X ч», «Поставить
в очередь» с подтверждением → jobqueue (одно задание на тип трубы, перед запасной работой) → job_point.py. Сетка стандартная;
«своя» — в «Дополнительно». Накатка — правило D-30 автоматически (с нуля, перепад задан). Таблица хранится в
runs\\queue\\таблица_точек.json: после перезапуска строки и статусы на месте."""
import csv, json, math, sys, threading, time
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import jobqueue as JQ
import gui_series as GS
from gui_task import Tip, models

TABLE = Path(r'F:\Leontiev_Project\runs\queue\таблица_точек.json')
RES = Path(r'F:\Leontiev_Project\runs\station\gui_results.csv')
KINDS = ('гладкая', 'накатка', 'сопло')
HEAT_MAX = 19.86        # подогрев СВЗ до сопел в данных модели, K
# ключ, заголовок, единицы, пределы (данные замороженной модели 31.10, 152 точки), для каких типов
COLS = [('kind', 'тип трубы', '', None, KINDS),
        ('td', 'шаг труб t/d (плотность пучка)', '', (1.2, 1.6), KINDS),
        ('L', 'L теплообмена', 'мм', (200.0, 660.0), KINDS),
        ('pm', 'давление магистрали', 'МПа', (2.53, 5.5), KINDS),
        ('pc', 'давление потребителя', 'МПа', (0.3, 1.6), KINDS),
        ('dp', 'перепад на задвижке ДЗВ', 'кПа', (0.52, 139.0), KINDS),
        ('T', 'T газа из магистрали (= T ДЗВ на входе)', '°C', (-9.76, 19.82), KINDS),
        ('Tsvz', 'T СВЗ перед соплами', '°C', None, KINDS),
        ('h', 'накатка: высота выступа', 'мм', (0.1, 1.0), ('накатка',)),
        ('pitch', 'накатка: шаг', 'мм', (1.5, 4.75), ('накатка',)),
        ('ar', 'сопло: выход / горло (по площади)', '', (1.44, 2.92), ('сопло',))]
OUTS = [('area', 'в области', 7), ('fc', 'прогноз эффекта ± σ, K', 15), ('status', 'статус', 11), ('eff', 'эффект, K', 9),
        ('Q', 'Q, Вт', 8), ('G', 'расход ДЗВ, кг/с', 10), ('ok', 'сошлось', 7)]
GRAY, RED, WHITE = '#e4e4e4', '#ffd6d6', 'white'
EST = {'гладкая': 1.0, 'накатка': 3.0, 'сопло': 2.0}   # ч Fluent на точку (накатка по D-30 — с нуля)


def num(s):
    s = str(s or '').strip().replace(',', '.')
    return float(s) if s else None


def limits(key, row):
    if key == 'Tsvz':
        T = num(row.get('T'))
        return (T, T + HEAT_MAX) if T is not None else None
    return next(c[3] for c in COLS if c[0] == key)


def kind_of(s):
    s = str(s or '').strip().lower()
    return next((k for k in KINDS if s and k.startswith(s[:3])), '')


class PointsFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding=6)
        self.rows, self.cells, self.cur = [], [], None
        ttk.Label(self, text='Каждая строка — один расчёт. Введите значения (запятая или точка), Ctrl+V — вставка строк из Excel. '
                             'Справа программа сразу показывает, в области ли точка, и прогноз; после расчёта — результат.',
                  wraplength=1300).pack(anchor='w')
        outer = ttk.Frame(self); outer.pack(fill='both', expand=True, pady=4)
        self.cv = tk.Canvas(outer, highlightthickness=0); sy = ttk.Scrollbar(outer, orient='vertical', command=self.cv.yview)
        sx = ttk.Scrollbar(outer, orient='horizontal', command=self.cv.xview)
        self.cv.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        self.cv.grid(row=0, column=0, sticky='nsew'); sy.grid(row=0, column=1, sticky='ns'); sx.grid(row=1, column=0, sticky='ew')
        outer.rowconfigure(0, weight=1); outer.columnconfigure(0, weight=1)
        self.grid_f = tk.Frame(self.cv); self.cv.create_window((0, 0), window=self.grid_f, anchor='nw')
        self.grid_f.bind('<Configure>', lambda e: self.cv.configure(scrollregion=self.cv.bbox('all')))
        tk.Label(self.grid_f, text='№', width=3, relief='ridge', bg='#dde3ea').grid(row=0, column=0, sticky='nsew')
        for j, (k, t, u, lim, kinds) in enumerate(COLS, start=1):
            lim_t = '' if not lim else f'\n{lim[0]:g}…{lim[1]:g}'
            if k == 'Tsvz':
                lim_t = f'\nT газа … +{HEAT_MAX:g} K'
            if k == 'kind':
                lim_t = '\nгладкая / накатка / сопло'
            l = tk.Label(self.grid_f, text=t + (f', {u}' if u else '') + lim_t, wraplength=105, relief='ridge', bg='#dde3ea', justify='center',
                         font=('Segoe UI', 8)); l.grid(row=0, column=j, sticky='nsew')
            Tip(l, f'{t}' + (f', {u}' if u else '') + (f': можно от {lim[0]:g} до {lim[1]:g} (данные модели, заморожено 31.10)' if lim else '') +
                ('' if kinds == KINDS else f' — только для типа «{kinds[0]}»'))
        for j, (k, t, w) in enumerate(OUTS, start=len(COLS) + 1):
            tk.Label(self.grid_f, text=t, wraplength=95, relief='ridge', bg='#e8efe0', font=('Segoe UI', 8)).grid(row=0, column=j, sticky='nsew')
        bar = ttk.Frame(self); bar.pack(fill='x')
        ttk.Button(bar, text='Копировать строку', command=self.copy_row).pack(side='left')
        ttk.Button(bar, text='Удалить строку', command=self.del_row).pack(side='left', padx=4)
        self.adv_on = tk.BooleanVar(value=False)
        ttk.Checkbutton(bar, text='Дополнительно: своя сетка', variable=self.adv_on, command=self.toggle_adv).pack(side='left', padx=16)
        self.adv = ttk.Frame(bar)
        self.mesh_e = {}
        for k, lab, v in (('axial_size_mm', 'шаг по оси, мм', '0.25'), ('global_size_mm', 'общий размер, мм', '0.5'), ('dzv_layers', 'слоёв ДЗВ', '')):
            ttk.Label(self.adv, text=lab).pack(side='left'); e = ttk.Entry(self.adv, width=6); e.insert(0, v); e.pack(side='left', padx=(2, 8))
            self.mesh_e[k] = e
        ttk.Label(bar, text='Накатка — автоматически по D-30: каждая точка с нуля, перепад задан.', foreground='#555').pack(side='right')
        bf = ttk.Frame(self); bf.pack(fill='x', pady=4)
        ttk.Label(bf, text='Зачем эти расчёты (что изменит в тексте) — обязательно:').pack(anchor='w')
        self.why = tk.Text(bf, height=2, wrap='word'); self.why.pack(fill='x')
        b2 = ttk.Frame(self); b2.pack(fill='x')
        self.sum = ttk.Label(b2, text='', font=('Segoe UI', 10, 'bold')); self.sum.pack(side='left')
        ttk.Button(b2, text='Поставить в очередь', command=self.enqueue).pack(side='right')
        self.msg = ttk.Label(self, text='', foreground='#555', wraplength=1300); self.msg.pack(anchor='w')
        self._todo, self._fc_pending, self._save_pending = [], False, False
        self.load()
        self.after(200, self._pump); self.after(2000, self.refresh_status)

    # --- служебное ---------------------------------------------------------------------------------------------------
    def _pump(self):
        while self._todo:
            try:
                self._todo.pop(0)()
            except Exception as e:
                self.msg.config(text=f'ошибка окна: {e!r}')
        self.after(200, self._pump)

    def toggle_adv(self):
        (self.adv.pack(side='left') if self.adv_on.get() else self.adv.pack_forget())

    def load(self):
        data = json.loads(TABLE.read_text(encoding='utf-8')) if TABLE.exists() else {}
        for r in data.get('rows', []):
            self.add_row(r)
        if data.get('why'):
            self.why.insert('1.0', data['why'])
        self.ensure_blank(); self.validate_all(); self.schedule_fc()

    def save(self):
        self._save_pending = False
        rows = [r for r in self.rows if any(str(r.get(k) or '').strip() for k, *_ in COLS) or r.get('tag')]
        TABLE.parent.mkdir(parents=True, exist_ok=True)
        TABLE.write_text(json.dumps(dict(rows=[{k: v for k, v in r.items() if not k.startswith('_')} for r in rows],
                                         why=self.why.get('1.0', 'end').strip(), saved=time.strftime('%d.%m.%Y %H:%M:%S')),
                                    ensure_ascii=False, indent=1), encoding='utf-8')

    def schedule_save(self):
        if not self._save_pending:
            self._save_pending = True; self.after(800, self.save)

    # --- строки ------------------------------------------------------------------------------------------------------
    def add_row(self, r=None):
        r = dict(r or {}); r.setdefault('status', 'черновик')
        i = len(self.rows); self.rows.append(r)
        gi = i + 1
        lab = tk.Label(self.grid_f, text=str(gi), width=3, relief='ridge', bg='#f3f3f3'); lab.grid(row=gi, column=0, sticky='nsew')
        lab.bind('<Button-1>', lambda e, i=i: self.select(i))
        cells = {'_n': lab}
        for j, (k, t, u, lim, kinds) in enumerate(COLS, start=1):
            if k == 'kind':
                w = ttk.Combobox(self.grid_f, values=KINDS, width=9, state='readonly')
                w.set(r.get('kind', ''))
                w.bind('<<ComboboxSelected>>', lambda e, i=i: self.changed(i))
                w.bind('<Control-Key>', lambda e, i=i, j=j: self.ctrl_key(e, i, j))   # вставка строк целиком, начиная с «тип трубы»
            else:
                w = tk.Entry(self.grid_f, width=9, justify='right', relief='solid', borderwidth=1)
                w.insert(0, str(r.get(k, '') if r.get(k) is not None else ''))
                w.bind('<KeyRelease>', lambda e, i=i: self.changed(i))
                w.bind('<Control-Key>', lambda e, i=i, j=j: self.ctrl_key(e, i, j))
                cells['_tip_' + k] = Tip(w, '')
            w.grid(row=gi, column=j, sticky='nsew')
            w.bind('<FocusIn>', lambda e, i=i: self.select(i), add='+')
            cells[k] = w
        for j, (k, t, wd) in enumerate(OUTS, start=len(COLS) + 1):
            l = tk.Label(self.grid_f, text='', width=wd, relief='ridge', bg='#fafafa', anchor='w', font=('Segoe UI', 9))
            l.grid(row=gi, column=j, sticky='nsew'); cells[k] = l
            if k == 'area':
                cells['_tip_area'] = Tip(l, '')
        self.cells.append(cells)
        return i

    def blank(self, i):
        r = self.rows[i]
        return not r.get('tag') and not any(str(self.get(i, k) or '').strip() for k, *_ in COLS)

    def ensure_blank(self):
        if not self.rows or not self.blank(len(self.rows) - 1):
            self.add_row()

    def get(self, i, k):
        w = self.cells[i][k]
        return w.get()

    def select(self, i):
        if self.cur is not None and self.cur < len(self.cells):
            self.cells[self.cur]['_n'].config(bg='#f3f3f3')
        self.cur = i; self.cells[i]['_n'].config(bg='#ffd27f')

    def read(self, i):
        r = self.rows[i]
        r['kind'] = self.get(i, 'kind')
        for k, *_ in COLS[1:]:
            r[k] = self.get(i, k).strip()
        return r

    def changed(self, i):
        if self.rows[i].get('tag'):
            return
        self.read(i)
        if not self.rows[i].get('kind') and any(self.rows[i].get(k) for k, *_ in COLS[1:]):
            self.cells[i]['kind'].set('гладкая'); self.rows[i]['kind'] = 'гладкая'
        self.rows[i].pop('_fc', None)
        self.validate(i); self.ensure_blank(); self.schedule_fc(); self.schedule_save(); self.summary()

    def copy_row(self):
        if self.cur is None or self.blank(self.cur):
            self.msg.config(text='Выберите строку (щёлкните по клетке или номеру).'); return
        src = self.read(self.cur) if not self.rows[self.cur].get('tag') else self.rows[self.cur]
        last = len(self.rows) - 1
        new = {k: src.get(k, '') for k, *_ in COLS}
        if self.blank(last):
            self.fill_row(last, new)
        else:
            self.fill_row(self.add_row(), new)
        self.ensure_blank(); self.validate_all(); self.schedule_fc(); self.schedule_save()

    def fill_row(self, i, vals):
        for k, v in vals.items():
            w = self.cells[i][k]
            if k == 'kind':
                w.set(kind_of(v) or '')
            else:
                st = w.cget('state'); w.config(state='normal'); w.delete(0, 'end'); w.insert(0, str(v)); w.config(state=st)
        self.read(i)

    def del_row(self):
        i = self.cur
        if i is None or i == len(self.rows) - 1 and self.blank(i):
            return
        r = self.rows[i]
        if r.get('status') in ('в очереди', 'идёт'):
            messagebox.showinfo('Удалить строку', 'Расчёт уже в очереди или идёт — строку нельзя удалить (снимите задание в очереди).'); return
        if r.get('tag') and not messagebox.askyesno('Удалить строку', f"Убрать строку {r['tag']} из таблицы? Результат расчёта останется в файлах."):
            return
        data = [dict(self.rows[k]) if self.rows[k].get('tag') else dict(self.read(k)) for k in range(len(self.rows)) if k != i]
        for w in self.grid_f.grid_slaves():
            if int(w.grid_info()['row']) > 0:
                w.destroy()
        self.rows, self.cells, self.cur = [], [], None
        for r in data:
            if any(str(r.get(k) or '').strip() for k, *_ in COLS) or r.get('tag'):
                self.add_row(r)
        self.ensure_blank(); self.validate_all(); self.refresh_status(once=True); self.schedule_save()

    def ctrl_key(self, e, i, j):
        if e.keycode != 86:            # V (в любой раскладке)
            return None
        try:
            txt = self.clipboard_get()
        except tk.TclError:
            return 'break'
        if '\t' not in txt and '\n' not in txt.strip():
            return None                # одно значение — обычная вставка
        lines = [ln for ln in txt.replace('\r', '').split('\n') if ln.strip()]
        keys = [c[0] for c in COLS]
        for n, ln in enumerate(lines):
            ii = i + n
            while ii >= len(self.rows):
                self.add_row()
            if self.rows[ii].get('tag'):
                continue
            vals = {}
            for m, v in enumerate(ln.split('\t')):
                jj = j - 1 + m
                if jj < len(keys):
                    vals[keys[jj]] = v.strip()
            self.fill_row(ii, vals)
            if not self.rows[ii].get('kind'):
                self.cells[ii]['kind'].set('гладкая'); self.rows[ii]['kind'] = 'гладкая'
        self.ensure_blank(); self.validate_all(); self.schedule_fc(); self.schedule_save()
        self.msg.config(text=f'вставлено строк: {len(lines)}')
        return 'break'

    # --- проверка ----------------------------------------------------------------------------------------------------
    def validate_all(self):
        for i in range(len(self.rows)):
            self.validate(i)
        self.summary()

    def validate(self, i):
        r, c = self.rows[i], self.cells[i]
        kind = r.get('kind') or ''
        locked = bool(r.get('tag'))
        bad = []
        for k, t, u, lim, kinds in COLS[1:]:
            w = c[k]
            need = (not kind) or kind in kinds
            if not need:
                w.config(state='normal'); w.delete(0, 'end'); w.config(state='disabled', disabledbackground=GRAY); r[k] = ''
                c['_tip_' + k].text = f'не нужно для типа «{kind}»'; continue
            w.config(state='readonly' if locked else 'normal')
            try:
                v = num(r.get(k))
            except ValueError:
                w.config(bg=RED, readonlybackground=RED); c['_tip_' + k].text = 'не число'; bad.append(t); continue
            lm = limits(k, r)
            out = v is not None and lm is not None and not (lm[0] - 1e-9 <= v <= lm[1] + 1e-9)
            miss = v is None and kind and not self.blank(i)
            col = RED if (out or miss) else WHITE
            w.config(bg=col, readonlybackground='#eef3fb' if locked and not out else col)
            c['_tip_' + k].text = (f'можно от {lm[0]:g} до {lm[1]:g}' if lm else '') + (' — нужно заполнить' if miss else '') + \
                (' — перепад < 15 кПа: риск сбоя расчёта' if k == 'dp' and v is not None and v < 15 else '')
            if out or miss:
                bad.append(t)
        r['_bad'] = bad
        self.show_out(i)

    def point(self, r):
        """Точка для прогноза / очереди (None — не заполнена или ошибки)."""
        if r.get('_bad') or not r.get('kind'):
            return None
        try:
            p = dict(kind=r['kind'], td=num(r['td']), L=num(r['L']), pm=num(r['pm']), pc=num(r['pc']), dp=num(r['dp']), T=num(r['T']),
                     heat=round(num(r['Tsvz']) - num(r['T']), 3) if num(r.get('Tsvz')) is not None else 0.0,
                     h=num(r.get('h')) if r['kind'] == 'накатка' else 0.0, pitch=num(r.get('pitch')) if r['kind'] == 'накатка' else 0.0,
                     ar=num(r.get('ar')) if r['kind'] == 'сопло' else 2.151)
        except (TypeError, ValueError):
            return None
        return p if all(v is not None for v in p.values()) else None

    def schedule_fc(self):
        if self._fc_pending:
            return
        self._fc_pending = True
        todo = [(i, self.point(r)) for i, r in enumerate(self.rows) if not r.get('_fc') and not r.get('tag')]
        todo = [(i, p) for i, p in todo if p]
        if not todo:
            self._fc_pending = False; return
        self.msg.config(text='прогноз и проверка области… (первый раз загрузка модели ≈ 1 мин)')

        def work():
            try:
                M = models()
                for i, p in todo:
                    a = GS.assess('гладкая' if p['kind'] == 'гладкая' else p['kind'], [dict(p)], M)[0]
                    self._todo.append(lambda i=i, a=a, p=p: self.set_fc(i, a, p))
                self._todo.append(lambda: self.msg.config(text=''))
            except Exception as e:
                import traceback; traceback.print_exc()
                self._todo.append(lambda: self.msg.config(text=f'прогноз не получен: {e!r}'))
            finally:
                self._fc_pending = False
                self._todo.append(lambda: self.schedule_fc() if any(not r.get('_fc') and not r.get('tag') and self.point(r) for r in self.rows) else None)
        threading.Thread(target=work, daemon=True).start()

    def set_fc(self, i, a, p):
        if i >= len(self.rows) or self.point(self.rows[i]) != p:
            return                      # строку изменили, пока считали
        r = self.rows[i]
        warn = [w for w in a['warn'] if 'не вход модели' not in w]
        f = a['fc'] or {}
        # 31.10 (поправка автора): «в области» — по прогнозу доли ДЗВ m (Ω 0,2–0,96), а не по каждому полю отдельно; перепад ≥ 5 кПа
        ok = bool(f) and 0.2 <= f.get('m', -1) <= 0.96 and p['dp'] >= 5.0
        if p['kind'] == 'накатка':      # накатка посчитана только при режиме A9_19 (t/d 1,4, L 400, 5,5 → 0,59 МПа, газ 8,63 °C, СВЗ 13,46 °C)
            at = (abs(p['td'] - 1.4) < 1e-6 and abs(p['L'] - 400) < 0.5 and abs(p['pm'] - 5.5) < 0.01 and abs(p['pc'] - 0.59) < 0.01
                  and abs(p['T'] - 8.63) < 0.5 and abs(p['heat'] - 4.83) < 0.5)
            ok = at and p['dp'] >= 5.0
            warn.append('накатка — не вход модели (D-28): прогноза эффекта нет; ' + ('режим A9_19 — в данных' if at else
                        'ВНЕ ДАННЫХ: накатка посчитана только при режиме A9_19 (t/d 1,4, L 400, 5,5 → 0,59 МПа, газ 8,63 °C, СВЗ 13,46 °C)'))
        elif p['kind'] == 'сопло':      # сопло — не вход модели: по 1D
            ok = not any(w.startswith('1D') for w in warn) and p['dp'] >= 5.0
            warn.append('сопло — не вход модели (D-28): прогноза эффекта нет; область — по 1D')
        if p['dp'] < 5.0:
            warn.append('перепад < 5 кПа — не ставится')
        r['_fc'] = dict(ok=ok, warn=warn, effect=f.get('effect_K') if p['kind'] == 'гладкая' else None, sigma=f.get('sigma_K'), m=f.get('m'),
                        x=f.get('x'), p=f.get('p'), inside=f.get('inside'), est=EST[p['kind']] + (0.5 if p['kind'] == 'гладкая' and p['L'] not in (200.0, 400.0, 660.0) else 0.0))
        self.show_out(i); self.summary()

    def show_out(self, i):
        r, c = self.rows[i], self.cells[i]
        f = r.get('_fc') or r.get('fc_saved')
        if r.get('_bad'):
            c['area'].config(text='✗ ввод', fg='#c62828'); c['_tip_area'].text = 'исправьте красные клетки: ' + ', '.join(r['_bad'])
        elif f:
            c['area'].config(text='✓' if f['ok'] else '✗', fg='#2e7d32' if f['ok'] else '#c62828')
            c['_tip_area'].text = ('; '.join(f['warn']) or 'в области данных и опыта') + (f"; прогноз m {f['m']:.2f} (допустимо 0,2–0,96)" if f.get('m') else '')
        else:
            c['area'].config(text=''); c['_tip_area'].text = ''
        c['fc'].config(text=(f"{f['effect']:+.2f} ± {f['sigma']:.2f}" if f and f.get('effect') is not None else ('нет данных' if f else '')))
        st = r.get('status', 'черновик') if not self.blank(i) else ''
        c['status'].config(text=st, fg={'готово': '#2e7d32', 'сбой': '#c62828', 'идёт': '#1565c0', 'в очереди': '#8d6e00'}.get(st.split()[0] if st else '', 'black'))
        res = r.get('res') or {}
        c['eff'].config(text=f"{res['eff']:+.3f}" if res.get('eff') is not None else '')
        c['Q'].config(text=f"{res['Q']:.0f}" if res.get('Q') is not None else '')
        c['G'].config(text=f"{res['G']:.4f}" if res.get('G') is not None else '')
        c['ok'].config(text=('✓' if res.get('ok') else '✗') if res else '', fg='#2e7d32' if res.get('ok') else '#c62828')

    def ready(self):
        return [(i, r) for i, r in enumerate(self.rows) if not r.get('tag') and not self.blank(i) and self.point(r) and (r.get('_fc') or {}).get('ok')]

    def summary(self):
        rd = self.ready()
        n_all = sum(1 for i, r in enumerate(self.rows) if not r.get('tag') and not self.blank(i))
        self.sum.config(text=f"{len(rd)} расчётов к постановке, ≈ {sum(r['_fc']['est'] for i, r in rd):.1f} ч Fluent" +
                             (f"  (черновиков всего {n_all}; с ✗ или без прогноза в очередь не идут)" if n_all != len(rd) else ''))

    # --- очередь -----------------------------------------------------------------------------------------------------
    def enqueue(self):
        why = self.why.get('1.0', 'end').strip()
        from gui_decision import bad_why
        if bad_why(why):
            messagebox.showerror('Поставить в очередь', 'Заполните «Зачем эти расчёты (что изменит в тексте)» — не пустое и не «тест»; '
                                                        'без этого в очередь не ставится (D-28, правило автора 31.10).'); return
        rd = self.ready()
        if not rd:
            messagebox.showinfo('Поставить в очередь', 'Нет строк с ✓ (в области, с прогнозом).'); return
        hours = sum(r['_fc']['est'] for i, r in rd)
        if not messagebox.askyesno('Поставить в очередь', f'{len(rd)} расчётов, ≈ {hours:.1f} ч Fluent.\nПоставить в общую очередь (перед запасной работой)?'):
            return
        mesh = None
        if self.adv_on.get():
            mesh = {k: float(e.get().replace(',', '.')) for k, e in self.mesh_e.items() if e.get().strip()}
            if 'dzv_layers' in mesh:
                mesh['dzv_layers'] = int(mesh['dzv_layers'])
        fc = json.loads(GS.FC.read_text(encoding='utf-8')) if GS.FC.exists() else {}
        made = []
        for kind in KINDS:
            grp = [(i, r) for i, r in rd if r['kind'] == kind]
            if not grp:
                continue
            no = GS.next_series_no()
            pts = []
            for k, (i, r) in enumerate(grp, 1):
                p = self.point(r)
                q = dict(tag=f'IF{no:03d}_{k:02d}', td=p['td'], L=p['L'], pm=p['pm'], pc=p['pc'], dp=p['dp'], T=p['T'], heat=p['heat'],
                         h=p['h'], pitch=p['pitch'], ar=p['ar'])
                if kind == 'сопло':
                    q['r_exit'] = round(GS.THROAT_R * math.sqrt(p['ar']), 3)
                pts.append((i, r, q))
            p0 = pts[0][2]
            job = dict(series=f'таблица точек: {kind}, {len(pts)} расчётов', kind='point', series_no=no, tube=kind, points=[q for _, _, q in pts], mesh=mesh,
                       plan='таблица расчётных точек (окно «Новая серия»)' + ('; накатка — D-30: с нуля, перепад задан' if kind == 'накатка' else ''),
                       stdout=f'runs\\station\\IF{no:03d}_stdout.txt', est_h=round(sum(r['_fc']['est'] for _, r, _ in pts), 1), text_change=why,
                       passport=dict(kind=kind, geometry=dict(t_d=p0['td'], L_mm=p0['L']), regime=dict(p_main=p0['pm'], p_cons=p0['pc'], dp_dzv_kPa=p0['dp'],
                                                                                                       T0_dzv=p0['T'], heat_K=p0['heat']), start='таблица точек'))
            res = JQ.add([job], by='автор (интерфейс, таблица точек)', after=GS.backup_after())
            jid = res[0]['id']
            for i, r, q in pts:
                f = r['_fc']
                fc[q['tag']] = dict(job=jid, kind={'гладкая': 'гладкая', 'накатка': 'накатка', 'сопло': 'сопло'}[kind], point=q, x=f.get('x'),
                                    effect_K=f.get('effect'), sigma_K=f.get('sigma'), m=f.get('m'), p=f.get('p'), inside=f.get('inside'), warn=f['warn'],
                                    time=time.strftime('%d.%m.%Y %H:%M:%S'), status='в очереди', в_обучение=False)
                r.update(tag=q['tag'], job=jid, status='в очереди', fc_saved=dict(ok=f['ok'], warn=f['warn'], effect=f.get('effect'), sigma=f.get('sigma'), m=f.get('m')))
            made.append(f'{jid} ({kind}, {len(pts)})')
        GS.FC.write_text(json.dumps(fc, ensure_ascii=False, indent=1), encoding='utf-8')
        self.validate_all(); self.save()
        self.msg.config(text='Поставлено: ' + ', '.join(made) + '. Прогноз до расчёта — runs\\journal\\gui_forecasts.json; строка в Журнал_работ.md.')

    def refresh_status(self, once=False):
        try:
            jobs = {j['id']: j for j in JQ.load()}
            fc = json.loads(GS.FC.read_text(encoding='utf-8')) if GS.FC.exists() else {}
            res = {}
            if RES.exists():
                for x in csv.DictReader(open(RES, encoding='utf-8')):
                    if x.get('G_dzv'):
                        res[x['tag']] = x
            changed = False
            for i, r in enumerate(self.rows):
                t = r.get('tag')
                if not t:
                    continue
                v, j = fc.get(t, {}), jobs.get(r.get('job'), {})
                ps = v.get('status', '')
                st = ('готово' if ps == 'сошёлся' else 'готово (предел)' if ps == 'предел итераций' else 'сбой' if ps in ('нет результата',) else
                      'снят' if ps.startswith('снят') else 'идёт' if j.get('status') == 'идёт' else 'в очереди' if j.get('status') == 'ждёт' else
                      'сбой' if j.get('status') == 'сбой' else r.get('status'))
                x = res.get(v.get('result_tag') or '')
                rr = dict(eff=float(x['dT_svz_vs_throttle']), Q=float(x['Q']), G=float(x['G_dzv']), ok=str(x['status']).startswith('сошёлся')) if x else None
                if st != r.get('status') or rr != r.get('res'):
                    r['status'], r['res'] = st, rr; changed = True
                    self.show_out(i)
            if changed:
                self.schedule_save()
        except Exception as e:
            self.msg.config(text=f'статусы не прочитаны: {e!r}')
        if not once:
            self.after(30000, self.refresh_status)
