"""Stage A5 on geometry v3 «as in the experiment» (agreed 08.10/09.10.2026: experiment check before the dataset, one
night).  Leontiev, Zditovets et al., Exp. Therm. Fluid Sci. 88 (2017) 202-219, Table 2 run 1: M_is 1.8, concurrent
flows, smooth subsonic channel, P*h1 = P*c1 = 1.05 MPa, T*h1 299.0 K, T*c1 298.9 K, G_sup 0.0491 kg/s, m 0.108-0.752.
Points read from Fig. 8a (литература\\опыт_2017_точки_с_рисунков.csv, +-0.3 K; the text, sect. 4.4.2, ties Fig. 8a
to runs 1 and 3, i.e. run 1 = smooth channel, concurrent):  m 0.11: dTc -11.8, dTh +1.2;  0.30: -8.9, +2.6;
0.75: -5.5, +3.8 K.   dTh(m) = T*h2(m) - T*h2(m=0) (Eq. 14),  dTc(m) = T*c2(m) - T*0 (Eq. 15).
Model: geometry v3 (cone 6 -> 14 mm over 400 mm + cylinder 14 mm to 700 mm, brass OD 29 mm -> wall 11.5 mm at the
inlet, DZV gap 1.5 mm, throat d 5.0 mm, nozzle exit d 6.0 mm, Izotov nozzle), work_v2 mesh settings, air ideal gas
with k(T), SST + Prt 0.85, brass k = 110, outer DZV wall adiabatic (rig: steel tube to the room, a_a 5-10 W/(m2 K) —
neglected), SVZ outlet 0.1 MPa (receiver near-atmospheric; supersonic exit), T0 299.0 K (25.85 C) at both inlets.
The DZV flow is set as in the rig — by the mass flow (Fluent targeted mass flow at outlet_dzv, syntax checked 09.10).
Order: (S) from scratch with a fixed small DZV pressure drop -> m = 0.30 -> 0.11 -> 0.75 (targeted mass flow,
continuations) -> m = 0 (outlet = inlet pressure, no DZV flow; reference of Eq. 14).
Waits for run_after_0909.py.  Rows -> runs\\a5v3\\a5v3_results.csv (cont_util.record), summary a5v3_summary.csv."""
import csv, subprocess, sys, time, traceback
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import gui_runner as G
import run_a3 as A3
import cont_util as U

BASE = Path(r'F:\Leontiev_Project\runs\a5v3')
CSV = BASE / 'a5v3_results.csv'
QLOG = Path(r'F:\Leontiev_Project\runs\queue_log.txt')
T0_C = 25.85
G_SUP = 0.0491
EXP = {0.11: (-11.8, 1.2), 0.30: (-8.9, 2.6), 0.75: (-5.5, 3.8)}   # m: (dTc, dTh), Fig. 8a, +-0.3 K
RIG = dict(r_end_mm=7.0, l_heat_mm=700.0, l_cone_mm=400.0, gap_mm=1.5, r_nozzle_exit_mm=3.0, r_throat_mm=2.5,
           wall_thickness_inlet_mm=11.5, neck_ratio=1.0, r_outlet_mm=7.0, l_exit_recovery_mm=12.0, l_exit_tail_mm=5.0,
           r_exit_rounding_mm=100.0)


def log(s):
    line = time.strftime('%H:%M:%S ') + s
    print(line, flush=True)
    BASE.mkdir(parents=True, exist_ok=True)
    with (BASE / 'a5v3_log.txt').open('a', encoding='utf-8') as f:
        f.write(line + '\n')


def qlog(s):
    with QLOG.open('a', encoding='utf-8') as f:
        f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + s + '\n')


def running(name):
    out = subprocess.run(['powershell', '-NoProfile', '-Command',
                          f"Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | ? {{$_.CommandLine -match '{name}'}} | Measure-Object | % Count"],
                         capture_output=True, text=True).stdout.strip()
    return out not in ('', '0')


def tmf(g):
    # absolute-pressure limits in atm (case units): 3 atm .. 10.362 atm (p0 1.05 MPa = 10.3627 atm)
    return [f'/define/boundary-conditions/set/pressure-outlet outlet_dzv () targeted-mf-boundary? yes targeted-mf no {g:g} '
            'targeted-mf-pmin no 3 targeted-mf-pmax no 10.362 q']


TMF_OFF = ['/define/boundary-conditions/set/pressure-outlet outlet_dzv () targeted-mf-boundary? no q']


def main():
    p = dict(G.DEFAULTS)
    p.update(A3.MESHES['work_v2'], **RIG)
    p.update(run_id='a5v3_start', prt=0.85, mesh_custom=True, wait_free=True, gas='air', wall_k=110.0,
             p0_svz_MPa=1.05, p_out_svz_MPa=0.1, p0_dzv_MPa=1.05, p_out_dzv_MPa=1.048,
             extra_lines=[U.t0_line(T0_C)])
    G.RUNS = BASE
    log('=== А5 v3 («как в опыте», run 1 табл. 2): с нуля, ДЗВ 1,05 -> 1,048 МПа (стартовое поле)')
    t0 = time.time()
    G.run(p, lambda s: log('  ' + s), lambda: False)
    start = BASE / p['run_id']
    U.record(CSV, 'a5v3_start', 'rig_work_v2', 'air', (1.05, 0.1, 1.05, 1.048), start, round((time.time() - t0) / 60, 1),
             log, start='с нуля (FMG)', t0_C=T0_C, l_heat_mm=700.0)
    prev = start / 'result.cas.h5'
    if not prev.exists():
        return log('А5 v3: нет стартового решения — остановка')
    rows = {}
    for m in (0.30, 0.11, 0.75):
        tag = f'a5v3_m{int(round(m * 100)):03d}'
        out = BASE / tag
        mins = U.continue_case(prev, out, tmf(m * G_SUP), (1.05, 0.1, 1.05, 1.0), log, f'{tag} (G_ДЗВ {m * G_SUP:.5f} кг/с)',
                               t0_C=T0_C)
        pod = 0.0
        if (out / 'result.cas.h5').exists():
            try:
                import run_after_0909 as R
                pod = round(R.outlet_pressures(out).get('outlet_dzv', 0.0), 5)
                log(f'  {tag}: давление на выходе ДЗВ {pod:.5f} МПа (перепад {1.05 - pod:.5f} МПа)')
            except Exception:
                log(f'  {tag}: давление на выходе ДЗВ не прочитано')
        rows[m] = U.record(CSV, tag, 'rig_work_v2', 'air', (1.05, 0.1, 1.05, pod), out, mins, log,
                           start=f'продолжение {prev.parent.name}', t0_C=T0_C, l_heat_mm=700.0)
        if (out / 'result.cas.h5').exists():
            prev = out / 'result.cas.h5'
    out = BASE / 'a5v3_m000'
    mins = U.continue_case(prev, out, TMF_OFF, (1.05, 0.1, 1.05, 1.05), log, 'a5v3_m000 (ДЗВ без расхода, опорный для ф. 14)',
                           t0_C=T0_C)
    r0 = U.record(CSV, 'a5v3_m000', 'rig_work_v2', 'air', (1.05, 0.1, 1.05, 1.05), out, mins, log,
                  start=f'продолжение {prev.parent.name}', t0_C=T0_C, l_heat_mm=700.0)
    # 09.10 (review): a difference dTh(m) = T*h2(m) - T*h2(0) is accepted only if BOTH runs converged; the experiment is
    # compared at the ACTUAL m (linear interpolation between the Fig. 8a points); the acceptance tolerance is set by the
    # author before the results (provisional: |dTh| <= 0.5 K, |dTc| <= 1.0 K, digitization +-0.3 K included) and the
    # trend over m must agree.  The criterion is only printed here, the decision is the author's.
    def exp_at(mc, i):
        pts = sorted((k, v[i]) for k, v in EXP.items())
        if mc <= pts[0][0]: return pts[0][1] if mc >= pts[0][0] - 0.03 else None
        for (a, fa), (b, fb) in zip(pts, pts[1:]):
            if a <= mc <= b: return fa + (fb - fa) * (mc - a) / (b - a)
        return pts[-1][1] if mc <= pts[-1][0] + 0.03 else None
    base_ok = str(r0.get('converged')) == 'True'
    log(f'  опорный m = 0: статус {r0.get("status")}, сошёлся {base_ok}' + ('' if base_ok else ' — разности ΔTh НЕ принимаются'))
    with (BASE / 'a5v3_summary.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['m_target', 'm_calc', 'status', 'converged', 'base_m0_converged', 'G_sup', 'dTc_calc', 'dTc_exp_at_m',
                    'dTc_diff', 'dTh_calc', 'dTh_exp_at_m', 'dTh_diff'])
        for m, r in sorted(rows.items()):
            try:
                mc = float(r['G_dzv']) / float(r['G_svz'])
                dtc = float(r['dT_dzv_total'])
                dth = float(r['dT_svz_total']) - float(r0['dT_svz_total'])
                ec, eh = exp_at(mc, 0), exp_at(mc, 1)
                conv = str(r.get('converged')) == 'True'
                w.writerow([m, round(mc, 3), r['status'], conv, base_ok, r['G_svz'], round(dtc, 3),
                            '' if ec is None else round(ec, 2), '' if ec is None else round(dtc - ec, 2),
                            round(dth, 3), '' if eh is None else round(eh, 2), '' if eh is None or not base_ok else round(dth - eh, 2)])
                # author 09.10 12:20: |dTh| <= 0.5 K, |dTc| <= 1.0 K (+ the same trend over m, judged on the whole set)
                ok = (conv and base_ok and ec is not None and eh is not None and abs(dtc - ec) <= 1.0 and abs(dth - eh) <= 0.5)
                log(f'  сверка m {m}: m расч. {mc:.3f}; ΔTc {dtc:+.2f} (опыт при этом m {ec if ec is None else round(ec, 2)}) K; '
                    f'ΔTh {dth:+.2f} (опыт {eh if eh is None else round(eh, 2)}) K; G СВЗ {r["G_svz"]} (опыт 0,0491); '
                    f'сошёлся {conv}, опорный {base_ok}; в допуске: {"да" if ok else "нет"}')
            except Exception:
                w.writerow([m, '', r.get('status'), '', base_ok, '', '', '', '', '', '', ''])


if __name__ == '__main__':
    qlog('=== А5 v3 (сверка с опытом): жду окончания run_after_0909')
    while running('run_after_0909') or running('run_resume_0909'):
        time.sleep(60)
    qlog('=== А5 v3 (сверка с опытом) — начат')
    try:
        main()
    except Exception:
        log('ОШИБКА программы: ' + traceback.format_exc())
    qlog('=== А5 v3 (сверка с опытом) — закончен (приёмка — по результатам)')
