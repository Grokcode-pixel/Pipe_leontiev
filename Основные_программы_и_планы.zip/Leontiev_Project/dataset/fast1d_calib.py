﻿"""16.10.2026 — калибровка быстрой модели fast1d по точкам CFD А9 (сошедшиеся, без A9_11/35/36) и проверка
многоуровневой модели (multi-fidelity): ГП по невязке «CFD − быстрая модель» против ГП только по CFD (скользящий
контроль по одной точке).  Вывод: runs\\fast1d\\calib.json, mf_check.md."""
import csv, json, math, sys, time
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import fast1d as F

A9 = Path(r'F:\Leontiev_Project\runs\a9')
OUT = Path(r'F:\Leontiev_Project\runs\fast1d')
NAMES = ('Cd', 'K_svz', 'K_dzv', 'K_loc', 'K_f')


def data():
    design = {p['id']: p for p in csv.DictReader(open(A9 / 'a9_design.csv', encoding='utf-8'))}
    res = {r['tag']: r for r in csv.DictReader(open(A9 / 'a9_results.csv', encoding='utf-8'))}
    rows = []
    for s in csv.DictReader(open(A9 / 'a9_points_status.csv', encoding='utf-8')):
        if s['id'] in ('A9_11', 'A9_35', 'A9_36') or s['num_status'] != 'сошлась':
            continue
        p, r = design[s['id']], res[s['result']]
        rows.append(dict(id=s['id'], td=float(p['t_d']), L=float(p['L_mm']), dp=float(p['dp_dzv_kPa']), pc=float(p['p_cons']),
                         t0=float(p['t0_dzv']), heat=float(p['heater']), eff=float(r['dT_svz_vs_throttle']),
                         m=float(r['G_dzv']) / float(r['G_svz']), Q=float(r['Q']), work=0 if r.get('x_shock_m') else 1))
    return rows


def predict(rows, par):
    return [F.run(r['td'], r['L'], r['dp'], r['pc'], r['t0'], r['heat'], par=par, n=80) for r in rows]


def resid(v, rows):
    par = dict(zip(NAMES, v))
    out = predict(rows, par)
    e = []
    for r, o in zip(rows, out):
        e += [math.log(max(o['Q'], 1.0) / r['Q']), math.log(o['m'] / r['m']), (o['effect_K'] - r['eff']) / 1.0]
    return np.array(e)


if __name__ == '__main__':
    OUT.mkdir(parents=True, exist_ok=True)
    rows = data()
    t = time.time()
    v0 = [0.97, 1.0, 1.0, 1.5, 1.0]
    fit = least_squares(resid, v0, args=(rows,), bounds=([0.85, 0.2, 0.2, 0.0, 0.1], [1.10, 5, 5, 20, 5]), diff_step=0.05,
                        max_nfev=60)
    par = dict(zip(NAMES, fit.x))
    out = predict(rows, par)
    eff_f = np.array([o['effect_K'] for o in out]); eff_c = np.array([r['eff'] for r in rows])
    m_f = np.array([o['m'] for o in out]); m_c = np.array([r['m'] for r in rows])
    w_f = np.array([o['working'] for o in out]); w_c = np.array([r['work'] for r in rows])
    info = dict(params={k: round(float(x), 4) for k, x in par.items()}, minutes=round((time.time() - t) / 60, 1),
                effect_rmse_K=round(float(np.sqrt(((eff_f - eff_c) ** 2).mean())), 3),
                effect_corr=round(float(np.corrcoef(eff_f, eff_c)[0, 1]), 3),
                m_rel_rmse=round(float(np.sqrt(((m_f / m_c - 1) ** 2).mean())), 3),
                working_agree=round(float((w_f == w_c).mean()), 3))
    (OUT / 'calib.json').write_text(json.dumps(info, ensure_ascii=False, indent=1), encoding='utf-8')
    with open(OUT / 'calib_points.csv', 'w', newline='', encoding='utf-8') as f:
        wr = csv.writer(f); wr.writerow(['id', 'eff_cfd', 'eff_fast', 'm_cfd', 'm_fast', 'Q_cfd', 'Q_fast', 'work_cfd', 'work_fast'])
        for r, o in zip(rows, out):
            wr.writerow([r['id'], r['eff'], round(o['effect_K'], 3), round(r['m'], 3), round(o['m'], 3), r['Q'], round(o['Q'], 1), r['work'], o['working']])
    print(json.dumps(info, ensure_ascii=False, indent=1))

