"""Single-writer alternative D48 stop for newly registered continuations.
No solver/process actions here; the existing U runner owns SCM and native save.
"""
import json,math,statistics
from pathlib import Path
import grs_temps as T
import gui_convergence as C

def evaluate(rows,regime):
    if len(rows)<3:return dict(accepted=False,full_window=False,n=len(rows),reason='Need3reports')
    last=rows[-1]['iteration'];w=[r for r in rows if r['iteration']>=last-1000]
    if len(w)<3 or last-w[0]['iteration']<1000:return dict(accepted=False,full_window=False,n=len(w),reason='Need full1000')
    keys=('Q','net','m_svz','m_dzv','dm')
    if not all(math.isfinite(r[k]) for r in w for k in keys):return dict(accepted=False,full_window=True,reason='Nonfinite input')
    q=statistics.mean(r['Q'] for r in w)
    if abs(q)<1e-9:return dict(accepted=False,full_window=True,reason='NearzeroQ')
    data={'Q':[r['Q'] for r in w],'Gs':[r['m_svz'] for r in w],'Gd':[r['m_dzv'] for r in w],
          'effect':[T.outlet_temps(r['Q'],r['m_svz'],r['m_dzv'],273.15+regime['T0_svz'],regime['p_main'],regime['p_cons'],regime['p_out_dzv'],regime['p0_dzv'],T0_dzv_K=273.15+regime['T0_dzv'])['dT_svz_vs_throttle'] for r in w]}
    mean=lambda k:statistics.mean(data[k]);amp=lambda k:(max(data[k])-min(data[k]))/2
    first=[i for i,r in enumerate(w) if r['iteration']<=last-500];second=[i for i,r in enumerate(w) if r['iteration']>last-500]
    if not first or not second:return dict(accepted=False,full_window=True,reason='No half-window evidence')
    drift=lambda k:abs(statistics.mean(data[k][i] for i in first)-statistics.mean(data[k][i] for i in second))
    o=dict(it=[w[0]['iteration'],last],n=len(w),full_window=True,Q=q,effect=mean('effect'),G_svz=mean('Gs'),G_dzv=mean('Gd'),imb_pct=100*statistics.mean(r['net'] for r in w)/abs(q),eff_amp=amp('effect'),Q_amp_pct=100*amp('Q')/abs(q),Gs_amp_pct=100*amp('Gs')/abs(mean('Gs')),Gd_amp_pct=100*amp('Gd')/abs(mean('Gd')),drift_eff=drift('effect'),drift_Q_pct=100*drift('Q')/abs(q),drift_Gs_pct=100*drift('Gs')/abs(mean('Gs')),drift_Gd_pct=100*drift('Gd')/abs(mean('Gd')))
    o['checks']=dict(imb=abs(o['imb_pct'])<1,eff=o['eff_amp']<=.05,Q=o['Q_amp_pct']<=1,G=max(o['Gs_amp_pct'],o['Gd_amp_pct'])<=.5,drift=o['drift_eff']<.025 and o['drift_Q_pct']<.5 and max(o['drift_Gs_pct'],o['drift_Gd_pct'])<.25)
    o['accepted']=all(o['checks'].values()) and all(abs(r['dm'])<=1 for r in w)
    return o

def state(rows,regime):
    if len(rows)<4:return dict(ready=False,windows=[],reason='Need two full consecutive windows')
    windows=[evaluate(rows[:-1],regime),evaluate(rows,regime)]
    recent=[r for r in rows if r['iteration']>=rows[-2]['iteration']-1000]
    mass=bool(recent) and all(math.isfinite(r['dm']) and abs(r['dm'])<=1 for r in recent)
    ready=rows[-1]['iteration']-rows[-2]['iteration']==500 and mass and all(w['accepted'] for w in windows)
    return dict(ready=ready,last_iteration=rows[-1]['iteration'],windows=windows,actual_mass_balance_ok=mass)

def install(regime):
    """Install only inside the new runner process; original files are never edited."""
    original=C.update_control
    def update(out,enabled=True,max_iter=None):
        rows=C.closed_samples(out);alternative=state(rows,regime)
        strict=C.decision(rows);stop=bool(enabled and (strict or alternative['ready']))
        limit=bool(max_iter and rows and rows[-1]['iteration']>=max_iter)
        result=dict(stop_requested=stop,limit_reached=limit and not stop,max_iter=max_iter,complete_reports=len(rows),checked_iteration=rows[-1]['iteration'] if rows else None,required_consecutive=2,includes_yplus=False,limits=C.STOP_LIMITS,checks=C.strict_checks(rows[-2],rows[-1]) if len(rows)>1 else {},d48=alternative,stop_basis='strict' if strict else 'D48' if alternative['ready'] else None)
        # Only this update function writes SCM; all decisions are complete before the one write.
        C.write_control(out,stop or limit)
        Path(out,'convergence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        return result
    C.update_control=update
    return original