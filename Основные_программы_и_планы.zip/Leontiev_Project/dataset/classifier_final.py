"""27.10.2026 — замечания рецензента (через автора), пп. 2 и 4:
B00, B03, B21 — в классификатор как «рабочие» (скачка нет, метка однозначна); в модель эффекта — только при дисбалансе
энергии < 1 % от Q трубы (рекомендация Ansys) — у всех трёх больше, поэтому модель эффекта не меняется.
Порог p_hi подбирается ТОЛЬКО на перекрёстной проверке по геометриям (наименьший порог без опасных ошибок
«скачок → рабочий»); отложенные геометрии 5–6 в подбор не входят. Так как на CV порог по построению ставится над
самым «рабочим» скачком, «0 опасных на CV» — не проверка; честная оценка — вложенная CV (порог подбирается внутри
обучающих частей и применяется к отложенной части) и отложенные 5–6. Верхняя граница 95 % при 0 из n —
точная (Клоппер — Пирсон, односторонняя) 1 − 0,05^(1/n) и «правило трёх» 3/n. Вывод: runs\\models\\classifier_final.md."""
import csv, json
import numpy as np
from sklearn.model_selection import GroupKFold
import model_compare as MC
import heldout_check as H
import classifier_variants as V

R = MC.R
X = np.vstack([H.X, V.Xl]); w = np.concatenate([H.w, np.ones(3)]); g = np.concatenate([H.g, V.gl])
# 29.10 (решение автора): несошедшиеся точки автопополнения группы «а» (дрейфы в норме, не закрыт только баланс энергии /
# continuity — как B00/B03/B21) — в классификатор с меткой по каналу (скачок / нет); в модель эффекта не идут
_af = R / 'journal' / 'auto_failures.json'
if _af.exists():
    _fc = json.loads((R / 'journal' / 'auto_forecasts.json').read_text(encoding='utf-8'))
    for _r in json.loads(_af.read_text(encoding='utf-8'))['rows']:
        if _r['g'] == 'а':
            X = np.vstack([X, [_fc[_r['tag']]['x']]]); w = np.append(w, 0 if _r['shock'] else 1)
            g = np.append(g, f"{_fc[_r['tag']]['td']}/{float(_fc[_r['tag']]['L'])}")


def oof(X, w, g, fc, pc):
    p = np.zeros(len(w))
    for tr, te in GroupKFold(n_splits=5).split(X, w, g):
        p[te] = pc(fc(H.Z(X[tr]), w[tr]), H.Z(X[te]))
    return p


def threshold(p, w):
    s = p[w == 0]
    return float(min(1.0, np.max(s) + 1e-3)) if len(s) else 0.5


def nested(X, w, g, fc, pc):
    """Порог подбирается на внутренней CV обучающих геометрий, применяется к внешней отложенной части."""
    danger, accepted = 0, 0
    for tr, te in GroupKFold(n_splits=5).split(X, w, g):
        t = threshold(oof(X[tr], w[tr], g[tr], fc, pc), w[tr])
        p = pc(fc(H.Z(X[tr]), w[tr]), H.Z(X[te]))
        danger += int(((p >= t) & (w[te] == 0)).sum()); accepted += int(((p >= t) & (w[te] == 1)).sum())
    return danger, accepted


ub = lambda n: 1 - 0.05 ** (1 / n)
# дисбаланс энергии трёх точек в % от Q трубы
RB = {r['tag']: r for r in csv.DictReader(open(R / 'setB/setB_results.csv', encoding='utf-8'))}
imb = {t: json.load(open(R / f'setB/{t}c/convergence.json', encoding='utf-8'))['checks']['energy_W']['value'] for t in V.LIMIT}
L = ['# Классификатор «рабочий / скачок» — итог (B00, B03, B21 как «рабочие»)', '',
     '## Три точки у границы скачка: дисбаланс энергии в % от Q трубы', '',
     '| Точка | дисбаланс, Вт | Q трубы, Вт | % от Q | в модель эффекта (< 1 %) | в классификатор |', '|---|---|---|---|---|---|']
for t in V.LIMIT:
    q = float(RB[t + 'c']['Q'])
    L.append(f'| {t}c | {imb[t]:.1f} | {q:.0f} | {100 * imb[t] / q:.1f} | нет | «рабочий» |')
n_sh, n_wk = int((w == 0).sum()), int(w.sum())
L += ['', 'Модель эффекта не меняется (98 точек, ГП: CV 0,172 K, отложенные 5–6 — 0,123 K).', '',
      f'## Классификатор: {len(w)} точек (рабочих {n_wk}, со скачком {n_sh}); отложенные 5–6: {len(H.wh)} точек, со скачком {int((H.wh == 0).sum())}', '',
      '| Модель | p_hi (только CV) | рабочих признано, CV | ушло в «досчитать» | опасных, вложенная CV | верхняя граница 95 % | опасных на 5–6 при p_hi |',
      '|---|---|---|---|---|---|---|']
out = {}
for name, (fr, fc, pr, pc) in MC.models().items():
    p = oof(X, w, g, fc, pc); t = threshold(p, w)
    acc = int(((p >= t) & (w == 1)).sum())
    dn, an = nested(X, w, g, fc, pc)
    ph = pc(fc(H.Z(X), w), H.Z(H.Xh)); dh = int(((ph >= t) & (H.wh == 0)).sum())
    bound = f'{100 * ub(n_sh):.0f} % (3/n = {100 * 3 / n_sh:.0f} %)' if dn == 0 else '—'
    L.append(f'| {name} | {t:.3f} | {acc} из {n_wk} | {n_wk - acc} | {dn} из {n_sh} (рабочих принято {an}) | {bound} | {dh} из {int((H.wh == 0).sum())} |')
    out[name] = dict(p_hi=t, acc=acc, nested_danger=dn, held_danger=dh)
best = min(out, key=lambda k: (out[k]['nested_danger'], -out[k]['acc']))
q = out[best]
L += ['', '27.10 (98 точек, без трёх точек, как 21.10) вложенная CV давала: квадратичная — 1 опасная из 23, CatBoost — 0, ГП — 0 (но принимает 3 рабочих). '
      'Прежнее «0 опасных» у квадратичной было следствием подбора порога на тех же прогнозах.', '',
      f"Предлагаемый выбор (по вложенной CV): **{best}**, p_hi = {q['p_hi']:.3f}. Порог подобран только на перекрёстной проверке по геометриям, "
      f"отложенные 5–6 не использовались. В текст: «{q['nested_danger']} из {n_sh} скачков названы рабочими (вложенная перекрёстная проверка по геометриям); "
      f"с вероятностью 95 % доля опасных ошибок не больше {100 * ub(n_sh):.0f} % (правило трёх — {100 * 3 / n_sh:.0f} %)»; цена порога — "
      f"«{n_wk - q['acc']} из {n_wk} рабочих режимов уходят в “досчитать”». Модель эффекта остаётся ГП (даёт ±σ для П2)."]
fr, fc, pr, pc = MC.models()[best]
ph = pc(fc(H.Z(X), w), H.Z(H.Xh))
L += ['', f'## {best}, p_hi {q["p_hi"]:.3f} на отложенных 5–6 (условие автора 27.10)', '',
      '| Точка | метка | p | статус |', '|---|---|---|---|']
L += [f"| {t} | {'рабочий' if wl else 'скачок'} | {p:.3f} | {'«рабочий»' if p >= q['p_hi'] else '«досчитать»'} |" for t, wl, p in zip(H.tags, H.wh, ph)]
L += ['', f"Опасных: {int(((ph >= q['p_hi']) & (H.wh == 0)).sum())} из {int((H.wh == 0).sum())}; рабочих признано "
      f"{int(((ph >= q['p_hi']) & (H.wh == 1)).sum())} из {int(H.wh.sum())}, в «досчитать» — {int(((ph < q['p_hi']) & (H.wh == 1)).sum())} "
      f"(при пороге 0,5 признано {int(((ph >= 0.5) & (H.wh == 1)).sum())} из {int(H.wh.sum())}). Новые геометрии классификатор почти всегда "
      'отправляет в «досчитать» — осторожно, но дорого: на новой геометрии рекомендация практически всегда идёт через расчёт Fluent (~9 мин).']
(MC.OUT / 'classifier_final.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
print('\n'.join(L))
