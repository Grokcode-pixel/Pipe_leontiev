"""Project convergence checks; only closed, complete coupled reports may stop a run."""
import json
import math
from pathlib import Path
import leontiev_pipeline as L


STOP_LIMITS = {   # fixed for the whole plan (task A1); author's decision 07.10.2026:
    # mass unchanged (< 1 %, SVZ channel); energy <= 5 W absolute (was 0.1 W);
    # dT drift <= 0.05 K/100 it (was 0.02); Q drift <= 1 W/100 it (was 0.1 %/100 it, now in watts);
    # mass-flow drift <= 0.1 %/100 it (unchanged, now a separate criterion)
    'continuity': 2.5e-4, 'mass_svz_pct': 1.0, 'energy_W': 5.0,   # 12.10 author 1e-4 -> 1.5e-4; 15.10 author -> 2.5e-4 (plateau ~2e-4 on the 200-mm cell); others unchanged
    'drift_K_per_100': 0.05, 'drift_Q_W_per_100': 1.0, 'drift_flow_pct_per_100': 0.1,   # SVZ flow
    'drift_flow_dzv_pct_per_100': 0.3}   # 15.10 author: DZV flow drift 0.1 -> 0.3 %/100 it (SVZ flow stays 0.1)


def strict_checks(previous, current):
    """Stop criteria between two closed reports.  y+ is NOT a stop criterion (mesh quality flag, stage A3)."""
    delta = current['iteration'] - previous['iteration']
    if delta <= 0:
        return {}
    drift = max(abs(current[k] - previous[k]) for k in ('dT_svz', 'dT_dzv')) * 100 / delta
    dQ = abs(current['Q'] - previous['Q']) * 100 / delta
    rel, rel_dzv = (abs(current[k] - previous[k]) / max(abs(current[k]), 1e-12) * 100 * 100 / delta for k in ('m_svz', 'm_dzv'))
    values = {
        'continuity': (current['continuity'], STOP_LIMITS['continuity'], False),
        'mass_svz_pct': (abs(current['dm']), STOP_LIMITS['mass_svz_pct'], True),
        'energy_W': (abs(current['net']), STOP_LIMITS['energy_W'], False),
        'drift_K_per_100': (drift, STOP_LIMITS['drift_K_per_100'], False),
        'drift_Q_W_per_100': (dQ, STOP_LIMITS['drift_Q_W_per_100'], False),
        'drift_flow_pct_per_100': (rel, STOP_LIMITS['drift_flow_pct_per_100'], False),
        'drift_flow_dzv_pct_per_100': (rel_dzv, STOP_LIMITS['drift_flow_dzv_pct_per_100'], False),
    }
    finite = all(math.isfinite(current[k]) and math.isfinite(previous[k])
                 for k in ('continuity', 'dm', 'net', 'dT_svz', 'dT_dzv', 'Q', 'm_svz', 'm_dzv'))
    return {k: {'value': value, 'passed': finite and (value < limit if exclusive else value <= limit)}
            for k, (value, limit, exclusive) in values.items()}


def channel_energy(fl):
    """Energy imbalance of each part (author 07.10, option б: recorded, not a stop criterion).
    Wall pairs: zone without '-shadow' = brass side, '-shadow' = gas side (same for every build).
    The three sums add up to the total 'net' (checked on a1_n95_545, edge03, ref085/grs)."""
    g = lambda k: fl.get(k, 0.0)
    return dict(e_svz=g('inlet_svz') + g('outlet_svz') + g('wall-air_svz-wall_abonite-shadow'),
                e_dzv=g('inlet_dzv') + g('outlet_dzv') + g('interior-air_dzv-wall_abonite-shadow'),
                e_solid=g('wall-air_svz-wall_abonite') + g('interior-air_dzv-wall_abonite') + g('wall-wall_abonite'))


def closed_samples(out):
    rows = []
    for path in sorted(Path(out).glob('coupled_*.trn')):
        text = path.read_text(encoding='utf-8', errors='replace')
        # stop-transcript issued from Scheme writes no "Transcript Stop Time" footer (07.10): a block is
        # closed once its report has been written completely
        if 'GRS_SAMPLE_END' not in text:
            continue
        samples, residuals = L.parse_trn(path)
        if not samples or not residuals:
            continue
        s, r = samples[-1], residuals[-1]
        required = ('inlet_mass_flow_rate_svz', 'outlet_mass_flow_rate_svz',
                    'outlet_total_temp_svz', 'outlet_total_temp_dzv', 'net', 'yp_svz', 'yp_dzv')
        if not all(k in s for k in required):
            continue
        mass = s['inlet_mass_flow_rate_svz']
        md = s.get('inlet_mass_flow_rate_dzv', float('nan'))
        rows.append(dict(iteration=r['it'], sample=s['sample'], continuity=r['continuity'],
                         dm=100*(mass+s['outlet_mass_flow_rate_svz'])/mass if mass else float('nan'),
                         dm_dzv=100*(md+s.get('outlet_mass_flow_rate_dzv', float('nan')))/md if md else float('nan'),
                         dT_svz=s['outlet_total_temp_svz']-25, dT_dzv=s['outlet_total_temp_dzv']-25,
                         Q=s['flux'].get('interior-air_dzv-wall_abonite', float('nan')),
                         **channel_energy(s['flux']),
                         m_svz=mass, m_dzv=s.get('inlet_mass_flow_rate_dzv', float('nan')),
                         net=s['net'], yp_svz=s['yp_svz'], yp_dzv=s['yp_dzv']))
    return rows


def decision(rows, consecutive=2):   # 2 checks x 500 it = criteria hold over the last 1000 iterations
    if len(rows) < consecutive + 1:
        return False
    pairs = zip(rows[-consecutive-1:-1], rows[-consecutive:])
    return all(bool(c := strict_checks(a, b)) and all(x['passed'] for x in c.values()) for a, b in pairs)


def write_control(out, stop):
    path = Path(out) / 'convergence_control.scm'
    text = '(set! grs-stop? %s)\n' % ('#t' if stop else '#f')
    if path.exists() and path.read_text(encoding='ascii') == text:
        return
    tmp = path.with_suffix('.tmp')
    tmp.write_text(text, encoding='ascii')
    tmp.replace(path)


def update_control(out, enabled=True, max_iter=None):
    rows = closed_samples(out)
    stop = enabled and decision(rows)
    # iteration limit enforced by the runner (author 07.10: 8000 -> 6000 coupled), so it also applies to runs
    # whose journal was written with a larger number of blocks
    limit = bool(max_iter and rows and rows[-1]['iteration'] >= max_iter)
    write_control(out, stop or limit)
    result = dict(stop_requested=stop, limit_reached=limit and not stop, max_iter=max_iter, complete_reports=len(rows),
                  checked_iteration=rows[-1]['iteration'] if rows else None,
                  required_consecutive=2, includes_yplus=False, limits=STOP_LIMITS,
                  checks=strict_checks(rows[-2], rows[-1]) if len(rows) > 1 else {})
    (Path(out) / 'convergence.json').write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
    return result


def coupled_journal(p, out):
    """Bounded blocks, flushed report files, then a normal case/data save in the caller.

    The runner evaluates previous completed blocks during the next block. A requested
    stop takes effect at the next block boundary; no process interruption is needed.
    """
    n, every = int(p['coupled_iters']), int(p.get('report_every', 500))
    if n < 1 or every < 1:
        raise ValueError('Число итераций и интервал отчёта должны быть положительными.')
    write_control(out, False)
    q = L.fl(out)
    lines = ['/file/stop-transcript'] + list(L.SOLVER_HEADER)
    lines += [f"(rpsetvar 'pressure/cpl-courant-number {float(p['cfl'])})",
              f"(rpsetvar 'pressure-coupled/courant-number {float(p['cfl'])})",
              '(define grs-stop? #f)', '(define grs-completed 0)']
    for idx, start in enumerate(range(0, n, every), 1):
        count = min(every, n-start)
        path = f'{q}/coupled_{idx:05d}.trn'
        lines += [f'(load "{q}/convergence_control.scm")', '(if (not grs-stop?) (begin',
                  f' (ti-menu-load-string "/file/start-transcript \\\"{path}\\\"")',
                  f' (ti-menu-load-string "/solve/iterate {count}")',
                  f' (set! grs-completed (+ grs-completed {count}))',
                  L.REPORT_BLOCK.format(it='grs-completed'),
                  ' (ti-menu-load-string "/file/stop-transcript")',
                  # author 07.10: wait ~15 s after each report so the runner can evaluate it and set the stop
                  # flag before the next block starts (otherwise one extra block of 500 it after convergence)
                  ' (system "ping -n 16 127.0.0.1 > nul")', '))']
    lines += [f'/file/start-transcript "{q}/finish.trn"',
              '(display "GRS_COUPLED_COMPLETED ") (write grs-completed) (newline)',
              '(display "GRS_STOP_REQUESTED ") (write grs-stop?) (newline)']
    return lines
