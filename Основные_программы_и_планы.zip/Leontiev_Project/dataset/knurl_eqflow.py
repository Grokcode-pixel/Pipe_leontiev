"""29.10.2026 — ПЛАН_v3 A2, решение автора D-24: накатка RU 233137 (наружная, шаг патента 4,75 мм, выступ 1,0 мм, t/d 1,4, L 400)
против гладкой трубы ПРИ ОДИНАКОВОМ РАСХОДЕ ДЗВ. Перепад ДЗВ подбирается (2–3 расчёта): первый — по G ∝ √Δp от KS10_A9_19,
дальше — секущая в логарифмах (G ∝ Δp^n). Сначала режим A9_19, затем одно станционное условие (как ST1: газ 0 °C, потребитель
0,6 МПа, магистраль 5,5). Стоп-правило автора: если первые 2 расчёта не сходятся — остановиться и сообщить.
Результаты: runs\\patents\\knurl_eqflow_results.csv, журнал runs\\patents\\a9_log.txt, итог — knurl_eqflow.json."""
import csv, json, math, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import gui_runner as G
import run_a9 as A

R = Path(r'F:\Leontiev_Project\runs')
A.BASE = R / 'patents'
A.CSV, A.AUX = A.BASE / 'knurl_eqflow_results.csv', A.BASE / 'knurl_aux.csv'
A.POINT_LIMIT = 6000
OUTJ = A.BASE / 'knurl_eqflow.json'
TOL = 0.03   # совпадение расхода ДЗВ с гладкой — 3 %
# условия: (имя, магистраль, потребитель, T0 СВЗ, T0 ДЗВ, целевой расход ДЗВ гладкой трубы, источник цели)
COND = (('A9_19', 5.5, 0.59, 13.46, 8.63, 'a9/a9_results.csv', 'A9_19'),
        ('ST1', 5.5, 0.6, 0.0, 0.0, 'station/station_results.csv', 'ST1'))


def target(path, tag):
    return float(next(r for r in csv.DictReader(open(R / path, encoding='utf-8')) if r['tag'] == tag)['G_dzv'])


def result(tag):
    if not A.CSV.exists():
        return None
    r = next((r for r in csv.DictReader(open(A.CSV, encoding='utf-8')) if r['tag'] in (tag, tag + 'h') and r.get('G_dzv')), None)
    return r


def wait_queue():
    import auto_enrich as AE
    while G.fluent_running() or AE._task_running('Leontiev_queue_1029'):
        time.sleep(120)


if __name__ == '__main__':
    wait_queue()
    A.qlog('=== накатка RU 233137 при одинаковом расходе ДЗВ (D-24) — начата')
    summary = json.loads(OUTJ.read_text(encoding='utf-8')) if OUTJ.exists() else {}
    src = A.BASE / 'KS10_A9_19'
    pts = [(11.98, 0.047508)]          # KS10_A9_19: перепад 11,98 кПа → G ДЗВ 0,0475 кг/с (27.10)
    fails = 0
    for cname, pm, pc, ts, td, tpath, ttag in COND:
        Gt = target(tpath, ttag)
        if cname != 'A9_19':
            pts = pts[-2:]          # для нового условия старт — с подобранного перепада A9_19
        A.log(f'=== накатка KS10, условие {cname}: цель — расход ДЗВ гладкой {Gt:.4f} кг/с ({ttag})')
        best = None
        for k in range(1, 4):
            if len(pts) >= 2 and pts[-1][1] != pts[-2][1]:
                (d0, g0), (d1, g1) = pts[-2], pts[-1]
                n = math.log(g1 / g0) / math.log(d1 / d0) if d1 != d0 else 0.5
                n = min(max(n, 0.3), 0.8)
                dp = d1 * (Gt / g1) ** (1 / n)
            else:
                d1, g1 = pts[-1]; dp = d1 * (Gt / g1) ** 2
            dp = round(min(max(dp, 2.0), 300.0), 2)
            tag = f'KQ_{cname}_{k}'
            A.log(f'  {tag}: перепад ДЗВ {dp} кПа (оценка до расчёта)')
            res_dir = A.done_dir(tag)
            if not res_dir:
                start = src
                if abs(dp - pts[-1][0]) > 30:      # большой скачок перепада — промежуточная ступень
                    mid = round(0.5 * (dp + pts[-1][0]), 2)
                    start = A.cont(src / 'result.cas.h5', tag + '_r', (pm, pc, pm, round(pm - mid / 1000, 6)), [], ts, td,
                                   f'накатка: ступень перепада {mid} кПа', A.AUX, limit=1500) or src
                res_dir = A.cont(start / 'result.cas.h5', tag, (pm, pc, pm, round(pm - dp / 1000, 6)), [], ts, td,
                                 f'накатка KS10 при равном расходе ДЗВ ({cname})', A.CSV)
            r = result(tag)
            conv = bool(res_dir) and A.converged(res_dir)
            if not r or not conv:
                fails += 1
                A.log(f'  {tag}: не сошёлся ({fails})')
                if fails >= 2 and best is None:
                    A.qlog('=== накатка: первые 2 расчёта не сошлись — СТОП, нужно решение автора'); sys.exit(1)
                if r:
                    pts.append((dp, float(r['G_dzv'])))
                continue
            g = float(r['G_dzv']); pts.append((dp, g)); src = res_dir
            best = dict(tag=tag, dp=dp, G_dzv=g, G_svz=float(r['G_svz']), Q=float(r['Q']), effect=float(r['dT_svz_vs_throttle']),
                        m=g / float(r['G_svz']), status=r['status'], target=Gt, miss_pct=100 * (g / Gt - 1))
            A.log(f"  {tag}: G ДЗВ {g:.4f} (цель {Gt:.4f}, {best['miss_pct']:+.1f} %), m {best['m']:.3f}, эффект {best['effect']:+.2f} K, Q {best['Q']:.0f} Вт")
            if abs(g / Gt - 1) <= TOL:
                break
        summary[cname] = best
        OUTJ.write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding='utf-8')
    A.qlog('=== накатка при одинаковом расходе ДЗВ — закончена')
