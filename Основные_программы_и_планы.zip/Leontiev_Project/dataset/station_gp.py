"""27.10.2026 — п. 4.3 плана: баланс станции через ГП (суррогат по CFD) и сверка с тремя станционными расчётами Fluent
18.10 (ST1–ST3, в обучение ГП не входят). ГП — та же модель, что model_compare (Matern 2,5 + шум), отдельно для
эффекта, Q, G_СВЗ, G_ДЗВ на трубу; 98 точек (А9 41, набор А 30, добор Б 27). Станция — grs_balance2, вариант (в):
зима 0 °C, потребитель 0,6 МПа, 5000 нм³/ч, 3 трубы, подогреватель после пучка, СПГ (Линде); труба — из трёх
источников: быстрая 1D (калибр.), ГП, CFD станционной точки. Вывод: runs\\balance\\station_gp.md."""
import csv, math, sys
import numpy as np
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import model_compare as MC
import grs_balance2 as B

R = MC.R


def rows():
    """Те же точки, что model_compare.load, но с Q и расходами."""
    X, T = [], []
    import gui_convergence as C
    conv = lambda d: (lambda r: bool(r) and C.decision(r))(C.closed_samples(d))

    def add(d, r):
        X.append([float(d['t_d']), float(d['L_mm']) / 6.6, math.log(float(d['dp_dzv_kPa'])), float(d['p_cons']),
                  float(d['t0_dzv']), float(d.get('heater') or 0.0), float(d.get('p_main') or 5.5)])
        T.append([float(r['dT_svz_vs_throttle']), float(r['Q']), float(r['G_svz']), float(r['G_dzv'])])
    D = {p['id']: p for p in csv.DictReader(open(R / 'a9/a9_design.csv', encoding='utf-8'))}
    RR = {r['tag']: r for r in csv.DictReader(open(R / 'a9/a9_results.csv', encoding='utf-8'))}
    for s in csv.DictReader(open(R / 'a9/a9_points_status.csv', encoding='utf-8')):
        if s['num_status'] == 'сошлась' and s['id'] not in ('A9_11', 'A9_35', 'A9_36'):
            add(D[s['id']], RR[s['result']])
    for ser, des, resf in (('setA', 'setA_design.csv', 'setA_results.csv'), ('setB', 'setB_design.csv', 'setB_results.csv')):
        DD = {p['id']: p for p in csv.DictReader(open(R / ser / des, encoding='utf-8'))}
        RR = {r['tag']: r for r in csv.DictReader(open(R / ser / resf, encoding='utf-8'))}
        for pid, d in DD.items():
            if d.get('set') == 'отложенная':
                continue
            for t in (pid + 'cc', pid + 'c', pid):
                if t in RR and conv(R / ser / t):
                    add(d, RR[t]); break
    if MC.STATION:   # 27.10 18:20 (К3): ST4–ST12 в обучении; ST1–ST3 — проверка
        for x, r, geo in MC.station_points():
            X.append(list(x))
            T.append([float(r['dT_svz_vs_throttle']), float(r['Q']), float(r['G_svz']), float(r['G_dzv'])])
    for p in MC.frozen_extra():   # 01.11 (D-32, D-33): добор В из окончательной заморозки
        X.append(list(p['x'])); T.append([float(p['effect']), float(p['Q']), float(p['G_svz']), float(p['G_dzv'])])
    return np.array(X), np.array(T)


X, T = rows()
lo, hi = X.min(0), X.max(0)
Z = lambda A: (A - lo) / np.where(hi > lo, hi - lo, 1)
GP = [MC.gp_fit(Z(X), T[:, j]) for j in range(4)]
ST = {r['tag']: r for r in csv.DictReader(open(R / 'station/station_results.csv', encoding='utf-8'))}
CASES = (('ST1', 1.4, 400, 10.0, 5.5), ('ST2', 1.4, 400, 10.0, 4.0), ('ST3', 1.2, 660, 105.0, 5.5))
# 27.10: ST4 — магистраль 3,0 МПа, вдали от обучающих точек (run_station_lowp.py), прогноз ГП записан до расчёта
if 'ST4' in ST:
    CASES += (('ST4', 1.4, 400, 10.0, 3.0),)


def n_tubes(c, pm):
    """27.10 12:00: число труб — правило grs_balance2.n_rule (целая часть расхода станции / расход трубы по Fluent,
    остаток — через дроссель); одно для всех источников трубы этой точки. Было: n = 3 для всех точек (ST3 при n = 3
    пропускал 0,99 кг/с > отпуска — «несоответствие расхода» было ошибкой балансового расчёта, а не Fluent)."""
    return B.n_rule(B.Station(p_main=pm, T_main=0.0, p_cons=0.6), c['G_svz'], c['G_dzv'])


def gp_tube(td, L, dp, pm):
    x = Z(np.array([[td, L / 6.6, math.log(dp), 0.6, 0.0, 0.0, pm]]))
    out = [g.predict(x, return_std=True) for g in GP]
    eff, Q, Gs, Gd = (float(o[0][0]) for o in out)
    return dict(effect_K=eff, Q=Q, G_svz=Gs, G_dzv=Gd, m=Gd / Gs, working=True), [float(o[1][0]) for o in out]


def cfd_tube(r):
    return dict(effect_K=float(r['dT_svz_vs_throttle']), Q=float(r['Q']), G_svz=float(r['G_svz']), G_dzv=float(r['G_dzv']),
                m=float(r['G_dzv']) / float(r['G_svz']), working=not r.get('x_shock_m'))


def station(tube, pm, n=3):
    st = B.Station(p_main=pm, T_main=0.0, p_cons=0.6, T_min=-10.0)
    bd = B.Bundle(td=1.4, L_mm=400, dp_kPa=10, n_on=n, heater_place='после', lng=True)
    B.tube = lambda bd_, st_, heat: tube
    v, a = B.var_v(st, bd), B.var_a(st)
    return a['Q_heater_kW'], v['Q_heater_kW'], v['lng_kgh']


if __name__ == '__main__':
    L = ['# Баланс станции через ГП и сверка со станционными расчётами Fluent (18.10)', '',
         f'ГП обучен на {len(X)} точках CFD; ST1–ST4 в обучение не входят. Станция: зима 0 °C, потребитель 0,6 МПа, 5000 нм³/ч, '
         '3 трубы (2 — если три пропускают больше отпуска станции), подогреватель после пучка, СПГ (Линде, недогрев 5 K); без пучка (а) — дроссель + подогреватель.', '',
         '## Труба: прогноз против расчёта Fluent', '',
         '| Точка | источник | эффект, K | Q трубы, Вт | G СВЗ, кг/с | G ДЗВ, кг/с | m |', '|---|---|---|---|---|---|---|']
    tubes = {}
    for tag, td, Lmm, dp, pm in CASES:
        c = cfd_tube(ST[tag])
        g, s = gp_tube(td, Lmm, dp, pm)
        tubes[tag] = {'Fluent': c, 'ГП': g}
        L.append(f"| {tag} | Fluent | {c['effect_K']:+.2f} | {c['Q']:.0f} | {c['G_svz']:.4f} | {c['G_dzv']:.4f} | {c['m']:.3f} |")
        L.append(f"| {tag} | ГП ± σ | {g['effect_K']:+.2f} ± {s[0]:.2f} | {g['Q']:.0f} ± {s[1]:.0f} ({100 * (g['Q'] / c['Q'] - 1):+.0f} %) | "
                 f"{g['G_svz']:.4f} | {g['G_dzv']:.4f} ({100 * (g['G_dzv'] / c['G_dzv'] - 1):+.0f} %) | {g['m']:.3f} |")
        if pm == 5.5:
            f = B.F.run(td, Lmm, dp, 0.6, 0.0, 0.0, par=B.CALIB)
            tubes[tag]['1D'] = f
            L.append(f"| {tag} | быстрая 1D | {f['effect_K']:+.2f} | {f['Q']:.0f} ({100 * (f['Q'] / c['Q'] - 1):+.0f} %) | {f['G_svz']:.4f} | "
                     f"{f['G_dzv']:.4f} ({100 * (f['G_dzv'] / c['G_dzv'] - 1):+.0f} %) | {f['m']:.3f} |")
    L += ['', '## Станция: подогреватель и СПГ (число труб — по правилу, одно для всех источников; «было» — 3 трубы)', '',
          '| Точка | труб | источник трубы | подогреватель без пучка (а), кВт | с пучком (в), кВт | СПГ, кг/ч | было (3 трубы): (в), кВт / СПГ, кг/ч |',
          '|---|---|---|---|---|---|---|']
    for tag, td, Lmm, dp, pm in CASES:
        n = n_tubes(tubes[tag]['Fluent'], pm)
        for src, tube in tubes[tag].items():
            try:
                qa, qv, lng = station(tube, pm, n)
                row = f'| {tag} | {n} | {src} | {qa:.1f} | {qv:.1f} | {lng:.1f} |'
            except ValueError as e:
                row = f'| {tag} | {n} | {src} | — | — | {e} |'
            try:
                _, qv3, lng3 = station(tube, pm, 3)
                row += f' {qv3:.1f} / {lng3:.1f} |'
            except ValueError:
                row += ' не проходит |'
            L.append(row)
    (R / 'balance/station_gp.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
    print('\n'.join(L))
