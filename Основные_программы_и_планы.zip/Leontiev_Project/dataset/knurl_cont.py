"""02.11.2026 — следующий этап после контрольной точки D0/D1 (задание автора, D-37): продолжение из готового поля ТОЙ ЖЕ геометрии.
W1 h 0,1 / s 2 — KM01_eq1c (14,91 кПа) → 18,9 кПа (сравнение с принятой KS1_01; сеточные паспорта сверяются);
W2 h 0,3 / s 2 — KM03r_eq1c (28,93 кПа) → 28,1 кПа (точка, до которой холодный старт KS1_02 не дошёл);
W3 h 1,0 / s 4,75 — KQ_A9_19_1 (87,99 кПа) → 87,99 кПа на исходной сетке (осевой шаг 1,0 мм) — повторяемость, не новая точка датасета.
Продолжение: родная пара case+data источника (result.cas.h5 / result.dat.h5) читается как есть — без инициализации, FMG, идеального
газа и интерполяции; геометрия, сетка, материалы, метан ПР, второй порядок (заголовок связанного решателя) — как в источнике;
меняются только объявленные граничные условия. Лимит — LIMIT итераций (записан в плане), одна попытка, без продления.
Стоп: первый технический срыв или непринятое качество (ни критерии, ни D-12a) — BLOCK.json, код 3, разбор. Устойчивый физически
нерабочий режим — записывается отдельно (результат исследования, не подтверждение рабочей рекомендации), серия идёт дальше.
HOLD (runs\\knurl_cont\\HOLD) — ожидание перед пробой; «стоп» — код 3 + BLOCK.
Исполнение — только по зарегистрированному плану runs\\plans\\накатка_продолжение_1102.json (SHA256 в .sha256; хеши кода и case/data
источников внутри).  python knurl_cont.py plan | check | run | report"""
import csv, hashlib, json, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')

R = Path(r'F:\Leontiev_Project\runs')
D = Path(r'F:\Leontiev_Project\dataset')
P = R / 'patents'
OUT = R / 'knurl_cont'
PLAN = R / 'plans' / 'накатка_продолжение_1102.json'
SHA = PLAN.with_suffix('.sha256')
LIMIT = 6000
TS, TD, PM, PC = 13.46, 8.63, 5.5, 0.59
CRIT_W3 = dict(effect_K=0.1, Q_pct=2.0, G_dzv_pct=2.0)
CODE = ['knurl_cont.py', 'cont_util.py', 'run_a9.py', 'knurl_shallow_retry.py', 'knurl_shallow.py', 'job_point.py', 'gui_convergence.py',
        'd12a.py', 'leontiev_pipeline.py', 'knurl_diag.py']
# tpl — шаблон, на сетке которого получено поле источника (цепочки: KM01_eq1c ← KM01_eq1 ← KM01_A9_19 ← KM01_A9_19_tpl;
# KM03r_eq1c ← KM03r_eq1 ← KM03r ← KM03r_tpl; KQ_A9_19_1 ← KQ_A9_19_1_r ← KS10_A9_19 ← KS10_A9_19_tpl) — продолжения сетку не меняют
WS = [dict(tag='W1', src='KM01_eq1c', tpl='KM01_A9_19_tpl', h=0.1, s=2.0, w=0.67, dp_from=14.91, dp=18.9,
           why='продолжение при смене режима; сравнение с KS1_01 (холодный старт, принята)', compare='KS1_01'),
      dict(tag='W2', src='KM03r_eq1c', tpl='KM03r_tpl', h=0.3, s=2.0, w=0.67, dp_from=28.93, dp=28.1, why='целевая точка, до которой холодный старт KS1_02 не дошёл'),
      dict(tag='W3', src='KQ_A9_19_1', tpl='KS10_A9_19_tpl', h=1.0, s=4.75, w=1.6, dp_from=87.99, dp=87.99,
           why='сохранение патентного решения на исходной сетке (осевой шаг 1,0 мм) — повторяемость', compare='KQ_A9_19_1')]


def sha(f):
    h = hashlib.sha256()
    with open(f, 'rb') as fo:
        for b in iter(lambda: fo.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest().upper()


def load(f):
    return json.loads(Path(f).read_text(encoding='utf-8')) if Path(f).exists() else {}


def save(f, d):
    Path(f).parent.mkdir(parents=True, exist_ok=True)
    Path(f).write_text(json.dumps(d, ensure_ascii=False, indent=1, default=float), encoding='utf-8')


def journal(s):
    with open(r'F:\Leontiev_Project\Журнал_работ.md', 'a', encoding='utf-8') as f:
        f.write(f"- {time.strftime('%d.%m.%Y %H:%M')} — продолжение накатки (D-37): {s}\n")


def reg(dp):
    return (PM, PC, PM, round(PM - dp / 1000, 6))


def mesh_passport(tpl_dir):
    """Сетка расчёта по папке шаблона / стадии с params.json (run_id → dataset\\variants): ячейки, осевой шаг, выступ, хеш mesh.msh."""
    pj = load(Path(tpl_dir) / 'params.json')
    name = Path(tpl_dir).name
    if not pj:
        return dict(template=name, note='params.json шаблона не найден')
    msh = D / 'variants' / pj['run_id'] / 'mesh.msh'
    return dict(template=name, run_id=pj['run_id'], axial_mm=pj.get('axial_size_mm'), knurl=pj.get('knurl_dzv'),
                cells=load(msh.with_name('mesh_result.json')).get('elements'), mesh_sha256=sha(msh) if msh.exists() else None)


def make_plan():
    import d12a, gui_convergence as C
    if PLAN.exists():
        sys.exit(f'{PLAN} уже есть — не перезаписываю')
    pts = []
    for w in WS:
        d = P / w['src']
        rows = C.closed_samples(d)
        e = d12a.evaluate(d)
        pts.append(dict(w, src_dir=str(d), src_case_sha256=sha(d / 'result.cas.h5'), src_data_sha256=sha(d / 'result.dat.h5'),
                        src_quality=dict(criteria=bool(rows) and C.decision(rows), d12a=e.get('ok'), effect=e.get('effect'), Q=e.get('Q'), G_dzv=e.get('G_dzv')),
                        mesh=mesh_passport(P / w['tpl']), target=dict(regime=reg(w['dp']), T0_svz=TS, T0_dzv=TD, gas='метан ПР (как в источнике)', limit=LIMIT)))
    ks1 = R / 'knurl_ds' / 'KS1_01_s_ideal'
    plan = dict(name='накатка_продолжение_1102', made=time.strftime('%d.%m.%Y %H:%M:%S'), decision='следующий этап после D0/D1 (задание автора 02.11, D-37)',
                method='родная пара case+data источника, без инициализации / FMG / идеального газа / интерполяции; меняются только ГУ (давления ДЗВ)',
                points=pts, limit=LIMIT, crit_W3=CRIT_W3, KS1_01_mesh=mesh_passport(ks1) if ks1.exists() else None,
                stop='первый технический срыв или непринятое качество → BLOCK.json, код 3; устойчивый нерабочий режим — записать отдельно, серия идёт',
                accept='критерии или D-12a на целевом режиме', code_sha256={c: sha(D / c) for c in CODE})
    txt = json.dumps(plan, ensure_ascii=False, indent=1, default=float)
    PLAN.write_text(txt, encoding='utf-8')
    h = hashlib.sha256(txt.encode('utf-8')).hexdigest().upper()
    SHA.write_text(h, encoding='utf-8')
    journal(f'план W1–W3 записан ДО запуска: {PLAN}, SHA256 {h}; лимит {LIMIT} итераций; источники: ' +
            ', '.join(f"{q['tag']} ← {q['src']} (D-12a {q['src_quality']['d12a']}, сетка {q['mesh'].get('run_id')}, {q['mesh'].get('cells')} ячеек)" for q in pts))
    return h


def registered():
    txt = PLAN.read_text(encoding='utf-8')
    if hashlib.sha256(txt.encode('utf-8')).hexdigest().upper() != SHA.read_text(encoding='utf-8').strip():
        raise RuntimeError('SHA256 плана не совпадает с записанным')
    plan = json.loads(txt)
    bad = [c for c, h in plan['code_sha256'].items() if sha(D / c) != h]
    if bad:
        raise RuntimeError(f'код изменён после регистрации: {bad}')
    return plan


def setup():
    import job_point as JP
    A = JP.setup(dict(tube='накатка', base=str(OUT), csv='knurl_cont_results.csv'))
    import knurl_shallow_retry as KR
    return A, KR


def journal_lines(A, w):
    """Строки журнала продолжения без запуска Fluent (крючок JOU_HOOK перехватывает и прерывает до запуска)."""
    U, got = A.U, {}

    class _Stop(Exception):
        pass

    def hook(lines):
        got['lines'] = list(lines); raise _Stop()
    U.JOU_HOOK, lim0 = hook, U.LIMIT
    U.LIMIT = LIMIT
    try:
        U.continue_case(Path(w['src_dir']) / 'result.cas.h5', OUT / '_check' / w['tag'], [], tuple(w['target']['regime']), lambda s: None, w['tag'],
                        t0_C=TS, t0_dzv_C=TD)
    except _Stop:
        pass
    finally:
        U.JOU_HOOK, U.LIMIT = None, lim0
    return got.get('lines', [])


def check_lines(lines, w):
    t = '\n'.join(lines)
    reg_ = w['target']['regime']
    bad = [k for k in ('initialize', 'interpolate', 'fmg', 'ch4_ideal', 'change-create air air') if k in t.lower()]
    need = [f'/file/read-case-data "{Path(w["src_dir"]).as_posix()}/result.cas.h5"'.replace('/', '/'),
            f'outlet_dzv definition "{reg_[3] * 1e6:.6g} [Pa]"', f'pressure_inlet_dzv definition "{reg_[2] * 1e6:.6g} [Pa]"',
            "(rpsetvar 'mom/scheme 1)", "(rpsetvar 'temperature/scheme 1)", "(rpsetvar 'k/scheme 1)", "(rpsetvar 'omega/scheme 1)"]
    miss = [n for n in need[1:] if n not in t]
    src_ok = 'read-case-data' in t and Path(w['src_dir']).name in t
    import re
    iters = sum(int(n) for n in re.findall(r'/solve/iterate (\d+)', t))
    return dict(forbidden=bad, missing=miss, reads_source=src_ok, iterations=iters, ok=not bad and not miss and src_ok and iters == LIMIT)


def check():
    plan = registered()
    A, KR = setup()
    rep = {}
    for w in plan['points']:
        q = dict(case=sha(Path(w['src_dir']) / 'result.cas.h5') == w['src_case_sha256'], data=sha(Path(w['src_dir']) / 'result.dat.h5') == w['src_data_sha256'])
        c = check_lines(journal_lines(A, w), w)
        rep[w['tag']] = dict(source_hashes=q, journal=c)
        print(w['tag'], 'источник case/data совпадает:', q, '| журнал:', c)
    save(OUT / 'check.json', rep)
    return rep


def hold_wait(tag):
    f, told = OUT / 'HOLD', False
    while f.exists():
        if 'стоп' in f.read_text(encoding='utf-8', errors='ignore').lower():
            return False
        if not told:
            journal(f'HOLD перед {tag} — жду снятия'); told = True
        time.sleep(60)
    return True


def block(why):
    save(OUT / 'BLOCK.json', dict(why=why, time=time.strftime('%d.%m.%Y %H:%M:%S')))
    journal(f'СТОП: {why} — BLOCK.json, разбор'); sys.exit(3)


def run():
    import d12a
    plan = registered()
    A, KR = setup()
    if (OUT / 'BLOCK.json').exists():
        journal(f"run не начат: BLOCK.json ({load(OUT / 'BLOCK.json').get('why')})"); sys.exit(3)
    res = load(OUT / 'results.json')
    for w in plan['points']:
        tag = w['tag']
        if res.get(tag, {}).get('done'):
            continue
        if not hold_wait(tag):
            block(f'HOLD «стоп» перед {tag}')
        if sha(Path(w['src_dir']) / 'result.cas.h5') != w['src_case_sha256'] or sha(Path(w['src_dir']) / 'result.dat.h5') != w['src_data_sha256']:
            block(f'{tag}: case/data источника изменились после регистрации')
        c = check_lines(journal_lines(A, w), w)
        if not c['ok']:
            block(f'{tag}: журнал продолжения не соответствует плану: {c}')
        KR.K.KN.update(dzv=w['h'], svz=None, pitch=w['s'], width=w['w'])
        A.log(f"=== {tag}: продолжение {w['src']} ({w['dp_from']} → {w['dp']} кПа), лимит {LIMIT}, одна попытка; {w['why']}")
        t0 = time.time()
        A.set_step(A.CONS)
        A.U.LIMIT = LIMIT
        out = OUT / tag
        try:
            mins = A.U.continue_case(Path(w['src_dir']) / 'result.cas.h5', out, [], tuple(w['target']['regime']), A.log, tag, t0_C=TS, t0_dzv_C=TD)
            A.U.record(A.CSV, tag, 'work_v2', 'ch4_pr', tuple(w['target']['regime']), out, mins, A.log, start=f"продолжение {w['src']} (D-37)",
                       t0_C=TS, t0_dzv_C=TD, l_heat_mm=400.0)
            d = out if A.ok(out) else None
        except Exception as ex:
            A.log(f'  {tag}: ОШИБКА программы {ex!r}'); d = None
        e = d12a.evaluate(d) if d else {}
        conv = bool(d) and A.converged(d)
        ok = bool(d) and (conv or bool(e.get('ok')))
        row = next((r for r in reversed(list(csv.DictReader(open(A.CSV, encoding='utf-8')))) if r['tag'] == tag), None) if A.CSV.exists() else None
        res[tag] = dict(done=True, ok=ok, converged=conv, d12a=e.get('ok'), folder=str(d) if d else None, hours=round((time.time() - t0) / 3600, 2),
                        regime=w['target']['regime'], gas='метан ПР (из источника)', effect=e.get('effect'), Q=e.get('Q'), G_dzv=e.get('G_dzv'), G_svz=e.get('G_svz'),
                        m=(e['G_dzv'] / e['G_svz']) if e.get('G_dzv') and e.get('G_svz') else None,
                        status=(row or {}).get('status'), reason=(row or {}).get('reason'), shock=(row or {}).get('x_shock_m') or None,
                        M_outlet=(row or {}).get('M_outlet'), reversed_pct=(row or {}).get('reversed_max_pct'), iter=(row or {}).get('iter'),
                        working=bool(row and str(row.get('status', '')).endswith('рабочий') and not str(row.get('status', '')).endswith('нерабочий')),
                        mesh=w['mesh'], finished=time.strftime('%d.%m.%Y %H:%M:%S'))
        save(OUT / 'results.json', res)
        r = res[tag]
        journal(f"{tag}: {'принята' if ok else 'НЕ принята'} ({r['status']}; {r['reason']}); {r['hours']} ч" +
                (f"; Q {r['Q']:.0f} Вт, G ДЗВ {r['G_dzv']:.4f}, эффект {r['effect']:+.2f} K, m {r['m']:.3f}" if r.get('Q') else ''))
        if not ok:
            block(f'{tag}: технический срыв или непринятое качество ({r["status"]})')
    report()


def report():
    import knurl_diag as KG
    res = load(OUT / 'results.json')
    L = [f'# Продолжение из готового поля той же геометрии — W1–W3 ({time.strftime("%d.%m.%Y %H:%M")})', '',
         '| проба | источник и сетка | изменения | конечный режим | качество | физический статус | Q, Вт / G СВЗ, G ДЗВ, кг/с / эффект, K / m | время, ч |',
         '|---|---|---|---|---|---|---|---|']
    for w in WS:
        r = res.get(w['tag'], {})
        mp = r.get('mesh') or {}
        L.append(f"| {w['tag']} | {w['src']}; сетка {mp.get('run_id')} ({mp.get('cells')} яч., осевой {mp.get('axial_mm')} мм) | перепад ДЗВ {w['dp_from']} → {w['dp']} кПа |"
                 f" {r.get('regime')} ПР | {'критерии' if r.get('converged') else 'D-12a' if r.get('d12a') else 'не принята' if r.get('done') else '—'} |"
                 f" {r.get('status')} ({r.get('reason')}); обратный ток {r.get('reversed_pct')} % |"
                 + (f" {r['Q']:.0f} / {r['G_svz']:.4f}, {r['G_dzv']:.4f} / {r['effect']:+.3f} / {r['m']:.3f} |" if r.get('Q') else ' — |') + f" {r.get('hours')} |")
    # W1 против KS1_01 — сначала сетки
    plan = load(PLAN)
    w1, ks = res.get('W1', {}), load(R / 'knurl_ds' / 'results.json').get('KS1_01', {})
    m1, mk = (w1.get('mesh') or {}), (plan.get('KS1_01_mesh') or {})
    same_mesh = bool(m1.get('mesh_sha256')) and m1.get('mesh_sha256') == mk.get('mesh_sha256')
    L += ['', f"W1 против KS1_01: сетки {'одинаковы (хеш)' if same_mesh else 'РАЗНЫЕ'} — {m1.get('run_id')} {m1.get('cells')} яч. / {mk.get('run_id')} {mk.get('cells')} яч.; "
              + ('разность результатов нельзя приписать только способу запуска; ' if not same_mesh else '')
              + (f"Q {w1['Q']:.0f} / {ks.get('Q', float('nan')):.0f} Вт, G ДЗВ {w1['G_dzv']:.4f} / {ks.get('G_dzv', float('nan')):.4f}, эффект {w1['effect']:+.3f} / {ks.get('effect', float('nan')):+.3f} K"
                 if w1.get('Q') else 'W1 нет результата')]
    # W3 против опоры — допуски записаны в плане
    w3 = res.get('W3', {})
    if w3.get('folder'):
        a, b = KG.summary(P / 'KQ_A9_19_1', 'опора'), KG.summary(Path(w3['folder']), 'W3')
        rows = []
        for k, tol, pct in (('effect', CRIT_W3['effect_K'], False), ('Q', CRIT_W3['Q_pct'], True), ('G_dzv', CRIT_W3['G_dzv_pct'], True)):
            dv = None if a.get(k) is None or b.get(k) is None else ((b[k] / a[k] - 1) * 100 if pct else b[k] - a[k])
            rows.append((k, a.get(k), b.get(k), dv, tol, dv is not None and abs(dv) <= tol))
        both = a['quality'] != 'не принята' and b['quality'] != 'не принята'
        passed = both and all(x[5] for x in rows)
        L += ['', 'W3 против опоры KQ_A9_19_1 (та же сетка, осевой шаг 1,0 мм; повторяемость, не сеточная независимость):', '',
              '| величина | опора | W3 | отклонение | допуск | выполнено |', '|---|---|---|---|---|---|']
        L += [f"| {k} | {va if va is None else round(va, 5)} | {vb if vb is None else round(vb, 5)} | {'—' if dv is None else round(dv, 3)} | {tol} | {'да' if okk else 'нет'} |"
              for k, va, vb, dv, tol, okk in rows]
        L += ['', f"Качество: опора {a['quality']}, W3 {b['quality']}; усреднение: {a['how']} / {b['how']}. **{'Сохранение решения подтверждено' if passed else 'НЕ подтверждено'}.**"]
        res['W3_сравнение'] = dict(rows=rows, passed=passed, both_ok=both)
        save(OUT / 'results.json', res)
    (OUT / 'W1_W3_итог.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
    print('\n'.join(L))


if __name__ == '__main__':
    {'plan': lambda: print(make_plan()), 'check': check, 'run': run, 'report': report}[sys.argv[1]]()
