"""29.10.2026 — сверка данных (решение автора п. 6; после потери 21 точки из-за метки AUxxc): по каждому источнику — сколько
расчётов есть в файлах, сколько сошлось (критерии проекта по convergence) и сколько попало в обучение (model_compare.load).
Плюс A5 — калибровка σ: доля фактов в ±1σ и ±2σ (отложенные 5–6 — ГП без них; журнал и автопополнение — прогноз до расчёта).
Вывод: runs\\models\\data_audit.md."""
import csv, json, math, sys
from collections import Counter
from pathlib import Path
import numpy as np
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import model_compare as MC
import gui_convergence as C

R = MC.R
conv = lambda d: (lambda rr: bool(rr) and C.decision(rr))(C.closed_samples(d)) if Path(d).exists() else False
X, y, w, g, src = MC.load()
train = Counter(src)
L = ['# Сверка данных и калибровка σ (29.10.2026)', '', '## Сколько расчётов в файлах, сколько сошлось, сколько в обучении', '',
     '| источник | точек плана / расчётов | сошлось (критерии проекта) | в обучении | разница и почему |', '|---|---|---|---|---|']
st = list(csv.DictReader(open(R / 'a9/a9_points_status.csv', encoding='utf-8')))
a9c = [s for s in st if s['num_status'] == 'сошлась']
L.append(f"| А9 | {len(st)} | {len(a9c)} | {train['А9']} | исключены A9_11, A9_35, A9_36 (решение 16.10) |")
for ser, des in (('setA', 'setA_design.csv'), ('setB', 'setB_design.csv')):
    D = list(csv.DictReader(open(R / ser / des, encoding='utf-8')))
    held = [d for d in D if d.get('set') == 'отложенная']
    cc = sum(any(conv(R / ser / t) for t in (d['id'] + 'cc', d['id'] + 'c', d['id'])) for d in D if d.get('set') != 'отложенная')
    hc = sum(any(conv(R / ser / t) for t in (d['id'] + 'cc', d['id'] + 'c', d['id'])) for d in held)
    name = 'набор А' if ser == 'setA' else 'добор Б'
    L.append(f"| {name} | {len(D)} (отложенных {len(held)}) | {cc} (+ отложенных {hc}) | {train[ser]} | "
             f"{'отложенные — только проверка' if held else ''}{'; ' if held and cc != train[ser] else ''}"
             f"{'' if cc == train[ser] else f'расхождение {cc - train[ser]}'} |")
sp = MC.station_points()
tags = [r['tag'] for _, r, _ in sp]
stt = [t for t in tags if t.startswith('ST')]
au = [t for t in tags if t.startswith('AU') and not t.endswith('c')]
auc = [t for t in tags if t.startswith('AU') and t.endswith('c')]
fc = json.loads((R / 'journal/auto_forecasts.json').read_text(encoding='utf-8'))
RR = {r['tag']: r for r in csv.DictReader(open(R / 'station/auto_results.csv', encoding='utf-8'))}
au_conv = sum(conv(R / 'station' / t) for t in fc)
auc_all = [t + 'c' for t in fc if t + 'c' in RR]
auc_conv = sum(conv(R / 'station' / t) for t in auc_all)
L.append(f"| станция ST4–ST13 | 10 (ST9 не сошёлся; ST1–ST3 — проверка) | — | {len(stt)} | ST1–ST3 не в обучении (проверка станции) |")
L.append(f"| автопополнение AU01–AU60 | {len(fc)} | {au_conv} | {len(au)} | |")
L.append(f"| досчёт группы «б» (AUxxc) | {len(auc_all)} | {auc_conv} | {len(auc)} | |")
L.append(f"| **всего в обучении** | | | **{len(y)}** | рабочих {int(w.sum())}, со скачком {int(len(w) - w.sum())} |")
L.append('| накатка, RU 2836642, A3a, опыт 2017 | — | — | 0 | другие конструкции / независимая проверка — в обучение не идут по плану |')

# --- A5: калибровка σ на отложенных 5–6 (ГП без них) и по прогнозам до расчёта
import heldout_check as H
lo, hi = X.min(0), X.max(0); Z = lambda A: (A - lo) / np.where(hi > lo, hi - lo, 1)
gp = MC.gp_fit(Z(X), y)
mu, sd = gp.predict(Z(H.Xh), return_std=True)
z = np.abs(mu - H.yh) / sd
rows = [('отложенные геометрии 5–6 (ГП на всех остальных)', z)]
# прогнозы до расчёта: журнал (ST4–ST13c) и автопополнение (сошедшиеся AU / AUxxc)
J = []
for f, res in (('forecasts.json', 'station_results.csv'), ('window_forecasts.json', 'window0_results.csv'), ('task2_forecast.json', 'task2_results.csv')):
    fj = json.loads((R / 'journal' / f).read_text(encoding='utf-8'))
    rr = {r['tag']: r for r in csv.DictReader(open(R / 'station' / res, encoding='utf-8'))}
    items = [(fj['tag'] + 'c', fj)] if 'tag' in fj else list(fj.items())
    for t, v in items:
        if t in rr and conv(R / 'station' / t):
            J.append(abs(v['effect_K'] - float(rr[t]['dT_svz_vs_throttle'])) / v['sigma_K'])
ST4 = json.loads((R / 'station/ST4_forecast.json').read_text(encoding='utf-8'))
J.append(abs(ST4['gp']['effect_K'] - 2.901) / ST4['sigma']['effect_K'])
rows.append(('журнал решений (прогноз до расчёта, ST4–ST13c)', np.array(J)))
A_ = []
for t, v in fc.items():
    for tt in (t, t + 'c'):
        if tt in RR and conv(R / 'station' / tt):
            A_.append(abs(v['effect_K'] - float(RR[tt]['dT_svz_vs_throttle'])) / v['sigma_K']); break
rows.append(('автопополнение (прогноз до расчёта, сошедшиеся AU)', np.array(A_)))
L += ['', '## A5: калибровка σ (доля фактов в ±1σ и ±2σ; для нормального распределения 68 % и 95 %)', '',
      '| выборка | точек | в ±1σ | в ±2σ | медиана |ошибка|/σ |', '|---|---|---|---|---|']
for name, zz in rows:
    L.append(f'| {name} | {len(zz)} | {100 * np.mean(zz <= 1):.0f} % | {100 * np.mean(zz <= 2):.0f} % | {np.median(zz):.2f} |')
allz = np.concatenate([r[1] for r in rows])
k68 = float(np.quantile(allz, 0.68)); k95 = float(np.quantile(allz, 0.95))
L += ['', f'Все вместе: {len(allz)} точек, в ±1σ {100 * np.mean(allz <= 1):.0f} %, в ±2σ {100 * np.mean(allz <= 2):.0f} %. '
      f'Множитель к σ, чтобы покрытие было 68 % / 95 %: {k68:.2f} / {k95 / 2:.2f}.']
(R / 'models/data_audit.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
print('\n'.join(L))
