"""Night 12->13.10.2026.  The global pseudo time step with the CONSERVATIVE length scale passed the check on the
experiment point a5v3_m075e (00:05: dTh 3.918 vs 3.930 K, dTc -5.231 vs -5.232 K, Q 188.5 = 188.5 W, G_dzv equal;
converged by auto-stop in 41 min).  Queue (all stages: pseudo-transient, global step, Conservative, x1):
1) second check on the experiment point a5v3_m030i (m 0.26);
2) pilot point a to convergence from cell_a_t12_m03_p03_p7 (same DZV drop 4.33 kPa);
3) pilot point b (t/d 1.6) by field transfer from cell_c_t14_m10_p03_pg, DZV drop 5 kPa FIXED (author 12.10: the drop is
   the factor, m is recorded) — no correction;
4) start-independence test (review): point e (t/d 1.4, p 1.2, drop 0.83 kPa) from SCRATCH (ideal methane -> PR) to compare
   with diag_e_pseudoglobal (from the neighbour: m 0.200, Q 587.3 W, effect +1.60 K)."""
import sys, time, traceback
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_diag_d2 as D2
import leontiev_pipeline as L
import run_a5v3b6 as B6
import cont_util as U
import gui_runner as G
F, P, log = D2.F, D2.P, D2.log
B, A = B6.B, B6.A
U.NPROC, U.CFL = 7, 20.0
CONS = '/solve/set/pseudo-time-method/global-time-step-settings yes 1 1 yes 1'
L.SOLVER_HEADER[L.SOLVER_HEADER.index(next(x for x in L.SOLVER_HEADER if 'global-time-step-settings' in x))] = CONS


def a5_check():
    U.LIMIT = 3000
    src, tag, pod = 'a5v3_m030i', 'a5v3_m030i_pgcons', round(B.P0 - B.DP0[0.30], 6)
    A.log('=== ночь 12→13.10: вторая проверка глобального псевдошага (Conservative) на точке сверки m030i')
    mins = U.continue_case(A.BASE / src / 'result.cas.h5', A.BASE / tag, A.TMF_OFF, (B.P0, 0.1, B.P0, pod), A.log, tag,
                           t0_C=A.T0_C)
    r = U.record(A.CSV, tag, 'rig_work_v2', 'air', (B.P0, 0.1, B.P0, pod), A.BASE / tag, mins, A.log,
                 start=f'продолжение {src} (глобальный псевдошаг, Conservative)', t0_C=A.T0_C, l_heat_mm=700.0)
    r0 = B6.rows_of(src)
    for k in ('dT_svz_total', 'dT_dzv_total', 'Q', 'G_dzv'):
        try:
            A.log(f'  сравнение {k}: CFL 5 {float(r0[k]):.4f} / глобальный шаг {float(r[k]):.4f} (разница {float(r[k]) - float(r0[k]):+.4f})')
        except Exception:
            pass


def point_a():
    U.LIMIT = 5000
    F.cont(P.BASE / 'cell_a_t12_m03_p03_p7' / 'result.cas.h5', 'cell_a_t12_m03_p03_pg', (5.5, 0.3, 5.5, 5.495674), [], None,
           'продолжение cell_a_t12_m03_p03_p7 (глобальный псевдошаг)')


def point_b():
    U.LIMIT = 5000
    tag, td, pout, dp = 'cell_b_t16_dp5_p03', 1.6, 0.3, 0.005
    tpl, _ = F.template(tag, td, pout)
    ip = P.BASE / 'ip' / 'cell_c_t14_m10_p03_pg.ip'
    ip.parent.mkdir(exist_ok=True)
    if not tpl.exists() or not (ip.exists() or F.write_ip('cell_c_t14_m10_p03_pg', ip)):
        return log(f'  {tag}: нет шаблона или файла переноса')
    reg = (5.5, pout, 5.5, round(5.5 - dp, 5))
    F.cont(tpl, f'{tag}_pg', reg, list(L.CH4_PR_LINES) + F.interp_lines(ip, reg[3]), None,
           'перенос поля cell_c_t14_m10_p03_pg на сетку t/d 1,6; перепад ДЗВ 5 кПа (фактор), глобальный псевдошаг')


def point_e_scratch():
    U.LIMIT = 6000
    tag = 'cell_e_scratch'
    p, _ = F.params(1.4, 1.2)
    p.update(run_id=f'{tag}_ideal', p_out_dzv_MPa=5.49917, startup_iters=1000, coupled_iters=5500, retries=1)
    G.RUNS = P.BASE
    log(f'=== {tag}: проверка независимости от старта — точка e С НУЛЯ (идеальный метан, глобальный псевдошаг)')
    t0 = time.time()
    G.run(p, lambda s: log('  ' + s), lambda: False)
    U.record(P.CSV, f'{tag}_ideal', 'work_v2', 'ch4_ideal', (5.5, 1.2, 5.5, 5.49917), P.BASE / p['run_id'],
             round((time.time() - t0) / 60, 1), log, start='с нуля (FMG)', t0_C=15.0)
    src = P.BASE / p['run_id'] / 'result.cas.h5'
    if src.exists():
        F.cont(src, f'{tag}_pr', (5.5, 1.2, 5.5, 5.49917), list(L.CH4_PR_LINES), None,
               f'продолжение {tag}_ideal (ПР, глобальный псевдошаг)')
        r, r0 = F.rows(f'{tag}_pr'), F.rows('diag_e_pseudoglobal')
        for k in ('G_dzv', 'Q', 'dT_svz_h', 'dT_svz_vs_throttle', 'dT_dzv_h'):
            try:
                log(f'  независимость от старта, {k}: от соседа {float(r0[k]):.4f} / с нуля {float(r[k]):.4f} '
                    f'(разница {float(r[k]) - float(r0[k]):+.4f})')
            except Exception:
                pass


if __name__ == '__main__':
    P.qlog('=== ночь 12→13.10 (проверка m030i, точки a и b, независимость от старта) — начат')
    for name, fn in (('проверка m030i', a5_check), ('точка a', point_a), ('точка b', point_b),
                     ('точка e с нуля', point_e_scratch)):
        t0 = time.time()
        try:
            fn()
            P.qlog(f'ночь 12→13.10: {name} — {(time.time() - t0) / 60:.0f} мин')
        except Exception:
            log(f'{name}: ОШИБКА программы: ' + traceback.format_exc())
    P.qlog('=== ночь 12→13.10 — очередь закончена')
