"""Baseline surrogate on dataset.csv (rows with tier strict/engineering/unsteady).

Inputs : geometry (r_end, l_heat, gap) + regime (p0_svz, p_out_svz, p0_dzv-p_out_dzv)
Outputs: dT_svz_avg (heating of supersonic outlet), dT_dzv_avg (cooling of subsonic outlet)
Reports leave-one-out error and suggests the most promising next design points.
Run: python surrogate.py
"""
import numpy as np, pandas as pd
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel as C
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

df = pd.read_csv(r'F:\Leontiev_Project\dataset\dataset.csv')
df = df[df.tier.isin(['strict', 'engineering', 'unsteady'])].copy()
df['dp_dzv'] = df.p0_dzv_MPa - df.p_out_dzv_MPa
X_cols = ['geom_r_end_mm', 'geom_l_heat_mm', 'geom_gap_mm', 'p0_svz_MPa', 'p_out_svz_MPa', 'dp_dzv']
X = df[X_cols].astype(float).values
res = {}
for tgt in ('dT_svz_avg', 'dT_dzv_avg'):
    y = df[tgt].astype(float).values
    k = C(1.0) * RBF(length_scale=np.ones(X.shape[1])) + WhiteKernel(0.05)
    m = make_pipeline(StandardScaler(), GaussianProcessRegressor(k, normalize_y=True, n_restarts_optimizer=5, random_state=0))
    pred = cross_val_predict(m, X, y, cv=LeaveOneOut())
    rmse = float(np.sqrt(np.mean((pred - y) ** 2)))
    print(f'{tgt}: n={len(y)}  range [{y.min():.2f},{y.max():.2f}]  std {y.std():.2f}  LOO-RMSE {rmse:.2f} K')
    m.fit(X, y); res[tgt] = m

# random candidate search inside the training box
rng = np.random.default_rng(0)
lo, hi = X.min(0), X.max(0)
cand = lo + (hi - lo) * rng.random((20000, X.shape[1]))
mu_h, sd_h = res['dT_svz_avg'][-1].predict(res['dT_svz_avg'][0].transform(cand), return_std=True)
mu_c, sd_c = res['dT_dzv_avg'][-1].predict(res['dT_dzv_avg'][0].transform(cand), return_std=True)
for name, score in (('max heating of SVZ', mu_h), ('max cooling of DZV', -mu_c), ('max |sum| both', mu_h - mu_c)):
    i = np.argsort(-score)[:3]
    print('\n', name)
    for j in i:
        print('  ' + ', '.join(f'{c}={v:.2f}' for c, v in zip(X_cols, cand[j])) + f'  -> dT_svz={mu_h[j]:+.2f}±{sd_h[j]:.2f}  dT_dzv={mu_c[j]:+.2f}±{sd_c[j]:.2f}')
