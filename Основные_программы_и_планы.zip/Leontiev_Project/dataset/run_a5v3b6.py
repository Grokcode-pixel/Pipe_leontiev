"""A5 v3b, order changed after the review (10.10.2026 12:00, author agreed): after m 0.11 (run_a5v3b5.py, interpolated
start — SVZ mass balance 0.36 % after 500 iterations instead of 8 %) the reference m = 0 is needed first (dTh of Eq. 14),
then m 0.75 (largest old discrepancy), then m 0.30 (old field is only a limit-reached start).  Plateau rule (review):
no automatic 8000 iterations per point — LIMIT 4000; a point that does not converge in 4000 is left for diagnosis.
Waits for b5 to record a5v3_m011i, stops b5 before its next point, then runs the rest with the b5 initialisation."""
import csv, subprocess, sys, time, traceback
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_a5v3b5 as B5
import cont_util as U
import gui_runner as G

B, A, log = B5.B, B5.A, B5.log
U.CFL = 5.0
U.LIMIT = 4000
U.NPROC = 4   # 12:30: laptop at 94-99 C / thermal throttling 98 % of the time with 7 processes


def rows_of(tag):
    if not A.CSV.exists():
        return None
    for r in csv.DictReader(open(A.CSV, encoding='utf-8')):
        if r.get('tag') == tag:
            return r
    return None


def main():
    while rows_of('a5v3_m011i') is None:
        time.sleep(20)
    subprocess.run(['powershell', '-NoProfile', '-Command',
                    "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | ? {$_.CommandLine -match 'run_a5v3b5'} | "
                    "% { Stop-Process -Id $_.ProcessId -Force }"])
    time.sleep(15)
    G.kill_since(time.time() - 60)
    log(f'=== А5 v3b6: порядок m 0 → 0,75 → 0,30 (замечание рецензента), предел {U.LIMIT} ит. (правило плато)')
    rows = {0.11: rows_of('a5v3_m011i')}
    r0 = B5.run('a5v3_m000i', 'a5v3_m000', B.P0)
    for m, old in ((0.75, 'a5v3_m075'), (0.30, 'a5v3_m030')):
        pod = round(B.P0 - B.DP0[m], 6)
        r = B5.run(f'a5v3_m{int(round(m * 100)):03d}i', old, pod)
        if r.get('G_dzv') and r.get('G_svz'):
            log(f'  достигнутый m {float(r["G_dzv"]) / float(r["G_svz"]):.3f} (цель {m})')
        rows[m] = r
    B.summary(rows, r0)


if __name__ == '__main__':
    A.qlog('=== А5 v3b6 (m 0 → 0,75 → 0,30, предел 4000) — ждёт m 0,11 из b5')
    try:
        main()
    except Exception:
        log('ОШИБКА программы: ' + traceback.format_exc())
    A.qlog('=== А5 v3b6 — закончен (приёмка — по результатам)')
