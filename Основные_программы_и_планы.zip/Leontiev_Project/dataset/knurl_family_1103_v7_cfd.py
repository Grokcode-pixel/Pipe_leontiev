"""Bounded same-shape end-to-end checks F05/W2 and F06/W3.
Uses existing verified templates, zone-name field transfer and single-writer D48.
No new geometries, meshing, cross-shape transfer or training changes.
"""
import json,math,shutil,sys,traceback
from pathlib import Path
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D));R=D.parent
import audit_knurl_reports_1103_v3 as A
import knurl_grid_1103_v8 as V
import build_knurl_case_1103_v9 as B
import leontiev_pipeline as L
import cont_util as U
import gui_convergence as C
import single_writer_d12a_1103_v1 as STOP
import passport
OUT=R/'runs/family_1103_v7_cfd';PLAN=R/'runs/plans/устойчивость_накатки_1103_v7_расчёты.json'
RAW_RUN=L.run_fluent
ORIGINAL_CONVERGED=V.G.converged if hasattr(V,'G') else None

def accepted_convergence(folder):
    f=Path(folder)/'convergence.json'
    conv=load(f) if f.exists() else {}
    if conv.get('stop_basis')=='D48' and conv.get('stop_requested') and conv.get('d48',{}).get('ready'):return True
    return ORIGINAL_CONVERGED(folder)


def save(path,value):
    def native(v):
        if hasattr(v,'item'):return v.item()
        raise TypeError('Unsupported JSON value '+str(type(v)))
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,default=native),encoding='utf-8')

def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def registered():
    if A.sha(PLAN)!=PLAN.with_suffix('.sha256').read_text().strip():raise RuntimeError('Changed CFD plan')
    p=load(PLAN)
    for f,h in {**p['source_sha256'],**p['code_sha256']}.items():
        if A.sha(f)!=h:raise RuntimeError('Changed source '+f)
    return p

def same_shape(target,source):
    for k in ('r_end_mm','l_heat_mm','gap_mm','neck_ratio','r_nozzle_exit_mm','wall_thickness_inlet_mm','wall_thickness_end_mm'):
        if k not in target or k not in source or not math.isclose(float(target[k]),float(source[k]),abs_tol=1e-9,rel_tol=1e-9):raise RuntimeError('Different shape '+k)
    for k in ('h_mm','pitch_mm','width_mm','x_first_mm'):
        if not math.isclose(float(target['knurl_dzv'][k]),float(source['knurl_dzv'][k]),abs_tol=1e-9,rel_tol=1e-9):raise RuntimeError('Different knurl '+k)
    if bool(target.get('dzv_counterflow'))!=bool(source.get('dzv_counterflow')):raise RuntimeError('Different flow direction')

def make_plan():
    if PLAN.exists():raise RuntimeError('Plan already exists')
    prep=load(R/'runs/plans/устойчивость_накатки_1103_v4_подготовка.json');outcome=load(R/'runs/family_1103_v4_setup/results.json')
    cases=[];files=[R/'runs/family_1103_v4_setup/results.json',R/'runs/family_1103_v4_setup/summary.json',R/'runs/family_1103_v4_setup/finished.json',R/'runs/knurl_postprocess_1103_v1/summary.json']
    for tag,source,sourceprm in [('F05','W2','KM03r_tpl'),('F06','W3','KS10_A9_19_tpl')]:
        c=next(x for x in prep['cases'] if x['tag']==tag);q=c['params'];sp=R/'runs/patents'/sourceprm/'params.json';same_shape(q,load(sp))
        if not outcome[tag].get('setup_ok'):raise RuntimeError('Template not passed '+tag)
        src=R/'runs/knurl_cont'/source;quality=V.evaluate(src)
        if not quality['accepted']:raise RuntimeError('Source not numerically accepted '+source)
        regime=passport.resolve(src)['regime'];tpl=R/'runs/family_1103_v4_setup'/(tag+'_template')
        B.final_side_check((tpl/'s5.trn').read_text(errors='replace'))
        cases.append(dict(tag=tag,source=str(src),source_params=str(sp),template=str(tpl),params=q,regime=regime,source_quality=quality,coverage=outcome[tag]['topology']['interface_percent']))
        files += [sp]+[src/n for n in ('result.cas.h5','result.dat.h5','axis.csv','cont.jou')]+[tpl/n for n in ('initial.cas.h5','initial.dat.h5','s4.trn','s5.trn','interface_audit.json')]
        files += [Path(c['mesh_source'])/'geometry_options_used.json']
    code=[Path(__file__),D/'single_writer_d12a_1103_v1.py',D/'knurl_grid_1103_v8.py',D/'audit_knurl_reports_1103_v3.py',D/'build_knurl_case_1103_v9.py',D/'cont_util.py',D/'gui_convergence.py',D/'gui_runner.py',D/'leontiev_pipeline.py',D/'grs_temps.py',D/'passport.py',D/'knurl_cont.py',D/'job_point.py',D/'run_a9.py',D/'knurl_shallow_retry.py',D/'knurl_shallow.py']
    p=dict(made=A.now(),authorization='Author03.11: verify changed size/pitch and geometry→mesh→CFD→report chain, continue approved independent known forms; D47/D48 preserved.',cases=cases,
        prerequisites='J0050 grid sensitivity and v9 native qualification passed; J0051 five native templates passed. F03 is a separate known failed mesh, excluded from CFD, not treated as success.',
        limit=6000,time_limit_h=8,nproc=6,cfl=20,
        numerical='Methane PR, SST/Prt0.85, second order, CFL20, exact own W2/W3 field by zone names with saved data after each read; pressure/T transfer_gate before iterations. Original strict stop OR two consecutive full1000/≥3 D12a windows.1%energy,.05K,1%Q,.5%bothG,half-drift tolerances; actual mass≤1%; one SCM writer inside new runner. No relaxation.',
        stop='One attempt per physical point, no retries/extensions; first unacceptable CFD or error/orphan stops remaining CFD. Complete case/data/axis and noFPE required. Numerical status and physics separate.',
        limitation='D48 save is recognized as numerical convergence for legacy reporting; physical classifier still checks flow separately. Software chain/same-shape repeat checks only. Not grid validation of these other shapes, not arbitrary cold start, not training174. Native curved-interface coverage F05≈96%/F06≈95% is recorded; energy balance does not prove geometrical interface accuracy or physical recommendation. F03 repair remains outstanding.',
        code_sha256={str(f):A.sha(f) for f in code},source_sha256={str(f):A.sha(f) for f in files})
    save(PLAN,p);PLAN.with_suffix('.sha256').write_text(A.sha(PLAN),encoding='ascii');print(PLAN,A.sha(PLAN))

def checked(jou,**kwargs):
    V.idle()
    if not RAW_RUN(jou,threads=6,timeout=900):raise RuntimeError('Native service session failed '+str(jou))
    V.idle()

def prepare(c):
    tag=c['tag'];src=Path(c['source']);tpl=OUT/(tag+'_template');tpl.mkdir()
    same_shape(c['params'],load(c['source_params']))
    for n in ('initial.cas.h5','initial.dat.h5','s4.trn','s5.trn','interface_audit.json'):shutil.copy2(Path(c['template'])/n,tpl/n)
    B.final_side_check((tpl/'s5.trn').read_text(errors='replace'))
    ips={z:OUT/(tag+'_'+z+'.ip') for z in V.ZONES};jou=OUT/(tag+'_export.jou');trn=OUT/(tag+'_export.trn')
    lines=['/file/confirm-overwrite? no',f'/file/start-transcript "{L.fl(trn)}"',f'/file/read-case-data "{L.fl(src/"result.cas.h5")}"']
    for z,ip in ips.items():lines += [f'/file/interpolate/zone-selection {z} ()',f'/file/interpolate/write-data "{L.fl(ip)}" yes yes']
    lines += V.field_report_lines()+['/file/stop-transcript','/exit yes']
    jou.write_text('\n'.join(lines)+'\n',encoding='utf-8');checked(jou)
    if not all(ip.exists() and ip.stat().st_size for ip in ips.values()):raise RuntimeError('Missing own-source interpolation files')
    reference=V.field_report(trn.read_text(errors='replace'))
    if len(reference)!=7:raise RuntimeError('Incomplete own-source pressure/temperature evidence')
    reads=V.transfer_lines(ips,tag);V.transfer_gate(tpl,reads,reference,tag)
    return tpl,reads

def report(p,r,finished=False):
    save(OUT/'results.json',r)
    lines=['# Проверка расчёта на собственных формах W2/W3','',A.now(),'','| Форма | Статус | Q, Вт | Эффект, K | GСВЗ/GДЗВ | Баланс, %Q |','|---|---|---|---|---|---|']
    for c in p['cases']:
        e=r.get(c['tag'],{});lines.append('| '+c['tag']+' | '+('принято численно' if e.get('accepted') else 'не принято' if e else 'ожидается')+' | '+str(e.get('Q','—'))+' | '+str(e.get('effect','—'))+' | '+str(e.get('G_svz','—'))+'/'+str(e.get('G_dzv','—'))+' | '+str(e.get('imb_pct','—'))+' |')
    lines+=['',p['limitation']];(OUT/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    if finished:save(OUT/'summary.json',dict(finished=A.now(),accepted=sum(bool(e.get('accepted')) for e in r.values()),total=2,full_geometry_range_verified=False,remaining='F03 native mesh repair; cold start of unseen shapes not proved',limitation=p['limitation']))

def run():
    p=registered();V.idle();OUT.mkdir(parents=True,exist_ok=True)
    if (OUT/'attempt.json').exists():raise RuntimeError('Already attempted; no blind repeat')
    proof=load(R/'runs/knurl_postprocess_1103_v1/summary.json')
    if not proof['local_mesh_sensitivity_passed'] or not proof['builder_v9_qualification']['passed']:raise RuntimeError('Prerequisites not accepted')
    save(OUT/'attempt.json',dict(time=A.now(),plan_sha256=A.sha(PLAN)))
    global ORIGINAL_CONVERGED
    import gui_runner as G
    ORIGINAL_CONVERGED=G.converged;G.converged=accepted_convergence
    V.OUT=OUT;V.ORIGINAL_RUN=RAW_RUN;L.run_fluent=checked
    import knurl_cont as K
    runner,_=K.setup();runner.BASE=OUT;runner.CSV=OUT/'results.csv';runner.AUX=OUT/'aux.csv';runner.POINT_LIMIT=p['limit'];runner.set_step(runner.CONS)
    U.LIMIT=p['limit'];U.TIME_LIMIT_H=p['time_limit_h'];U.NPROC=p['nproc'];U.CFL=p['cfl'];results={};report(p,results)
    try:
        for c in p['cases']:
            registered();tag=c['tag'];save(OUT/'state.json',dict(time=A.now(),phase='native_template',tag=tag,source=c['source']))
            tpl,reads=prepare(c);V.idle();target=OUT/tag;target.mkdir();save(target/'params.json',dict(c['params'],run_id=tag))
            reg=c['regime'];pressures=[reg['p_main'],reg['p_cons'],reg['p0_dzv'],reg['p_out_dzv']]
            old_update=STOP.install(reg)
            save(OUT/'state.json',dict(time=A.now(),phase='cfd',tag=tag,source=c['source'],stop_policy='single-writer D48'))
            try:
                minutes=U.continue_case(tpl/'initial.cas.h5',target,list(L.CH4_PR_LINES)+[L.wall_k_line(110),L.SYMMETRY_DZV_LINE]+reads,pressures,lambda s:print(A.now(),s,flush=True),tag,t0_C=reg['T0_svz'],t0_dzv_C=reg['T0_dzv'])
            finally:C.update_control=old_update
            U.record(runner.CSV,tag,'family_1103_v7','ch4_pr',pressures,target,minutes,lambda s:print(A.now(),s,flush=True),start='Own same-shape source '+str(c['source']),t0_C=reg['T0_svz'],t0_dzv_C=reg['T0_dzv'])
            e=V.evaluate(target);e.update(minutes=minutes,coverage=c['coverage'],source=c['source'])
            original=c['source_quality'];e['source_difference']=dict(effect_K=abs(e['effect']-original['effect']),Q_pct=100*abs(e['Q']/original['Q']-1),G_svz_pct=100*abs(e['G_svz']/original['G_svz']-1),G_dzv_pct=100*abs(e['G_dzv']/original['G_dzv']-1))
            results[tag]=e;report(p,results)
            if not e['accepted']:raise RuntimeError(tag+' did not pass full-window numerical acceptance')
            V.idle()
        report(p,results,True);save(OUT/'finished.json',dict(time=A.now()));print(OUT/'report.md',flush=True)
    finally:
        L.run_fluent=RAW_RUN
        G.converged=ORIGINAL_CONVERGED
if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'check'
    if mode=='plan':make_plan()
    elif mode=='check':print('CHECK OK',len(registered()['cases']),'same-shape points; no CFD')
    elif mode=='run':
        try:run()
        except Exception as e:
            OUT.mkdir(parents=True,exist_ok=True);save(OUT/'BLOCK.json',dict(time=A.now(),error=str(e),traceback=traceback.format_exc()));raise
    else:raise SystemExit('plan | check | run')