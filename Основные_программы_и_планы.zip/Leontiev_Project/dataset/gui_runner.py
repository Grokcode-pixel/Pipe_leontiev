"""One full run for the GUI: geometry -> Workbench mesh -> Fluent case -> SIMPLE ramp to the target regime
(Prt via Viscous dialog OK) -> coupled -> axis profile.  Everything in ONE visible Fluent window.

By default, hybrid initialization uses a small pressure drop, followed by a SIMPLE
pressure ramp. Coupled runs at the target pressures and can stop at a report boundary
when all strict project criteria pass three consecutive checks.
"""
import csv, json, math, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import leontiev_pipeline as L
import build_fluent_case as B
import run_dataset as R
import gui_convergence as C
from make_gui_prt_journal import GUI_PRT

RUNS = Path(r'F:\Leontiev_Project\runs\gui')
GAS_LABEL = {'air': 'air ideal', 'ch4_ideal': 'methane ideal', 'ch4_pr': 'methane Peng-Robinson'}
CSV = L.DS / 'gui_runs.csv'
BASE = {'inlet_svz': 1.6e6, 'outlet_svz': 0.3e6, 'pressure_inlet_dzv': 5.5e6, 'outlet_dzv': 5.2e6}

DEFAULTS = dict(   # n95 geometry, patent regime (converged 06.10.2026)
    run_id='run01',
    r_end_mm=4.8, l_heat_mm=400.0, gap_mm=0.3, neck_ratio=0.95, r_nozzle_exit_mm=3.3,
    axial_size_mm=1.0, convergent_div=80,
    p0_svz_MPa=5.5, p_out_svz_MPa=0.3, p0_dzv_MPa=5.5, p_out_dzv_MPa=5.2,
    prt=0.85,   # 08.10: working value after A2 (was 0.65); series scripts set it explicitly anyway
    ramp_steps=15, ramp_iters=100, simple_iters=100, coupled_iters=5500, cfl=20.0, threads=6,  # total limit 6000; 27.10: 6 processes on the new PC (was 7)
    report_every=500, step_ratio=1.15, retries=1, auto_stop=True, startup='fmg', startup_cfl=5.0, startup_iters=500,
    reuse_mesh=False, wait_free=True, soft_start=True,
    wall_k=L.BRASS_K)   # 08.10 16:40: brass (author); the night queue 08->09.10 runs with its loaded old defaults (234)


def fluent_running():
    out = subprocess.run(['tasklist', '/FI', 'IMAGENAME eq cx2420.exe', '/FO', 'CSV', '/NH'],
                         capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW).stdout
    return any(l.startswith('"cx2420') for l in out.splitlines())


def mesh_spec(p):
    return dict(id=p['run_id'], r_end_mm=p['r_end_mm'], l_heat_mm=p['l_heat_mm'], gap_mm=p['gap_mm'],
                neck_ratio=p['neck_ratio'], r_nozzle_exit_mm=p['r_nozzle_exit_mm'],
                axial_size_mm=p['axial_size_mm'], convergent_div=int(p['convergent_div']),
                **{k: p[k] for k in ('layer_div', 'core_div', 'dzv_h1_mm', 'dzv_layers', 'global_size_mm',
                                     'r_outlet_mm', 'l_exit_recovery_mm', 'l_exit_tail_mm', 'nozzle_div', 'nozzle_bias',
                                     'layer_div_convergent', 'r_inlet_mm', 'r_throat_mm', 'l_nozzle_mm',
                                     'r_exit_rounding_mm', 'wall_thickness_inlet_mm', 'l_cone_mm',
                                     'wall_thickness_end_mm', 'dzv_counterflow', 'knurl_dzv', 'knurl_svz') if p.get(k)})   # 09.10: unit cell; 20.10: knurl_svz (v6)


def verify_mesh(p, msh):
    """Check exported cell count and saved Workbench parameters, not just a passed flag."""
    import re
    with Path(msh).open('rb') as stream:
        header = stream.read(4096)
    cells = re.search(rb'\(12\s+\(0\s+([0-9a-fA-F]+)\s+([0-9a-fA-F]+)\s+0\)\)', header)
    if not cells:
        raise ValueError('Не удалось прочитать число ячеек экспортированной сетки.')
    actual = int(cells[2], 16) - int(cells[1], 16) + 1
    result = json.loads(msh.with_name('mesh_result.json').read_text(encoding='utf-8'))
    wb = json.loads(msh.with_name('mesh_result.json.wb.json').read_text(encoding='utf-8'))
    if not result.get('passed') or not wb.get('passed') or actual != int(result['elements']):
        raise ValueError(f"Экспорт сетки не подтверждён: файл {actual} ячеек, отчёт {result.get('elements')}.")
    expected = L.geometry_params(mesh_spec(p))
    for name, expression in expected.items():
        saved = wb.get('params', {}).get(name)
        if saved is None or abs(float(saved.split()[0]) - float(expression.split()[0])) > 1e-5:
            raise ValueError(f'Геометрия сетки не соответствует запуску: {name}: {saved} / {expression}.')
    # 02.11.2026 (задание автора 02.11, п. 3): число ячеек и параметры Workbench не подтверждают наличие всех областей —
    # KS1_04 (h 1 / s 2) экспортирована без тела air_dzv и границ ДЗВ (Workbench: passed). Обязательные зоны — по ИМЕНИ и ТИПУ;
    # нет хотя бы одной — сетка негодна, решение не запускается. Структурный паспорт — mesh_zones.json рядом с сеткой.
    zones = mesh_zones(msh)
    Path(msh).with_name('mesh_zones.json').write_text(json.dumps(zones, ensure_ascii=False, indent=1), encoding='utf-8')
    miss = [f'{t} {n}' for n, t in REQUIRED_ZONES.items() if zones.get(n) != t]
    if miss:
        raise ValueError('Сетка неполная — нет обязательных зон: ' + ', '.join(miss) + ' (решение не запускается).')
    return actual


REQUIRED_ZONES = {'air_svz': 'fluid', 'air_dzv': 'fluid', 'wall_abonite': 'solid', 'inlet_svz': 'velocity-inlet', 'outlet_svz': 'pressure-outlet',
                  'inlet_dzv': 'velocity-inlet', 'outlet_dzv': 'pressure-outlet', 'axis': 'axis'}


def mesh_zones(msh):
    """{имя зоны: тип} по записям (45 (id тип имя)…) файла сетки Fluent."""
    import re
    s = Path(msh).read_bytes().decode('latin-1')
    return {m[2]: m[1] for m in re.findall(r'\(45 \((\d+) ([a-z\-]+) ([A-Za-z0-9_\-]+)\)', s)}


def expected_cells(p):
    """Structured mesh: cell count depends on length and axial step only.  Fitted on 400 mm -> 96 860 and
    115 mm -> 35 956 cells at 1.0 mm (n95, t115); the channel part scales with 1/axial_size."""
    return int(round(11281 + 213.7 * p['l_heat_mm'] / float(p['axial_size_mm'])))


def interp_ok(p):
    """The reference field (G4: L 400, r_end 4.8, gap 0.3) is only meaningful on the same channel; on a
    different length it put 80 % reversed flow at the inlet and diverged at iteration 1 (t115).
    soft_start=True (default, dataset): never interpolate, every point is started the same way."""
    return not p.get('soft_start', True) and abs(p['l_heat_mm'] - 400) < 1 and abs(p['r_end_mm'] - 4.8) < 0.01 and abs(p['gap_mm'] - 0.3) < 0.01


def bc_lines(vals):
    out = []
    for name, v in vals.items():
        out += [f'/define/named-expressions/edit {name} definition "{v:.6g} [Pa]" q', f'/define/named-expressions/compute {name}']
    return out


def journal(p, out):
    """Combined journal (case build + ramp + coupled + axis export).  Returns path."""
    interp = interp_ok(p)
    case_ready = p.get('reuse_mesh') and (out / 'initial.dat.h5').exists()
    lines = ['/file/confirm-overwrite? no']
    if case_ready:   # cold startup reinitializes, so the old data file need not be loaded
        command = 'read-case-data' if interp else 'read-case'
        lines += [f'/file/{command} "{L.fl(out)}/initial.cas.h5"']
    else:
        calls = []
        orig = B.L.run_fluent
        B.L.run_fluent = lambda j, threads=4, **_: calls.append(Path(j))
        try:
            B.build(L.DS / 'variants' / p['run_id'] / 'mesh.msh', out, p0_svz_MPa=1.6, interpolate=interp)
        except Exception:
            pass   # topology check needs s4.trn, produced later inside the combined session
        finally:
            B.L.run_fluent = orig
        for j in calls:
            lines += [l for l in j.read_text(encoding='utf-8').splitlines() if l not in ('/exit yes', '/file/confirm-overwrite? no')]
    trn = out / 'run.trn'
    target = {'inlet_svz': p['p0_svz_MPa'] * 1e6, 'outlet_svz': p['p_out_svz_MPa'] * 1e6,
              'pressure_inlet_dzv': p['p0_dzv_MPa'] * 1e6, 'outlet_dzv': p['p_out_dzv_MPa'] * 1e6}
    a = [f'/file/start-transcript "{L.fl(trn)}"'] + [g.format(prt=p['prt']) for g in GUI_PRT]
    gas = p.get('gas', 'air')
    if gas != 'air':                       # 08.10, A6: methane ideal / Peng-Robinson (material 'air' redefined)
        a += list(L.GAS_LINES[gas]) + ['/define/materials/list-properties air']
    elif p.get('air_k', 'poly') == 'poly':   # 08.10: k(T) is the working model (author)
        a += [L.AIR_K_LINE, '/define/materials/list-properties air']
    if p.get('wall_k'):   # 08.10 16:40: brass 110 W/(m K) from the dataset on (author); old runs: 234 from the settings
        a += [L.wall_k_line(float(p['wall_k'])), '/define/materials/list-properties latun']
    a += list(p.get('extra_lines', []))   # 08.10: e.g. adiabatic wall for A5 (applied after the wall line)
    n_ramp, it_ramp = int(p['ramp_steps']), int(p['ramp_iters'])
    if not interp and p.get('startup', 'fmg') == 'fmg':
        # 07.10.2026: the SIMPLE ramp failed on n95 at ~0.7 MPa (nozzle start, run03); coupled straight at the
        # target after hybrid + FMG initialization started without FPE (startup_test/A_fmg).  Default start.
        cfl0 = float(p.get('startup_cfl', 5.0))
        a += list(L.SOLVER_HEADER) + [f"(rpsetvar 'pressure/cpl-courant-number {cfl0})",
                                      f"(rpsetvar 'pressure-coupled/courant-number {cfl0})"]
        a += bc_lines(target) + ['/solve/initialize/hyb-initialization', '/solve/initialize/fmg-initialization yes',
                                 f"/solve/iterate {int(p.get('startup_iters', 500))}"]
    elif interp:
        a += list(L.SIMPLE_HEADER)
        # proven path (n95, pat55): reference field, 50 it settle, linear ramp under SIMPLE
        a += bc_lines(BASE) + ['/solve/iterate 50']
        for s in range(1, n_ramp + 1):
            a += bc_lines({k: BASE[k] + (target[k] - BASE[k]) * s / n_ramp for k in target}) + [f'/solve/iterate {it_ramp}']
        a += [f"/solve/iterate {int(p['simple_iters'])}"]
    else:
        # no reference field: start like a real rig from an almost zero pressure drop, then ramp.
        # t115: hybrid init straight at the target diverged at it. 6-8; SIMPLE diverged on the first ramp
        # step when the nozzle chokes -> conservative SIMPLE ramp, ~15 % pressure steps.
        gentle = {'inlet_svz': target['outlet_svz'] + 0.05e6, 'outlet_svz': target['outlet_svz'],
                  'pressure_inlet_dzv': target['outlet_dzv'] + 0.01e6, 'outlet_dzv': target['outlet_dzv']}
        a += list(L.SIMPLE_HEADER)
        eqs = ('mom', 'temperature', 'k', 'omega')
        if p.get('ramp_solver') == 'coupled':
            a += list(L.SOLVER_HEADER)
            a += [f"(rpsetvar 'pressure/cpl-courant-number {p.get('ramp_cfl', 0.5)})",
                  f"(rpsetvar 'pressure-coupled/courant-number {p.get('ramp_cfl', 0.5)})"]
        a += bc_lines(gentle) + ['/solve/initialize/hyb-initialization']
        a += [f"(rpsetvar '{e}/scheme 0)" for e in eqs] + ["(rpsetvar 'pressure/relax 0.1)", "(rpsetvar 'mom/relax 0.2)",
                                                          f"/solve/iterate {int(p.get('settle_iters', 300))}"]
        if not p.get('ramp_first_order', False):
            a += ["(rpsetvar 'pressure/relax 0.2)", "(rpsetvar 'mom/relax 0.3)"] + [f"(rpsetvar '{e}/scheme 1)" for e in eqs]
        # switching to coupled here (CFL 2) blew up at its first iteration (continuity 1e-4 -> 0.16, FPE):
        # keep SIMPLE with low URF for the whole ramp, coupled only at the target (as in pat55)
        a += ['/solve/iterate 200', "(rpsetvar 'pressure/relax 0.1)", "(rpsetvar 'mom/relax 0.2)"]
        r = target['inlet_svz'] / gentle['inlet_svz']
        n = max(n_ramp, int(math.ceil(math.log(r) / math.log(float(p.get('step_ratio', 1.15))))))
        for s in range(1, n + 1):
            f = s / n
            v = {'inlet_svz': gentle['inlet_svz'] * r ** f, 'outlet_svz': target['outlet_svz'], 'outlet_dzv': target['outlet_dzv'],
                 'pressure_inlet_dzv': gentle['pressure_inlet_dzv'] + (target['pressure_inlet_dzv'] - gentle['pressure_inlet_dzv']) * f}
            a += bc_lines(v) + [f'/solve/iterate {it_ramp}']
        if p.get('ramp_first_order', False):
            a += ['/solve/iterate 300'] + [f"(rpsetvar '{e}/scheme 1)" for e in eqs]
            a += ['/solve/iterate 300']
        a += ["(rpsetvar 'pressure/relax 0.2)", "(rpsetvar 'mom/relax 0.3)", f"/solve/iterate {int(p['simple_iters'])}"]
    a += [f'/file/write-case-data "{L.fl(out)}/ramp.cas.h5"']
    b = C.coupled_journal(p, out)
    lines += a + b + [f'/file/write-case-data "{L.fl(out)}/result.cas.h5"']
    lines += [f'/file/export/ascii "{L.fl(out)}/axis.csv" axis () yes mach-number pressure total-pressure '
              'temperature total-temperature axial-velocity () yes'] + [e.format(q=L.fl(out)) for e in p.get('extra_exports', [])] + ['/file/stop-transcript']
    jou = out / 'all_in_one.jou'
    jou.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return jou


def status(out):
    """Latest samples of the run (list of dicts with derived values)."""
    trns = list(Path(out).glob('fluent-*.trn'))
    if not trns:
        return None
    f = max(trns, key=lambda q: q.stat().st_mtime)
    txt = f.read_text(encoding='utf-8', errors='replace')
    s, r = L.parse_trn(f)
    blocks = sorted(Path(out).glob('coupled_*.trn'))
    if blocks:
        s = []
        for block in blocks:
            ss, rr = L.parse_trn(block)
            if rr and (not r or rr[-1]['it'] > r[-1]['it']):
                r = rr
            for sample in ss:
                if rr:
                    sample['iteration'] = rr[-1]['it']
                    sample['continuity'] = rr[-1]['continuity']
            s.extend(ss)
    rows = []
    for x in s:
        required = ('inlet_mass_flow_rate_svz', 'inlet_mass_flow_rate_dzv', 'outlet_total_temp_svz', 'outlet_total_temp_dzv', 'outlet_mass_flow_rate_svz', 'net', 'yp_svz', 'yp_dzv')
        if not all(k in x for k in required):
            continue
        ms, md = x['inlet_mass_flow_rate_svz'], x['inlet_mass_flow_rate_dzv']
        rows.append(dict(iteration=x.get('iteration', x['sample']), continuity=x.get('continuity', float('nan')),
                         dT_svz=x['outlet_total_temp_svz'] - 25, dT_dzv=x['outlet_total_temp_dzv'] - 25,
                         m_svz=ms, m_dzv=md, ratio=md / ms if ms else float('nan'),
                         dm=100 * (ms + x['outlet_mass_flow_rate_svz']) / ms if ms else float('nan'),
                         Q=x['flux'].get('interior-air_dzv-wall_abonite', float('nan')), net=x['net'],
                         yp_svz=x['yp_svz'], yp_dzv=x['yp_dzv']))
    names = ['сетка', 'интерфейсы', 'настройки', 'контакты', 'инициализация']
    done = [n for n, s in zip(names, ('s1_raw', 's2', 's3', 's4', 's5')) if (Path(out) / f'{s}.trn').exists()]
    stage = (f'Подготовка кейса: этап {len(done)}/5 ({done[-1]})' if done and not (Path(out) / 'run.trn').exists()
             else 'Расчёт' if (Path(out) / 'run.trn').exists() else 'Запуск Fluent…')
    import re
    pv = re.findall(r'edit inlet_svz definition "([\d.e+]+) \[Pa\]"', txt)
    try:
        every = int(json.loads((Path(out) / 'params.json').read_text(encoding='utf-8')).get('report_every', 100))
    except Exception:
        every = 100
    return dict(stage=stage, every=every, p_svz=float(pv[-1]) / 1e6 if pv else None, iter=r[-1]['it'] if r else 0, continuity=r[-1]['continuity'] if r else float('nan'),
                fpe='floating point exception' in txt,
                error=('Interrupting journal' in txt or 'error or interrupt occurred while reading the journal' in txt),
                samples=rows)


def criteria(st):
    """Strict project criteria on the last samples -> dict name -> (value, ok)."""
    s = st['samples']
    if len(s) < 2:
        return {}
    a, b = s[-2], s[-1]
    interval = b.get('iteration', 0) - a.get('iteration', 0)
    interval = interval if interval > 0 else st.get('every', 100)
    drift = max(abs(b['dT_svz'] - a['dT_svz']), abs(b['dT_dzv'] - a['dT_dzv'])) * 100 / interval
    return {'continuity ≤ 1e-4': (st['continuity'], st['continuity'] <= 1e-4),
            '|дисбаланс массы СВЗ| < 1 %': (b['dm'], abs(b['dm']) < 1),
            '|энергия| ≤ 0,1 Вт': (b['net'], math.isfinite(b['net']) and abs(b['net']) <= 0.1),
            'дрейф ΔT < 0,02 K/100 ит.': (drift, drift < 0.02),
            'y+ ≤ 1': (max(b['yp_svz'], b['yp_dzv']), all(math.isfinite(b[k]) and b[k] <= 1 for k in ('yp_svz', 'yp_dzv')))}


COLS = (['time', 'run_id', 'r_end_mm', 'l_heat_mm', 'gap_mm', 'neck_ratio', 'r_nozzle_exit_mm', 'axial_size_mm',
         'convergent_div', 'p0_svz_MPa', 'p_out_svz_MPa', 'p0_dzv_MPa', 'p_out_dzv_MPa', 'prt', 'soft_start',
         'step_ratio', 'ramp_iters', 'coupled_iters', 'cfl', 'iter', 'continuity',
         'dT_svz', 'dT_dzv', 'm_svz', 'm_dzv', 'ratio', 'dm', 'Q', 'net', 'yp_svz', 'yp_dzv', 'converged',
         'status', 'reason', 'startup', 'gas', 'turb_model', 'cells', 'M_nozzle', 'M_min_channel', 'M_mean_channel',
         'M_outlet', 'x_shock_m', 'reversed_max_pct', 'dT_limit_K', 'flag_above_limit', 'flag_yplus', 'minutes',
         'case_file', 'dm_dzv', 'energy_pct_Q', 'dT_limit_K_r0864', 'flag_above_limit_r0864',
         'energy_svz_W', 'energy_dzv_W', 'energy_solid_W'])
# dT_limit_K / flag_above_limit: r = 0.885 (task); *_r0864: r = 0.864 measured in this device (Leontiev et al. 2017)


LABELS = {   # label states the unit once: the threshold and the current value are both in it
    'continuity': 'невязка continuity, — (порог ≤ 2,5e-4)',
    'mass_svz_pct': 'дисбаланс массы СВЗ, % (порог < 1)',
    'energy_W': 'дисбаланс энергии, Вт (порог ≤ 5)',
    'drift_K_per_100': 'дрейф ΔT, K/100 ит. (порог ≤ 0,05)',
    'drift_Q_W_per_100': 'дрейф Q, Вт/100 ит. (порог ≤ 1)',
    'drift_flow_pct_per_100': 'дрейф расхода СВЗ, %/100 ит. (порог ≤ 0,1)',
    'drift_flow_dzv_pct_per_100': 'дрейф расхода ДЗВ, %/100 ит. (порог ≤ 0,3)'}   # 15.10 author


def criteria_out(out):
    """Stop criteria on the last two closed reports, as used by the auto-stop (for display)."""
    rows = C.closed_samples(out)
    if not rows:
        return {}
    b = rows[-1]
    if len(rows) < 2:   # one report: drifts need two, the rest can be shown already
        lim = C.STOP_LIMITS
        res = {LABELS['continuity']: (b['continuity'], b['continuity'] <= lim['continuity']),
               LABELS['mass_svz_pct']: (abs(b['dm']), abs(b['dm']) < lim['mass_svz_pct']),
               LABELS['energy_W']: (abs(b['net']), abs(b['net']) <= lim['energy_W'])}
        for k in ('drift_K_per_100', 'drift_Q_W_per_100', 'drift_flow_pct_per_100', 'drift_flow_dzv_pct_per_100'):
            res[LABELS[k]] = (None, None)
    else:
        res = {LABELS[k]: (v['value'], v['passed']) for k, v in C.strict_checks(rows[-2], rows[-1]).items()}
    res['y+, — (порог ≤ 1; только флаг сетки)'] = (max(b['yp_svz'], b['yp_dzv']), max(b['yp_svz'], b['yp_dzv']) <= 1)
    # option б (07.10): per-part balances, information only (ok = None -> shown with '·')
    res['баланс энергии СВЗ, Вт (справочно)'] = (b['e_svz'], None)
    res['баланс энергии ДЗВ, Вт (справочно)'] = (b['e_dzv'], None)
    res['баланс энергии стенки, Вт (справочно)'] = (b['e_solid'], None)
    res['дисбаланс массы ДЗВ, % (справочно)'] = (b['dm_dzv'], None)
    return res

R_REC = 0.885       # recovery factor, air (task A2; to be calibrated)
REV_LIMIT = 1.0     # % area of reversed flow on any boundary -> "обратный ток" (agreed 07.10)


def classify(out, p, stopped):
    """Status + reason code from the axis Mach profile and the reversed-flow messages (task A1)."""
    import re
    info = dict(M_nozzle='', M_min_channel='', M_mean_channel='', M_outlet='', x_shock_m='', reversed_max_pct='')
    reasons = []
    try:
        rows = sorted(([float(v) for v in r] for r in list(csv.reader(open(Path(out) / 'axis.csv')))[1:]), key=lambda r: r[1])
        L_ch = p['l_heat_mm'] / 1000
        ch = [r for r in rows if 0.005 <= r[1] <= 0.95 * L_ch]
        Ms = [r[8] for r in ch]
        info.update(M_nozzle=round(min(rows, key=lambda r: abs(r[1] - 0.003))[8], 3), M_min_channel=round(min(Ms), 3),
                    M_mean_channel=round(sum(Ms) / len(Ms), 3), M_outlet=round(rows[-1][8], 3))
        if max(Ms) < 1:
            reasons.append('нет сверхзвука (запирание)')
        elif min(Ms) < 1:
            x = next(r[1] for r in ch if r[8] < 1)
            info['x_shock_m'] = round(x, 4)
            reasons.append(f'скачок в канале, x={x:.3f} м')
    except Exception as e:
        reasons.append(f'нет профиля оси ({e.__class__.__name__})')
    last = sorted(Path(out).glob('coupled_*.trn'))
    if last:
        txt = last[-1].read_text(encoding='utf-8', errors='replace')
        rev = [float(x) for x in re.findall(r'Reversed flow on \d+ faces? \(([\d.]+)% area\)', txt)[-20:]]
        info['reversed_max_pct'] = max(rev) if rev else 0.0
        if rev and max(rev) > REV_LIMIT:
            reasons.append(f'обратный ток {max(rev):.1f} % площади')
    if not stopped:
        return 'сбой', 'предел итераций' + ('; ' + '; '.join(reasons) if reasons else ''), info
    if reasons:
        return 'сошёлся_нерабочий', '; '.join(reasons), info
    return 'сошёлся_рабочий', 'сверхзвук по всей длине канала', info


def run_log_lines(out):
    """Messages of one run for the GUI: its own run_log.txt, else its section of the series log."""
    out = Path(out)
    f = out / 'run_log.txt'
    if f.exists():
        return f.read_text(encoding='utf-8', errors='replace').splitlines()
    if out.parent.name == 'ref085':   # reference points: section "=== <tag>:" of runs\ref085\ref085_log.txt
        lines = (out.parent / 'ref085_log.txt').read_text(encoding='utf-8', errors='replace').splitlines() \
            if (out.parent / 'ref085_log.txt').exists() else []
        start = [i for i, l in enumerate(lines) if f'=== {out.name}:' in l]
        return [l for l in lines[start[-1]:] if '===' not in l or f'{out.name}:' in l][:50] if start else []
    if out.parent.name == 'a4':   # exit unit: section "=== диффузор: давление … 1.0 МПа" of runs\a4\a4_log.txt
        lines = (out.parent / 'a4_log.txt').read_text(encoding='utf-8', errors='replace').splitlines() \
            if (out.parent / 'a4_log.txt').exists() else []
        start = [i for i, l in enumerate(lines) if '=== ' in l and out.name.split('_p')[-1].lstrip('0') and
                 f"{int(out.name.split('_p')[-1]) / 100:g} МПа" in l] if '_p' in out.name else []
        return lines[start[-1]:][-60:] if start else lines[-60:]
    if out.parent.name == 'night':   # night queue: section of runs\night\night_log.txt
        lines = (out.parent / 'night_log.txt').read_text(encoding='utf-8', errors='replace').splitlines() \
            if (out.parent / 'night_log.txt').exists() else []
        start = [i for i, l in enumerate(lines) if f'=== {out.name}' in l or f'=== {out.name.rsplit(chr(95), 1)[0]}' in l]
        return lines[start[-1]:][-60:] if start else lines[-60:]
    if out.parent.name == 'a3':   # mesh study: section "=== сетка «work»" of runs\a3\a3_log.txt
        lines = (out.parent / 'a3_log.txt').read_text(encoding='utf-8', errors='replace').splitlines() \
            if (out.parent / 'a3_log.txt').exists() else []
        name = out.name.replace('a3_', '').replace('_adiab', '')
        start = [i for i, l in enumerate(lines) if f'=== сетка «{name}»' in l]
        return lines[start[-1]:][-60:] if start else []
    if out.parent.name == 'a2' and out.name.startswith('prt'):   # calibration runs: "=== Prt 0.85" in a2_log.txt
        series, key = out.parent / 'a2_log.txt', f"Prt {int(out.name[3:]) / 100:g}"
    else:
        series, key = RUNS / 'a1_log.txt', out.name
    if not series.exists():
        return []
    lines = series.read_text(encoding='utf-8', errors='replace').splitlines()
    if out.parent.name == 'a2':
        start = [i for i, l in enumerate(lines) if f'=== {key}:' in l]
        return [l for l in lines[start[-1]:] if '===' not in l or key in l][:50] if start else []
    start = [i for i, l in enumerate(lines) if f'=== {out.name}:' in l or f'расчёт {out.name}' in l]
    if not start:
        return []
    sec = []
    for l in lines[start[0]:]:
        if '=== ' in l and out.name not in l and sec:
            break
        sec.append(l)
    return sec


def max_total_iter(p):
    """Iteration limit = startup + coupled limit (author 07.10: coupled limit 6000)."""
    return int(p.get('startup_iters', 500)) + int(p['coupled_iters'])


def converged(out):
    """Converged = the stop criteria held in the last two checks (not merely 'the loop was stopped',
    which is also how the iteration limit ends a run)."""
    return C.decision(C.closed_samples(out))


def stop_requested(out):
    """finish.trn echoes the command, then prints the value on the next line:
    'GRS_STOP_REQUESTED  (write grs-stop?)\\n#t()' -> look for #t right after the marker (edge01, 07.10)."""
    import re
    f = Path(out) / 'finish.trn'
    txt = f.read_text(encoding='utf-8', errors='replace') if f.exists() else ''
    return bool(re.search(r'GRS_STOP_REQUESTED[^#]{0,80}#t', txt))


def dT_limit(M, T0=298.15, r=R_REC, g=1.4):
    a = (g - 1) / 2 * M * M
    return T0 * (1 - r) * a / (1 + a)


def write_row(row):
    new = not CSV.exists()
    with CSV.open('a', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=COLS, extrasaction='ignore')
        if new:
            w.writeheader()
        w.writerow(row)


def append_result(p, st, out=None, stopped=False, cells='', minutes=''):
    b = st['samples'][-1] if st and st['samples'] else {}
    status_, reason, info = classify(out, p, stopped) if out else ('сбой', 'нет данных', {})
    lim = dT_limit(info['M_mean_channel']) if info.get('M_mean_channel') not in ('', None) else ''
    lim2 = dT_limit(info['M_mean_channel'], r=0.864) if info.get('M_mean_channel') not in ('', None) else ''
    above = bool(lim != '' and b and -b['dT_dzv'] > lim)
    row = dict(p)
    row.update({k: round(v, 5) for k, v in b.items() if isinstance(v, float)})   # samples carry continuity/iteration too
    closed = C.closed_samples(out) if out else []
    if closed:
        c = closed[-1]
        row.update(dm_dzv=round(c['dm_dzv'], 5), energy_pct_Q=round(abs(c['net']) / max(abs(c['Q']), 1e-9) * 100, 4),
                   energy_svz_W=round(c['e_svz'], 4), energy_dzv_W=round(c['e_dzv'], 4), energy_solid_W=round(c['e_solid'], 4))
    row.update(time=time.strftime('%Y-%m-%d %H:%M'), iter=st['iter'] if st else '', continuity=st['continuity'] if st else '')
    write_row(dict(row, converged=stopped,
                   status=status_, reason=reason, startup=p.get('startup', 'fmg'), gas=GAS_LABEL.get(p.get('gas', 'air'), p.get('gas')) + ('' if p.get('gas', 'air') != 'air' else (', k(T)' if p.get('air_k', 'poly') == 'poly' else ', k const')), turb_model='SST k-omega',
                   cells=cells, **info, dT_limit_K=round(lim, 3) if lim != '' else '', flag_above_limit=above,
                   dT_limit_K_r0864=round(lim2, 3) if lim2 != '' else '',
                   flag_above_limit_r0864=bool(lim2 != '' and b and -b['dT_dzv'] > lim2),
                   flag_yplus=bool(b and max(b['yp_svz'], b['yp_dzv']) > 1), minutes=minutes,
                   case_file=str(Path(out) / 'result.cas.h5') if out else ''))
    return status_, reason


def run(p, log, stop_flag):
    """Blocking full run.  log(str) for messages, stop_flag() -> True to abort."""
    out = RUNS / p['run_id']
    out.mkdir(parents=True, exist_ok=True)
    t_all = time.time()
    _log = log

    def log(s):   # every message also goes to the run's own run_log.txt (shown by the GUI for any run)
        try:
            with (out / 'run_log.txt').open('a', encoding='utf-8') as f:
                f.write(time.strftime('%H:%M:%S ') + s + '\n')
        except OSError:
            pass
        return _log(s)
    (out / 'params.json').write_text(json.dumps(p, indent=1, ensure_ascii=False), encoding='utf-8')
    if p.get('wait_free', True):
        while fluent_running() and not stop_flag():
            log('Fluent занят другим расчётом — жду освобождения…')
            time.sleep(60)
    if stop_flag():
        return log('Остановлено.')
    msh = L.DS / 'variants' / p['run_id'] / 'mesh.msh'
    if p.get('reuse_mesh') and msh.exists():
        log(f'Сетка уже есть: {msh}')
    else:
        log('Workbench: геометрия → сетка (обычно 3–5 мин)…')
        m = R.build_mesh(mesh_spec(p), timeout=1500)
        if not m or not m.get('passed'):
            return log(f'ОШИБКА сетки: {m}')
        log(f"Сетка готова: {m.get('elements')} ячеек")
    cells = verify_mesh(p, msh)
    exp = expected_cells(p)
    # the formula is calibrated only for the default mesh settings (axial 1.0 mm, 80 divisions, default
    # first layer / radial divisions); for refined A3 meshes it would reject a correct mesh -> skip there
    calibrated = abs(float(p['axial_size_mm']) - 1.0) < 1e-9 and int(p['convergent_div']) == 80 and not p.get('mesh_custom')
    if not calibrated:
        log(f'Проверка числа ячеек пропущена: для этих настроек сетки нет эталона ({cells} ячеек).')
    elif abs(cells - exp) / exp > 0.05:
        # run01 (06.10): 80 189 cells instead of 96 860 with matching parameters -> rebuild once
        log(f'Число ячеек {cells} отличается от ожидаемого {exp} больше чем на 5 % — перестраиваю сетку')
        m = R.build_mesh(mesh_spec(p), timeout=1500)
        cells = verify_mesh(p, msh)
        if abs(cells - exp) / exp > 0.05:
            append_failure(p, None, cells, 0)
            return log(f'Статус «сбой»: сетка {cells} ячеек при ожидаемых {exp} (после перестройки). Нужна проверка человеком.')
    log(f'Проверка сетки: {cells} ячеек (ожидалось ≈{exp}); параметры Workbench совпадают с запуском.')
    q = dict(p)
    for attempt in range(int(p.get('retries', 1)) + 1):
        if attempt:
            # automatic retry with softer settings on the same prepared case
            if q.get('startup', 'fmg') == 'fmg':
                q.update(reuse_mesh=True, startup_cfl=2.0, startup_iters=1000)
                log('Повтор: FMG-старт с CFL 2 и 1000 итераций разгона')
            else:
                q.update(reuse_mesh=True, step_ratio=1 + (float(q.get('step_ratio', 1.15)) - 1) / 2,
                         ramp_iters=int(float(q['ramp_iters']) * 1.5))
                log(f"Повтор {attempt}: шаг ступени ×{q['step_ratio']:.3f}, {q['ramp_iters']} итераций на ступень")
        if attempt:
            archive = out / f'attempt_{attempt:02d}'
            archive.mkdir(exist_ok=True)
            import shutil
            for old in list(out.glob('*.trn')) + list(out.glob('*.jou')) + list(out.glob('convergence.*')):
                shutil.copy2(old, archive / old.name)
        (out / f'params_attempt_{attempt+1:02d}.json').write_text(json.dumps(q, indent=2, ensure_ascii=False), encoding='utf-8')
        for f in list(out.glob('*.trn')) + list(out.glob('axis.csv')):
            if f.name.startswith(('fluent-', 'run.', 'axis', 'coupled_', 'finish.')):
                try:
                    f.unlink()
                except OSError:
                    pass
        jou = journal(q, out)
        log(f'Запуск Fluent (окно): {jou}')
        t0 = time.time()
        subprocess.Popen([L.FLUENT, '2ddp', f"-t{int(q['threads'])}", '-i', str(jou)], cwd=str(out),
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True)
        failed = False
        stop_announced = False
        while not (out / 'axis.csv').exists():
            if stop_flag():
                kill_since(t0)
                return log('Остановлено пользователем.')
            st = status(out)
            check = C.update_control(out, q.get('auto_stop', True), max_iter=max_total_iter(q))
            if check['stop_requested'] and not stop_announced:
                log('Критерии сходимости выполнены в двух проверках подряд. Fluent завершит текущий блок и сохранит кейс.')
                stop_announced = True
            if st and (st['fpe'] or st['error']):
                kill_since(t0)
                log(f"ОШИБКА в Fluent (расхождение) на итерации {st['iter']}, вход СВЗ {st.get('p_svz') or 0:.2f} МПа — окно закрыто")
                failed = True
                break
            time.sleep(2)
        if not failed:
            time.sleep(10)
            st = status(out)
            stopped = converged(out)
            status_, reason = append_result(q, st, out, stopped, cells, round((time.time() - t_all) / 60, 1))
            kill_since(t0)   # case/data and axis profile are saved; an idle window would block the next queued run
            return log(f'Готово: статус «{status_}» ({reason}). Записано в {CSV}; окно Fluent закрыто.')
    append_failure(q, status(out), cells, round((time.time() - t_all) / 60, 1))
    log('Статус «сбой» (расходимость после повтора). Строка записана в gui_runs.csv.')


def append_failure(p, st, cells='', minutes=''):
    # 15.10: p may already hold startup/gas/... -> override via a dict merge (dict(**p, startup=...) raised TypeError)
    write_row({**dict(time=time.strftime('%Y-%m-%d %H:%M')), **p, **dict(iter=st['iter'] if st else 0, converged=False,
                   status='сбой', reason=f"расходимость (FPE), вход СВЗ {st.get('p_svz') if st else ''} МПа",
                   startup=p.get('startup', 'fmg'), gas=GAS_LABEL.get(p.get('gas', 'air'), p.get('gas')) + ('' if p.get('gas', 'air') != 'air' else (', k(T)' if p.get('air_k', 'poly') == 'poly' else ', k const')), turb_model='SST k-omega', cells=cells, minutes=minutes)})


def kill_since(t0):
    """Kill Fluent processes started after t0 (this run only)."""
    import datetime
    ps = ("Get-Process cx2420,fluent,fl_mpi2420,mpiexec,hydra_pmi_proxy -ErrorAction SilentlyContinue | "
          f"Where-Object {{ $_.StartTime -gt (Get-Date '{datetime.datetime.fromtimestamp(t0 - 5):%Y-%m-%d %H:%M:%S}') }} | "
          "ForEach-Object { Stop-Process -Id $_.Id -Force }")
    subprocess.run(['powershell', '-NoProfile', '-Command', ps], capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
