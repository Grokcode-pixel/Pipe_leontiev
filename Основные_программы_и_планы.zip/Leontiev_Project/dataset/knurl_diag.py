"""02.11.2026 — задание автора 02.11 и дополнение по D0–D4 (D-36). Диагностика накатки перед продолжением датасета: одна проверка
сетки без CFD (D0) и не больше четырёх целевых CFD-проб (D1–D4). Версия 2 (v1 — план накатка_диагностика_1102.json — не запускалась).
Исполнение — ТОЛЬКО по зарегистрированному плану runs\\plans\\накатка_диагностика_1102_v2.json: SHA256 плана сверяется с записанным
(…_v2.sha256), хеши кода и сеток-источников — с записанными в плане; любое расхождение — стоп до явного решения.
Каждая проба = параметры исходного запуска (params.json источника) + ровно объявленные изменения (changes); сетка — КОПИЯ проверенной
сетки источника (хеш копии = хеш источника, все обязательные зоны), а не новая сборка:
  D1 h 0,3 / s 2, 28,1 кПа — источник KS1_02_s_ideal (срыв на итерации 503); изменение: ramp_first_order=True;
  D2 h 0,1 / s 1,5, 18,9 кПа — источник KR_01_s_ideal (срыв на итерации 503); изменение: ramp_first_order=True;
  D3 патент h 1,0 / s 4,75, 87,99 кПа — сетка и физика опоры KS10_A9_19_tpl → KQ_A9_19_1 (осевой шаг 1,0 мм); изменения: старт
     «как на стенде» с расписанием D-30 (опора стартовала FMG-шаблоном и продолжениями) + ramp_first_order=True + перепад 87,99 кПа;
     стадия ПР — текущий cont_util (опора считалась им же в версии 30.10). Это проверка
     воспроизводимости старого результата на ТОЙ ЖЕ сетке — не сеточной независимости и не переноса на 0,25 мм;
  D4 h 1 / s 2, 15 кПа — источник KS1_03_s_ideal (полная сетка, срыв на 503); изменение: ramp_first_order=True.
Стоп (устойчив к перезапуску): D1 не прошёл подъём давления → D2–D4 не запускаются, пока нет файла RELEASE_D1.json с новым
решением / протоколом (явное действие). HOLD (runs\\knurl_diag\\HOLD): перед каждой точкой — ожидание, пока файл есть (задание
остаётся «идёт», зависимое не начинается); текст «стоп» в HOLD — выход с кодом 3 и BLOCK.json.
Проверка протокола по журналу Fluent: в блоке подъёма давления все уравнения (mom, temperature, k, omega) — первый порядок на всех
ступенях, второй порядок включается только после последней ступени (check_ramp).
Приём точки: целевой режим (метан ПР, второй порядок) — сошлась по критериям или D-12a. D3 — сравнение с опорой (report):
эффект ±0,1 K, Q ±2 %, G ДЗВ ±2 % (одинаковый способ усреднения: окно D-12a, если пригодно у обоих; иначе последний отчёт).
  python knurl_diag.py plan | check | mesh | cfd | report"""
import csv, hashlib, json, math, shutil, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')

R = Path(r'F:\Leontiev_Project\runs')
D = Path(r'F:\Leontiev_Project\dataset')
VAR = D / 'variants'
OUT = R / 'knurl_diag'
PLAN = R / 'plans' / 'накатка_диагностика_1102_v2.json'
SHA = PLAN.with_suffix('.sha256')
CODE = ['knurl_diag.py', 'gui_runner.py', 'scratch_one.py', 'mesh_variant.py', 'cont_util.py', 'run_a9.py', 'knurl_shallow_retry.py',
        'job_point.py', 'build_fluent_case.py', 'leontiev_pipeline.py', 'gui_convergence.py', 'd12a.py']
REF_D3 = R / 'patents' / 'KQ_A9_19_1'
CRIT_D3 = dict(effect_K=0.1, Q_pct=2.0, G_dzv_pct=2.0)
SRC = [dict(tag='D1', src=R / 'knurl_ds' / 'KS1_02_s_ideal', h=0.3, s=2.0, w=0.67, dp=28.1, ref='KS1_02 (срыв на итерации 503)',
            changes=dict(ramp_first_order=True)),
       dict(tag='D2', src=R / 'knurl_ds' / 'KR_01_s_ideal', h=0.1, s=1.5, w=0.5, dp=18.9, ref='KR_01 (срыв на итерации 503)',
            changes=dict(ramp_first_order=True)),
       dict(tag='D3', src=R / 'patents' / 'KS10_A9_19_tpl', h=1.0, s=4.75, w=1.6, dp=87.99, ref='KQ_A9_19_1 (сошлась по критериям; осевой шаг 1,0 мм)',
            # шаблон опоры отличается от запусков датасета только расписанием старта (FMG, 10 + 10 итераций — шаблон) →
            # расписание D-30, как у KS1_* (startup_iters 1000, coupled_iters 5500), + флаг + целевой перепад опоры
            changes=dict(startup='ramp', startup_iters=1000, coupled_iters=5500, ramp_first_order=True, p_out_dzv_MPa=round(5.5 - 87.99 / 1000, 6))),
       dict(tag='D4', src=R / 'knurl_ds' / 'KS1_03_s_ideal', h=1.0, s=2.0, w=0.67, dp=15.0, ref='KS1_03 (полная сетка; срыв на итерации 503)',
            changes=dict(ramp_first_order=True))]
A919 = dict(pm=5.5, pc=0.59, T=8.63, heat=4.83)
EQS = ('mom', 'temperature', 'k', 'omega')
IGNORE = {'run_id'}   # отличается всегда (новая папка)


def sha(f):
    return hashlib.sha256(Path(f).read_bytes()).hexdigest().upper()


def journal(s):
    with open(r'F:\Leontiev_Project\Журнал_работ.md', 'a', encoding='utf-8') as f:
        f.write(f"- {time.strftime('%d.%m.%Y %H:%M')} — диагностика накатки (D-36): {s}\n")


def load(f):
    return json.loads(Path(f).read_text(encoding='utf-8')) if Path(f).exists() else {}


def save(f, d):
    Path(f).parent.mkdir(parents=True, exist_ok=True)
    Path(f).write_text(json.dumps(d, ensure_ascii=False, indent=1, default=float), encoding='utf-8')


def check_ramp(jt):
    """Блок подъёма давления (после последней гибридной инициализации): первый порядок всех EQS до последней ступени,
    второй — только после неё и до записи ramp.cas.h5. Возвращает (ok, причина)."""
    i0 = jt.rfind('/solve/initialize/hyb-initialization')
    iw = jt.find('ramp.cas.h5', i0)
    if i0 < 0 or iw < 0:
        return False, 'в журнале нет блока подъёма давления (старт не «как на стенде»)'
    i200 = jt.find('/solve/iterate 200', i0)
    last = jt.rfind('/define/named-expressions/edit inlet_svz', i0, iw)
    if i200 < 0 or last < i200:
        return False, 'нет ступеней давления после /solve/iterate 200'
    end = jt.find('\n', jt.find('/solve/iterate', last))
    steps = jt.count('/define/named-expressions/edit inlet_svz', i200, end)
    pre, ramp, post = jt[i0:i200], jt[i0:end], jt[end:iw]
    miss0 = [e for e in EQS if f"(rpsetvar '{e}/scheme 0)" not in pre]
    bad1 = [e for e in EQS if f"(rpsetvar '{e}/scheme 1)" in ramp]
    miss1 = [e for e in EQS if f"(rpsetvar '{e}/scheme 1)" not in post]
    if miss0 or bad1 or miss1:
        return False, f'первый порядок до подъёма нет: {miss0}; второй порядок на ступенях: {bad1}; второй после подъёма нет: {miss1}'
    return True, f'первый порядок на всех {steps} ступенях, второй — после последней'


def expected_params(p):
    """Параметры пробы = params.json источника + объявленные изменения."""
    src = load(Path(p['src']) / 'params.json')
    return dict(src, **p['changes'])


def mesh_src(p):
    return VAR / load(Path(p['src']) / 'params.json')['run_id']


def make_plan():
    import gui_runner as G
    if PLAN.exists():
        sys.exit(f'{PLAN} уже есть — не перезаписываю')
    pts = []
    for p in SRC:
        ms = mesh_src(p)
        z = G.mesh_zones(ms / 'mesh.msh')
        miss = [f'{t} {n}' for n, t in G.REQUIRED_ZONES.items() if z.get(n) != t]
        pts.append(dict({k: (str(v) if isinstance(v, Path) else v) for k, v in p.items()}, mesh_source=str(ms), mesh_sha256=sha(ms / 'mesh.msh'),
                        mesh_missing=miss, params_sha256=sha(Path(p['src']) / 'params.json'), expected=expected_params(p)))
    plan = dict(name='накатка_диагностика_1102_v2', made=time.strftime('%d.%m.%Y %H:%M:%S'), decision='задание автора 02.11 + дополнение по D0–D4 (D-36)',
                replaces='накатка_диагностика_1102.json (v1, не запускалась): сетки D1/D2 строились заново, параметры — из кода',
                D0=dict(source=str(R / 'knurl_ds' / 'KS1_04_s_ideal' / 'params.json'), builds=2,
                        start_state='каждая сборка — из исходного проекта Workbench после завершения процессов Workbench (run_dataset.build_mesh)',
                        record='состав зон; тела до/после генерации (подавление, площадь, ячейки), контакты, сообщения Meshing, экспорт',
                        conclusion_rule='обе сетки полные — «дефект не воспроизведён», а не «причина устранена»'),
                points=pts, crit_D3=CRIT_D3, ref_D3=str(REF_D3), code_sha256={c: sha(D / c) for c in CODE},
                stop='D1 не прошёл подъём давления → D2–D4 не запускать до RELEASE_D1.json (новое решение / протокол)',
                hold='HOLD — ожидание перед точкой (задание «идёт»); «стоп» в HOLD — код 3 + BLOCK.json',
                accept='целевой режим, метан ПР, второй порядок; критерии или D-12a',
                admission='D1–D4 — на своих проверенных архивных сетках независимо от D0; статус очереди «готово» не означает пригодность')
    txt = json.dumps(plan, ensure_ascii=False, indent=1, default=float)
    PLAN.write_text(txt, encoding='utf-8')
    h = hashlib.sha256(txt.encode('utf-8')).hexdigest().upper()
    SHA.write_text(h, encoding='utf-8')
    journal(f'план v2 записан ДО запуска: {PLAN}, SHA256 {h}; сетки источников: ' +
            ', '.join(f"{q['tag']} ← {Path(q['mesh_source']).name} ({q['mesh_sha256'][:12]}…{', НЕПОЛНАЯ: ' + str(q['mesh_missing']) if q['mesh_missing'] else ''})" for q in pts))
    return h


def registered():
    """План и код совпадают с зарегистрированными; иначе исключение."""
    plan_txt = PLAN.read_text(encoding='utf-8')
    if hashlib.sha256(plan_txt.encode('utf-8')).hexdigest().upper() != SHA.read_text(encoding='utf-8').strip():
        raise RuntimeError('SHA256 плана не совпадает с записанным — план изменён после регистрации')
    plan = json.loads(plan_txt)
    bad = [c for c, h in plan['code_sha256'].items() if sha(D / c) != h]
    if bad:
        raise RuntimeError(f'код изменён после регистрации плана: {bad} — нужна новая версия плана')
    return plan


def hold_wait(tag):
    """True — продолжать; False — стоп (HOLD со словом «стоп»)."""
    f = OUT / 'HOLD'
    told = False
    while f.exists():
        if 'стоп' in f.read_text(encoding='utf-8', errors='ignore').lower():
            save(OUT / 'BLOCK.json', dict(why='HOLD: стоп', before=tag, time=time.strftime('%d.%m.%Y %H:%M:%S')))
            journal(f'HOLD «стоп» перед {tag} — выход (код 3), BLOCK.json'); return False
        if not told:
            journal(f'HOLD перед {tag} — жду снятия (задание остаётся «идёт»)'); told = True
        time.sleep(60)
    return True


def prepare(A, p):
    """Сетка-копия и параметры пробы; возвращает (over, проблемы)."""
    import gui_runner as G
    probs = []
    dst = VAR / f"{p['tag']}_s_ideal"
    dst.mkdir(parents=True, exist_ok=True)
    src = Path(p['mesh_source'])
    for f in ('mesh.msh', 'mesh_result.json', 'mesh_result.json.wb.json'):
        if (src / f).exists():
            shutil.copy2(src / f, dst / f)
    if sha(dst / 'mesh.msh') != p['mesh_sha256'] or sha(src / 'mesh.msh') != p['mesh_sha256']:
        probs.append('хеш сетки не совпадает с планом')
    z = G.mesh_zones(dst / 'mesh.msh')
    miss = [n for n, t in G.REQUIRED_ZONES.items() if z.get(n) != t]
    if miss:
        probs.append(f'сетка неполная: {miss}')
    over = {k: v for k, v in p['expected'].items() if k not in IGNORE}
    over['reuse_mesh'] = True
    return over, probs


def gen_params(A, KR, p, over):
    """Параметры, которые получит gui_runner (как scratch_one.run: cell_params → retries 0 → update(over))."""
    KR.K.KN.update(dzv=p['h'], svz=None, pitch=p['s'], width=p['w'])
    import job_point as JP
    jp = dict(tag=p['tag'], td=1.4, L=400.0, dp=p['dp'], pc=A919['pc'], T=A919['T'], heat=A919['heat'], pm=A919['pm'])
    pt = JP.design(jp, p['tag'] + '_s', A919['T'] + A919['heat'], A919['T'])
    q, _ = A.cell_params(1.4, 400.0, f"{p['tag']}_s_ideal", pt, 'ch4_ideal', 1000, 5500)
    q['retries'] = 0
    q.update(over)
    return q, pt


def diff_params(q, p):
    exp = dict(p['expected'], reuse_mesh=True)
    keys = (set(q) | set(exp)) - IGNORE
    return {k: (exp.get(k), q.get(k)) for k in sorted(keys) if exp.get(k) != q.get(k)}


def check():
    """Холостая проверка без Fluent: план и код, сетки, параметры (только объявленные изменения), журнал подъёма давления."""
    import job_point as JP
    import gui_runner as G
    plan = registered()
    A = JP.setup(dict(tube='накатка', base=str(OUT / '_check'), csv='check.csv'))
    import knurl_shallow_retry as KR
    rep = {}
    for p in plan['points']:
        over, probs = prepare(A, p)
        q, _ = gen_params(A, KR, p, over)
        d = diff_params(q, p)
        out = OUT / '_check' / p['tag']
        out.mkdir(parents=True, exist_ok=True)
        jou = G.journal(q, out)
        ok_r, why_r = check_ramp(jou.read_text(encoding='utf-8'))
        rep[p['tag']] = dict(problems=probs, param_diff=d, ramp_check=(ok_r, why_r))
        print(p['tag'], 'проблемы:', probs or 'нет', '| отличия параметров от плана:', d or 'нет', '| подъём давления:', ok_r, why_r)
    # контроль: старый журнал KS1_02 (без флага) должен НЕ пройти проверку
    old = (R / 'knurl_ds' / 'KS1_02_s_ideal' / 'all_in_one.jou').read_text(encoding='utf-8')
    rep['контроль KS1_02 (без флага)'] = check_ramp(old)
    print('контроль старого журнала KS1_02:', rep['контроль KS1_02 (без флага)'])
    save(OUT / 'check.json', rep)
    return rep


def mesh():
    import gui_runner as G
    plan = registered()
    p0 = load(plan['D0']['source'])
    res = load(OUT / 'results.json')
    for k in (1, 2):
        tag = f'D0_m{k}'
        if res.get(tag, {}).get('done'):
            continue
        if not hold_wait(tag):
            sys.exit(3)
        p = dict(p0, run_id=tag)
        t0 = time.time()
        m = G.R.build_mesh(G.mesh_spec(p), timeout=1500)
        msh = VAR / tag / 'mesh.msh'
        mr = load(VAR / tag / 'mesh_result.json')
        z = G.mesh_zones(msh) if msh.exists() else {}
        miss = [n for n, t in G.REQUIRED_ZONES.items() if z.get(n) != t]
        res[tag] = dict(done=True, passed=bool(m and m.get('passed')), elements=(m or {}).get('elements'), seconds=round(time.time() - t0),
                        gen_seconds=mr.get('gen_seconds'), zones=z, missing=miss, bodies_before=mr.get('bodies_before_mesh'),
                        bodies_after=mr.get('bodies_after_mesh'), messages=mr.get('messages_after_mesh'), contacts=mr.get('contacts_all'),
                        exported=mr.get('exported'), mesh_sha256=sha(msh) if msh.exists() else None, finished=time.strftime('%d.%m.%Y %H:%M:%S'))
        save(OUT / 'results.json', res)
        journal(f"{tag} (сетка h 1 / s 2, без CFD): Workbench passed={res[tag]['passed']}, {res[tag]['elements']} ячеек, генерация {mr.get('gen_seconds')} с; "
                + ('все обязательные зоны есть' if not miss else 'НЕТ зон: ' + ', '.join(miss)) + '; состояние тел и сообщения — runs\\knurl_diag\\results.json')
    r = [res.get(f'D0_m{k}', {}) for k in (1, 2)]
    if all(x.get('done') for x in r):
        concl = ('дефект не воспроизведён (обе сетки полные) — причина не установлена' if not any(x['missing'] for x in r) else
                 'дефект воспроизведён: ' + '; '.join(f"D0_m{k}: нет {x['missing']}" for k, x in enumerate(r, 1) if x['missing']))
        res['D0_вывод'] = concl
        save(OUT / 'results.json', res)
        journal('D0 — вывод: ' + concl)


def cfd():
    import job_point as JP
    import scratch_one as SO
    import d12a
    plan = registered()
    OUT.mkdir(parents=True, exist_ok=True)
    A = JP.setup(dict(tube='накатка', base=str(OUT), csv='knurl_diag_results.csv'))
    import knurl_shallow_retry as KR
    res = load(OUT / 'results.json')
    if (OUT / 'BLOCK.json').exists():
        journal(f"cfd не начат: BLOCK.json ({load(OUT / 'BLOCK.json').get('why')})"); sys.exit(3)
    for p in plan['points']:
        tag = p['tag']
        d1 = res.get('D1', {})
        if tag != 'D1' and d1.get('done') and not d1.get('ideal_ok') and not (OUT / 'RELEASE_D1.json').exists():
            journal(f'{tag} не запущен: D1 не прошёл подъём давления (сохранённый результат), RELEASE_D1.json нет — нужен разбор / новое решение')
            sys.exit(3)
        if res.get(tag, {}).get('done'):
            continue
        if not hold_wait(tag):
            sys.exit(3)
        over, probs = prepare(A, p)
        q, pt = gen_params(A, KR, p, over)
        dif = diff_params(q, p)
        if probs or dif:
            res[tag] = dict(done=False, blocked=True, problems=probs, param_diff=dif, time=time.strftime('%d.%m.%Y %H:%M:%S'))
            save(OUT / 'results.json', res)
            save(OUT / 'BLOCK.json', dict(why=f'{tag}: {probs} {dif}', time=time.strftime('%d.%m.%Y %H:%M:%S')))
            journal(f'{tag} не запущен: {probs or ""} отличия параметров от плана: {dif or "нет"} — BLOCK.json'); sys.exit(3)
        A.log(f"=== {tag} (диагностика v2): h {p['h']} / s {p['s']} / ширина {p['w']}, перепад {p['dp']} кПа; сетка — копия {Path(p['mesh_source']).name} "
              f"({p['mesh_sha256'][:12]}…); изменения против источника: {p['changes']}; опора: {p['ref']}")
        t0 = time.time()
        try:
            d = SO.run(A, pt, tag + '_s', 400.0, f'{tag}: диагностика v2 (изменения {p["changes"]})', **over)
        except Exception as ex:
            A.log(f'  {tag}: ОШИБКА программы {ex!r}'); d = None
        jou = OUT / f'{tag}_s_ideal' / 'all_in_one.jou'
        ramp = check_ramp(jou.read_text(encoding='utf-8')) if jou.exists() else (False, 'журнала нет')
        ideal_ok = A.ok(OUT / f'{tag}_s_ideal')
        e = d12a.evaluate(d) if d else {}
        ok = bool(d) and (A.converged(d) or bool(e.get('ok')))
        row = next((r for r in reversed(list(csv.DictReader(open(A.CSV, encoding='utf-8')))) if d and r['tag'] == d.name), None) if A.CSV.exists() else None
        res[tag] = dict(done=True, ideal_ok=ideal_ok, ok=ok, converged=bool(d) and A.converged(d), d12a=e.get('ok'), folder=str(d) if d else None,
                        hours=round((time.time() - t0) / 3600, 2), effect=e.get('effect'), Q=e.get('Q'), G_dzv=e.get('G_dzv'), G_svz=e.get('G_svz'),
                        status=row.get('status') if row else 'нет результата', reason=row.get('reason') if row else None,
                        shock=bool(row and row.get('x_shock_m')), reversed_pct=(row or {}).get('reversed_max_pct'), ramp_check=ramp,
                        mesh_sha256=sha(VAR / f'{tag}_s_ideal' / 'mesh.msh'), finished=time.strftime('%d.%m.%Y %H:%M:%S'))
        save(OUT / 'results.json', res)
        r = res[tag]
        journal(f"{tag}: подъём давления {'пройден' if ideal_ok else 'НЕ пройден'} (журнал: {ramp[1]}); целевой режим (ПР) — "
                f"{'принят' if ok else 'не принят'} ({r['status']}); {r['hours']} ч" +
                (f"; Q {r['Q']:.0f} Вт, G ДЗВ {r['G_dzv']:.4f}, эффект {r['effect']:+.2f} K" if r.get('Q') else ''))
        if tag == 'D3':
            report()
        if tag == 'D1' and not ideal_ok:
            journal('D1 не прошёл подъём давления — D2–D4 этим протоколом НЕ запускаются (стоп по плану; сохраняется между перезапусками)')
            sys.exit(3)


def summary(d, label):
    """Значения точки для сравнения: окно D-12a, если пригодно; иначе последний отчёт (способ указывается)."""
    import d12a
    import gui_convergence as C
    e = d12a.evaluate(d)
    if e.get('ok'):
        return dict(effect=e['effect'], Q=e['Q'], G_dzv=e['G_dzv'], G_svz=e['G_svz'], how='окно D-12a (1000 итераций)', quality='D-12a')
    rows = C.closed_samples(d)
    conv = bool(rows) and C.decision(rows)
    return dict(effect=e.get('effect'), Q=e.get('Q'), G_dzv=e.get('G_dzv'), G_svz=e.get('G_svz'), how='окно D-12a (не пройдено)' if e else 'нет данных',
                quality='критерии' if conv else 'не принята')


def report():
    res = load(OUT / 'results.json')
    r3 = res.get('D3', {})
    if not r3.get('folder'):
        print('D3 нет результата — сравнение невозможно'); return
    a, b = summary(REF_D3, 'опора'), summary(Path(r3['folder']), 'D3')
    m = lambda x: x['G_dzv'] / x['G_svz'] if x.get('G_dzv') and x.get('G_svz') else float('nan')
    rows = []
    for k, tol, pct in (('effect', CRIT_D3['effect_K'], False), ('Q', CRIT_D3['Q_pct'], True), ('G_dzv', CRIT_D3['G_dzv_pct'], True)):
        if a.get(k) is None or b.get(k) is None:
            rows.append((k, a.get(k), b.get(k), None, tol, False)); continue
        dv = (b[k] / a[k] - 1) * 100 if pct else b[k] - a[k]
        rows.append((k, a[k], b[k], dv, tol, abs(dv) <= tol))
    both_ok = a['quality'] != 'не принята' and b['quality'] != 'не принята'
    passed = both_ok and all(x[5] for x in rows)
    L = [f'# D3 — воспроизводимость патентного варианта (h 1,0 / s 4,75, 87,99 кПа) ({time.strftime("%d.%m.%Y %H:%M")})', '',
         'Сетка — та же, что у опоры (KS10_A9_19_tpl, осевой шаг 1,0 мм). Это проверка воспроизводимости старого результата новым '
         'протоколом запуска, НЕ сеточной независимости и НЕ переноса на сетку 0,25 мм.', '',
         '| величина | опора KQ_A9_19_1 | D3 | отклонение | допуск | выполнено |', '|---|---|---|---|---|---|']
    names = {'effect': 'эффект, K', 'Q': 'Q, Вт', 'G_dzv': 'G ДЗВ, кг/с'}
    for k, va, vb, dv, tol, okk in rows:
        L.append(f"| {names[k]} | {va if va is None else round(va, 5)} | {vb if vb is None else round(vb, 5)} | "
                 f"{'—' if dv is None else (f'{dv:+.2f} %' if k != 'effect' else f'{dv:+.3f} K')} | {tol}{' %' if k != 'effect' else ' K'} | {'да' if okk else 'нет'} |")
    L += ['', f"Качество: опора — {a['quality']}, D3 — {b['quality']}; усреднение: опора — {a['how']}, D3 — {b['how']}; "
              f"m: опора {m(a):.3f}, D3 {m(b):.3f}; режим D3: {r3.get('status')} ({r3.get('reason')}); газ — метан ПР; сетка D3 — хеш {r3.get('mesh_sha256', '')[:12]}….",
          '', f"**Заключение: {'воспроизводимость подтверждена' if passed else 'воспроизводимость НЕ подтверждена' + ('' if both_ok else ' (одно из решений не принято по критериям — сравнение не доказательно)')}.**"]
    (OUT / 'D3_сравнение.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
    res['D3_сравнение'] = dict(rows=rows, passed=passed, both_ok=both_ok)
    save(OUT / 'results.json', res)
    journal(f"D3 — сравнение с опорой: {'воспроизводимость подтверждена' if passed else 'НЕ подтверждена'} (runs\\knurl_diag\\D3_сравнение.md)")
    print('\n'.join(L))


if __name__ == '__main__':
    {'plan': lambda: print(make_plan()), 'check': check, 'mesh': mesh, 'cfd': cfd, 'report': report}[sys.argv[1]]()
