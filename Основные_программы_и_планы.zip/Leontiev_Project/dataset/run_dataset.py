"""Dataset orchestrator: geometry variant -> mesh (Workbench macro) -> Fluent case -> regime runs -> dataset.csv

Usage:
    python run_dataset.py doe_geometry.json        # list of variants, see make_doe()
Each variant:
    {"id": "v001", "r_end_mm": 4.8, "l_heat_mm": 400, "gap_mm": 0.3,
     "regimes": [{"p0_svz_MPa":1.6,"p_out_svz_MPa":0.3,"p0_dzv_MPa":5.5,"p_out_dzv_MPa":5.2}, ...]}
The Workbench step uses RunWB2 with the project closed in the GUI (the project file must not be open
elsewhere).  Result of every step is written to dataset/variants/<id>/ ; failures are recorded, never skipped silently.
"""
import json, random, shutil, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import leontiev_pipeline as L
import build_fluent_case as B

RUNWB = r'C:\Program Files\ANSYS Inc\v242\Framework\bin\Win64\RunWB2.exe'
PROJECT = r'F:\Leontiev_Project\g_08_1.wbpj'
MACRO = r'F:\Leontiev_Project\dataset\wb_build_variant.wbjn'
SPEC = L.DS / 'current_variant.json'


REFERENCE = r'F:\Leontiev_Project\эталон_проекта_20261102\g_08_1.wbpj'   # 02.11.2026: fixed state (copy of g_08_1.wbpj of 02.11 14:44)
WORK = Path(r'F:\Leontiev_wb_work')                                        # scratch copy, recreated for every build


def fresh_copy(ref):
    """02.11.2026 (author): every build starts from the SAME fixed state — a fresh scratch copy of the reference project
    (wbpj + _files). The reference and the old master g_08_1.wbpj are never opened or saved by a build."""
    if WORK.exists():
        shutil.rmtree(WORK)   # scratch copy only (not data): previous build's working project
    WORK.mkdir(parents=True)
    shutil.copy2(ref, WORK / 'g_08_1.wbpj')
    shutil.copytree(Path(ref).parent / 'g_08_1_files', WORK / 'g_08_1_files', ignore=shutil.ignore_patterns('.lock'))
    return str(WORK / 'g_08_1.wbpj')


def _sha(f):
    import hashlib
    return hashlib.sha256(Path(f).read_bytes()).hexdigest().upper()


def build_mesh(v, timeout=1500, project=None):
    # 08.10: a test copy of the project can be used; 02.11: `project` is the REFERENCE to copy from (default REFERENCE),
    # the build itself runs in a fresh scratch copy; the reference must stay byte-identical (checked below)
    ref = project or REFERENCE
    ref_hash = _sha(ref)
    project = fresh_copy(ref)
    vd = L.DS / 'variants' / v['id']; vd.mkdir(parents=True, exist_ok=True)
    msh = vd / 'mesh.msh'; res = vd / 'mesh_result.json'
    for p in (res, Path(str(res) + '.wb.json')):
        if p.exists():
            p.unlink()
    spec = dict(id=v['id'], geometry=L.geometry_params(v), msh=str(msh), result=str(res), force_nudge=True)
    if v.get('axial_size_mm'):
        spec['axial_size_m'] = v['axial_size_mm'] * 1e-3      # coarser/finer axial mesh (default 0.5 mm)
    if v.get('convergent_div'):
        spec['convergent_div'] = v['convergent_div']
    for k in ('layer_div', 'core_div', 'dzv_h1_mm', 'dzv_layers', 'global_size_mm', 'nozzle_div', 'nozzle_bias',
              'layer_div_convergent'):   # stage A3 mesh settings
        if v.get(k):
            spec[k] = v[k]
    SPEC.write_text(json.dumps(spec, indent=1))
    # 08.10 (geometry v3): options read by the geometry script itself, written for EVERY mesh (no stale values)
    # 09.10 (geometry v4): + DZV counterflow (inlet at the far end); ignored by the v3 script
    (Path(project).parent / 'geometry_options.json').write_text(json.dumps({'l_cone_mm': float(v.get('l_cone_mm') or 0.0),
                                                                            'dzv_counterflow': bool(v.get('dzv_counterflow')),
                                                                            'knurl_dzv': v.get('knurl_dzv') or None,     # 13.10 (v5)
                                                                            'knurl_svz': v.get('knurl_svz') or None}))   # 20.10 (v6)
    for name in ('AnsysFWW.exe', 'AnsysWBU.exe', 'SpaceClaim.exe', 'AnsysFW.exe'):
        subprocess.run(['taskkill', '/F', '/IM', name], capture_output=True)
    time.sleep(3)
    lock = Path(project).parent / 'g_08_1_files' / '.lock'
    if lock.exists():
        lock.unlink()
    p = subprocess.Popen([RUNWB, '-F', project, '-R', MACRO])
    t0 = time.time()
    def _done(f):   # the macro creates the .wb.json early and fills it at the end: wait for valid JSON
        try:
            return f.exists() and f.stat().st_size > 0 and json.loads(f.read_text(encoding='utf-8')) is not None
        except (OSError, ValueError):
            return False
    while time.time() - t0 < timeout:
        if _done(res) and _done(Path(str(res) + '.wb.json')):
            break
        time.sleep(5)
    time.sleep(5)
    for name in ('AnsysFWW.exe', 'AnsysWBU.exe', 'SpaceClaim.exe'):   # always release the project
        subprocess.run(['taskkill', '/F', '/IM', name], capture_output=True)
    if not res.exists():
        return None
    out = json.loads(res.read_text())
    out.update(reference=ref, reference_sha256=ref_hash, reference_unchanged=_sha(ref) == ref_hash, work_copy=project)
    if not out['reference_unchanged']:
        out['passed'] = False
        out['reference_error'] = 'эталон проекта изменился во время сборки — сборка не принимается'
    res.write_text(json.dumps(out, indent=1))
    return out


def make_doe(n, seed=1, start=1):
    """Latin hypercube over geometry + regime variables (bounds are the screening ranges)."""
    rnd = random.Random(seed)
    # Variables from the screening + literature hints (G_dzv/G_svz 0.05-1.5 is controlled by the DZV gap and
    # the DZV pressure drop; pi = p0_svz/p_out_svz up to ~12-16 is a separate regime study, p_out_svz 0.1-0.4 MPa).
    names = ['r_end_mm', 'l_heat_mm', 'gap_mm', 'p0_svz_MPa', 'p_out_svz_MPa', 'dp_dzv_MPa']
    lo = [4.2, 250, 0.15, 1.1, 0.10, 0.02]
    hi = [6.0, 500, 0.6, 1.6, 0.40, 0.30]
    cols = []
    for _ in names:
        idx = list(range(n)); rnd.shuffle(idx); cols.append([(i + rnd.random()) / n for i in idx])
    out = []
    for i in range(n):
        d = {nm: lo[j] + (hi[j] - lo[j]) * cols[j][i] for j, nm in enumerate(names)}
        out.append(dict(id=f'v{start+i:03d}', r_end_mm=d['r_end_mm'], l_heat_mm=d['l_heat_mm'], gap_mm=d['gap_mm'],
                        regimes=[dict(p0_svz_MPa=d['p0_svz_MPa'], p_out_svz_MPa=d['p_out_svz_MPa'],
                                      p0_dzv_MPa=5.5, p_out_dzv_MPa=5.5 - d['dp_dzv_MPa'])]))
    return out


def run_variant(v, reuse_mesh=False):
    vd = L.DS / 'variants' / v['id']
    log = {'id': v['id']}
    if not reuse_mesh:
        r = build_mesh(v)
        log['mesh'] = r
        if not r or not r.get('passed'):
            L.append_row(dict(case_id=v['id'], geom_r_end_mm=v['r_end_mm'], geom_l_heat_mm=v['l_heat_mm'], geom_gap_mm=v['gap_mm']),
                         dict(status='mesh_failed', converged=0, why=str(r)[:200]))
            return log
    try:
        c = B.build(vd / 'mesh.msh', vd / 'fluent', p0_svz_MPa=v['regimes'][0]['p0_svz_MPa'])
    except Exception as e:
        L.append_row(dict(case_id=v['id'], geom_r_end_mm=v['r_end_mm'], geom_l_heat_mm=v['l_heat_mm'], geom_gap_mm=v['gap_mm']),
                     dict(status='fluent_case_failed', converged=0, why=str(e)[:200]))
        return log
    base = c['initial_case']
    for k, reg in enumerate(v['regimes']):
        spec = dict(reg, case_id=f"{v['id']}_r{k}", geom_r_end_mm=v['r_end_mm'], geom_l_heat_mm=v['l_heat_mm'], geom_gap_mm=v['gap_mm'])
        res = L.run_case(spec, base, vd / f'run_r{k}', max_stages=6, iters=300, threads=4)
        L.append_row(spec, res)
        log[f'run{k}'] = res
        if res.get('final_case'):
            base = res['final_case']          # warm start next regime from the previous result
    return log


if __name__ == '__main__':
    variants = json.loads(Path(sys.argv[1]).read_text())
    for v in variants:
        print(json.dumps(run_variant(v), default=str)[:400], flush=True)
