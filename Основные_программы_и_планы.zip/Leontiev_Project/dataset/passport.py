"""30.10.2026 — паспорт расчёта (решение автора: интерфейс автора, шаг 1): тип трубы, геометрия, режим, сетка, из какого расчёта
продолжен, серия и план. Новые расчёты получают паспорт при постановке в очередь (jobqueue.py); для уже посчитанных —
восстановление по цепочке: продолжение (cont.jou: read-case-data → папка-источник) … → шаблон / расчёт с нуля (params.json
gui_runner: геометрия, сетка, начальный режим). Режим точки — из её собственного журнала (именованные выражения давлений, T0).
Сверка с обучением (как data_audit.md): паспорт каждой точки обучения против её входа модели x.
usage: python passport.py   → runs\\queue\\passports.json, runs\\queue\\паспорта_сверка.md"""
import csv, json, math, re, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')

R = Path(r'F:\Leontiev_Project\runs')
Q = R / 'queue'
D_OUT, THROAT = 6.3 * 2, 2.25
SERIES = [   # (префикс метки или папка, серия, план)
    ('a9/', 'А9 — опорный датасет', 'ЛГК (план 14.10)'), ('setA/', 'набор А', 'ЛГК по неопределённости'),
    ('setB/', 'добор Б', 'добор по неопределённости'), ('station/AU', 'автопополнение', 'max неопределённости 4p(1−p)+σ/δ'),
    ('station/ST', 'станция / журнал решений', 'точки задач (прогноз до расчёта)'), ('station/CF', 'sppr --confirm', 'команда программы'),
    ('patents/KQ', 'накатка KS10 при равном расходе ДЗВ', 'D-24: подбор перепада'), ('patents/KM', 'разведка мелкой накатки', 'h 0,1/0,2/0,3, шаг 2'),
    ('patents/KS', 'накатка RU 233137', 'патентный шаг'), ('patents/RU2836642', 'три потока RU 2836642', 'остановлено (D-18)'),
    ('nozzle/', 'сопло как фактор (D-26)', 'срезанный ЛГК'), ('a3a/', 'A3a — проверка на новых трубах', 'максимин + срезанный ЛГК'),
    ('pilot/', 'пилот ячейки', 'пилотные режимы'), ('cell3d', '3D-проверка', '—'),
    ('station/IF', 'интерфейс автора (окно 2)', 'план окна 2'),   # 31.10: серии интерфейса автора
]


def _num(s):
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def td_from_gap(gap):
    """Зазор 2D-ячейки = R_экв − r_o, R_экв² = √3/(2π)·t² → t/d."""
    req = gap + D_OUT / 2
    return round(req / math.sqrt(math.sqrt(3) / (2 * math.pi)) / D_OUT, 3)


def series_of(d):
    rel = str(d.relative_to(R)).replace('\\', '/')
    for key, s, plan in SERIES:
        if rel.startswith(key) or ('/' + key.split('/')[-1]) in '/' + rel and key.endswith(('AU', 'ST', 'CF', 'KQ', 'KM', 'KS')) and rel.split('/')[0] == key.split('/')[0]:
            return s, plan
    return rel.split('/')[0], '—'


def _cells(d):
    for f in (d / 'run_log.txt',):
        if f.exists():
            m = re.findall(r'Сетка готова: (\d+)', f.read_text(encoding='utf-8', errors='replace'))
            if m:
                return int(m[-1])
    return None


def regime_from_jou(text):
    out = {}
    for k, v in re.findall(r'named-expressions/edit (\w+) definition "([-\d.e+]+) \[Pa\]"', text):
        out[k] = float(v) / 1e6
    t0 = {}
    for zones, v in re.findall(r'set/pressure-inlet ((?:inlet_\w+ ?)+) \(\) t0 no ([-\d.]+)', text):
        for z in zones.split():
            t0[z] = float(v)
    reg = {}
    if out:
        reg = dict(p_main=out.get('inlet_svz'), p_cons=out.get('outlet_svz'), p0_dzv=out.get('pressure_inlet_dzv'), p_out_dzv=out.get('outlet_dzv'))
    if t0:
        reg.update(T0_svz=t0.get('inlet_svz'), T0_dzv=t0.get('inlet_dzv', t0.get('inlet_svz')))
    if 'real-gas-peng-robinson' in text:
        reg['gas'] = 'метан ПР'
    elif 'polynomial 4 2.143344e+03' in text:
        reg['gas'] = 'метан идеальный'
    return reg


def resolve(d, depth=0):
    """Паспорт по цепочке источников (без Fluent)."""
    d = Path(d)
    p = dict(tag=d.name, dir=str(d), parent=None)
    try:
        p['series'], p['plan'] = series_of(d)
    except ValueError:
        p['series'], p['plan'] = '—', '—'
    jou = d / 'cont.jou'
    prm = d / 'params.json'
    if jou.exists() and depth < 40:
        text = jou.read_text(encoding='utf-8', errors='replace')
        m = re.search(r'/file/read-case-data "([^"]+)"', text)
        if m:
            src = Path(m.group(1).replace('/', '\\')).parent
            if not src.exists() and (d.parent / src.name).exists():   # 30.10: папки серий перенесены fix_misplaced_1030.py из runs\station
                src = d.parent / src.name
            base = resolve(src, depth + 1) if src.exists() else {}
            p.update({k: v for k, v in base.items() if k in ('kind', 'geometry', 'mesh')})
            p['parent'] = str(src)
            reg = dict(base.get('regime') or {})
            reg.update({k: v for k, v in regime_from_jou(text).items() if v is not None})
            p['regime'] = reg
            p['how'] = 'продолжение'
        return _finish(p)
    if prm.exists():
        q = json.loads(prm.read_text(encoding='utf-8'))
        kn = q.get('knurl_dzv')
        rex = float(q.get('r_nozzle_exit_mm') or 3.3)
        gap = _num(q.get('gap_mm'))
        p['kind'] = 'накатка' if kn else ('сопло' if abs(rex - 3.3) > 1e-6 else 'гладкая')
        p['geometry'] = dict(t_d=td_from_gap(gap) if gap else None, L_mm=_num(q.get('l_heat_mm')), gap_mm=gap,
                             throat_mm=THROAT, r_exit_mm=rex, area_ratio=round((rex / THROAT) ** 2, 3), r_end_mm=_num(q.get('r_end_mm')),
                             wall_in_mm=_num(q.get('wall_thickness_inlet_mm')), wall_end_mm=_num(q.get('wall_thickness_end_mm')),
                             knurl=dict(h_mm=kn.get('h_mm'), pitch_mm=kn.get('pitch_mm'), width_mm=kn.get('width_mm')) if kn else None)
        p['mesh'] = dict(axial_mm=_num(q.get('axial_size_mm')), dzv_layers=q.get('dzv_layers'), dzv_h1_mm=_num(q.get('dzv_h1_mm')),
                         core_div=q.get('core_div'), nozzle_div=q.get('nozzle_div'), cells=_cells(d),
                         preset='work_v2' if q.get('mesh_custom') and _num(q.get('axial_size_mm')) == 1.0 else 'своя')
        reg = dict(p_main=_num(q.get('p0_svz_MPa')), p_cons=_num(q.get('p_out_svz_MPa')), p0_dzv=_num(q.get('p0_dzv_MPa')),
                   p_out_dzv=_num(q.get('p_out_dzv_MPa')), gas={'ch4_pr': 'метан ПР', 'ch4_ideal': 'метан идеальный'}.get(q.get('gas'), q.get('gas')))
        reg.update(regime_from_jou('\n'.join(q.get('extra_lines') or [])))
        p['regime'] = reg
        p['how'] = 'шаблон / с нуля (gui_runner)'
        return _finish(p)
    p['how'] = 'нет журнала (своя сетка или неполная папка)'
    return _finish(p)


def _finish(p):
    r = p.get('regime') or {}
    if r.get('p0_dzv') is not None and r.get('p_out_dzv') is not None:
        r['dp_dzv_kPa'] = round((r['p0_dzv'] - r['p_out_dzv']) * 1000, 3)
    if r.get('T0_svz') is not None and r.get('T0_dzv') is not None:
        r['heat_K'] = round(r['T0_svz'] - r['T0_dzv'], 3)
    return p


def training_points():
    """Точки обучения с папками (та же выборка, что station_gp.rows / data_audit)."""
    import model_compare as MC
    import gui_convergence as C
    conv = lambda d: (lambda r: bool(r) and C.decision(r))(C.closed_samples(d))
    xr = lambda d: [float(d['t_d']), float(d['L_mm']), math.log(float(d['dp_dzv_kPa'])), float(d['p_cons']), float(d['t0_dzv']),
                    float(d.get('heater') or 0.0), float(d.get('p_main') or 5.5)]
    out = []
    D = {q['id']: q for q in csv.DictReader(open(R / 'a9/a9_design.csv', encoding='utf-8'))}
    for s in csv.DictReader(open(R / 'a9/a9_points_status.csv', encoding='utf-8')):
        if s['num_status'] == 'сошлась' and s['id'] not in ('A9_11', 'A9_35', 'A9_36'):
            out.append(('А9', R / 'a9' / s['result'], xr(D[s['id']])))
    for ser, des, resf, nm in (('setA', 'setA_design.csv', 'setA_results.csv', 'набор А'), ('setB', 'setB_design.csv', 'setB_results.csv', 'добор Б')):
        DD = {q['id']: q for q in csv.DictReader(open(R / ser / des, encoding='utf-8'))}
        RR = {r['tag'] for r in csv.DictReader(open(R / ser / resf, encoding='utf-8'))}
        for pid, d in DD.items():
            if d.get('set') == 'отложенная':
                continue
            for t in (pid + 'cc', pid + 'c', pid):
                if t in RR and conv(R / ser / t):
                    out.append((nm, R / ser / t, xr(d))); break
    for x, r, geo in MC.station_points():
        out.append(('станция / авто', R / 'station' / r['tag'], [x[0], x[1] * 6.6] + list(x[2:])))
    for p in MC.frozen_extra():   # 01.11 (D-32, D-33): добор В
        out.append((p['src'], Path(p['folder']), [p['x'][0], p['x'][1] * 6.6] + list(p['x'][2:])))
    return out


def check(passports):
    """Паспорт против входа модели: t/d, L, перепад ДЗВ, потребитель, T газа, подогрев, магистраль."""
    names = ('t/d', 'L', 'перепад ДЗВ', 'потребитель', 'T ДЗВ', 'подогрев', 'магистраль')
    tol = (0.01, 0.6, 0.01, 0.002, 0.05, 0.05, 0.002)
    rows, by_src = [], {}
    for src, d, x in training_points():
        pp = passports.get(str(d))
        bs = by_src.setdefault(src, [0, 0, 0])
        bs[0] += 1
        if not pp:
            rows.append((src, d.name, 'нет паспорта (папки нет)')); continue
        g, r = pp.get('geometry') or {}, pp.get('regime') or {}
        v = [g.get('t_d'), g.get('L_mm'), math.log(r['dp_dzv_kPa']) if r.get('dp_dzv_kPa') else None, r.get('p_cons'),
             r.get('T0_dzv'), r.get('heat_K'), r.get('p_main')]
        bad = [f'{names[i]}: паспорт {v[i]} / модель {round(x[i], 4)}' for i in range(7)
               if v[i] is None or abs(v[i] - x[i]) > tol[i] + (abs(x[i]) * 0.002 if i == 1 else 0)]
        if bad:
            bs[2] += 1; rows.append((src, d.name, '; '.join(bad)))
        else:
            bs[1] += 1
    return by_src, rows


def main():
    Q.mkdir(parents=True, exist_ok=True)
    t = time.time()
    dirs = sorted({f.parent for pat in ('*/*/cont.jou', '*/*/params.json', '*/*/*/cont.jou', '*/*/*/params.json') for f in R.glob(pat)})
    pas = {}
    for d in dirs:
        try:
            pas[str(d)] = resolve(d)
        except Exception as e:
            pas[str(d)] = dict(tag=d.name, dir=str(d), error=repr(e))
    old = json.loads((Q / 'passports.json').read_text(encoding='utf-8')) if (Q / 'passports.json').exists() else {}
    for k, v in old.items():   # паспорта, записанные при постановке в очередь, не перезаписываются восстановленными
        if v.get('source') == 'очередь':
            pas[k] = v
    (Q / 'passports.json').write_text(json.dumps(pas, ensure_ascii=False, indent=1), encoding='utf-8')
    by_src, bad = check(pas)
    L = [f'# Паспорта расчётов: восстановление по цепочке и сверка с обучением ({time.strftime("%d.%m.%Y %H:%M")})', '',
         f'Папок расчётов: {len(pas)}; без журнала/параметров: {sum(1 for v in pas.values() if not v.get("geometry"))}; ошибок разбора: '
         f'{sum(1 for v in pas.values() if v.get("error"))}. Время {time.time() - t:.0f} с.', '',
         'Сверка «паспорт ↔ вход модели» для точек обучения (как data_audit.md):', '',
         '| источник | точек в обучении | паспорт совпал | расхождения |', '|---|---|---|---|']
    for s, (n, ok, b) in by_src.items():
        L.append(f'| {s} | {n} | {ok} | {b} |')
    tot = [sum(v[i] for v in by_src.values()) for i in range(3)]
    L.append(f'| **всего** | **{tot[0]}** | **{tot[1]}** | **{tot[2]}** |')
    if bad:
        L += ['', '## Расхождения', '', '| источник | точка | что не совпало |', '|---|---|---|'] + [f'| {a} | {b} | {c} |' for a, b, c in bad]
    (Q / 'паспорта_сверка.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
    print('\n'.join(L[:12 + len(by_src)]))
    if bad:
        print('\n'.join(f'{a} {b}: {c}' for a, b, c in bad[:15]))


if __name__ == '__main__':
    main()
