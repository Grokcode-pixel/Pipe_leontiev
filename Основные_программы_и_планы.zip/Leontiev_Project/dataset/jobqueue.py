"""30.10.2026 — общая очередь расчётов (решение автора: один список заданий, один исполнитель; интерфейс только ставит в очередь).
Файл runs\\queue\\jobs.json — список заданий по порядку. Задание: id, когда и кем поставлено, серия, план, вид:
  'script' — серия целиком (готовый раннер: knurl_shallow.py, nozzle_series.py, …), 'point' — одна точка CFD (job_point.py);
паспорт (тип трубы, геометрия, режим, сетка, источник, серия, план), оценка часов, статус: ждёт / идёт / готово / сбой / снято.
Запись — через блокировку файла (интерфейс и исполнитель не пишут одновременно). Каждая постановка — строка в Журнал_работ.md."""
import json, os, time
from contextlib import contextmanager
from pathlib import Path

Q = Path(r'F:\Leontiev_Project\runs\queue')
JOBS = Q / 'jobs.json'
LOCK = Q / 'jobs.lock'
PASSPORTS = Q / 'passports.json'
JOURNAL = Path(r'F:\Leontiev_Project\Журнал_работ.md')
STATUSES = ('ждёт', 'идёт', 'готово', 'сбой', 'снято')


@contextmanager
def locked(timeout=60):
    Q.mkdir(parents=True, exist_ok=True)
    t = time.time()
    while True:
        try:
            fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY); os.write(fd, str(os.getpid()).encode()); os.close(fd); break
        except FileExistsError:
            if time.time() - LOCK.stat().st_mtime > 300:   # брошенная блокировка (процесс умер)
                LOCK.unlink(missing_ok=True); continue
            if time.time() - t > timeout:
                raise TimeoutError('очередь занята')
            time.sleep(0.2)
    try:
        yield
    finally:
        LOCK.unlink(missing_ok=True)


def load(path=JOBS):
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else []


def save(jobs, path=JOBS):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(jobs, ensure_ascii=False, indent=1), encoding='utf-8')
    os.replace(tmp, path)


def journal(line):
    with open(JOURNAL, 'a', encoding='utf-8') as f:
        f.write(f'- {time.strftime("%d.%m.%Y %H:%M")} — очередь: {line}\n')


def add(jobs_new, by='автор', path=JOBS, write_journal=True, after=None):
    """jobs_new: список dict(series, plan, kind, script|point, passport, est_h, note, text_change). Паспорт пишется сразу
    (source = 'очередь'). after — id задания, за которым встать (иначе в конец).
    30.10.2026 (решение автора, «стоп-кран»): новая серия Fluent ставится только с ответом «какое положение и какое число в
    тексте она изменит» — поле text_change обязательно."""
    miss = [j.get('series') for j in jobs_new if not str(j.get('text_change') or '').strip()]
    if miss:
        raise ValueError(f'стоп-кран: нет ответа «какое положение и какое число в тексте изменит» (text_change) — {miss}')
    with locked():
        jobs = load(path)
        n = max([int(j['id'][1:]) for j in jobs] or [0])
        pos = next((i + 1 for i, j in enumerate(jobs) if j['id'] == after), len(jobs))
        out = []
        for j in jobs_new:
            n += 1
            j = dict(j, id=f'J{n:04d}', added=time.strftime('%d.%m.%Y %H:%M:%S'), by=by, status='ждёт')
            jobs.insert(pos, j); pos += 1; out.append(j)
        save(jobs, path)
        if path == JOBS:
            pas = json.loads(PASSPORTS.read_text(encoding='utf-8')) if PASSPORTS.exists() else {}
            for j in out:
                if j.get('passport'):
                    pas[f"queue:{j['id']}"] = dict(j['passport'], source='очередь', job=j['id'])
            PASSPORTS.write_text(json.dumps(pas, ensure_ascii=False, indent=1), encoding='utf-8')
    if write_journal and out:
        s = out[0]
        journal(f"поставлено {len(out)} задан(ий) {out[0]['id']}–{out[-1]['id']} ({by}): серия «{s.get('series')}», план «{s.get('plan')}», "
                f"≈ {sum(float(j.get('est_h') or 0) for j in out):.1f} ч")
    return out


def update(job_id, path=JOBS, **kw):
    with locked():
        jobs = load(path)
        for j in jobs:
            if j['id'] == job_id:
                j.update(kw)
        save(jobs, path)


def remove(job_id, path=JOBS):
    """Снять задание (только «ждёт»)."""
    with locked():
        jobs = load(path)
        for j in jobs:
            if j['id'] == job_id and j['status'] == 'ждёт':
                j['status'] = 'снято'; j['finished'] = time.strftime('%d.%m.%Y %H:%M:%S')
        save(jobs, path)
    journal(f'задание {job_id} снято')
