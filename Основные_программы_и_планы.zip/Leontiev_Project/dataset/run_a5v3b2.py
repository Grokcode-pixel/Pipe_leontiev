"""A5 v3b, continuations redone (10.10.2026 06:20).  In run_a5v3b.py (resolved DZV mesh, 40 layers) the start field was
obtained (a5v3_start: iteration limit, shock x 0.551 m, as in the old series), but BOTH continuations with the targeted
DZV mass flow failed: m 0.30 diverged at iteration 8212 (NaN at inlet_dzv), m 0.11 swung the DZV flow from +0.022 to
-0.006 kg/s with an energy imbalance of 1076 W at 8500.  The targeted-mass-flow outlet is unstable on the fine DZV
layers.  Fix: the DZV flow is set by a FIXED outlet pressure (stable pressure BC); the pressure is estimated from the old
series (1.04968 / 1.04873 / 1.04381 MPa for m 0.11 / 0.30 / 0.75) with a factor 2 on the pressure drop for the finer
wall layers; if the achieved m is off by more than 15 %, ONE correction continuation with dp*(m_target/m)^1.8.  The
experiment is compared at the ACTUAL m anyway (run_a5v3 summary logic).  CFL 5 for all continuations.
Order: start -> m 0.11 -> 0.30 -> 0.75 -> m 0 (reference), each from the previous converged case.
Rows -> runs\\a5v3b\\a5v3_results.csv (same file), summary a5v3_summary.csv; log a5v3_log.txt."""
import csv, sys, time, traceback
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_a5v3 as A
import cont_util as U

A.BASE = Path(r'F:\Leontiev_Project\runs\a5v3b')
A.CSV = A.BASE / 'a5v3_results.csv'
U.CFL = 5.0
P0 = 1.05
DP0 = {0.11: 2 * 0.00032, 0.30: 2 * 0.00127, 0.75: 2 * 0.00619}
log = A.log


def run_point(prev, m, dp, tag):
    out = A.BASE / tag
    pod = round(P0 - dp, 6)
    mins = U.continue_case(prev, out, A.TMF_OFF, (P0, 0.1, P0, pod), log, f'{tag} (давление на выходе ДЗВ {pod:.5f} МПа)',
                           t0_C=A.T0_C)
    r = U.record(A.CSV, tag, 'rig_work_v2', 'air', (P0, 0.1, P0, pod), out, mins, log, start=f'продолжение {prev.parent.name}',
                 t0_C=A.T0_C, l_heat_mm=700.0)
    return out, r


def main():
    prev = A.BASE / 'a5v3_start' / 'result.cas.h5'
    rows = {}
    for m in (0.11, 0.30, 0.75):
        tag = f'a5v3_m{int(round(m * 100)):03d}p'
        dp = DP0[m]
        out, r = run_point(prev, m, dp, tag)
        if (out / 'result.cas.h5').exists() and r.get('G_dzv') and r.get('G_svz'):
            mc = float(r['G_dzv']) / float(r['G_svz'])
            log(f'  {tag}: достигнутый m {mc:.3f} (цель {m})')
            if mc > 0 and abs(mc - m) / m > 0.15:
                prev = out / 'result.cas.h5'
                dp = dp * (m / mc) ** 1.8
                out, r = run_point(prev, m, dp, tag + '2')
        rows[m] = r
        if (out / 'result.cas.h5').exists():
            prev = out / 'result.cas.h5'
    out = A.BASE / 'a5v3_m000p'
    mins = U.continue_case(prev, out, A.TMF_OFF, (P0, 0.1, P0, P0), log, 'a5v3_m000p (ДЗВ без расхода, опорный для ф. 14)',
                           t0_C=A.T0_C)
    r0 = U.record(A.CSV, 'a5v3_m000p', 'rig_work_v2', 'air', (P0, 0.1, P0, P0), out, mins, log,
                  start=f'продолжение {prev.parent.name}', t0_C=A.T0_C, l_heat_mm=700.0)
    summary(rows, r0)


def summary(rows, r0):
    """Same comparison as run_a5v3.main (actual m, author's tolerance |dTh| <= 0.5 K, |dTc| <= 1.0 K)."""
    def exp_at(mc, i):
        pts = sorted((k, v[i]) for k, v in A.EXP.items())
        if mc <= pts[0][0]: return pts[0][1] if mc >= pts[0][0] - 0.03 else None
        for (a, fa), (b, fb) in zip(pts, pts[1:]):
            if a <= mc <= b: return fa + (fb - fa) * (mc - a) / (b - a)
        return pts[-1][1] if mc <= pts[-1][0] + 0.03 else None
    base_ok = str(r0.get('converged')) == 'True'
    log(f'  опорный m = 0: статус {r0.get("status")}, сошёлся {base_ok}' + ('' if base_ok else ' — разности ΔTh НЕ принимаются'))
    with (A.BASE / 'a5v3_summary.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['m_target', 'm_calc', 'status', 'converged', 'base_m0_converged', 'G_sup', 'dTc_calc', 'dTc_exp_at_m',
                    'dTc_diff', 'dTh_calc', 'dTh_exp_at_m', 'dTh_diff'])
        for m, r in sorted(rows.items()):
            try:
                mc = float(r['G_dzv']) / float(r['G_svz'])
                dtc = float(r['dT_dzv_total'])
                dth = float(r['dT_svz_total']) - float(r0['dT_svz_total'])
                ec, eh = exp_at(mc, 0), exp_at(mc, 1)
                conv = str(r.get('converged')) == 'True'
                w.writerow([m, round(mc, 3), r['status'], conv, base_ok, r['G_svz'], round(dtc, 3),
                            '' if ec is None else round(ec, 2), '' if ec is None else round(dtc - ec, 2),
                            round(dth, 3), '' if eh is None else round(eh, 2), '' if eh is None or not base_ok else round(dth - eh, 2)])
                ok = (conv and base_ok and ec is not None and eh is not None and abs(dtc - ec) <= 1.0 and abs(dth - eh) <= 0.5)
                log(f'  сверка m {m}: m расч. {mc:.3f}; ΔTc {dtc:+.2f} (опыт при этом m {ec if ec is None else round(ec, 2)}) K; '
                    f'ΔTh {dth:+.2f} (опыт {eh if eh is None else round(eh, 2)}) K; Q {r.get("Q")} Вт; '
                    f'сошёлся {conv}, опорный {base_ok}; в допуске: {"да" if ok else "нет"}')
            except Exception:
                w.writerow([m, '', r.get('status'), '', base_ok, '', '', '', '', '', '', ''])


if __name__ == '__main__':
    A.qlog('=== А5 v3b2 (продолжения с фиксированным давлением на выходе ДЗВ, CFL 5) — начат')
    try:
        main()
    except Exception:
        log('ОШИБКА программы: ' + traceback.format_exc())
    A.qlog('=== А5 v3b2 — закончен (приёмка — по результатам)')
