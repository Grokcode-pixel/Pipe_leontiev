"""Create a journal that sets turbulent Prandtl numbers the way the Viscous Model dialog does
(set rp variables, open the dialog through the navigation tree, press OK).  Needs a Fluent WITH a window."""
import sys
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import leontiev_pipeline as L

GUI_PRT = [
    '(rpsetvar (quote keprt) {prt})',
    '(rpsetvar (quote wallprt) {prt})',
    '(cx-gui-do cx-set-list-tree-selections "NavigationPane*Frame2*Table1*List_Tree2" (list "Setup|Models|Viscous (SST k-omega)"))',
    '(cx-gui-do cx-activate-item "NavigationPane*Frame2*Table1*List_Tree2")',
    '(cx-gui-do cx-activate-item "Viscous Model*PanelButtons*PushButton1(OK)")',
]


def with_prt(journal_text, prt):
    lines = journal_text.split('\n')
    i = [k for k, l in enumerate(lines) if l.startswith('/file/read-case-data')][0]
    lines[i + 1:i + 1] = [g.format(prt=prt) for g in GUI_PRT]
    return '\n'.join(lines)


if __name__ == '__main__':
    case_in, case_out, trn, jou, n_iter, report, prt = sys.argv[1:8]
    s = dict(p0_svz_MPa=1.6, p_out_svz_MPa=0.3, p0_dzv_MPa=5.5, p_out_dzv_MPa=5.2)
    j = L.stage_journal(s, case_in, case_out, trn, int(n_iter), 10, report_every=int(report))
    open(jou, 'w').write(with_prt(j, prt))
