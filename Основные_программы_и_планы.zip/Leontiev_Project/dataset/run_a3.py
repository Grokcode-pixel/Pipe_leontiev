"""Stage A3: mesh.  n95 geometry, patent regime (SVZ 5.5->0.3 MPa, DZV 5.5->5.2 MPa), SST + Prt 0.85.
Three meshes refined ~2x in every direction (author approved 07.10.2026 21:10):
  coarse : axial 2.0 mm, core 35, wall strip x1 (first SVZ cell 1 um),    DZV first layer 0.2 um / 16 layers, size 1.0 mm
  work   : axial 1.0 mm, core 70, wall strip x2 (0.5 um, y+ target <= 1), DZV 0.1 um / 20 layers,          size 0.5 mm
  fine   : axial 0.5 mm, core 140, wall strip x4 (0.25 um),               DZV 0.05 um / 24 layers,         size 0.25 mm
Each mesh: full run (Workbench mesh -> Fluent FMG start -> coupled, auto-stop; row in gui_runs.csv), then the
adiabatic wall (brass k = 1e-5) continued from that solution -> r by axis / 1D / wall-pressure Mach (as in A2).
usage: python run_a3.py [work coarse fine]      results: runs\\a3\\a3_results.csv, log runs\\a3\\a3_log.txt"""
import csv, json, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import leontiev_pipeline as L
import gui_runner as G
import gui_convergence as C
import run_a2 as A2
import r_variants as RV
from make_gui_prt_journal import GUI_PRT

BASE = Path(r'F:\Leontiev_Project\runs\a3')
WALL = A2.WALL
LIMIT = 5500
MESHES = {
    'work':   dict(axial_size_mm=1.0, convergent_div=80,  layer_div=2, core_div=70,  dzv_h1_mm=0.0001,  dzv_layers=20, global_size_mm=0.5),
    'coarse': dict(axial_size_mm=2.0, convergent_div=40,  layer_div=1, core_div=35,  dzv_h1_mm=0.0002,  dzv_layers=16, global_size_mm=1.0),
    'fine':   dict(axial_size_mm=0.5, convergent_div=160, layer_div=4, core_div=140, dzv_h1_mm=0.00005, dzv_layers=24, global_size_mm=0.25),
    # 08.10.2026, author's choice (б): 'fine' did not converge (oscillation in the DZV channel, DZV mass ±0.1 %,
    # continuity ~2e-3 at 6000 it) -> refine along the length and in the SVZ only, DZV first layer kept at 0.1 um / 20
    # 08.10.2026 v2 (smooth nozzle contour geometry_script_v2 + nozzle axial growth 20/40/80 div., factor 10 from the throat;
    # cell at the throat ~ convergent cell, at the nozzle exit ~ channel cell); fine: convergent strips split as on work
    'coarse_v2': dict(axial_size_mm=2.0, convergent_div=40, nozzle_div=20, nozzle_bias=10, layer_div=1, core_div=35,
                      dzv_h1_mm=0.0002, dzv_layers=16, global_size_mm=1.0),
    'work_v2':   dict(axial_size_mm=1.0, convergent_div=80, nozzle_div=40, nozzle_bias=10, layer_div=2, core_div=70,
                      dzv_h1_mm=0.0001, dzv_layers=20, global_size_mm=0.5),
    'fine_v2':   dict(axial_size_mm=0.5, convergent_div=160, nozzle_div=80, nozzle_bias=10, layer_div=4, layer_div_convergent=2,
                      core_div=140, dzv_h1_mm=0.00005, dzv_layers=24, global_size_mm=0.25),
    'fine2':  dict(axial_size_mm=0.5, convergent_div=160, layer_div=4, core_div=140, dzv_h1_mm=0.0001, dzv_layers=20, global_size_mm=0.25),
}


def log(s):
    line = time.strftime('%H:%M:%S ') + s
    print(line, flush=True)
    BASE.mkdir(parents=True, exist_ok=True)
    with (BASE / 'a3_log.txt').open('a', encoding='utf-8') as f:
        f.write(line + '\n')


def adiabatic(src, out):
    """Continue the converged conjugate solution with an adiabatic wall; export fields for r."""
    out.mkdir(parents=True, exist_ok=True)
    for f in list(out.glob('*.trn')) + list(out.glob('*.csv')):
        f.unlink()
    q = L.fl(out)
    lines = ['/file/confirm-overwrite? no', f'/file/start-transcript "{q}/run.trn"', f'/file/read-case-data "{L.fl(src)}"']
    lines += [g.format(prt=0.85) for g in GUI_PRT] + [L.AIR_K_LINE]   # 08.10: k(T) applied explicitly in continuations
    lines += ['/define/materials/change-create latun latun no no yes constant 1e-05', '/define/materials/list-properties latun']
    lines += C.coupled_journal(dict(coupled_iters=LIMIT, report_every=500, cfl=20.0), out)
    lines += [f'/file/write-case-data "{q}/result.cas.h5"',
              f'/file/export/ascii "{q}/svz_faces.csv" interior-air_svz () yes density axial-velocity temperature '
              'total-temperature pressure total-pressure mach-number () no',
              f'/file/export/ascii "{q}/wall_p.csv" {WALL} () yes pressure temperature () yes',
              f'/file/export/ascii "{q}/wall.csv" {WALL} () yes temperature heat-flux () yes',
              f'/file/export/ascii "{q}/axis.csv" axis () yes mach-number pressure total-pressure temperature '
              'total-temperature axial-velocity () yes', '/file/stop-transcript']
    jou = out / 'adiabatic.jou'
    jou.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    t0 = time.time()
    subprocess.Popen([L.FLUENT, '2ddp', '-t7', '-i', str(jou)], cwd=str(out), stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True)
    first, said = None, False
    while not (out / 'axis.csv').exists():
        rows = C.closed_samples(out)
        if rows and first is None:
            first = rows[0]['iteration'] - 500
        c = C.update_control(out, True, max_iter=first + LIMIT if first is not None else None)
        if c['stop_requested'] and not said:
            log('  адиабатная стенка: критерии выполнены в двух проверках подряд — Fluent сохранит кейс'); said = True
        st = G.status(out)
        if st and (st['fpe'] or st['error']):
            G.kill_since(t0)
            log(f'  адиабатная стенка: СБОЙ на итерации {st["iter"]}')
            return None
        if time.time() - t0 > 6 * 3600:
            G.kill_since(t0); log('  адиабатная стенка: СБОЙ (время)'); return None
        time.sleep(10)
    time.sleep(10)
    G.kill_since(t0)
    res = dict(conv_adiab=C.decision(C.closed_samples(out)), min_adiab=round((time.time() - t0) / 60, 1))
    res.update(A2.recovery(out))
    for k, v in RV.analyse(out).items():
        res[f'r_{k}'] = v['r']
    return res


def run(name):
    p = dict(G.DEFAULTS)
    p.update(MESHES[name], run_id=f'a3_{name}', prt=0.85, mesh_custom=True, wait_free=True)
    G.RUNS = BASE
    out = BASE / p['run_id']
    log(f'=== сетка «{name}»: ' + ', '.join(f'{k}={v}' for k, v in MESHES[name].items()))
    t0 = time.time()
    G.run(p, lambda s: log('  ' + s), lambda: False)
    if not (out / 'axis.csv').exists() or not (out / 'result.cas.h5').exists():
        return log(f'{name}: сопряжённый расчёт не дал результата — адиабатный не запускаю')
    st = G.status(out)
    b = st['samples'][-1]
    closed = C.closed_samples(out)
    cells = G.verify_mesh(p, L.DS / 'variants' / p['run_id'] / 'mesh.msh')
    res = dict(mesh=name, cells=cells, converged=G.converged(out), iter=st['iter'],
               dT_svz=round(b['dT_svz'], 3), dT_dzv=round(b['dT_dzv'], 3), Q=round(b['Q'], 1),
               m_svz=round(closed[-1]['m_svz'], 6) if closed else '', m_dzv=round(closed[-1]['m_dzv'], 6) if closed else '',
               ratio=round(b['ratio'], 4), yp_svz=round(b['yp_svz'], 3), yp_dzv=round(b['yp_dzv'], 3),
               min_conj=round((time.time() - t0) / 60, 1))
    log(f"{name}: {cells} ячеек; ΔT СВЗ {res['dT_svz']:+.3f} K, ΔT ДЗВ {res['dT_dzv']:+.3f} K, Q {res['Q']:.1f} Вт, "
        f"G СВЗ {res['m_svz']} кг/с, G_дз/G_сз {res['ratio']}, y+ СВЗ/ДЗВ {res['yp_svz']}/{res['yp_dzv']}")
    log(f'{name}: адиабатная стенка (продолжение того же решения) для r')
    a = adiabatic(out / 'result.cas.h5', BASE / f'{p["run_id"]}_adiab')
    if a:
        res.update(a)
        log(f"{name}: r по оси {a['r_mean']}, по 1D M {a.get('r_1D')}, по p стенки {a.get('r_pwall')}; T стенки {a['Tw_mean_K']} K")
    new = not (BASE / 'a3_results.csv').exists()
    cols = ['mesh', 'cells', 'converged', 'iter', 'dT_svz', 'dT_dzv', 'Q', 'm_svz', 'm_dzv', 'ratio', 'yp_svz', 'yp_dzv',
            'min_conj', 'conv_adiab', 'min_adiab', 'r_mean', 'r_sd', 'r_min', 'r_max', 'n', 'M_mean', 'Tw_mean_K',
            'q_wall_abs_max', 'r_axis', 'r_1D', 'r_pwall']
    with (BASE / 'a3_results.csv').open('a', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction='ignore')
        if new:
            w.writeheader()
        w.writerow(res)


if __name__ == '__main__':
    for name in sys.argv[1:] or ['work', 'coarse', 'fine']:
        try:
            run(name)
        except Exception:
            import traceback; log('ОШИБКА программы: ' + traceback.format_exc())
    log('=== А3, три сетки: закончено')
