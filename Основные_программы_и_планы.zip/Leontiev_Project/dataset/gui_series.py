"""31.10.2026 — интерфейс автора, шаг 2: окно «Новая серия» (задание автора 30.10, ШАГ 2). Tkinter, новых пакетов нет.
Тип трубы (гладкая / накатка / сопло) → диапазоны геометрии и режима → план (одна точка / сетка / ЛГК / срезанный ЛГК —
make_a9_design.sliced_lhs) → сетка (пресет v2 или свои) → список точек с проверками и оценкой времени → «Поставить в очередь».
Проверки: 1D-запуск сверхзвука (модель ru2836642_1d, порог потери полного давления 4,2 — edge_task2_1d), перепад ДЗВ < 15 кПа
(риск сбоя), паспорт применимости (границы данных модели), прогноз ГП: m вне Ω (0,2–0,96) — в очередь НЕ ставится (D-28).
Постановка — jobqueue.add: стоп-кран (поле «какое положение и какое число в тексте изменит» обязательно), паспорт, строка
в Журнал_работ.md; место — перед запасной работой. Прогноз до расчёта — runs\\journal\\gui_forecasts.json. Fluent окно не
запускает: серию считает job_point.py из общей очереди."""
import json, math, sys, threading, time
from pathlib import Path
import numpy as np
import tkinter as tk
from tkinter import ttk, messagebox
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
sys.path.insert(0, r'F:\Leontiev_Project\program')
import jobqueue as JQ

FC = Path(r'F:\Leontiev_Project\runs\journal\gui_forecasts.json')
THR_1D = 4.2                   # порог запуска по потере полного давления (edge_task2_1d)
THROAT_R = 2.25                # мм, горло сопла базы
KINDS = ('гладкая', 'накатка', 'сопло')
# ключ, подпись, от, до, логарифм, для каких типов
FACTORS = [('td', 't/d', 1.4, 1.4, False, KINDS), ('L', 'L теплообмена, мм', 400.0, 400.0, False, KINDS),
           ('h', 'накатка: высота выступа, мм', 0.1, 0.3, True, ('накатка',)), ('pitch', 'накатка: шаг, мм', 2.0, 2.0, False, ('накатка',)),
           ('ar', 'сопло: A/A* (1,44 опыт 2017; 2,15 база)', 2.15, 2.15, False, ('сопло',)),
           ('pm', 'давление магистрали, МПа', 5.5, 5.5, False, KINDS), ('pc', 'давление потребителя, МПа', 0.6, 0.6, False, KINDS),
           ('dp', 'перепад на задвижке ДЗВ, кПа', 15.0, 40.0, True, KINDS), ('T', 'температура газа, °C', 5.0, 5.0, False, KINDS),
           ('heat', 'подогрев СВЗ до сопел, K', 0.0, 0.0, False, KINDS)]
GEO = ('td', 'L', 'h', 'pitch', 'ar')
PLANS = ('одна точка', 'сетка', 'латинский гиперкуб', 'срезанный гиперкуб')
EST_H = {'гладкая': 1.0, 'накатка': 1.5, 'сопло': 2.0}   # ч на точку (новый ПК, одно окно 1×6; новая L с нуля — +0,5 ч)


def check1d(L, r_exit=3.3):
    """1D (изоэнтропа + трение + тепло + площадь; канал — конус r_exit → 4,8 мм на L; тепло ∝ L — консервативно)."""
    import ru2836642_1d as D
    D.Q = 1100.0 * L / 400.0
    r = lambda x: r_exit + (4.8 - r_exit) * x / L
    m, xc, ld, pr = D.march(L, lambda x: math.pi * r(x) ** 2, lambda x: 2 * r(x))
    return (not xc and pr <= THR_1D), f'1D: M в конце {m:.2f}, потеря p0 {pr:.2f}' + (f', M→1 на {xc:.0f} мм' if xc else '')


def make_points(kind, ranges, plan, n, levels, per_slice, seed=20261031):
    """ranges: {ключ: (от, до, лог)} для факторов этого типа. Возвращает список точек {ключ: значение}."""
    from scipy.stats import qmc
    from make_a9_design import sliced_lhs
    keys = list(ranges)
    var = [k for k in keys if abs(ranges[k][1] - ranges[k][0]) > 1e-12]
    rng = np.random.default_rng(seed)

    def val(k, u):
        lo, hi, lg = ranges[k]
        return math.exp(math.log(lo) + u * (math.log(hi) - math.log(lo))) if lg else lo + u * (hi - lo)

    def maximin_lhs(nn, d):
        best, bd = None, -1
        for _ in range(300):
            u = qmc.LatinHypercube(d=d, seed=rng).random(nn)
            dd = min((np.linalg.norm(a - b) for i, a in enumerate(u) for b in u[i + 1:]), default=1.0)
            if dd > bd:
                best, bd = u, dd
        return best
    base = {k: ranges[k][0] for k in keys}
    if plan == 'одна точка' or not var:
        return [base]
    if plan == 'сетка':
        grids = [np.linspace(0, 1, max(levels, 2)) for _ in var]
        return [dict(base, **{k: val(k, u) for k, u in zip(var, combo)}) for combo in np.array(np.meshgrid(*grids)).reshape(len(var), -1).T]
    if plan == 'латинский гиперкуб':
        return [dict(base, **{k: val(k, u) for k, u in zip(var, row)}) for row in maximin_lhs(n, len(var))]
    gv, rv = [k for k in var if k in GEO], [k for k in var if k not in GEO]   # срезы — геометрии, в срезе — режимы
    n_sl = max(n, 1)
    geos = maximin_lhs(n_sl, len(gv)) if gv else np.zeros((n_sl, 0))
    if rv:
        x, _ = sliced_lhs(n_sl, per_slice, len(rv), rng)
    else:
        x = np.zeros((n_sl * per_slice, 0))
    out = []
    for s in range(n_sl):
        g = {k: val(k, u) for k, u in zip(gv, geos[s])}
        for j in range(per_slice):
            out.append(dict(base, **g, **{k: val(k, u) for k, u in zip(rv, x[s * per_slice + j])}))
    return out


def rounded(p):
    nd = dict(td=3, L=0, h=3, pitch=2, ar=2, pm=2, pc=2, dp=1, T=2, heat=2)
    return {k: (float(round(float(v), nd.get(k, 3))) if isinstance(v, (float, np.floating)) else v) for k, v in p.items()}   # без numpy — для JSON очереди


def assess(kind, pts, M):
    """Проверки и прогноз до расчёта для каждой точки. M — sppr.Models (может быть None — без прогноза)."""
    rows = []
    for p in pts:
        w = []
        r_exit = THROAT_R * math.sqrt(p['ar']) if kind == 'сопло' else 3.3
        ok1d, t1d = check1d(p['L'], r_exit)
        if not ok1d:
            w.append('1D: сверхзвук не удерживается — ' + t1d)
        if p['dp'] < 15.0:
            w.append('перепад ДЗВ < 15 кПа — риск сбоя')
        if kind == 'накатка' and abs(p['L'] - 400) > 0.5:
            w.append('накатка посчитана только при L 400 — перенос поля на другую длину ненадёжен')
        if kind != 'гладкая':
            w.append(f'{kind} — не вход модели (D-28): прогноз по гладкой трубе')
        fc, put = None, True
        if M is not None:
            fc = M.predict(p['td'], p['L'], p['dp'], p['pc'], p['T'], p['heat'], p['pm'])
            out = [n for n, ins in zip(('t/d', 'L', 'перепад', 'потребитель', 'T газа', 'подогрев', 'магистраль'), fc['inside']) if not ins]
            if out:
                w.append('вне паспорта применимости (данных): ' + ', '.join(out))
            if not 0.2 <= fc['m'] <= 0.96:
                w.append(f"прогноз m {fc['m']:.2f} вне Ω (0,2–0,96) — в очередь не ставится (D-28)"); put = False
        est = EST_H[kind] + (0.5 if kind == 'гладкая' and abs(p['L'] - 400) > 0.5 and abs(p['L'] - 660) > 0.5 and abs(p['L'] - 200) > 0.5 else 0.0)
        rows.append(dict(p=p, fc=fc, warn=w, put=put, est=est, t1d=t1d))
    return rows


def next_series_no():
    nums = [int(j['series_no']) for j in JQ.load() if str(j.get('series_no', '')).isdigit()]
    return max(nums, default=0) + 1


def backup_after():
    """Место в очереди: перед первой ждущей запасной работой (после предыдущего задания); иначе — в конец."""
    jobs = JQ.load()
    for i, j in enumerate(jobs):
        if j['status'] == 'ждёт' and str(j.get('series', '')).startswith('ЗАПАСНАЯ') and i > 0:
            return jobs[i - 1]['id']
    return None


class SeriesFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding=8)
        self.M, self.rows, self.loading = None, [], False
        top = ttk.Frame(self); top.pack(fill='x')
        ttk.Label(top, text='Тип трубы:').pack(side='left')
        self.kind = tk.StringVar(value='гладкая')
        for k in KINDS:
            ttk.Radiobutton(top, text=k, value=k, variable=self.kind, command=self.on_kind).pack(side='left', padx=4)
        ttk.Label(top, text='   Название серии:').pack(side='left')
        self.name = tk.StringVar(value='')
        ttk.Entry(top, textvariable=self.name, width=48).pack(side='left', padx=4)
        mid = ttk.Frame(self); mid.pack(fill='x', pady=6)
        fr = ttk.LabelFrame(mid, text='Диапазоны (от = до — фактор постоянный; перепад и высота выступа — в логарифме)', padding=6)
        fr.pack(side='left', fill='y')
        self.ent, self.rowsw = {}, {}
        for i, (k, lab, lo, hi, lg, kinds) in enumerate(FACTORS):
            w = [ttk.Label(fr, text=lab), ttk.Entry(fr, width=9), ttk.Label(fr, text='—'), ttk.Entry(fr, width=9)]
            w[1].insert(0, f'{lo:g}'); w[3].insert(0, f'{hi:g}')
            for c, x in enumerate(w):
                x.grid(row=i, column=c, sticky='w', padx=2, pady=1)
            self.ent[k], self.rowsw[k] = (w[1], w[3]), w
        right = ttk.Frame(mid); right.pack(side='left', fill='both', expand=True, padx=10)
        pf = ttk.LabelFrame(right, text='План', padding=6); pf.pack(fill='x')
        self.plan = tk.StringVar(value='одна точка')
        ttk.Combobox(pf, textvariable=self.plan, values=PLANS, state='readonly', width=22).grid(row=0, column=0, columnspan=2, sticky='w')
        self.n, self.lev, self.per = tk.IntVar(value=6), tk.IntVar(value=3), tk.IntVar(value=3)
        for r, (lab, var) in enumerate((('точек (ЛГК) / срезов (срезанный)', self.n), ('уровней на фактор (сетка)', self.lev),
                                        ('режимов в срезе (срезанный)', self.per)), start=1):
            ttk.Label(pf, text=lab).grid(row=r, column=0, sticky='w'); ttk.Spinbox(pf, from_=1, to=60, textvariable=var, width=5).grid(row=r, column=1, sticky='w')
        mf = ttk.LabelFrame(right, text='Сетка', padding=6); mf.pack(fill='x', pady=4)
        self.mesh = tk.StringVar(value='пресет v2')
        ttk.Radiobutton(mf, text='готовый пресет v2 (work_v2; у накатки осевой шаг 0,25 мм)', value='пресет v2', variable=self.mesh).grid(row=0, column=0, columnspan=4, sticky='w')
        ttk.Radiobutton(mf, text='свои:', value='свои', variable=self.mesh).grid(row=1, column=0, sticky='w')
        self.mesh_e = {}
        for c, (k, lab, v) in enumerate((('axial_size_mm', 'шаг по оси, мм', '0.25'), ('global_size_mm', 'общий размер, мм', '0.5'),
                                          ('dzv_layers', 'слоёв ДЗВ', ''))):
            ttk.Label(mf, text=lab).grid(row=2, column=2 * c, sticky='w'); e = ttk.Entry(mf, width=7); e.insert(0, v); e.grid(row=2, column=2 * c + 1, sticky='w')
            self.mesh_e[k] = e
        tf = ttk.LabelFrame(right, text='Стоп-кран (D-28, обязательно): какое положение и какое число в тексте изменит серия', padding=6)
        tf.pack(fill='x', pady=4)
        self.text_change = tk.Text(tf, height=3, width=70, wrap='word'); self.text_change.pack(fill='x')
        bf = ttk.Frame(right); bf.pack(fill='x', pady=4)
        ttk.Button(bf, text='Собрать точки и проверить', command=self.build).pack(side='left')
        self.btn_q = ttk.Button(bf, text='Поставить в очередь', command=self.enqueue, state='disabled'); self.btn_q.pack(side='left', padx=8)
        self.msg = ttk.Label(right, text='', wraplength=620, justify='left'); self.msg.pack(anchor='w')
        cols = ('n', 'td', 'L', 'extra', 'pm', 'pc', 'dp', 'T', 'heat', 'fc', 'm', 'put', 'warn')
        heads = ('№', 't/d', 'L', 'накатка / сопло', 'магистр.', 'потреб.', 'перепад', 'T', 'подогр.', 'прогноз эффекта', 'm', 'в очередь', 'предупреждения')
        widths = (34, 46, 50, 110, 60, 60, 60, 50, 56, 120, 50, 70, 520)
        tw = ttk.Frame(self); tw.pack(fill='both', expand=True)
        self.tree = ttk.Treeview(tw, columns=cols, show='headings', height=12)
        for c, h, w in zip(cols, heads, widths):
            self.tree.heading(c, text=h); self.tree.column(c, width=w, anchor='w', stretch=(c == 'warn'))
        sb = ttk.Scrollbar(tw, orient='vertical', command=self.tree.yview); self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side='left', fill='both', expand=True); sb.pack(side='left', fill='y')
        self.sum = ttk.Label(self, text=''); self.sum.pack(anchor='w')
        self.on_kind()
        self._todo = []; self.after(200, self._pump)

    def _pump(self):   # Tk — только из главного потока: фоновый поток кладёт сюда, окно выполняет
        while self._todo:
            try:
                self._todo.pop(0)()
            except Exception as e:
                self.msg.config(text=f'ошибка окна: {e!r}')
        self.after(200, self._pump)

    def on_kind(self):
        k = self.kind.get()
        for key, *_, kinds in FACTORS:
            st = 'normal' if k in kinds else 'disabled'
            for w in (self.rowsw[key][1], self.rowsw[key][3]):
                w.configure(state=st)
        self.btn_q.configure(state='disabled')

    def ranges(self):
        k, out = self.kind.get(), {}
        for key, lab, lo, hi, lg, kinds in FACTORS:
            if k not in kinds:
                continue
            a, b = (float(e.get().replace(',', '.')) for e in self.ent[key])
            if a > b:
                a, b = b, a
            if lg and a <= 0:
                raise ValueError(f'{lab}: должно быть > 0')
            out[key] = (a, b, lg)
        if k != 'накатка':
            out.update(h=(0.0, 0.0, False), pitch=(0.0, 0.0, False))
        if k != 'сопло':
            out['ar'] = (2.151, 2.151, False)
        return out

    def build(self):
        try:
            rg = self.ranges()
            pts = [rounded(p) for p in make_points(self.kind.get(), rg, self.plan.get(), int(self.n.get()), int(self.lev.get()), int(self.per.get()))]
        except Exception as e:
            messagebox.showerror('Новая серия', f'Ошибка в диапазонах или плане: {e}'); return
        if len(pts) > 60:
            messagebox.showwarning('Новая серия', f'{len(pts)} точек — больше 60; уменьшите число уровней / точек'); return
        self.pts = pts
        self.msg.config(text='Загружаю модель (ГП + классификатор) для прогноза до расчёта… первый раз ≈ 1 мин, дальше сразу')
        self.btn_q.configure(state='disabled')
        kind = self.kind.get()          # Tk-переменные читаются здесь, в главном потоке

        def work():
            try:
                if self.M is None:
                    import contextlib, io
                    import sppr
                    with contextlib.redirect_stdout(io.StringIO()):
                        self.M = sppr.Models()
                rows = assess(kind, pts, self.M)
                self._todo.append(lambda: self.show(rows))
            except Exception as e:
                import traceback; traceback.print_exc()
                self._todo.append(lambda: self.msg.config(text=f'Ошибка проверки: {e!r}'))
        threading.Thread(target=work, daemon=True).start()

    def show(self, rows):
        self.rows = rows
        for i in self.tree.get_children():
            self.tree.delete(i)
        for i, r in enumerate(rows, 1):
            p, fc = r['p'], r['fc']
            extra = (f"h {p['h']} / шаг {p['pitch']}" if self.kind.get() == 'накатка' else f"A/A* {p['ar']}" if self.kind.get() == 'сопло' else '—')
            self.tree.insert('', 'end', values=(i, p['td'], f"{p['L']:g}", extra, p['pm'], p['pc'], p['dp'], p['T'], p['heat'],
                                                f"{fc['effect_K']:+.2f} ± {fc['sigma_K']:.2f} K" if fc else '—', f"{fc['m']:.2f}" if fc else '—',
                                                'да' if r['put'] else 'НЕТ', '; '.join(r['warn']) or 'нет'))
        put = [r for r in rows if r['put']]
        self.sum.config(text=f"точек {len(rows)}, в очередь пойдут {len(put)}; оценка ≈ {sum(r['est'] for r in put):.1f} ч Fluent "
                             f"(одно окно 1×6, по одной; стоп: первые 2 не сошлись)")
        self.msg.config(text='Проверено. Точки с «НЕТ» (прогноз вне Ω) в очередь не ставятся. Заполните стоп-кран и нажмите «Поставить в очередь».')
        self.btn_q.configure(state='normal' if put else 'disabled')

    def enqueue(self):
        tc = self.text_change.get('1.0', 'end').strip()
        if not tc:
            messagebox.showerror('Стоп-кран', 'Нужен ответ: какое положение и какое число в тексте изменит эта серия (D-28).'); return
        put = [r for r in self.rows if r['put']]
        if not put:
            return
        kind, no = self.kind.get(), next_series_no()
        name = self.name.get().strip() or f'серия интерфейса {no}: {kind}'
        mesh = None
        if self.mesh.get() == 'свои':
            mesh = {k: float(e.get().replace(',', '.')) for k, e in self.mesh_e.items() if e.get().strip()}
            if 'dzv_layers' in mesh:
                mesh['dzv_layers'] = int(mesh['dzv_layers'])
        pts = []
        for i, r in enumerate(put, 1):
            p = dict(r['p'], tag=f'IF{no:03d}_{i:02d}')
            if kind == 'сопло':
                p['r_exit'] = round(THROAT_R * math.sqrt(p['ar']), 3)
            pts.append(p)
        plan = f"{self.plan.get()}" + (f", {len(pts)} точек" if len(pts) > 1 else '') + f"; сетка: {self.mesh.get()}" + (f" {mesh}" if mesh else '')
        if not messagebox.askyesno('Поставить в очередь', f'«{name}»: {len(pts)} точек, ≈ {sum(r["est"] for r in put):.1f} ч.\n'
                                   'Поставить в общую очередь (перед запасной работой)?'):
            return
        p0 = pts[0]
        job = dict(series=name, kind='point', series_no=no, tube=kind, points=pts, mesh=mesh, plan=plan,
                   stdout=f'runs\\station\\IF{no:03d}_stdout.txt', est_h=round(sum(r['est'] for r in put), 1), text_change=tc,
                   passport=dict(kind=kind, geometry=dict(t_d=p0['td'], L_mm=p0['L'], **({'knurl': dict(h_mm=p0['h'], pitch_mm=p0['pitch'])} if kind == 'накатка' else {}),
                                                          **({'area_ratio': p0['ar']} if kind == 'сопло' else {})),
                                 regime=dict(p_main=p0['pm'], p_cons=p0['pc'], dp_dzv_kPa=p0['dp'], T0_dzv=p0['T'], heat_K=p0['heat']),
                                 start='интерфейс автора, окно 2'))
        res = JQ.add([job], by='автор (интерфейс, окно 2)', after=backup_after())
        jid = res[0]['id'] if res else '?'
        fc = json.loads(FC.read_text(encoding='utf-8')) if FC.exists() else {}
        for p, r in zip(pts, put):
            f = r['fc'] or {}
            fc[p['tag']] = dict(job=jid, kind=kind, point=p, x=f.get('x'), effect_K=f.get('effect_K'), sigma_K=f.get('sigma_K'), m=f.get('m'),
                                p=f.get('p'), inside=f.get('inside'), n_train=getattr(self.M, 'n_train', None), warn=r['warn'],
                                time=time.strftime('%d.%m.%Y %H:%M:%S'), status='в очереди', в_обучение=False)
        FC.parent.mkdir(parents=True, exist_ok=True)
        FC.write_text(json.dumps(fc, ensure_ascii=False, indent=1), encoding='utf-8')
        self.msg.config(text=f'Поставлено: {jid} «{name}», {len(pts)} точек. Прогноз до расчёта записан (runs\\journal\\gui_forecasts.json); '
                             'строка в Журнал_работ.md. Ход — во вкладке 1.')
        self.btn_q.configure(state='disabled')
