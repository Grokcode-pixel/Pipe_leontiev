"""Outlet temperatures of the real gas by enthalpy (author 08.10.2026: methane real gas is the plan gas; heating of the
SVZ is counted against throttling to the consumer pressure, cooling of the DZV against the inlet; Fluent total
temperatures are recorded as well).  Energy balance per channel (closes within ~1 W in the CFD):
    h0_out_svz = h0_in + Q / G_svz,   h0_out_dzv = h0_in - Q / G_dzv
Gas at rest after the outlet (consumer / pipe): T = T(h0_out, p_out) — CoolProp HEOS (methane).
Throttle reference: T(h0_in, p_out) — the same pressure reduction without the tube.
usage: from grs_temps import outlet_temps; outlet_temps(Q, G_svz, G_dzv, T0_K, p0_MPa, p_svz_out_MPa, p_dzv_out_MPa)"""
import CoolProp.CoolProp as CP

FLUID = 'Methane'


def outlet_temps(Q_W, G_svz, G_dzv, T0_K=298.15, p0_MPa=5.5, p_svz_out_MPa=0.3, p_dzv_out_MPa=5.2, p0_dzv_MPa=None,
                 T0_dzv_K=None):
    """09.10.2026: T0_dzv_K — separate DZV inlet temperature (heater on the SVZ line only); T0_K is the SVZ inlet.
    Changes are returned relative to each stream's own inlet temperature."""
    p0d = (p0_dzv_MPa or p0_MPa) * 1e6
    T0d = T0_dzv_K or T0_K
    h_in_s = CP.PropsSI('H', 'T', T0_K, 'P', p0_MPa * 1e6, FLUID)
    h_in_d = CP.PropsSI('H', 'T', T0d, 'P', p0d, FLUID)
    ps, pd = p_svz_out_MPa * 1e6, p_dzv_out_MPa * 1e6
    T_svz = CP.PropsSI('T', 'H', h_in_s + Q_W / G_svz, 'P', ps, FLUID)
    T_dzv = CP.PropsSI('T', 'H', h_in_d - Q_W / G_dzv, 'P', pd, FLUID)
    T_thr_s = CP.PropsSI('T', 'H', h_in_s, 'P', ps, FLUID)
    T_thr_d = CP.PropsSI('T', 'H', h_in_d, 'P', pd, FLUID)
    return dict(dT_svz_h=round(T_svz - T0_K, 3), dT_dzv_h=round(T_dzv - T0d, 3),
                dT_svz_throttle=round(T_thr_s - T0_K, 3), dT_dzv_throttle=round(T_thr_d - T0d, 3),
                dT_svz_vs_throttle=round(T_svz - T_thr_s, 3), dT_dzv_vs_throttle=round(T_dzv - T_thr_d, 3))


if __name__ == '__main__':
    print(outlet_temps(1506.8, 0.158237, 0.049462))
