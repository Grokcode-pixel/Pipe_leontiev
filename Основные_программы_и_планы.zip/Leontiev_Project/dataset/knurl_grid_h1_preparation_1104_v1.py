import sys,traceback
from pathlib import Path
import knurl_cold_chain_1104_v3 as C
R=C.R;P=R/'runs/plans/grid_h1_preparation_1104_v1.json';OUT=R/'runs/grid_h1_preparation_1104_v1';CURRENT=None

def registered():
 if C.sha(P)!=P.with_suffix('.sha256').read_text().strip():raise RuntimeError('Plan changed')
 p=C.load(P)
 for f,h in p['protected'].items():
  if C.sha(f)!=h:raise RuntimeError('Source changed '+f)
 return CURRENT or p

def run():
 global CURRENT
 p=registered();C.V.idle();OUT.mkdir(exist_ok=True)
 if (OUT/'attempt.json').exists():raise RuntimeError('Already attempted')
 C.save(OUT/'attempt.json',dict(time=C.now(),CFD_iterations=0));res={}
 for cfg in p['levels']:
  CURRENT=cfg;C.P=P;C.OUT=Path(cfg['output']);C.OUT.mkdir();C.registered=registered
  C.save(OUT/'state.json',dict(time=C.now(),phase='mesh',tag=cfg['params']['run_id']))
  msh,cells=C.mesh_gate(cfg)
  C.save(OUT/'state.json',dict(time=C.now(),phase='native_template',tag=cfg['params']['run_id']))
  b=C.B.build(msh,C.OUT/'template',p0_svz_MPa=5.5,interpolate=False);C.V.idle()
  res[cfg['params']['run_id']]=dict(cells=cells,mesh_sha256=C.sha(msh),quality=b['final_quality'],coverage=b['interface_percent'],CFD_iterations=0)
  C.save(OUT/'results.json',res)
  if b['final_quality']['native_warning_below_001']:raise RuntimeError('Final quality warning; no CFD')
 C.save(OUT/'finished.json',dict(time=C.now(),prepared=True,CFD_iterations=0))
 (OUT/'report_ru.md').write_text('# Две сетки выступа1мм: подготовка без CFD\n\n'+str(res)+'\n\nТочность по теплу/расходам ещё не проверена.\n',encoding='utf-8')
if __name__=='__main__':
 try:run()
 except Exception as e:C.save(OUT/'BLOCK.json',dict(time=C.now(),error=repr(e),traceback=traceback.format_exc()));raise