"""27.10.2026 — автопополнение датасета (решение автора 27.10: пока автора нет, досчитывать точки там, где система не уверена).
Цикл без ИИ (контур К3): ждёт свободный Fluent → переобучает ГП и CatBoost (sppr.Models: все сошедшиеся точки, включая
ST4… и предыдущие авто-точки) → среди станционных режимов на посчитанных геометриях выбирает точку с наибольшей
неопределённостью: 4·p(1−p) (класс «рабочий / скачок») + σ/δ (эффект), не ближе 0,05 к данным и к уже выбранным →
записывает прогноз ДО расчёта (runs\\journal\\auto_forecasts.json, журнал станции) → считает Fluent продолжением от ближайшего
сошедшегося кейса той же геометрии (ступени магистрали по 0,75 МПа) → следующая точка уже с переобученной моделью.
Остановка: файл runs\\journal\\STOP_auto.txt, MAX_POINTS или STOP_AT. Итог по точкам — runs\\journal\\auto_enrich.md."""
import io, contextlib, csv, json, math, sys, time
from datetime import datetime
from pathlib import Path
import numpy as np
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
sys.path.insert(0, r'F:\Leontiev_Project\program')
import gui_runner as G
import run_a9 as A
_saved = (A.BASE, A.CSV, A.AUX)   # 30.10: импорт run_station переключает общие пути run_a9 — при импорте auto_enrich из других серий их вернуть
import run_station as S
A.BASE, A.CSV, A.AUX = _saved

J = Path(r'F:\Leontiev_Project\runs\journal')
FC, STOP = J / 'auto_forecasts.json', J / 'STOP_auto.txt'
MAX_POINTS = 60   # 27.10 23:10: очередь до утра 29.10 без простоя
STOP_AT = datetime(2026, 10, 29, 7, 0)
AUTO_CSV = S.OUT / 'auto_results.csv'
DP = (2, 3, 5, 8, 10, 15, 20, 30, 50, 80, 105)
PM = (3.0, 3.5, 4.0, 4.5, 5.0, 5.5)
T0 = (-5.0, 0.0, 5.0, 10.0)


def wait_free():
    while G.fluent_running() or any(t for t in ('Leontiev_tri_flow',) if _task_running(t)):
        if STOP.exists():
            return False
        time.sleep(120)
    return True


def _task_running(name):
    import subprocess
    out = subprocess.run(['schtasks', '/Query', '/TN', name, '/FO', 'CSV', '/NH'], capture_output=True, text=True,
                         creationflags=subprocess.CREATE_NO_WINDOW).stdout
    return 'Running' in out or 'Выполняется' in out


def sources():
    """Сошедшиеся кейсы, от которых можно продолжать: станционные точки (ST…, AU…) и — 27.10 23:10, решение автора
    «чтобы расчёты были разные» — все сошедшиеся точки А9, набора А и добора Б (15 геометрий; сетки уже есть)."""
    import model_compare as MC
    import gui_convergence as C
    R = MC.R
    out = [(R / 'station' / r['tag'], x) for x, r, geo in MC.station_points()]
    conv = lambda d: (lambda rows: bool(rows) and C.decision(rows))(C.closed_samples(d))
    xr = lambda d: [float(d['t_d']), float(d['L_mm']) / 6.6, math.log(float(d['dp_dzv_kPa'])), float(d['p_cons']),
                    float(d['t0_dzv']), float(d.get('heater') or 0.0), float(d.get('p_main') or 5.5)]
    D = {p['id']: p for p in csv.DictReader(open(R / 'a9/a9_design.csv', encoding='utf-8'))}
    for s in csv.DictReader(open(R / 'a9/a9_points_status.csv', encoding='utf-8')):
        if s['num_status'] == 'сошлась' and s['id'] not in ('A9_11', 'A9_35', 'A9_36') and (R / 'a9' / s['result'] / 'result.cas.h5').exists():
            out.append((R / 'a9' / s['result'], xr(D[s['id']])))
    for ser, des in (('setA', 'setA_design.csv'), ('setB', 'setB_design.csv')):
        for pid, d in {p['id']: p for p in csv.DictReader(open(R / ser / des, encoding='utf-8'))}.items():
            for t in (pid + 'cc', pid + 'c', pid):
                if (R / ser / t / 'result.cas.h5').exists() and conv(R / ser / t):
                    out.append((R / ser / t, xr(d))); break
    return out


def choose(M, done_tags):
    src = {}
    for path, x in sources():
        src.setdefault((round(x[0], 3), round(x[1] * 6.6, 1)), []).append((path, x))
    Ztr = M.G.Z(M.G.X)
    fc = json.loads(FC.read_text(encoding='utf-8')) if FC.exists() else {}
    picked = [M.G.Z(np.array([v['x']]))[0] for v in fc.values()]
    best = None
    for (td, L), lst in src.items():
        for dp in DP:
            for pm in PM:
                for t0 in T0:
                    o = M.predict(td, L, dp, 0.6, t0, 0.0, pm)
                    if not all(o['inside']) or not (0.15 <= o['m'] <= 1.1) or o['cfd']:
                        continue
                    z = M.G.Z(np.array([o['x']]))[0]
                    d = min(np.sqrt(((Ztr - z) ** 2).sum(1)).min(), min([np.linalg.norm(z - q) for q in picked] or [9]))
                    if d < 0.05:
                        continue
                    score = 4 * o['p'] * (1 - o['p']) + min(o['sigma_K'] / 0.5, 1.0)
                    if best is None or score > best[0]:
                        s = min(lst, key=lambda t: abs(t[1][6] - pm) + abs(math.log(math.exp(t[1][2]) / dp)) + abs(t[1][4] - t0) / 10 + abs(t[1][3] - 0.6) + t[1][5] / 10)
                        best = (score, dict(o, td=td, L=L, dp=dp, pm=pm, t0=t0, src=str(s[0]), src_pm=s[1][6], dist=float(d), score=score))
    return best[1] if best else None


def summary():
    fc = json.loads(FC.read_text(encoding='utf-8')) if FC.exists() else {}
    RR = {r['tag']: r for r in csv.DictReader(open(AUTO_CSV, encoding='utf-8'))} if AUTO_CSV.exists() else {}
    L = ['# Автопополнение датасета (auto_enrich.py)', '', 'Прогноз записан до расчёта; модель переобучается перед каждой точкой.', '',
         '| точка | время прогноза | t/d, L | перепад, кПа | магистраль, МПа | газ, °C | p «рабочий» | эффект ± σ, K | Fluent: статус | эффект, K | разница, K |',
         '|---|---|---|---|---|---|---|---|---|---|---|']
    for t, v in fc.items():
        r = RR.get(t, {})
        e = r.get('dT_svz_vs_throttle')
        L.append(f"| {t} | {v['time']} | {v['td']} / {v['L']:.0f} | {v['dp']} | {v['pm']} | {v['t0']:+.0f} | {v['p']:.3f} | {v['effect_K']:+.2f} ± {v['sigma_K']:.2f} | "
                 f"{r.get('status', 'считается / нет')}{', скачок ' + r['x_shock_m'] + ' м' if r.get('x_shock_m') else ''} | "
                 f"{float(e):+.2f} | {v['effect_K'] - float(e):+.2f} |" if e else
                 f"| {t} | {v['time']} | {v['td']} / {v['L']:.0f} | {v['dp']} | {v['pm']} | {v['t0']:+.0f} | {v['p']:.3f} | {v['effect_K']:+.2f} ± {v['sigma_K']:.2f} | "
                 f"{r.get('status', 'считается / нет')} | — | — |")
    (J / 'auto_enrich.md').write_text('\n'.join(L) + '\n', encoding='utf-8')


if __name__ == '__main__':
    A.BASE, A.CSV = S.OUT, AUTO_CSV
    import sppr
    A.qlog('=== автопополнение датасета — начато')
    n = len(json.loads(FC.read_text(encoding='utf-8'))) if FC.exists() else 0
    while n < MAX_POINTS and datetime.now() < STOP_AT and not STOP.exists():
        if not wait_free():
            break
        # 28.10 02:10: модули моделей кэшируются в процессе → без сброса ГП и CatBoost не видели новых точек (обучение 107 у всех AU)
        for mod in ('station_gp', 'classifier_final', 'classifier_variants', 'heldout_check', 'model_compare'):
            sys.modules.pop(mod, None)
        with contextlib.redirect_stdout(io.StringIO()):
            M = sppr.Models()
        c = choose(M, None)
        if not c:
            A.log('=== авто: кандидатов нет — стоп'); break
        n += 1
        tag = f'AU{n:02d}'
        fc = json.loads(FC.read_text(encoding='utf-8')) if FC.exists() else {}
        fc[tag] = {k: (v if not isinstance(v, (np.floating, np.integer)) else float(v)) for k, v in c.items()}
        fc[tag].update(time=time.strftime('%d.%m.%Y %H:%M:%S'), n_train=M.n_train, p_hi=M.p_hi)
        FC.write_text(json.dumps(fc, ensure_ascii=False, indent=1), encoding='utf-8')
        A.log(f"=== {tag} (авто, обучение {M.n_train} точек): ПРОГНОЗ ДО расчёта: t/d {c['td']} L {c['L']:.0f}, перепад {c['dp']} кПа, "
              f"магистраль {c['pm']} МПа, газ {c['t0']:+.0f} °C; эффект {c['effect_K']:+.2f} ± {c['sigma_K']:.2f} K, m {c['m']:.3f}, "
              f"p {c['p']:.3f} (p_hi {M.p_hi:.3f}); оценка {c['score']:.2f}; старт от {c['src']}")
        summary()
        cur, p = Path(c['src']), c['src_pm']
        k = 0
        while abs(c['pm'] - p) > 0.8:
            k += 1; p = round(p + (0.75 if c['pm'] > p else -0.75), 2)
            cur = A.cont(cur / 'result.cas.h5', f'{tag}_r{k}', S.reg(p, c['dp']), [], c['t0'], c['t0'], f'авто: ступень магистрали {p} МПа',
                         A.AUX, limit=1500, l_mm=float(c['L'])) or cur
        A.cont(cur / 'result.cas.h5', tag, S.reg(c['pm'], c['dp']), [], c['t0'], c['t0'], f'авто: от {cur.name}', A.CSV, l_mm=float(c['L']))
        summary()
    A.qlog(f'=== автопополнение датасета — закончено ({n} точек)')
