"""П. 3.4 итогового плана (17.10.2026): подтверждение чисел станции расчётами Fluent.
Условия станции: зима, газ 0 °C, подогреватель ПОСЛЕ пучка (подогрев СВЗ 0), давление потребителя 0,6 МПа.
 ST1: t/d 1,4, L 400, перепад ДЗВ 10 кПа, магистраль 5,5 МПа (от SA_41 набора А: 11 кПа, 0,56 МПа);
 ST2: то же при магистрали 4,0 МПа (ступени магистрали 5,5 → 4,75 → 4,0, от ST1);
 ST3: t/d 1,2, L 660, перепад 105 кПа, магистраль 5,5 МПа (от A8C1).
Прогноз быстрой модели записывается в журнал ДО расчёта (Q трубы, m, эффект) — для «прогноз → расчёт».
Ждёт окончания набора А (run_setA.py).  Предел 3000 ит. на точку, 1500 на ступень."""
import json, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_a9 as A
import run_pilot_cell as PC
import fast1d as F

OUT = Path(r'F:\Leontiev_Project\runs\station')
A.BASE, A.CSV, A.AUX = OUT, OUT / 'station_results.csv', OUT / 'station_aux.csv'
A.POINT_LIMIT = 3000
CAL = json.load(open(r'F:\Leontiev_Project\runs\fast1d\calib.json', encoding='utf-8'))['params']
T0, PC_ = 0.0, 0.6


def reg(p0, dp):
    return (p0, PC_, p0, round(p0 - dp / 1000.0, 6))


if __name__ == '__main__':
    OUT.mkdir(parents=True, exist_ok=True)
    while PC.running(r'run_setA\.py'):
        time.sleep(120)
    A.qlog('=== п. 3.4 подтверждение станции — начат')
    for tag, td, L, dp in (('ST1', 1.4, 400, 10.0), ('ST3', 1.2, 660, 105.0)):
        o = F.run(td, L, dp, PC_, T0, 0.0, par=CAL)
        A.log(f"=== {tag}: ПРОГНОЗ быстрой модели ДО расчёта (магистраль 5,5): Q {o['Q']:.0f} Вт, m {o['m']:.3f}, эффект {o['effect_K']:+.2f} K, рабочий {o['working']}")
    src1 = A.done_dir('SA_41') if False else Path(r'F:\Leontiev_Project\runs\setA') / 'SA_41'
    if not A.ok(src1):
        src1 = Path(r'F:\Leontiev_Project\runs\setA') / 'SA_40'
    st1 = A.cont(src1 / 'result.cas.h5', 'ST1', reg(5.5, 10.0), [], T0, T0, f'станция: от {src1.name}', A.CSV, l_mm=400.0)
    if st1:
        cur = st1
        for k, p0 in enumerate((4.75,), 1):
            aux = A.cont(cur / 'result.cas.h5', f'ST2_r{k}', reg(p0, 10.0), [], T0, T0, f'ступень магистрали {p0} МПа', A.AUX, limit=1500, l_mm=400.0)
            cur = aux or cur
        A.log('=== ST2: магистраль 4,0 МПа (быстрая модель пока только 5,5 МПа — прогноза нет)')
        A.cont(cur / 'result.cas.h5', 'ST2', reg(4.0, 10.0), [], T0, T0, f'станция: магистраль 4,0 от {cur.name}', A.CSV, l_mm=400.0)
    A.cont(Path(r'F:\Leontiev_Project\runs\a8cfd\A8C1') / 'result.cas.h5', 'ST3', reg(5.5, 105.0), [], T0, T0, 'станция: от A8C1', A.CSV, l_mm=660.0)
    A.qlog('=== п. 3.4 подтверждение станции — закончен')
