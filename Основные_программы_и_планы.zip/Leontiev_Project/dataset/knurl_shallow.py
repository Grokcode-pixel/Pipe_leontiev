"""29.10.2026 — решение автора (п. 3): разведка мелкой наружной накатки в пределах Калинина — Дрейцера — Ярхо для зазора
ячейки (t/d 1,4: зазор ≈ 3 мм, D_г ≈ 6 мм): выступ 0,1 / 0,2 / 0,3 мм, шаг 2 мм (ширина выступа 1/3 шага, как у серий
KD/KS), t/d 1,4, L 400, режим A9_19, сравнение с гладкой ПРИ ОДИНАКОВОМ РАСХОДЕ ДЗВ (перепад подбирается, ≤ 2 расчёта на вариант).
Первая точка варианта — перенос поля гладкой A9_19 на сетку с выступами (как KS10); осевой шаг сетки 0,25 мм (выступ 0,67 мм —
≈ 3 ячейки). Стоп-правило: первые 2 расчёта серии не сошлись — стоп. Ждёт окончания knurl_eqflow (KS10).
Итог: runs\\patents\\knurl_shallow.json, журнал runs\\patents\\a9_log.txt."""
import csv, json, math, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_patents_knurl as K

A = K.A
R = Path(r'F:\Leontiev_Project\runs')
A.CSV = A.BASE / 'knurl_shallow_results.csv'
A.POINT_LIMIT = 6000
OUTJ = A.BASE / 'knurl_shallow.json'
VARS = ((0.1, 'KM01'), (0.2, 'KM02'), (0.3, 'KM03'))
G_SMOOTH = float(next(r for r in csv.DictReader(open(R / 'a9/a9_results.csv', encoding='utf-8')) if r['tag'] == 'A9_19')['G_dzv'])
_cp = A.cell_params


def cell_params(*a, **k):
    p, cell = _cp(*a, **k)
    p.update(axial_size_mm=0.25)
    return p, cell


A.cell_params = cell_params


def row(tag):
    if not A.CSV.exists():
        return None
    return next((r for r in csv.DictReader(open(A.CSV, encoding='utf-8')) if r['tag'] in (tag, tag + 'h') and r.get('G_dzv')), None)


def wait_prev():
    import auto_enrich as AE
    while A.G.fluent_running() or AE._task_running('Leontiev_queue_1029') or AE._task_running('Leontiev_knurl_eqflow'):
        time.sleep(120)


if __name__ == '__main__':
    wait_prev()
    A.qlog('=== разведка мелкой накатки (0,1 / 0,2 / 0,3 мм, шаг 2 мм) — начата')
    design = {p['id']: p for p in csv.DictReader(open(K.A9 / 'a9_design.csv', encoding='utf-8'))}
    smooth = next(K.A9 / t for t in ('A9_19ch', 'A9_19c', 'A9_19h', 'A9_19') if (K.A9 / t / 'result.cas.h5').exists())
    ts, td_, pm, pc = 13.46, 8.63, 5.5, 0.59
    summary = json.loads(OUTJ.read_text(encoding='utf-8')) if OUTJ.exists() else {}
    n_calc = n_fail = 0
    for h, pre in VARS:
        K.KN.update(dzv=h, svz=None, pitch=2.0, width=0.67)
        pt = dict(design['A9_19'], id=f'{pre}_A9_19')
        first = A.done_dir(pt['id']) or A.transfer(smooth, pt)
        n_calc += 1
        r = row(pt['id'])
        ok = bool(first) and r is not None and A.converged(first)
        if not ok:
            n_fail += 1
            A.log(f'  {pt["id"]}: не сошёлся')
            if n_calc <= 2 and n_fail >= 2:
                A.qlog('=== мелкая накатка: первые 2 расчёта не сошлись — СТОП, нужно решение автора'); sys.exit(1)
            if not r:
                continue
        pts = [(11.98, float(r['G_dzv']))]
        src, best = first, dict(tag=pt['id'], dp=11.98, G_dzv=float(r['G_dzv']), Q=float(r['Q']), G_svz=float(r['G_svz']),
                                effect=float(r['dT_svz_vs_throttle']), converged=ok)
        for k in (1, 2):   # подбор перепада под расход гладкой
            if abs(pts[-1][1] / G_SMOOTH - 1) <= 0.03 or not src:
                break
            if len(pts) >= 2:
                (d0, g0), (d1, g1) = pts[-2], pts[-1]
                n = min(max(math.log(g1 / g0) / math.log(d1 / d0), 0.3), 0.8)
                dp = d1 * (G_SMOOTH / g1) ** (1 / n)
            else:
                dp = pts[-1][0] * (G_SMOOTH / pts[-1][1]) ** 2
            dp = round(min(max(dp, 2.0), 300.0), 2)
            tag = f'{pre}_eq{k}'
            A.log(f'  {tag}: перепад ДЗВ {dp} кПа (оценка до расчёта; цель — расход гладкой {G_SMOOTH:.4f} кг/с)')
            d = A.done_dir(tag) or A.cont(src / 'result.cas.h5', tag, (pm, pc, pm, round(pm - dp / 1000, 6)), [], ts, td_,
                                         f'мелкая накатка {h} мм при равном расходе ДЗВ', A.CSV)
            n_calc += 1
            rr = row(tag)
            if not d or not rr:
                n_fail += 1; continue
            pts.append((dp, float(rr['G_dzv']))); src = d
            best = dict(tag=tag, dp=dp, G_dzv=float(rr['G_dzv']), Q=float(rr['Q']), G_svz=float(rr['G_svz']),
                        effect=float(rr['dT_svz_vs_throttle']), converged=A.converged(d))
        best.update(h=h, pitch=2.0, target=G_SMOOTH, miss_pct=100 * (best['G_dzv'] / G_SMOOTH - 1), m=best['G_dzv'] / best['G_svz'])
        summary[pre] = best
        OUTJ.write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding='utf-8')
        A.log(f"=== {pre} (h {h}): перепад {best['dp']} кПа, G ДЗВ {best['G_dzv']:.4f} ({best['miss_pct']:+.1f} %), Q {best['Q']:.0f} Вт, эффект {best['effect']:+.2f} K")
    A.qlog('=== разведка мелкой накатки — закончена')
