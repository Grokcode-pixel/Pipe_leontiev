"""30.10.2026 — задание автора, Fluent п. 2: A9_19 с удлинённым выходным участком — проверить, что обратный ток — артефакт
границы, а не режим. Уточнение по расчётам: обратный ток у A9_19, KM01, KM02r — на выходе СВЗ (pressure-outlet 15, 110 граней
= outlet_svz; у outlet_dzv, 88 граней, обратного тока нет). Поэтому удлиняется выходной участок СВЗ: хвост после диффузора
восстановления (P21, l_exit_tail_mm) 3 → 100 мм (≈ 10 диаметров выхода); остальное — как у A9_19 (сетка work_v2, режим, ПР).
Старт — перенос поля A9_19 (интерполяция, без подстановки ДЗВ), одна попытка, ≤ 3000 итераций.
Итог: runs\\a9_exit\\сравнение_выход.md — эффект, Q, расходы, обратный ток против A9_19; «артефакт границы», если на новом
выходе обратного тока нет (≤ 1 % площади) и эффект / Q не изменились (≤ 0,05 K / ≤ 1 %).
31.10.2026 — перенос поля разошёлся на 20-й итерации (в новом хвосте T упёрлась в 1 K); решение автора по ночи 31.10, п. 4:
одна попытка С НУЛЯ, без переноса поля (python a9_19_long_exit.py scratch → тег A9_19xs, scratch_one.run); не сошлось —
записать и идти дальше."""
import csv, json, sys, time
from pathlib import Path
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_a9 as A
import leontiev_pipeline as L
import scratch_one as SO

SRC = A.BASE / 'A9_19'
OUT = Path(r'F:\Leontiev_Project\runs\a9_exit')
TAIL_MM = 100.0
LIMIT = 3000
SCRATCH = 'scratch' in sys.argv[1:]
TAG = 'A9_19xs' if SCRATCH else 'A9_19x'
HOW = 'с нуля, без переноса поля' if SCRATCH else 'перенос поля A9_19'
A.BASE, A.CSV, A.AUX = OUT, OUT / 'exit_results.csv', OUT / 'exit_aux.csv'
A.A3.MESHES['work_v2'] = dict(A.A3.MESHES['work_v2'], l_exit_tail_mm=TAIL_MM)   # только в этом процессе


def row(tag, f):
    rs = [r for r in csv.DictReader(open(f, encoding='utf-8')) if r['tag'] == tag] if Path(f).exists() else []
    return rs[-1] if rs else None


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    A.qlog(f'=== A9_19 с удлинённым выходом СВЗ (хвост {TAIL_MM:.0f} мм, {HOW}) — начат')
    pt = dict(next(p for p in csv.DictReader(open(SRC.parent / 'a9_design.csv', encoding='utf-8')) if p['id'] == 'A9_19'), id=TAG)
    reg = A.regime(pt)
    t0s, t0d = float(pt['t0_svz']), float(pt['t0_dzv'])
    A.G.RUNS = OUT
    d = A.done_dir(pt['id'])
    if not d and SCRATCH:
        d = SO.run(A, pt, TAG, 400.0, f'с нуля, хвост выхода {TAIL_MM:.0f} мм (решение автора 31.10, одна попытка)')
    elif not d:
        p, _ = A.cell_params(1.4, 400.0, 'A9_19x_tpl', pt, 'ch4_ideal', 10, 10)
        A.log(f'=== A9_19x: шаблон с хвостом выхода {TAIL_MM:.0f} мм; перенос поля A9_19')
        A.G.run(p, lambda s: A.log('  ' + s), lambda: False)
        tpl = OUT / 'A9_19x_tpl' / 'result.cas.h5'
        if not tpl.exists():
            tpl = OUT / 'A9_19x_tpl' / 'initial.cas.h5'
        ip = OUT / 'ip' / 'A9_19.ip'
        ip.parent.mkdir(exist_ok=True)
        if not tpl.exists() or not (ip.exists() or A.write_ip(SRC / 'result.cas.h5', ip)):
            A.log('  A9_19x: нет шаблона или файла переноса'); A.qlog('=== A9_19x: сбой (нет шаблона / переноса)'); return 1
        A.set_step(A.CONS)
        A.U.LIMIT = LIMIT
        out = OUT / pt['id']
        mins = A.U.continue_case(tpl, out, list(L.CH4_PR_LINES) + [f'/file/interpolate/read-data "{L.fl(ip)}"'], reg, A.log, pt['id'],
                                 t0_C=t0s, t0_dzv_C=t0d)
        A.U.record(A.CSV, pt['id'], 'work_v2', 'ch4_pr', reg, out, mins, A.log, start=f'перенос поля A9_19, хвост выхода {TAIL_MM:.0f} мм',
                   t0_C=t0s, t0_dzv_C=t0d, l_heat_mm=400.0)
        d = out if A.ok(out) else None
    r0, r1 = row('A9_19', SRC.parent / 'a9_results.csv'), row(TAG, A.CSV)
    if not r1 or not r1.get('dT_svz_vs_throttle'):
        A.qlog(f'=== {TAG}: нет результата (одна попытка, {HOW})')
        with open(r'F:\Leontiev_Project\Журнал_работ.md', 'a', encoding='utf-8') as fj:
            fj.write(f'- {time.strftime("%d.%m.%Y %H:%M")} — A9_19 с удлинённым выходом СВЗ ({HOW}, одна попытка): нет результата — '
                     f'вопрос «граница или режим» не решён расчётом; по решению автора 31.10 — записано, очередь идёт дальше\n')
        return 1
    f = lambda r, k: float(r[k]) if r.get(k) not in (None, '') else float('nan')
    de, dq = f(r1, 'dT_svz_vs_throttle') - f(r0, 'dT_svz_vs_throttle'), 100 * (f(r1, 'Q') / f(r0, 'Q') - 1)
    rev1 = f(r1, 'reversed_max_pct')
    conv = bool(d) and A.converged(d)
    artifact = rev1 <= 1.0 and abs(de) <= 0.05 and abs(dq) <= 1.0
    verdict = ('артефакт границы: на удлинённом выходе обратного тока нет, эффект и Q не изменились' if artifact else
               'не артефакт (или не только): ' + '; '.join(s for s, c in ((f'обратный ток {rev1:.1f} % площади на новом выходе', rev1 > 1.0),
                                                                          (f'эффект изменился на {de:+.3f} K', abs(de) > 0.05),
                                                                          (f'Q изменилось на {dq:+.2f} %', abs(dq) > 1.0)) if c))
    keys = (('эффект против дросселя, K', 'dT_svz_vs_throttle'), ('Q, Вт', 'Q'), ('G СВЗ, кг/с', 'G_svz'), ('G ДЗВ, кг/с', 'G_dzv'),
            ('обратный ток на выходе СВЗ, % площади', 'reversed_max_pct'), ('M на выходе', 'M_outlet'), ('статус', 'status'), ('причина', 'reason'))
    Lm = [f'# A9_19: выходной участок СВЗ 3 → {TAIL_MM:.0f} мм, {HOW} ({time.strftime("%d.%m.%Y %H:%M")})', '',
          'Зачем: проверить, что обратный ток на выходе (9–13 % площади у A9_19 и накатки) — артефакт границы, а не режим. '
          'Обратный ток — на выходе СВЗ (outlet_svz), у выхода ДЗВ его нет.', '',
          f'| величина | A9_19 (хвост 3 мм) | {TAG} (хвост 100 мм) |', '|---|---|---|']
    Lm += [f'| {n} | {r0.get(k, "")} | {r1.get(k, "")} |' for n, k in keys]
    Lm += ['', f'Сошёлся по критериям: {"да" if conv else "нет (предел итераций; см. дисбаланс по D-12)"}.', '', f'**Вывод:** {verdict}.']
    (OUT / 'сравнение_выход.md').write_text('\n'.join(Lm) + '\n', encoding='utf-8')
    (OUT / 'сравнение_выход.json').write_text(json.dumps(dict(d_effect_K=de, d_Q_pct=dq, reversed_pct=rev1, converged=conv, artifact=artifact,
                                                           verdict=verdict), ensure_ascii=False, indent=1), encoding='utf-8')
    with open(r'F:\Leontiev_Project\Журнал_работ.md', 'a', encoding='utf-8') as fj:
        fj.write(f'- {time.strftime("%d.%m.%Y %H:%M")} — A9_19 с удлинённым выходом СВЗ (хвост {TAIL_MM:.0f} мм, {HOW}; '
                 f'{"сошёлся" if conv else "не сошёлся по критериям"}): эффект {de:+.3f} K, Q {dq:+.2f} %, '
                 f'обратный ток {rev1:.1f} % → {verdict} (runs\\a9_exit\\сравнение_выход.md)\n')
    A.qlog(f'=== {TAG} закончен: {verdict}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
