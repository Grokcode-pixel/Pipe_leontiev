"""A9 design (14.10.2026, author's decisions on A8): the reference dataset for the strategy comparison (A8) and the models
(A10).  Two decision levels (council remarks): X0 = construction (chief engineer): t/d, L/d;  U = setpoints (dispatcher):
DZV pressure drop (valve), consumer pressure, SVZ heater, plus the disturbance T0 of the gas.
- geometries: 3 t/d x 3 L/d grid (a computed geometry = one mesh; transfer of fields only between equal lengths);
- regimes: SLICED Latin hypercube (maximin) — every geometry gets 4 regime points that are an LHS by themselves and the
  union of the 36 is an LHS in the 4 regime factors;
- the DZV drop is planned through the target m in 0.2..1.0 (accepted range) and the pilot law
  m = 0.155*(dp/0.5 kPa)^0.51*(gap/2.96 mm)^1.4 (smooth tube, checked on b: 0.84 vs 0.82); m is recorded as achieved;
- consumer pressure 0.3..1.6 MPa: the accepted working range is 0.3..1.2, the start boundary of the cell is 1.2..1.4 MPa;
  the band 1.2..1.6 trains the classifier 'working / not working' (a wrong recommendation of a non-working regime is an
  A8 metric) — to be confirmed by the author;
- 6 control points (random, same geometries, never used for training) and 2 repeated points (from scratch vs from the
  neighbour) for the start-independence check;
- constants: 5.5 MPa before the nozzle, methane PR, brass 110, wall 1.5 mm at the channel end, counterflow, symmetry.
Later portions (author): knurl (RU 233137) and the RU 2836642 geometry as additional X0 factors."""
import csv, math
from pathlib import Path
import numpy as np
from scipy.stats import qmc
import leontiev_pipeline as L

OUT = Path(r'F:\Leontiev_Project\runs\a9')
TD = (1.2, 1.4, 1.6)
LD = (30, 60, 100)
D_EXIT = 6.6            # mm, nozzle exit diameter (r 3.3)
L_MM = {30: 200.0, 60: 400.0, 100: 660.0}   # 60 calibers = the reference 400 mm (pilot fields reusable)
RANGES = dict(m_target=(0.2, 1.0), p_cons=(0.3, 1.6), t0_dzv=(-10.0, 20.0), heater=(0.0, 20.0))
SEED = 20261014


def dp_for(m, gap, l_mm=400.0):
    # friction drop ~ length (pilot law at L 400 mm)
    return 0.5 * (m / 0.155 / (gap / 2.96) ** 1.4) ** (1 / 0.51) * l_mm / 400.0     # kPa


def sliced_lhs(n_slices, n_per, d, rng):
    """Sliced LHS (Qian 2012): each slice an LHS, the union an LHS; maximin over random permutations."""
    best, best_d = None, -1
    for _ in range(400):
        N = n_slices * n_per
        x = np.empty((N, d))
        for j in range(d):
            # strata 0..N-1; slice s takes one stratum from each block of n_slices consecutive strata
            perm_blocks = [rng.permutation(n_slices) for _ in range(n_per)]
            for s in range(n_slices):
                strata = [b * n_slices + perm_blocks[b][s] for b in range(n_per)]
                rng.shuffle(strata)
                for k, st in enumerate(strata):
                    x[s * n_per + k, j] = (st + rng.random()) / N
        dmin = min(np.linalg.norm(a - b) for i, a in enumerate(x) for b in x[i + 1:])
        if dmin > best_d:
            best, best_d = x.copy(), dmin
    return best, best_d


def main():
    rng = np.random.default_rng(SEED)
    geos = [(td, ld) for ld in LD for td in TD]
    x, dmin = sliced_lhs(len(geos), 4, 4, rng)
    rows = []
    names = list(RANGES)
    def scale(u):
        return {k: RANGES[k][0] + u[i] * (RANGES[k][1] - RANGES[k][0]) for i, k in enumerate(names)}
    for g, (td, ld) in enumerate(geos):
        gap = L.cell_geometry(td, 1.5, 4.8, 3.3)['gap_mm']
        for k in range(4):
            v = scale(x[g * 4 + k])
            rows.append(dict(set='обучение', geo=g + 1, t_d=td, L_d=ld, L_mm=L_MM[ld], gap_mm=round(gap, 3), **v))
    ctl = rng.random((6, 4))
    for i in range(6):
        g = int(rng.integers(len(geos)))
        td, ld = geos[g]
        gap = L.cell_geometry(td, 1.5, 4.8, 3.3)['gap_mm']
        rows.append(dict(set='контроль', geo=g + 1, t_d=td, L_d=ld, L_mm=L_MM[ld], gap_mm=round(gap, 3), **scale(ctl[i])))
    for r in rows:
        r['dp_dzv_kPa'] = round(dp_for(r['m_target'], r['gap_mm'], r['L_mm']), 2)
        r['t0_svz'] = round(r['t0_dzv'] + r['heater'], 2)
        for k in ('m_target', 'p_cons', 't0_dzv', 'heater'):
            r[k] = round(r[k], 3 if k == 'm_target' else 2)
        r['zone'] = 'рабочая (≤1,2)' if r['p_cons'] <= 1.2 else 'граница/за границей запуска'
    # two repeats (start independence): first training point of geometry 2 and 6 again, from scratch
    for g in (2, 6):
        src = next(r for r in rows if r['geo'] == g and r['set'] == 'обучение' and r['p_cons'] <= 1.2)
        rows.append(dict(src, set='повтор с нуля'))
    for i, r in enumerate(rows, 1):
        r['id'] = f'A9_{i:02d}'
    OUT.mkdir(parents=True, exist_ok=True)
    cols = ['id', 'set', 'geo', 't_d', 'L_d', 'L_mm', 'gap_mm', 'm_target', 'dp_dzv_kPa', 'p_cons', 't0_dzv', 'heater',
            't0_svz', 'zone']
    with open(OUT / 'a9_design.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction='ignore'); w.writeheader(); w.writerows(rows)
    tr = [r for r in rows if r['set'] == 'обучение']
    print(f'обучение {len(tr)}, контроль 6, повтор 2; maximin min dist {dmin:.3f}; '
          f'за границей запуска (p>1,2): {sum(r["p_cons"] > 1.2 for r in tr)}; '
          f'перепад ДЗВ {min(r["dp_dzv_kPa"] for r in rows)}–{max(r["dp_dzv_kPa"] for r in rows)} кПа')
    for r in rows:
        print(' ', r['id'], r['set'], f"t/d {r['t_d']} L/d {r['L_d']}", f"m {r['m_target']} dp {r['dp_dzv_kPa']} кПа",
              f"p {r['p_cons']} T0дзв {r['t0_dzv']} подогрев {r['heater']}")


if __name__ == '__main__':
    main()
