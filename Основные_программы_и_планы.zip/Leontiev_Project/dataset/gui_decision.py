"""31.10.2026 — вкладка «Решение (главный инженер)», перестройка по замечаниям автора 31.10 (сутки без автора):
 • сверху крупно рядом со статусом — какой уровень ответил: «по готовой карте / подбор по модели / нужен расчёт / вне области»;
 • кнопки «Утвердить / Отклонить / Заказать расчёт» → запись в журнал решений (runs\\journal\\Журнал_решений.md);
 • при «досчитать» и «нет данных» (в т. ч. накатка) — «Посчитать при этих условиях» прямо здесь (в очередь — после подтверждения,
   с обязательным «зачем»; точки вне Ω и с перепадом < 5 кПа не ставятся; накатка — по D-30);
 • рекомендация группами: условия станции / что выбирает проектировщик (трубы, t/d, L, накатка) / что выбирает эксплуатация
   (задвижка, подогреватель) / результат; погрешность — от всех четырёх выходов модели (не «± 0,0»); p — «p = … при пороге …»;
 • график справа: топливо, кВт и СПГ, кг/ч от перепада задвижки, закрашены «вне области» и «скачок»; ниже — «тепло Q — потеря давления ДЗВ».
Расход — м³/ч при стандартных условиях (20 °C, 101,325 кПа): 5000 м³/ч = 0,928 кг/с."""
import json, math, sys, threading, time
from pathlib import Path
import numpy as np
import tkinter as tk
from tkinter import ttk, messagebox
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
sys.path.insert(0, r'F:\Leontiev_Project\program')
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from gui_task import Tip, STATUS, LEVELS, kind_text, pmv, models

JOURNAL = Path(r'F:\Leontiev_Project\runs\journal\Журнал_решений.md')
LEVEL_TEXT = {'К1': 'по готовой карте', 'К2': 'подбор по модели', 'К3': 'нужен расчёт', 'П1': 'вне области'}
LEVEL_COL = {'К1': '#2e7d32', 'К2': '#1565c0', 'К3': '#b07d00', 'П1': '#c62828'}
KNURL_NODATA = ((0.1, 2.0), (0.3, 2.0), (1.0, 2.0))   # «посчитать при этих условиях» для накатки — по D-30 (шаг 2 мм, перепад 30 кПа)


def bad_why(s):
    s = (s or '').strip()
    return (not s) or len(s) < 10 or s.lower().strip(' .!«»"') in ('тест', 'test', 'проверка')


class DecisionFrame(ttk.Frame):
    def __init__(self, master, goto_queue=None):
        super().__init__(master, padding=8)
        self.res = None
        top = ttk.Frame(self); top.pack(fill='x')
        self.status = tk.Label(top, text='Задача ещё не решена — заполните вкладку «Задача» и нажмите «Подобрать»', font=('Segoe UI', 20, 'bold'),
                               fg='white', bg='#888', padx=14, pady=6)
        self.status.pack(side='left')
        self.level = tk.Label(top, text='', font=('Segoe UI', 16, 'bold'), padx=12, pady=8, relief='groove')
        self.level.pack(side='left', padx=10)
        Tip(self.level, 'Какой уровень ответил: по готовой карте (точка уже посчитана Fluent) / подбор по модели (прогноз по данным) / '
                        'нужен расчёт Fluent / вне области применимости.')
        sf = ttk.Frame(top); sf.pack(side='left', padx=8)
        self.season = tk.StringVar(value='зима')
        for s in ('зима', 'лето'):
            ttk.Radiobutton(sf, text=s, value=s, variable=self.season, command=self.show).pack(anchor='w')
        bb = ttk.Frame(top); bb.pack(side='right')
        for t, c in (('Утвердить', lambda: self.decide('утверждено')), ('Отклонить', lambda: self.decide('отклонено')), ('Заказать расчёт', self.order_best)):
            ttk.Button(bb, text=t, command=c).pack(side='left', padx=3)
        self.why = ttk.Label(self, text='', wraplength=1280, justify='left', font=('Segoe UI', 10)); self.why.pack(anchor='w', pady=(4, 2))
        self.why_tip = Tip(self.why, '')
        mid = ttk.Frame(self); mid.pack(fill='both', expand=True)
        left = ttk.Frame(mid); left.pack(side='left', fill='y')
        rf = ttk.LabelFrame(left, text='Рекомендация', padding=6); rf.pack(fill='x'); self.rec_frame = rf
        self.rec = ttk.Label(rf, text='—', font=('Consolas', 9), justify='left'); self.rec.pack(anchor='w')
        bf = ttk.LabelFrame(left, text='Было → стало (топливо = всё топливное тепло станции, вместе с подогревом СВЗ до сопел)', padding=4)
        bf.pack(fill='x', pady=3)
        self.bs = ttk.Treeview(bf, columns=('row', 'N', 'fuel', 'lng'), show='headings', height=3)
        for c, h, w in (('row', 'как устроено', 330), ('N', 'топливо (подогреватель), кВт', 170), ('fuel', 'газ на топливо, м³/ч', 130), ('lng', 'СПГ, кг/ч', 110)):
            self.bs.heading(c, text=h); self.bs.column(c, width=w, anchor='w')
        self.bs.pack(fill='x')
        tf = ttk.LabelFrame(left, text='Лучшие варианты рядом', padding=4); tf.pack(fill='x', pady=3)
        self.tops = ttk.Treeview(tf, columns=('who', 'what', 'n', 'dp', 'N', 'lng', 'st'), show='headings', height=3)
        for c, h, w in (('who', '', 185), ('what', 'труба', 235), ('n', 'труб', 36), ('dp', 'задвижка ДЗВ, кПа', 100), ('N', 'топливо, кВт', 100),
                        ('lng', 'СПГ, кг/ч', 90), ('st', 'статус', 95)):
            self.tops.heading(c, text=h); self.tops.column(c, width=w, anchor='w')
        self.tops.pack(fill='x')
        right = ttk.Frame(mid); right.pack(side='left', fill='both', expand=True, padx=6)
        self.fig = Figure(figsize=(5.4, 5.6), dpi=88)
        self.ax1 = self.fig.add_subplot(2, 1, 1); self.ax2 = self.fig.add_subplot(2, 1, 2)
        self.canvas = FigureCanvasTkAgg(self.fig, master=right); self.canvas.get_tk_widget().pack(fill='both', expand=True)
        self.act = ttk.LabelFrame(self, text='Что делать дальше', padding=6); self.act.pack(fill='x', pady=3)
        self.act_lab = ttk.Label(self.act, text='—', wraplength=1280, justify='left'); self.act_lab.pack(anchor='w')
        self.act_box = ttk.Frame(self.act); self.act_box.pack(fill='x')
        lv = ttk.Frame(self); lv.pack(fill='x')
        self.src = ttk.Label(lv, text='', foreground='#555'); self.src.pack(side='left')
        self._todo = []; self.after(200, self._pump)
        self.to_order = []

    def _pump(self):
        while self._todo:
            try:
                self._todo.pop(0)()
            except Exception as e:
                self.act_lab.config(text=f'ошибка окна: {e!r}')
        self.after(200, self._pump)

    def set_result(self, res):
        self.res = res; self.show()

    # ------------------------------------------------------------------------------------------------------------------------
    def show(self):
        if not self.res:
            return
        import sppr
        s = self.res['seasons'][self.season.get()]
        d, base, b, card, form = s['d'], s['base'], s['d'].get('best'), s['card'], self.res['form']
        sp = s.get('spreads') or {}
        word, col = STATUS.get(d['rule'], ('ВЫДАТЬ', '#2e7d32'))
        if d['rule'] == 'П3' and not b:
            word = 'ВЫДАТЬ: пучок не рекомендован'
        self.status.config(text=f'{word}   ({self.season.get()}: газ из магистрали {card["T_main"]:+.1f} °C)', bg=col)
        lv = s['level']
        self.level.config(text='ответ: ' + LEVEL_TEXT[lv], fg=LEVEL_COL[lv])
        self.why.config(text='Причина: ' + s['simple'] + '   (подробно — наведите курсор)')
        self.why_tip.text = 'Формулировка программы: ' + d['why']
        self.rec_frame.config(text={'П3': 'Рекомендация', 'П2': 'Рекомендация предварительная — до расчёта Fluent',
                                    'П1': 'Лучшее, что есть, — условно, до расширения данных'}.get(d['rule'], 'Рекомендация'))
        fuel_kgs = card['flow_nm3h'] * 0.928 / 5000
        L = ['УСЛОВИЯ СТАНЦИИ',
             f"  магистраль {card['p_main']:g} МПа; потребитель {card['p_cons']:g} МПа, {card['flow_nm3h']:.0f} м³/ч (ст. усл. 20 °C = {fuel_kgs:.3f} кг/с)",
             f"  газ из магистрали {card['T_main']:+.1f} °C ({self.season.get()}); T газа потребителю ≥ {card['T_min']:+.0f} °C; газ ДЗВ — {card['dzv_to']}; цель — {card['goal']}"
             + (f"; требуемый СПГ {card['lng_req_kgh']:g} кг/ч" if card.get('lng_req_kgh') else '')]
        if b:
            o, e = b['o'], sp.get(id(b)) or {}
            tb = s.get('tubes') or {}
            heat = b.get('heat') or 0.0
            z = b['z'] if not str(b['z']).startswith('как CFD') else 'до сопел (как в расчёте Fluent) + после пучка'
            cool = card['T_main'] - b['T_dzv'] if b.get('T_dzv') is not None else None
            L += ['ВЫБИРАЕТ ПРОЕКТИРОВЩИК',
                  f"  число труб {b['n']} (не больше {tb.get('n_max', '—')}: {card['flow_nm3h']:.0f} м³/ч / расход одной трубы {tb.get('g_tube', float('nan')):.4f} кг/с)",
                  f"  шаг труб t/d (плотность пучка) {b['td']:g};  длина теплообмена L {b['L']:.0f} мм;  труба — {kind_text(b['kind'])}",
                  'ВЫБИРАЕТ ЭКСПЛУАТАЦИЯ',
                  f"  перепад задвижки ДЗВ {b['dp']:g} кПа;  подогреватель {z}: до сопел {b.get('pre', 0):.1f} + после пучка {b.get('post', 0):.1f} кВт",
                  f"  T СВЗ перед соплами {card['T_main'] + heat:+.1f} °C (подогрев {heat:.1f} K)",
                  'РЕЗУЛЬТАТ',
                  f"  топливо (всё тепло) {pmv(b['N'], e.get('N'))} кВт  ({b['fuel']:.2f} м³/ч газа)",
                  '  СПГ ' + (f"{pmv(b['lng'], e.get('lng'))} кг/ч" if card['dzv_to'] == 'СПГ' else 'нет (сценарий без СПГ)'),
                  f"  T газа потребителю не ниже {card['T_min']:+.0f} °C (уставка подогревателя)",
                  '  охлаждение ДЗВ ' + (f"{pmv(cool, e.get('Tdzv'))} K (газ ДЗВ {b['T_dzv']:+.1f} °C)" if cool is not None else 'нет данных'),
                  f"  труба: эффект {o['effect_K']:+.2f} ± {o['sigma_K']:.2f} K; тепло {o['Q']:.0f} ± {o.get('sigma_Q', 0):.0f} Вт; доля ДЗВ m {o['m']:.3f} ± {o.get('sigma_m', 0):.3f}; "
                  f"p = {o['p']:.3f} при пороге {self.res['p_hi']:.3f}"]
            if card['dzv_to'] == 'транзит':
                L.append(f"  транзит: газ ДЗВ уходит при {b.get('p_dzv', float('nan')):.3f} МПа (потеря {b['dp']:g} кПа)" +
                         ('; ВОССТАНАВЛИВАТЬ давление — энергия на это в программе не считается (нет данных)' if form.get('restore') else ''))
            L.append('  источник: ' + (f"Fluent, расчёт {o['src']}" if o.get('cfd') else
                                         f"модель ГП по {self.res['n_train']} точкам Fluent (заморожено), σ × {sppr.SIGMA_MULT:g}; подбор {self.res['time']}"))
        else:
            L += ['РЕКОМЕНДАЦИИ НЕТ — см. причину и «Что делать дальше».']
        self.rec.config(text='\n'.join(L))
        # было → стало: три строки
        for i in self.bs.get_children():
            self.bs.delete(i)
        vb, lb = s.get('vb'), s.get('lng_b')
        el = sp.get(id(lb)) or {} if lb else {}
        self.bs.insert('', 'end', values=('как сейчас: клапан + подогреватель', f"{base['Q_heater_kW']:.1f}", f"{base['fuel_nm3h']:.2f}", '0'))
        self.bs.insert('', 'end', values=('+ установка СПГ без пучка (сырьё — как газ ДЗВ)', f"{vb['Q_heater_kW']:.1f}" if vb else 'нет данных',
                                          f"{vb['fuel_nm3h']:.2f}" if vb else '—', f"{vb['lng_kgh']:.1f}" if vb else '—'))
        same = '' if card['dzv_to'] == 'СПГ' else ' (тот же пучок, газ ДЗВ — в СПГ)'
        self.bs.insert('', 'end', values=('+ СПГ + пучок' + same, pmv(lb['N'], el.get('N')) if lb else 'нет данных', f"{lb['fuel']:.2f}" if lb else '—',
                                          pmv(lb['lng'], el.get('lng')) if lb else '—'))
        for i in self.tops.get_children():
            self.tops.delete(i)
        for who, r in s['tops']:
            if r is None:
                why = 'не разрешена' if not form['knurl'] else 'нет данных: накатка посчитана только при 5,5 → 0,59 МПа, газ 8,63 °C'
                self.tops.insert('', 'end', values=(who, why, '', '', '', '', '')); continue
            er = sp.get(id(r)) or {}
            self.tops.insert('', 'end', values=(who, f"{kind_text(r['kind'])}, t/d {r['td']:g}, L {r['L']:.0f} мм", r['n'], f"{r['dp']:g}", pmv(r['N'], er.get('N')),
                                                pmv(r['lng'], er.get('lng')) if card['dzv_to'] == 'СПГ' else '—', STATUS.get(r['rule'], ('—',))[0]))
        self.draw(s, b, card)
        self.actions(s, d, b, card, form)
        self.src.config(text=f"данные: {self.res['n_train']} точек Fluent в обучении (заморожено); порог класса p = {self.res['p_hi']:.3f}; "
                             'программа только рекомендует — на станции ничем не управляет')

    def draw(self, s, b, card):
        a = self.ax1; a.clear()
        if getattr(self, 'tw', None) is not None:   # вторая ось (СПГ) прошлого подбора — убрать, иначе линии рисуются дважды
            self.tw.remove(); self.tw = None
        ch = s.get('chart') or []
        if ch:
            xs = [c[0] for c in ch]
            edges = [xs[0] - (xs[1] - xs[0]) / 2 if len(xs) > 1 else xs[0] - 1] + [(xs[i] + xs[i + 1]) / 2 for i in range(len(xs) - 1)] + \
                    [xs[-1] + (xs[-1] - xs[-2]) / 2 if len(xs) > 1 else xs[0] + 1]
            lab = set()
            for i, (dp, N, lng, cat, m, p) in enumerate(ch):
                zone = 'скачок' if p < 0.5 or 'скачок' in cat else ('вне области' if not (0.2 <= m <= 0.96) or cat.startswith('П1') else None)
                if zone:
                    a.axvspan(edges[i], edges[i + 1], color='#f4c7c3' if zone == 'скачок' else '#d9d9d9', alpha=0.8,
                              label=None if zone in lab else zone); lab.add(zone)
            pts = [(c[0], c[1]) for c in ch if c[1] is not None]
            a.plot([q[0] for q in pts], [q[1] for q in pts], 'o-', color='tab:red', label='топливо, кВт')
            a.set_ylabel('топливо, кВт', color='tab:red', fontsize=8)
            if card['dzv_to'] == 'СПГ':
                a2 = self.tw = a.twinx()
                pl = [(c[0], c[2]) for c in ch if c[2] is not None]
                a2.plot([q[0] for q in pl], [q[1] for q in pl], 's--', color='tab:blue', label='СПГ, кг/ч')
                a2.set_ylabel('СПГ, кг/ч', color='tab:blue', fontsize=8); a2.tick_params(labelsize=7)
            if b:
                a.axvline(b['dp'], color='k', lw=1, ls=':'); a.plot([b['dp']], [b['N']], '*', color='k', ms=13, label='выбранный')
            a.legend(fontsize=6, loc='upper left')
            a.set_title(f"Топливо и СПГ от перепада задвижки (t/d {b['td']:g}, L {b['L']:.0f} мм, {b['n']} труб(ы) по месту, подогреватель {b['z']})", fontsize=8)
        else:
            a.text(0.5, 0.5, 'нет данных для графика (выбрана точка Fluent или нет варианта)', ha='center', transform=a.transAxes, fontsize=8)
        a.set_xlabel('перепад задвижки ДЗВ, кПа', fontsize=8); a.tick_params(labelsize=7); a.grid(alpha=0.3)
        a = self.ax2; a.clear()
        for ln, sty, colr in ((s['sm_line'], 'o-', 'tab:blue'), (s.get('sm_ref'), 'o--', 'tab:gray')):
            if ln and ln[2]:
                (td, Lm), z, pts = ln
                x = [p[0] for p in pts]; y = [p[1] for p in pts]; e = [p[2] for p in pts]
                a.plot(x, y, sty, color=colr, label=f'гладкая t/d {td:g}, L {Lm:.0f} мм (модель ± σ)')
                a.fill_between(x, np.array(y) - e, np.array(y) + e, color=colr, alpha=0.15)
        if s['kn_pts']:
            a.plot([p[0] for p in s['kn_pts']], [p[1] for p in s['kn_pts']], 'D-', color='tab:orange', label='накатка (Fluent)')
        else:
            a.text(0.02, 0.95, 'накатка: нет данных при этих условиях', transform=a.transAxes, fontsize=7, color='tab:orange', va='top')
        a.set_xlabel('потеря давления ДЗВ, кПа', fontsize=8); a.set_ylabel('тепло одной трубы Q, Вт', fontsize=8)
        a.set_title('Тепло Q — потеря давления ДЗВ', fontsize=8); a.tick_params(labelsize=7); a.grid(alpha=0.3); a.legend(fontsize=6, loc='lower right')
        self.fig.tight_layout(); self.canvas.draw_idle()

    # ------------------------------------------------------------------------------------------------------------------------
    def actions(self, s, d, b, card, form):
        for w in self.act_box.winfo_children():
            w.destroy()
        self.to_order = []
        txt = []
        if d['rule'] == 'П2' and d.get('calc'):
            c = d['calc']
            self.to_order.append(dict(kind='гладкая', td=c['td'], L=c['L'], dp=float(c['dp']), pm=card['p_main'], pc=card['p_cons'], T=card['T_main'],
                                      heat=float(c.get('heat') or 0.0) if c['z'] == 'до сопел' else 0.0, h=0.0, pitch=0.0, ar=2.151))
            txt.append(f"ДОСЧИТАТЬ: нужен расчёт Fluent — {kind_text(c['kind'])}, t/d {c['td']:g}, L {c['L']:.0f} мм, перепад {c['dp']:g} кПа; "
                       f"прогноз до расчёта: эффект {c['o']['effect_K']:+.2f} ± {c['o']['sigma_K']:.2f} K, m {c['o']['m']:.2f}.")
        if form['knurl'] and not s.get('knurl_at'):
            for h, pch in KNURL_NODATA:
                self.to_order.append(dict(kind='накатка', td=1.4, L=400.0, dp=30.0, pm=card['p_main'], pc=card['p_cons'], T=card['T_main'], heat=0.0,
                                          h=h, pitch=pch, ar=2.151))
            txt.append('НАКАТКА — нет данных при этих условиях: можно посчитать накатку 0,1 / 0,3 / 1,0 мм (шаг 2 мм, t/d 1,4, L 400, перепад 30 кПа) '
                       'по D-30 (с нуля).')
        if d['rule'] == 'П1':
            txt.append('ВЕРНУТЬ ЗАДАЧУ — что вне области и ближайшее допустимое:\n• ' + '\n• '.join(s['outside'] or [d['why']]) +
                       ('\nЧто сделать: ' + '; '.join(s.get('todo') or []) if s.get('todo') else ''))
        if d['rule'] == 'П3' and not txt:
            txt.append('ВЫДАТЬ: рекомендацию можно утвердить (кнопка «Утвердить» — запись в журнал решений). Режимная карта для диспетчера — этап 3.')
        self.act_lab.config(text='\n'.join(txt))
        if self.to_order:
            ttk.Label(self.act_box, text='Зачем (что изменит в тексте / в решении):').pack(side='left')
            self.why_e = tk.Entry(self.act_box, width=70); self.why_e.pack(side='left', padx=4)
            self.why_e.insert(0, f"решение задачи «{card['title']}»: статус {STATUS.get(d['rule'], ('',))[0]} → проверка расчётом Fluent")
            ttk.Button(self.act_box, text=f'Посчитать при этих условиях ({len(self.to_order)})', command=lambda: self.order(self.to_order)).pack(side='left', padx=6)

    def journal(self, what):
        s = self.res['seasons'][self.season.get()]
        d, b, card = s['d'], s['d'].get('best'), s['card']
        rec = (f"{kind_text(b['kind'])}, t/d {b['td']:g}, L {b['L']:.0f} мм, труб {b['n']}, задвижка {b['dp']:g} кПа, подогреватель {b['z']}; "
               f"топливо {b['N']:.1f} кВт, СПГ {b['lng']:.1f} кг/ч") if b else '—'
        with open(JOURNAL, 'a', encoding='utf-8') as f:
            f.write(f"\n## Решение главного инженера (интерфейс, {time.strftime('%d.%m.%Y %H:%M')}): {card['title']}\n\n| Поле | Значение |\n|---|---|\n"
                    f"| Условия | магистраль {card['p_main']:g} МПа, потребитель {card['p_cons']:g} МПа, {card['flow_nm3h']:.0f} м³/ч (ст. усл. 20 °C), "
                    f"газ {card['T_main']:+.1f} °C, T потребителю ≥ {card['T_min']:+.0f} °C, газ ДЗВ — {card['dzv_to']}, цель — {card['goal']} |\n"
                    f"| Статус программы | {d['status']} ({d.get('cat')}); ответ — {LEVEL_TEXT[s['level']]} |\n| Рекомендация | {rec} |\n| Решение ЛПР | **{what}** |\n")

    def decide(self, what):
        if not self.res:
            return
        if messagebox.askyesno('Решение главного инженера', f'Записать в журнал решений: «{what}»?'):
            self.journal(what); messagebox.showinfo('Журнал решений', f'Записано: {what} (runs\\journal\\Журнал_решений.md)')

    def order_best(self):
        if not self.res:
            return
        s = self.res['seasons'][self.season.get()]
        b, card = s['d'].get('best'), s['card']
        if self.to_order:
            return self.order(self.to_order)
        if not b or b['kind'] != 'гладкий':
            messagebox.showinfo('Заказать расчёт', 'Выбранный вариант — точка Fluent или варианта нет: заказывать нечего.'); return
        self.order([dict(kind='гладкая', td=b['td'], L=b['L'], dp=float(b['dp']), pm=card['p_main'], pc=card['p_cons'], T=card['T_main'],
                         heat=float(b.get('heat') or 0.0) if b['z'] == 'до сопел' else 0.0, h=0.0, pitch=0.0, ar=2.151)], check=True)

    def order(self, pts, check=False):
        why = getattr(self, 'why_e', None).get().strip() if getattr(self, 'why_e', None) and self.why_e.winfo_exists() else ''
        if check or bad_why(why):
            import tkinter.simpledialog as sd
            why = sd.askstring('Зачем этот расчёт', 'Что изменит в тексте / в решении (не «тест»):', initialvalue=why, parent=self) or ''
        if bad_why(why):
            messagebox.showerror('Заказать расчёт', 'Нужно поле «зачем» (не пустое и не «тест») — без него в очередь не ставится.'); return
        M = models()
        put, skip = [], []
        for p in pts:
            if p['dp'] < 5.0:
                skip.append(f"перепад {p['dp']:g} кПа < 5"); continue
            if p['kind'] == 'гладкая':
                o = M.predict(p['td'], p['L'], p['dp'], p['pc'], p['T'], p['heat'], p['pm'])
                if not (0.2 <= o['m'] <= 0.96):
                    skip.append(f"t/d {p['td']}, L {p['L']:.0f}, перепад {p['dp']:g}: прогноз m {o['m']:.2f} вне Ω"); continue
                p = dict(p, _fc=o)
            put.append(p)
        if not put:
            messagebox.showinfo('Заказать расчёт', 'Ничего не поставлено: ' + '; '.join(skip)); return
        if not messagebox.askyesno('Заказать расчёт', f"Поставить в общую очередь {len(put)} расчёт(а) Fluent (перед запасной работой)?" +
                                   ('\nНе ставятся: ' + '; '.join(skip) if skip else '')):
            return
        import jobqueue as JQ, gui_series as GS
        fc = json.loads(GS.FC.read_text(encoding='utf-8')) if GS.FC.exists() else {}
        made = []
        for kind in ('гладкая', 'накатка'):
            grp = [p for p in put if p['kind'] == kind]
            if not grp:
                continue
            no = GS.next_series_no()
            q = [dict(tag=f'IF{no:03d}_{k:02d}', **{x: p[x] for x in ('td', 'L', 'pm', 'pc', 'dp', 'T', 'heat', 'h', 'pitch', 'ar')}) for k, p in enumerate(grp, 1)]
            r = JQ.add([dict(series=f"решение главного инженера: {kind}, {len(q)} расч.", kind='point', series_no=no, tube=kind, points=q, mesh=None,
                             plan='вкладка «Решение»' + ('; накатка — D-30' if kind == 'накатка' else ''), stdout=f'runs\\station\\IF{no:03d}_stdout.txt',
                             est_h=(3.0 if kind == 'накатка' else 1.0) * len(q), text_change=why,
                             passport=dict(kind=kind, geometry=dict(t_d=q[0]['td'], L_mm=q[0]['L']), regime=dict(p_main=q[0]['pm'], p_cons=q[0]['pc'],
                                                                                                                   dp_dzv_kPa=q[0]['dp'], T0_dzv=q[0]['T'])))],
                       by='главный инженер (интерфейс, вкладка «Решение»)', after=GS.backup_after())
            for p, qq in zip(grp, q):
                o = p.get('_fc') or {}
                fc[qq['tag']] = dict(job=r[0]['id'], kind=kind, point=qq, x=o.get('x'), effect_K=o.get('effect_K'), sigma_K=o.get('sigma_K'), m=o.get('m'),
                                     p=o.get('p'), time=time.strftime('%d.%m.%Y %H:%M:%S'), status='в очереди', в_обучение=False)
            made.append(f"{r[0]['id']} ({kind}, {len(q)})")
        GS.FC.write_text(json.dumps(fc, ensure_ascii=False, indent=1), encoding='utf-8')
        self.journal('заказан расчёт: ' + ', '.join(made))
        messagebox.showinfo('Заказать расчёт', 'Поставлено: ' + ', '.join(made) + '. Прогноз до расчёта записан; запись — в журнале решений.')
