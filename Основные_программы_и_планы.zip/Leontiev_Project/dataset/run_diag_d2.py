"""12.10.2026 — D2 (author agreed): the same cell e continuation as D1 but with the brass k back to 110 and the coupled
solver in PSEUDO-TRANSIENT mode with a GLOBAL pseudo time step (Fluent probe 20:24: formulation 0 = Off, which is what
the project used so far; 1 = Global Time Step).  Settings: automatic step, length scale 'Aggressive', factor 1, solid
zones automatic, factor 1 (syntax checked in runs\\a5v3b\\ip_old\\probe_pt3.trn).  Only L.SOLVER_HEADER of THIS process
is changed.  3000 it. from cell_e_t14_m03_p12_p2 (DZV drop 0.83 kPa, flow 0.0656 kg/s and decaying ~0.2 %/100 it.).
Compare the flow decay per 100 it. and per minute with the CFL-20 stage p2."""
import sys, time, traceback
sys.path.insert(0, r'F:\Leontiev_Project\dataset')
import run_pilot_night as N
import leontiev_pipeline as L
import gui_convergence as C
F, P, U, log = N.F, N.P, N.U, N.log
U.LIMIT = 3000
PT = ['/solve/set/pseudo-time-method/formulation 1',
      '/solve/set/pseudo-time-method/global-time-step-settings yes 0 1 yes 1']
L.SOLVER_HEADER[:] = [PT[0] if 'pseudo-time-method/formulation' in x else x for x in L.SOLVER_HEADER]
L.SOLVER_HEADER.insert(L.SOLVER_HEADER.index(PT[0]) + 1, PT[1])


def main():
    tag = 'diag_e_pseudoglobal'
    log('=== диагностика D2: ячейка e, псевдонестационарный метод с глобальным шагом (сетка та же, k 110)')
    t0 = time.time()
    F.cont(P.BASE / 'cell_e_t14_m03_p12_p2' / 'result.cas.h5', tag, (5.5, 1.2, 5.5, 5.49917), [], None,
           'диагностика D2: продолжение cell_e_t14_m03_p12_p2, глобальный псевдошаг')
    minutes = (time.time() - t0) / 60
    rows = C.closed_samples(P.BASE / tag)
    for a, b in zip(rows, rows[1:]):
        log(f'  {tag}: ит. {b["iteration"]}: расход ДЗВ {b["m_dzv"]:.5f} кг/с, изменение '
            f'{100 * (b["m_dzv"] - a["m_dzv"]) / a["m_dzv"] / 5:+.3f} %/100 ит., Q {b["Q"]:.1f} Вт, баланс {b["net"]:.1f} Вт')
    if len(rows) > 1:
        n = rows[-1]['iteration'] - rows[0]['iteration']
        log(f'  D2: {minutes:.0f} мин; расход {rows[0]["m_dzv"]:.5f} -> {rows[-1]["m_dzv"]:.5f} кг/с за {n} ит. '
            f'(CFL 20, этап p2: ~-0,18 %/100 ит., ~1 с/ит.)')


if __name__ == '__main__':
    P.qlog('=== диагностика D2 (глобальный псевдошаг) — начат')
    try:
        main()
    except Exception:
        log('D2: ОШИБКА программы: ' + traceback.format_exc())
    P.qlog('=== диагностика D2 — закончен')
