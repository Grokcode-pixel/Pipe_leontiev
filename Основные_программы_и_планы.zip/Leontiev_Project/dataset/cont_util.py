"""Shared helpers for continuation runs and result rows (08.10.2026).
continue_case: read a converged case, apply extra lines (gas, properties, T0), set the regime pressures, coupled with
auto-stop (up to LIMIT iterations), export axis, close Fluent.  record: one row with BOTH Fluent total temperatures
(dT_svz_total / dT_dzv_total, author 08.10) and, for methane, the enthalpy-based outlet temperatures of the gas at rest
plus the throttle reference (grs_temps.py)."""
import csv, subprocess, time
from pathlib import Path
import leontiev_pipeline as L
import gui_runner as G
import gui_convergence as C
from make_gui_prt_journal import GUI_PRT
import grs_temps

LIMIT = 5500
GUARD_ENERGY_W = None   # 11.10: if set, a stage is failed when the energy imbalance exceeds it (after 1500 it.)
GUARD_FRAC = None       # 29.10: if set, the guard is GUARD_FRAC * |Q of the tube| (W) instead of GUARD_ENERGY_W
STALL_MIN = 20  # 11.10: watchdog, minutes without a new iteration -> kill (G.status 'iter')
NPROC = 6    # 27.10: new PC (Ryzen 7 7700, 8 cores): 500-it test 6/7/8/10/12 -> 0.125/0.127/0.126/0.136/0.140 s/it (runs\speed_pc2_500); was 7 on the laptop
CFL = 20.0   # 09.10: module-level so a series can lower it (fine DZV layers were unstable at CFL 20 after the startup)
PARALLEL = False  # 27.10: several Fluent windows at once — no wait for a free Fluent, kill only this window's process tree
# 30.10: 3D-пучок (bundle3d_run.py) — решатель, предел времени, свои строки экспорта (последний файл — axis.csv: по нему
# continue_case понимает, что Fluent закончил) и правка строк журнала; по умолчанию — как для 2D
SOLVER_DIM = '2ddp'
TIME_LIMIT_H = 4
END_EXPORT = None
JOU_HOOK = None


def _kill(t0, proc):
    if PARALLEL:
        subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
    else:
        G.kill_since(t0)
COLS = ['tag', 'mesh', 'gas', 'p0_svz', 'p_out_svz', 'p0_dzv', 'p_out_dzv', 'T0_C', 'start', 'status', 'reason', 'converged',
        'iter', 'dT_svz_total', 'dT_dzv_total', 'Q', 'G_svz', 'G_dzv', 'ratio', 'net_W', 'dm_svz_pct', 'dm_dzv_pct',
        'dT_svz_h', 'dT_dzv_h', 'dT_svz_throttle', 'dT_dzv_throttle', 'dT_svz_vs_throttle', 'dT_dzv_vs_throttle',
        'yp_svz', 'M_mean_channel', 'M_outlet', 'x_shock_m', 'reversed_max_pct', 'minutes',
        'T0_dzv_C', 'G_dzv_target', 'G_dzv_miss_pct', 'cond_margin_K']   # 09.10


def t0_line(t0_C):
    return f'/define/boundary-conditions/set/pressure-inlet inlet_svz inlet_dzv () t0 no {t0_C:g} q'


def t0_lines(t0_svz_C, t0_dzv_C):
    """09.10.2026: separate inlet temperatures (heater on the SVZ line only, author's decision 0...+20 K)."""
    return [f'/define/boundary-conditions/set/pressure-inlet inlet_svz () t0 no {t0_svz_C:g} q',
            f'/define/boundary-conditions/set/pressure-inlet inlet_dzv () t0 no {t0_dzv_C:g} q']


def tmf_lines(g_kg_s, p_min_MPa, p_max_MPa):
    """09.10.2026: targeted mass flow at the DZV outlet.  Limits are ABSOLUTE pressures in the case units (atm, operating
    pressure 0).  Dataset rule (review): p_min >= consumer pressure + return-line losses, p_max just below p0_DZV.
    The achieved flow is checked afterwards (record: G_dzv vs target), an unreachable flow is a physical status."""
    atm = 0.101325
    return [f'/define/boundary-conditions/set/pressure-outlet outlet_dzv () targeted-mf-boundary? yes targeted-mf no {g_kg_s:g} '
            f'targeted-mf-pmin no {p_min_MPa / atm:.5f} targeted-mf-pmax no {p_max_MPa / atm:.5f} q']


def cond_margin(axis_csv):
    """09.10.2026: condensation flag for methane — min over the axis of (static T - T_sat(p)) where p < p_crit (K).
    Negative = the core flow is below the saturation line (the PR model does not represent condensation; real natural
    gas with heavier components condenses earlier)."""
    import CoolProp.CoolProp as CP
    pc = CP.PropsSI('Pcrit', 'Methane')
    best = None
    for r in csv.DictReader(open(axis_csv)):
        r = {k.strip(): v for k, v in r.items()}
        p, T = float(r['pressure']), float(r['temperature'])
        if 1e4 < p < pc:
            d = T - CP.PropsSI('T', 'P', p, 'Q', 1, 'Methane')
            best = d if best is None or d < best else best
    return None if best is None else round(best, 2)


def continue_case(src_case, out, extra, regime, log, tag, t0_C=None, wall_k=None, t0_dzv_C=None):
    """regime = (p0_svz, p_out_svz, p0_dzv, p_out_dzv) MPa.  Returns minutes or None on failure.
    wall_k: set the wall conductivity explicitly (a continued case keeps the value of its source case).
    t0_dzv_C: separate DZV inlet temperature (09.10); t0_C is then the SVZ inlet temperature."""
    if wall_k:
        extra = list(extra) + [L.wall_k_line(float(wall_k))]
    out = Path(out); out.mkdir(parents=True, exist_ok=True)
    for f in list(out.glob('*.trn')) + list(out.glob('axis.csv')):
        f.unlink()
    q = L.fl(out)
    p0s, pos, p0d, pod = regime
    target = {'inlet_svz': p0s * 1e6, 'outlet_svz': pos * 1e6, 'pressure_inlet_dzv': p0d * 1e6, 'outlet_dzv': pod * 1e6}
    lines = ['/file/confirm-overwrite? no', f'/file/start-transcript "{q}/run.trn"', f'/file/read-case-data "{L.fl(src_case)}"']
    lines += [g.format(prt=0.85) for g in GUI_PRT] + list(extra) + G.bc_lines(target)
    if t0_dzv_C is not None:
        lines += t0_lines(25.0 if t0_C is None else t0_C, t0_dzv_C)
    elif t0_C is not None:
        lines.append(t0_line(t0_C))
    lines += C.coupled_journal(dict(coupled_iters=LIMIT, report_every=500, cfl=CFL), out)
    lines += [f'/file/write-case-data "{q}/result.cas.h5"']
    lines += ([s.format(q=q) for s in END_EXPORT] if END_EXPORT else
              [f'/file/export/ascii "{q}/axis.csv" axis () yes mach-number pressure total-pressure temperature '
               'total-temperature axial-velocity () yes'])
    lines += ['/file/stop-transcript']
    if JOU_HOOK:
        lines = JOU_HOOK(lines)
    (out / 'cont.jou').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    log(f'=== {tag}: продолжение с {Path(src_case).parent.name}; режим СВЗ {p0s}->{pos}, ДЗВ {p0d}->{pod} МПа'
        + (f', T0 {t0_C:g} °C' if t0_C is not None else ''))
    while not PARALLEL and G.fluent_running():
        time.sleep(60)
    t0 = time.time()
    proc = subprocess.Popen([L.FLUENT, SOLVER_DIM, f'-t{NPROC}', '-i', str(out / 'cont.jou')], cwd=str(out), stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True)
    first, said = None, False
    last_it, t_it = None, time.time()
    prev_ce, cur_ce, last_ce_it = None, None, None
    while not (out / 'axis.csv').exists():
        rows = C.closed_samples(out)
        if rows and first is None:
            first = rows[0]['iteration'] - 500
        c = C.update_control(out, True, max_iter=first + LIMIT if first is not None else None)
        if c['stop_requested'] and not said:
            log('  критерии сходимости выполнены в двух проверках подряд — Fluent сохранит кейс'); said = True
        # 11.10 22:15: guard against a slow blow-up at a large CFL (cell a at CFL 100: energy imbalance 2 -> 4530 W)
        ce = (c.get('checks') or {}).get('energy_W')
        # 13.10 15:10: only a GROWING imbalance is a blow-up (knurl h 0.5 after the field transfer: 602 -> 471 -> 363 W,
        # a decaying start transient, was killed by the absolute rule)
        if ce and c['checked_iteration'] != last_ce_it:
            prev_ce, last_ce_it, cur_ce = cur_ce, c['checked_iteration'], ce['value']
        # 29.10 (решение автора): порог страховки — доля теплового потока трубы Q (GUARD_FRAC), а не абсолютные Вт: у новой
        # геометрии (RU 2836642) дисбаланс колебался ±200…430 Вт при стабильных выходах (Q ≈ 1080 Вт) и снимался правилом 300 Вт
        guard = GUARD_ENERGY_W
        if GUARD_FRAC and rows and rows[-1].get('Q'):
            guard = GUARD_FRAC * abs(rows[-1]['Q'])
        if (guard and ce and first is not None and c['checked_iteration'] - first >= 1500 and ce['value'] > guard
                and prev_ce is not None and cur_ce > prev_ce):
            _kill(t0, proc); log(f'  {tag}: СБОЙ (дисбаланс энергии {ce["value"]:.0f} Вт > {guard:.0f} Вт — неустойчиво при CFL {CFL:g})')
            return None
        st = G.status(out)
        if st and (st['fpe'] or st['error']):
            _kill(t0, proc); log(f'  {tag}: СБОЙ (расходимость или ошибка журнала) на итерации {st["iter"]}'); return None
        if time.time() - t0 > TIME_LIMIT_H * 3600:
            _kill(t0, proc); log(f'  {tag}: СБОЙ (время)'); return None
        # 11.10: watchdog — 10.10 Fluent hung twice (iteration not finishing, CPU busy, Stop ignored)
        it = st['iter'] if st else None
        if it != last_it:
            last_it, t_it = it, time.time()
        elif it is not None and time.time() - t_it > STALL_MIN * 60:
            _kill(t0, proc); log(f'  {tag}: СБОЙ (зависание: итерация {it} не меняется {STALL_MIN} мин)'); return None
        time.sleep(10)
    time.sleep(10)
    _kill(t0, proc)
    return round((time.time() - t0) / 60, 1)


def record(csv_path, tag, mesh, gas, regime, out, minutes, log, start='', t0_C=25.0, l_heat_mm=400.0, t0_dzv_C=None,
           g_dzv_target=None):
    """t0_C = SVZ inlet temperature; t0_dzv_C = DZV inlet temperature (09.10; default = t0_C).  g_dzv_target: targeted DZV
    flow — the achieved flow is checked (|G - target| > 1 % -> reason gets 'расход ДЗВ не достигнут')."""
    out = Path(out)
    p0s, pos, p0d, pod = regime
    t0d = t0_C if t0_dzv_C is None else t0_dzv_C
    row = dict(tag=tag, mesh=mesh, gas=gas, p0_svz=p0s, p_out_svz=pos, p0_dzv=p0d, p_out_dzv=pod, T0_C=t0_C, start=start,
               minutes=minutes, T0_dzv_C=t0d, G_dzv_target=g_dzv_target)
    st = G.status(out) if out.exists() else None
    if st and st['samples'] and (out / 'axis.csv').exists():
        b = st['samples'][-1]; cl = C.closed_samples(out)
        conv = G.converged(out)
        status_, reason, info = G.classify(out, dict(l_heat_mm=l_heat_mm), conv)
        row.update(status=status_, reason=reason, converged=conv, iter=st['iter'], dT_svz_total=round(b['dT_svz'] + 25 - t0_C, 3),
                   dT_dzv_total=round(b['dT_dzv'] + 25 - t0d, 3), Q=round(b['Q'], 1), ratio=round(b['ratio'], 4),
                   yp_svz=round(b['yp_svz'], 3), **{k: info.get(k) for k in ('M_mean_channel', 'M_outlet', 'x_shock_m', 'reversed_max_pct')})
        if cl:
            row.update(G_svz=round(cl[-1]['m_svz'], 6), G_dzv=round(cl[-1]['m_dzv'], 6), net_W=round(cl[-1]['net'], 3),
                       dm_svz_pct=round(cl[-1]['dm'], 4), dm_dzv_pct=round(cl[-1]['dm_dzv'], 4))
            if g_dzv_target:
                miss = abs(cl[-1]['m_dzv'] - g_dzv_target) / g_dzv_target * 100
                row['G_dzv_miss_pct'] = round(miss, 2)
                if miss > 1.0:
                    row['reason'] = f"{row['reason']}; расход ДЗВ не достигнут ({miss:.1f} %)"
            if gas.startswith('ch4'):
                row.update(grs_temps.outlet_temps(b['Q'], cl[-1]['m_svz'], cl[-1]['m_dzv'], 273.15 + t0_C, p0s, pos, pod, p0d,
                                                  T0_dzv_K=273.15 + t0d))
                try:
                    row['cond_margin_K'] = cond_margin(out / 'axis.csv')
                except Exception:
                    pass
        log(f"{tag}: {status_} ({reason}); полная T: СВЗ {row['dT_svz_total']:+.3f} K, ДЗВ {row['dT_dzv_total']:+.3f} K; "
            f"Q {row['Q']:.1f} Вт; G {row.get('G_svz')}/{row.get('G_dzv')} кг/с"
            + (f"; по энтальпии: СВЗ {row['dT_svz_h']:+.2f} K (дроссель {row['dT_svz_throttle']:+.2f}, эффект {row['dT_svz_vs_throttle']:+.2f}), "
               f"ДЗВ {row['dT_dzv_h']:+.2f} K" if 'dT_svz_h' in row else ''))
    else:
        row.update(status='сбой', reason='нет результата')
        log(f'{tag}: нет результата (сбой)')
    new = not Path(csv_path).exists()
    # 09.10: new columns are appended; an older file keeps its own header (no column shift)
    cols = COLS if new else (next(csv.reader(open(csv_path, encoding='utf-8')), None) or COLS)
    with open(csv_path, 'a', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction='ignore')
        if new:
            w.writeheader()
        w.writerow(row)
    return row
