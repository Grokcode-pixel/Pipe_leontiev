"""Recovery factor r from CFD by three Mach-number definitions, with the experiment's Eq. 13
(Leontiev et al. 2017):  r = 1 - (T0 - Taw)/T0 * (2/((g-1) M^2) + 1),  T0 = inlet total temperature.
  axis : M on the axis (what run_a2.py used)
  1D   : M from mass-flux-averaged section T and T0:  M = sqrt(2/(g-1) (T0m/Tm - 1))   (closest to the 1D processing)
  pwall: M from wall static pressure and mass-averaged section total pressure (isentropic relation)
Section averages: nodes of interior-air_svz grouped by x, weight rho*u*r (axisymmetric), trapezoid in r.
usage: python r_variants.py <case dir> ...   (needs svz_faces.csv, wall_p.csv, axis.csv from export_r_fields.py)"""
import csv, math, sys
from collections import defaultdict
from pathlib import Path
G = 1.4
T0_IN = 298.15
L_CH = 0.400


def rows(path):
    r = list(csv.reader(open(path)))
    h = [x.strip() for x in r[0]]
    return [dict(zip(h, map(float, v))) for v in r[1:] if v]


def r_eq13(Taw, M, T0=T0_IN):
    return 1 - (T0 - Taw) / T0 * (2 / ((G - 1) * M * M) + 1)


def interp(xs, ys, x):
    for i in range(1, len(xs)):
        if xs[i] >= x:
            t = (x - xs[i - 1]) / (xs[i] - xs[i - 1]) if xs[i] != xs[i - 1] else 0
            return ys[i - 1] + t * (ys[i] - ys[i - 1])
    return ys[-1]


def analyse(d):
    d = Path(d)
    sec = defaultdict(list)
    for n in rows(d / 'svz_faces.csv'):
        sec[round(n['x-coordinate'], 5)].append(n)
    stations = []
    for x, ns in sorted(sec.items()):
        if not 0.05 <= x <= 0.85 * L_CH or len(ns) < 10:
            continue
        ns.sort(key=lambda n: n['y-coordinate'])
        w = s_T = s_T0 = s_p0 = 0.0
        for a, b in zip(ns, ns[1:]):
            dr = b['y-coordinate'] - a['y-coordinate']
            for n, f in ((a, 0.5), (b, 0.5)):
                wt = n['density'] * n['axial-velocity'] * n['y-coordinate'] * dr * f
                w += wt; s_T += wt * n['temperature']; s_T0 += wt * n['total-temperature']; s_p0 += wt * n['total-pressure']
        if w <= 0:
            continue
        Tm, T0m, p0m = s_T / w, s_T0 / w, s_p0 / w
        stations.append((x, math.sqrt(max(2 / (G - 1) * (T0m / Tm - 1), 1e-9)), p0m, ns[0]['mach-number']))
    xs = [s[0] for s in stations]
    wall = sorted(rows(d / 'wall_p.csv'), key=lambda w: w['x-coordinate'])
    out = {'axis': [], '1D': [], 'pwall': []}
    for wnode in wall:
        x = wnode['x-coordinate']
        if not xs[0] <= x <= xs[-1]:
            continue
        Taw = wnode['temperature']
        M_ax = interp(xs, [s[3] for s in stations], x)
        M_1d = interp(xs, [s[1] for s in stations], x)
        p0m = interp(xs, [s[2] for s in stations], x)
        M_pw = math.sqrt(max(2 / (G - 1) * ((p0m / wnode['pressure']) ** ((G - 1) / G) - 1), 1e-9))
        for k, M in (('axis', M_ax), ('1D', M_1d), ('pwall', M_pw)):
            if M > 1.5:
                out[k].append((r_eq13(Taw, M), M))
    res = {}
    for k, v in out.items():
        rs = [a for a, _ in v]
        m = sum(rs) / len(rs)
        res[k] = dict(r=round(m, 4), sd=round(math.sqrt(sum((a - m) ** 2 for a in rs) / max(len(rs) - 1, 1)), 4),
                      M=round(sum(b for _, b in v) / len(v), 3), n=len(v))
    return res


if __name__ == '__main__':
    for d in sys.argv[1:]:
        print(Path(d).name, analyse(d), flush=True)
