"""Leontiev-tube dataset pipeline (Fluent regime runs + result parsing + dataset CSV).

Stage A (this file): regime / boundary-condition studies on an existing, verified
Fluent case (mesh fixed).  Stage B (geometry) is driven by wb_build_variant.wbjn and
build_geometry_case() below, then the same run_case() is used.

Every row stores inputs, outputs AND quality flags; only rows with `converged=1`
should be used as clean training labels.  Nothing here accepts a result by itself.
"""
import csv, json, math, re, subprocess, time
from pathlib import Path

FLUENT = r'C:\Program Files\ANSYS Inc\v242\fluent\ntbin\win64\fluent.exe'
ROOT = Path(r'F:\Leontiev_Project')
DS = ROOT / 'dataset'
T_REF_K = 298.15

# ---------------------------------------------------------------- journals
def fl(p):
    return str(p).replace('\\', '/')

REPORT_BLOCK = r'''
    (display "GRS_SAMPLE_START ") (write {it}) (newline)
    (ti-menu-load-string "/solve/report-definitions/compute outlet_total_temp_svz outlet_total_temp_dzv outlet_total_pressure_svz outlet_total_pressure_dzv inlet_mass_flow_rate_svz inlet_mass_flow_rate_dzv outlet_mass_flow_rate_svz outlet_mass_flow_rate_dzv ()")
    (display "GRS_YPLUS_SVZ") (newline)
    (ti-menu-load-string "/report/surface-integrals/facet-max wall_outer-air_svz wall-air_svz-wall_abonite-shadow () y-plus no")
    (display "GRS_YPLUS_DZV") (newline)
    (ti-menu-load-string "/report/surface-integrals/facet-max wall_outer-air_dzv interior-air_dzv-wall_abonite-shadow () y-plus no")
    (display "GRS_ENERGY_FLUX_START") (newline)
    (ti-menu-load-string "/report/fluxes/heat-transfer yes no")
    (display "GRS_ENERGY_FLUX_END") (newline)
    (display "GRS_SAMPLE_END") (newline)
'''


# 08.10.2026, author: air thermal conductivity k(T) = mu_Sutherland(T)*(cp + 5/4 R) (Eucken), cubic in T [K], 80-400 K,
# Prt 0.85 preliminary until A5.  Answers checked in the Fluent window (k, then 4 x no).  Old cases carry the old constant
# k, so every continuation must apply this line explicitly.
AIR_K_POLY = (-1.387359e-03, 1.211858e-04, -1.364036e-07, 9.301419e-11)
AIR_K_LINE = ('/define/materials/change-create air air no no yes polynomial 4 '
              + ' '.join(f'{c:.6e}' for c in AIR_K_POLY) + ' no no no no')


# 08.10.2026 16:40, author: wall material = brass (as in the 2017 experiment); typical conductivity of brass LS59-1
# ~110 W/(m K) (handbook value; the grade is not given in the paper).  Runs before the dataset used 234 W/(m K)
# (material 'latun' of the project, an aluminium-like value).  Answers for the solid material: density no, cp no, k yes.
BRASS_K = 110.0


def wall_k_line(k):
    return f'/define/materials/change-create latun latun no no yes constant {k:g}'


# 08.10.2026, stage A6 — methane (material 'air' is redefined so that zones/BCs stay the same).  Ideal-gas cp0, k, mu
# fitted to CoolProp (HEOS, 0.1 MPa) over 120-350 K (max errors 0.16 / 0.33 / 0.27 %).  Prompt order checked in the
# Fluent window 08.10 11:20-11:35.  Peng-Robinson: switching the density method first, then a second command for the
# critical constants (they are asked only once PR is active).  Units of the case: temperature in C, pressure in atm
# (Tc 190.564 K = -82.586 C; pc 4.5992 MPa = 45.391 atm; vc = 1/162.66 = 0.0061478 m3/kg; omega 0.01142).
_CH4_POLY = ('polynomial 4 2.143344e+03 -6.785060e-01 -2.958273e-04 1.167260e-05 '
             'yes polynomial 4 -3.672790e-03 1.535971e-04 -2.181227e-07 4.301212e-10 '
             'yes polynomial 4 -1.462361e-06 5.896580e-08 -7.477285e-11 6.494579e-14 yes 16.0428 no no')
CH4_IDEAL_LINES = ['/define/materials/change-create air air no yes ' + _CH4_POLY]
CH4_PR_LINES = ['/define/materials/change-create air air yes real-gas-peng-robinson yes ' + _CH4_POLY,
                '/define/materials/change-create air air no no no no no no no no no yes -82.586 yes 45.391 yes 0.0061478 yes 0.01142']
GAS_LINES = {'air': None, 'ch4_ideal': CH4_IDEAL_LINES, 'ch4_pr': CH4_PR_LINES}


# Same numerical set-up as the G2-G4 runs: pressure-based coupled, second order, residual
# convergence check OFF (otherwise Fluent stops /solve/iterate after a few iterations).
SOLVER_HEADER = [
    '/solve/set/p-v-coupling 24',
    '/solve/set/pseudo-time-method/formulation 0',
    '/solve/set/poor-mesh-numerics/orthogonality-enhancing-cell-centroids? yes 0.1',
    "(rpsetvar 'residuals/settings '((continuity #t 0. #f 0.0001 0.0001 1e-05 0.0001 0. 0.05) (x-velocity #t 0. #f 0.0001 0.0001 1e-05 0.0001 0. 0.05) (y-velocity #t 0. #f 0.0001 0.0001 1e-05 0.0001 0. 0.05) (energy #t 0. #f 1e-08 1e-08 1e-05 0.0001 0. 0.05) (k #t 0. #f 0.0001 0.0001 1e-05 0.0001 0. 0.05) (omega #t 0. #f 0.0001 0.0001 1e-05 0.0001 0. 0.05)))",
    "(rpsetvar 'mom/scheme 1)", "(rpsetvar 'temperature/scheme 1)", "(rpsetvar 'k/scheme 1)", "(rpsetvar 'omega/scheme 1)",
    "(rpsetvar 'temperature/relax 1.)", "(rpsetvar 'temperature/amg-alpha 0.00001)", "(rpsetvar 'amg-scalar/max-cycles 200)",
]


SIMPLE_HEADER = [   # proven start-up recipe of the original runs: SIMPLE, second order, conservative URFs
    '/solve/set/p-v-coupling 20', '/solve/set/pseudo-time-method/formulation 0',
    '/solve/set/poor-mesh-numerics/orthogonality-enhancing-cell-centroids? yes 0.1',
    "(rpsetvar 'residuals/settings '((continuity #t 0. #f 0.0001 0.0001 1e-05 0.0001 0. 0.05) (x-velocity #t 0. #f 0.0001 0.0001 1e-05 0.0001 0. 0.05) (y-velocity #t 0. #f 0.0001 0.0001 1e-05 0.0001 0. 0.05) (energy #t 0. #f 1e-08 1e-08 1e-05 0.0001 0. 0.05) (k #t 0. #f 0.0001 0.0001 1e-05 0.0001 0. 0.05) (omega #t 0. #f 0.0001 0.0001 1e-05 0.0001 0. 0.05)))",
    "(rpsetvar 'pressure/relax 0.2)", "(rpsetvar 'mom/relax 0.3)", "(rpsetvar 'k/relax 0.3)", "(rpsetvar 'omega/relax 0.3)",
    "(rpsetvar 'temperature/relax 0.9)", "(rpsetvar 'mom/scheme 1)", "(rpsetvar 'temperature/scheme 1)",
    "(rpsetvar 'k/scheme 1)", "(rpsetvar 'omega/scheme 1)", "(rpsetvar 'temperature/amg-alpha 0.001)", "(rpsetvar 'amg-scalar/max-cycles 100)",
]


def stage_journal(spec, case_in, case_out, trn, n_iter, cfl, ramp_steps=None, report_every=100, first_order=False, simple=False):
    """One Fluent session: read case+data, apply BC values (ramped), iterate, sample, save."""
    expr = {  # named expression -> value in Pa
        'inlet_svz': spec['p0_svz_MPa'] * 1e6,
        'outlet_svz': spec['p_out_svz_MPa'] * 1e6,
        'outlet_dzv': spec['p_out_dzv_MPa'] * 1e6,
        'pressure_inlet_dzv': spec['p0_dzv_MPa'] * 1e6,
    }
    j = []
    j.append(f'/file/start-transcript "{fl(trn)}"')
    j.append(f'/file/read-case-data "{fl(case_in)}"')
    hdr = SIMPLE_HEADER if simple else SOLVER_HEADER
    hdr = [h.replace('scheme 1)', 'scheme 0)') for h in hdr] if first_order else hdr
    j.extend(hdr)
    if spec.get('prt'):                       # turbulent Prandtl number (energy + wall), e.g. 0.65
        j.append(f"(rpsetvar 'keprt {float(spec['prt'])})")
        j.append(f"(rpsetvar 'wallprt {float(spec['prt'])})")
    if not simple:
        j.append(f"(rpsetvar 'pressure/cpl-courant-number {float(cfl)})")
        j.append(f"(rpsetvar 'pressure-coupled/courant-number {float(cfl)})")
    cur = spec.get('_current') or {}
    steps = ramp_steps or 1
    for s in range(1, steps + 1):
        for name, tgt in expr.items():
            c0 = cur.get(name, tgt)
            v = c0 + (tgt - c0) * s / steps
            j.append(f'/define/named-expressions/edit {name} definition "{v:.6g} [Pa]" q')
            j.append(f'/define/named-expressions/compute {name}')
        if steps > 1:
            j.append('/solve/iterate %d' % spec.get('ramp_iters', 80))
    n_blocks = max(1, n_iter // report_every)
    j.append('(do ((grs-step 0 (+ grs-step 1))) ((= grs-step %d))' % n_blocks)
    j.append('    (ti-menu-load-string "/solve/iterate %d")' % report_every)
    j.append(REPORT_BLOCK.format(it='(* (+ grs-step 1) %d)' % report_every))
    j.append(')')
    j.append(f'/file/write-case-data "{fl(case_out)}"')
    j.append('/file/stop-transcript')
    j.append('/exit yes')
    return '\n'.join(j) + '\n'

# ---------------------------------------------------------------- parsing
NUM = r'(-?[\d\.]+(?:e[\+-]?\d+)?|nan)'


def parse_trn(trn):
    """Return list of samples (dict) and per-iteration residual table."""
    t = Path(trn).read_text(encoding='utf-8', errors='replace').splitlines()
    samples, res = [], []
    cur, sec = None, None
    for ln in t:
        m = re.match(r'^\s+(\d{1,6})\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+\d+:\d+:\d+\s+\d+\s*$', ln)
        if m:
            try:
                res.append(dict(it=int(m.group(1)), continuity=float(m.group(2)), energy=float(m.group(5))))
            except ValueError:
                pass
        m = re.match(r'^GRS_SAMPLE_START (\d+)', ln)
        if m:
            cur = dict(sample=int(m.group(1)), flux={}); sec = None; continue
        if cur is None:
            continue
        if ln.startswith('GRS_SAMPLE_END'):
            samples.append(cur); cur = None; continue
        m = re.match(r'^(outlet_total_temp_svz|outlet_total_temp_dzv|outlet_total_pressure_svz|outlet_total_pressure_dzv|'
                     r'inlet_mass_flow_rate_svz|inlet_mass_flow_rate_dzv|outlet_mass_flow_rate_svz|outlet_mass_flow_rate_dzv)\s*$', ln)
        if m:
            sec = m.group(1); continue
        if ln.startswith('GRS_YPLUS_SVZ'):
            sec = 'yp_svz'; continue
        if ln.startswith('GRS_YPLUS_DZV'):
            sec = 'yp_dzv'; continue
        if ln.startswith('GRS_ENERGY_FLUX_START'):
            sec = 'flux'; continue
        if sec in ('yp_svz', 'yp_dzv'):
            m = re.match(r'^\s*(wall\S*|interior\S*)\s+' + NUM + r'\s*$', ln)
            if m:
                try:
                    cur[sec] = max(cur.get(sec, 0.0), float(m.group(2)))
                except ValueError:
                    pass
            elif ln.strip().startswith('---') and sec in cur:
                pass
            if ln.strip().startswith('GRS_ENERGY'):
                sec = None
            continue
        if sec == 'flux':
            m = re.match(r'^\s*(\S+)\s+' + NUM + r'\s*$', ln)
            if m and m.group(1) not in ('Net',):
                try:
                    cur['flux'][m.group(1)] = float(m.group(2))
                except ValueError:
                    pass
            m = re.match(r'^\s*Net\s+' + NUM + r'\s*$', ln)
            if m:
                cur['net'] = float(m.group(1))
            continue
        m = re.match(r'^\s+(outlet|inlet)_(svz|dzv)\s+' + NUM + r'\s*$', ln)
        if m and sec and sec not in ('flux',):
            try:
                cur[sec] = float(m.group(3))
            except ValueError:
                pass
            sec = None
    return samples, res


def metrics_from_sample(s):
    f = s['flux']
    q_wall = f.get('wall-air_svz-wall_abonite-shadow', f.get('wall-air_svz-wall_abonite', 0.0))
    # heat from wall into SVZ gas / out of DZV gas (W); gas-side wall zones
    q_svz = abs(f.get('wall-air_svz-wall_abonite', 0.0))
    q_dzv = abs(f.get('interior-air_dzv-wall_abonite', 0.0))
    imb_svz = f.get('inlet_svz', 0) + f.get('outlet_svz', 0) - f.get('wall-air_svz-wall_abonite', 0)
    imb_dzv = f.get('inlet_dzv', 0) + f.get('outlet_dzv', 0) - f.get('interior-air_dzv-wall_abonite', 0)
    out = dict(
        dT_svz=s.get('outlet_total_temp_svz', float('nan')) - 25.0,   # report is in Celsius
        dT_dzv=s.get('outlet_total_temp_dzv', float('nan')) - 25.0,
        m_svz=s.get('inlet_mass_flow_rate_svz'), m_dzv=s.get('inlet_mass_flow_rate_dzv'),
        m_out_svz=abs(s.get('outlet_mass_flow_rate_svz', 0) or 0), m_out_dzv=abs(s.get('outlet_mass_flow_rate_dzv', 0) or 0),
        yplus_svz=s.get('yp_svz'), yplus_dzv=s.get('yp_dzv'),
        Q_svz_W=q_svz, Q_dzv_W=q_dzv, imb_svz_W=imb_svz, imb_dzv_W=imb_dzv, net_W=s.get('net'))
    if out['m_svz']:
        out['mass_imb_svz'] = abs(out['m_svz'] - out['m_out_svz']) / out['m_svz']
        out['mass_imb_dzv'] = abs(out['m_dzv'] - out['m_out_dzv']) / out['m_dzv'] if out['m_dzv'] else None
        out['mdot_ratio_dzv_svz'] = out['m_dzv'] / out['m_svz']
    return out


def averaged(samples, k=3):
    """Mean and scatter of the last k reports (quasi-steady / slowly oscillating solutions)."""
    ms = [metrics_from_sample(s) for s in samples[-k:]]
    out = {}
    for key in ('dT_svz', 'dT_dzv', 'm_svz', 'm_dzv', 'Q_svz_W', 'Q_dzv_W', 'imb_svz_W', 'imb_dzv_W',
                'mass_imb_svz', 'mass_imb_dzv', 'yplus_svz', 'yplus_dzv', 'mdot_ratio_dzv_svz'):
        v = [m[key] for m in ms if m.get(key) is not None]
        if v:
            out[key] = sum(v) / len(v)
            out[key + '_sd'] = (sum((x - out[key]) ** 2 for x in v) / len(v)) ** 0.5
    return out


def tier(samples, res):
    """'strict' (project criteria for the report window) / 'engineering' (usable as dataset label) / 'none'."""
    if len(samples) < 3:
        return 'none'
    a = averaged(samples)
    c = [r['continuity'] for r in res[-300:]] or [1.0]
    ms = [metrics_from_sample(s) for s in samples[-3:]]
    drift = max(abs(ms[-1]['dT_svz'] - ms[0]['dT_svz']), abs(ms[-1]['dT_dzv'] - ms[0]['dT_dzv']))
    q = max(a.get('Q_svz_W', 0), a.get('Q_dzv_W', 0), 1e-9)
    strict = (a['dT_svz_sd'] < 0.01 and a['dT_dzv_sd'] < 0.01 and abs(a['imb_svz_W']) < 0.1 and abs(a['imb_dzv_W']) < 0.1
              and a['mass_imb_svz'] < 1e-3 and max(c) < 1e-4 and a['yplus_svz'] < 1 and a['yplus_dzv'] < 1)
    eng = (drift < 0.12 and a['dT_svz_sd'] < 0.08 and a['dT_dzv_sd'] < 0.08 and abs(a['imb_svz_W']) < 0.04 * q and abs(a['imb_dzv_W']) < 0.04 * q
           and a['mass_imb_svz'] < 0.05 and a['mass_imb_dzv'] < 0.05 and max(c) < 5e-3
           and a['yplus_svz'] < 1 and a['yplus_dzv'] < 1)
    if strict:
        return 'strict'
    if eng:
        return 'engineering'
    # slowly oscillating / unsteady solution (shock moving): usable only as an averaged label with scatter
    a5 = averaged(samples, k=min(5, len(samples)))
    if (a5['mass_imb_svz'] < 0.10 and a5['mass_imb_dzv'] < 0.10 and max(c) < 2e-2
            and abs(a5['imb_svz_W']) < 0.25 * q and abs(a5['imb_dzv_W']) < 0.25 * q
            and a5['yplus_svz'] < 1 and a5['yplus_dzv'] < 1):
        return 'unsteady'
    return 'none'


def quality(samples, res, win=3, tol=None):
    tol = tol or dict(dT=0.02, imb_abs=0.5, imb_rel=0.02, mass=5e-3, cont=1e-3, yplus=1.0)
    if len(samples) < win:
        return dict(converged=0, why='too few samples')
    ms = [metrics_from_sample(s) for s in samples[-win:]]
    why = []
    for k in ('dT_svz', 'dT_dzv'):
        v = [m[k] for m in ms]
        if max(v) - min(v) > tol['dT']:
            why.append(f'{k} range {max(v)-min(v):.3f}')
    last = ms[-1]
    for k, q in (('imb_svz_W', 'Q_svz_W'), ('imb_dzv_W', 'Q_dzv_W')):
        lim = max(tol['imb_abs'], tol['imb_rel'] * (last[q] or 0))
        if abs(last[k]) > lim:
            why.append(f'{k}={last[k]:.2f}W>{lim:.2f}')
    for k in ('mass_imb_svz', 'mass_imb_dzv'):
        if last.get(k) is not None and last[k] > tol['mass']:
            why.append(f'{k}={last[k]:.4f}')
    c = [r['continuity'] for r in res[-win * 100:]]
    if c and max(c) > tol['cont']:
        why.append(f'continuity {max(c):.1e}')
    for k in ('yplus_svz', 'yplus_dzv'):
        if last.get(k) is not None and last[k] > tol['yplus']:
            why.append(f'{k}={last[k]:.2f}')
    return dict(converged=int(not why), why='; '.join(why))

# ---------------------------------------------------------------- runner
def run_fluent(journal_path, threads=6, gui=False, timeout=7200):   # 27.10: 6 processes on the new PC (was 7)
    args = [FLUENT, '2ddp', f'-t{threads}'] + ([] if gui else ['-g']) + ['-i', str(journal_path)]
    p = subprocess.Popen(args, cwd=str(Path(journal_path).parent),
                         creationflags=0x08000000 if not gui else 0)
    t0 = time.time()
    while p.poll() is None and time.time() - t0 < timeout:
        time.sleep(5)
    if p.poll() is None:
        p.kill()
        return False
    return True


def run_case(spec, base_case, workdir, max_stages=6, iters=300, threads=6, gui=False):
    """Warm-start from base_case (cas.h5 with .dat.h5), iterate in stages until converged."""
    wd = Path(workdir); wd.mkdir(parents=True, exist_ok=True)
    (wd / 'spec.json').write_text(json.dumps(spec, indent=1))
    case_in = Path(base_case)
    all_samples, all_res = [], []
    ramp = spec.get('ramp_steps', 1)
    for st in range(1, max_stages + 1):
        case_out = wd / f'stage{st}.cas.h5'
        trn = wd / f'stage{st}.trn'
        if trn.exists():
            trn.unlink()
        jou = wd / f'stage{st}.jou'
        cfl = spec.get('cfl', [5, 10, 20, 20, 20, 20])[min(st - 1, 5)]
        cold = bool(spec.get('cold_start')) and st == 1
        if cold:                      # first-order, small CFL, pressure ramp from spec['_current']
            cfl = 2
        use_simple = spec.get('simple_first', True) and st == 1      # SIMPLE start-up stage, then coupled
        jou.write_text(stage_journal(spec, case_in, case_out, trn, iters, cfl,
                                     ramp_steps=ramp if st == 1 else 1, first_order=cold, simple=use_simple))
        ok = run_fluent(jou, threads=threads, gui=gui)
        if not trn.exists():
            return dict(status='no_transcript', stages=st)
        samples, res = parse_trn(trn)
        if any('floating point exception' in l for l in trn.read_text(errors='replace').splitlines()):
            if st == 1 and not spec.get('_robust_tried'):
                # robust restart: first-order, very small CFL, then retry the normal stage
                spec['_robust_tried'] = True
                c0 = wd / 'stage0.cas.h5'; t0 = wd / 'stage0.trn'
                if t0.exists():
                    t0.unlink()
                j0 = wd / 'stage0.jou'
                j0.write_text(stage_journal(spec, case_in, c0, t0, 300, 1, report_every=100, first_order=True))
                run_fluent(j0, threads=threads, gui=gui)
                if t0.exists() and c0.exists() and not any('floating point exception' in l for l in t0.read_text(errors='replace').splitlines()):
                    case_in = c0
                    trn.unlink()
                    jou.write_text(stage_journal(spec, case_in, case_out, trn, iters, 3, ramp_steps=1))
                    run_fluent(jou, threads=threads, gui=gui)
                    samples, res = parse_trn(trn)
                    if not any('floating point exception' in l for l in trn.read_text(errors='replace').splitlines()):
                        all_samples += samples; all_res += res; case_in = case_out
                        q = quality(all_samples, all_res); q['tier'] = tier(all_samples, all_res)
                        if q['tier'] in ('strict', 'engineering'):
                            q['converged'] = 1
                            break
                        continue
            return dict(status='diverged', stages=st, **(metrics_from_sample(samples[-1]) if samples else {}))
        all_samples += samples; all_res += res
        case_in = case_out
        q = quality(all_samples, all_res)
        q['tier'] = tier(all_samples, all_res)
        if q['tier'] in ('strict', 'engineering'):
            q['converged'] = 1
            break
    final = metrics_from_sample(all_samples[-1]) if all_samples else {}
    avg = averaged(all_samples) if len(all_samples) >= 3 else {}
    final.update({k + '_avg': v for k, v in avg.items() if not k.endswith('_sd')})
    final.update({k: v for k, v in avg.items() if k.endswith('_sd') and k.startswith('dT')})
    return dict(status='ok' if all_samples else 'no_samples', stages=st,
                iterations=sum(1 for _ in all_res), final_case=str(case_in), **final, **q)


FIELDS = ['case_id', 'time', 'status', 'converged', 'tier', 'why', 'iterations',
          'p0_svz_MPa', 'p_out_svz_MPa', 'p0_dzv_MPa', 'p_out_dzv_MPa', 'pi_svz',
          'geom_r_end_mm', 'geom_l_heat_mm', 'geom_gap_mm', 'geom_r_throat_mm',
          'dT_svz_avg', 'dT_dzv_avg', 'dT_svz_sd', 'dT_dzv_sd', 'dT_svz', 'dT_dzv', 'm_svz', 'm_dzv', 'mdot_ratio_dzv_svz', 'Q_svz_W', 'Q_dzv_W',
          'imb_svz_W', 'imb_dzv_W', 'mass_imb_svz', 'mass_imb_dzv', 'yplus_svz', 'yplus_dzv', 'final_case']


def append_row(spec, result, csv_path=DS / 'dataset.csv'):
    row = {k: '' for k in FIELDS}
    row.update(case_id=spec['case_id'], time=time.strftime('%Y-%m-%d %H:%M:%S'))
    row.update({k: spec.get(k, '') for k in FIELDS if k in spec})
    row.update({k: result.get(k, '') for k in FIELDS if k in result})
    new = not Path(csv_path).exists()
    with open(csv_path, 'a', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        if new:
            w.writeheader()
        w.writerow(row)


# ---------------------------------------------------------------- geometry rules
def exit_geometry(r_end_mm, neck_ratio=0.8):
    """Smooth exit diffuser scaled from r_end (rules used for G4; angle ~4.6 deg).
    neck_ratio = r_neck/r_end; the neck acts as a second throat (0.8 chokes at G4 flow)."""
    neck = neck_ratio * r_end_mm
    rround = 0.658 * r_end_mm
    lround = 0.342 * r_end_mm
    assert rround > lround / 2
    return {'P33': 0.75 * r_end_mm, 'P23': neck, 'P30': lround, 'P20': rround,
            'P19': max(12.0, (r_end_mm - neck) / math.tan(math.radians(4.6))),
            'P27': r_end_mm, 'P21': 0.625 * r_end_mm}


def geometry_params(d):
    """Design vars -> Workbench parameter expressions (mm).  d: r_end, l_heat, gap (mm)."""
    r_end, l_heat, gap = d['r_end_mm'], d['l_heat_mm'], d['gap_mm']
    p = {'P35': r_end, 'P32': l_heat, 'P34': 14.492992126556777 - r_end, 'P28': gap, 'P29': gap}
    p.update(exit_geometry(r_end, d.get('neck_ratio', 0.8)))
    if d.get('r_nozzle_exit_mm'):
        p['P26'] = d['r_nozzle_exit_mm']
    # 08.10: Workbench keeps the last value of a parameter -> nozzle inlet, throat and nozzle length are always sent
    # (project defaults from geometry_defaults.json unless overridden below)
    p.update({'P37': 7.5, 'P22': 2.25, 'P18': 18.91, 'P38': 11.192992126555975})   # P38: wall thickness at the inlet (rig OD 29)
    # stage A4 (07.10.2026): exit chamber = abrupt widening after the neck (outlet radius, widening length, tail)
    # 08.10: nozzle inlet radius P37 (author's request), throat P22, nozzle length P18, rounding radius P20 (A5)
    for key, name in (('r_outlet_mm', 'P27'), ('l_exit_recovery_mm', 'P19'), ('l_exit_tail_mm', 'P21'), ('r_inlet_mm', 'P37'),
                      ('r_throat_mm', 'P22'), ('l_nozzle_mm', 'P18'), ('r_exit_rounding_mm', 'P20'),
                      ('wall_thickness_inlet_mm', 'P38'), ('wall_thickness_end_mm', 'P34')):   # 09.10: P34 for the unit cell
        if d.get(key):
            p[name] = d[key]
    return {k: f'{v:.6f} [mm]' for k, v in p.items()}


def cell_geometry(t_over_d, s_min_mm, r_end_mm, r_nozzle_exit_mm):
    """09.10.2026 (author's decision): unit cell of the RU 2162190 tube bundle.  Thin tube with a CYLINDRICAL outer
    surface: outer radius r_o = r_end + s_min (s_min = wall at the channel end, the thinnest place); the wall is thicker at
    the nozzle exit (conical channel inside).  Triangular pitch t = (t/d)*2*r_o; hexagonal cell area sqrt(3)/2*t^2 ->
    equal-area circle R_eq = t*sqrt(sqrt(3)/(2*pi)) = 0.5250*t; DZV annulus gap = R_eq - r_o (same at both ends).
    The outer cell boundary is a symmetry boundary (set in Fluent: SYMMETRY_DZV_LINE), not a wall."""
    r_o = r_end_mm + s_min_mm
    t = t_over_d * 2.0 * r_o
    r_eq = t * math.sqrt(math.sqrt(3.0) / (2.0 * math.pi))
    return dict(wall_thickness_end_mm=s_min_mm, wall_thickness_inlet_mm=r_o - r_nozzle_exit_mm, gap_mm=r_eq - r_o,
                cell_r_outer_mm=r_o, cell_pitch_mm=t, cell_r_eq_mm=r_eq)


SYMMETRY_DZV_LINE = '/define/boundary-conditions/zone-type wall_outer-air_dzv symmetry'
