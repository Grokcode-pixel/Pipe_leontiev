import json,traceback,time
FIRST_LAYER_HEIGHT_M=float(json.load(open(r'F:\Leontiev_Project\mesh_run_config.json'))['first_layer_height_um'])*1e-6
r={'started':time.time(),'run_token':globals().get('MESH_RUN_TOKEN')}
r['first_layer_height_um']=FIRST_LAYER_HEIGHT_M*1e6
try:
    model=ExtAPI.DataModel.Project.Model
    mesh=model.Mesh
    mesh.GenerateMesh()
    r['generated']=True
    for key in ('Nodes','Elements','Tri3','Quad4','Minimum','Maximum','Average','MeshMetric','State','ObjectState'):
        try:r[key]=str(getattr(mesh,key))
        except:pass
    r['controls']=[]
    for o in mesh.Children:
        d={'name':str(o.Name),'type':str(o.GetType())}
        for k in ('ScopingMethod','NamedSelection','BoundaryNamedSelection','FirstLayerHeight','MaximumLayers','NumberOfLayers','GrowthRate','ElementSize','State','ObjectState','InflationOption'):
            try:d[k]=str(getattr(o,k))
            except:pass
        try:d['location_ids']=list(o.Location.Ids)
        except:pass
        try:d['boundary_ids']=list(o.BoundaryLocation.Ids)
        except:pass
        r['controls'].append(d)
    r['contacts']=[]
    for o in model.Connections.GetChildren(DataModelObjectCategory.ContactRegion,True):
        d={'name':str(o.Name)}
        for k in ('SourceLocation','TargetLocation','SourceNamedSelection','TargetNamedSelection','Suppressed','State'):
            try:
                v=getattr(o,k)
                d[k]=list(v.Ids) if hasattr(v,'Ids') else str(v)
            except:pass
        r['contacts'].append(d)
    r['messages']=[{'text':str(getattr(m,'DisplayString',m)),'severity':str(getattr(m,'Severity',''))} for m in ExtAPI.Application.Messages]
    if str(mesh.State)!='UpToDate' or str(mesh.ObjectState)!='Solved':
        r['generated']=False
        r['error']='Meshing did not produce a complete up-to-date mesh: '+str(mesh.State)+' / '+str(mesh.ObjectState)
    if any(x['severity']=='Error' for x in r['messages']):
        r['generated']=False
        r['error']='Meshing reported errors; inspect messages'
except:r['error']=traceback.format_exc()
r['seconds']=time.time()-r['started']
with open(globals().get('MESH_RESULT_PATH',r'F:\Leontiev_Project\mesh_baseline_generated.json'),'w') as f:json.dump(r,f,indent=2)
