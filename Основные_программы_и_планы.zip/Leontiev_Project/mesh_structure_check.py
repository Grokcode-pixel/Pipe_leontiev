import json,traceback
r={'sections':[],'passed':False}
try:
    model=ExtAPI.DataModel.Project.Model
    md=ExtAPI.DataModel.MeshDataByName('Global')
    names={str(n.Name):n for n in model.NamedSelections.Children if list(n.Location.Ids)}
    with open(r'F:\Leontiev_Project\nozzle_setup.json') as f:settings=json.load(f)
    counts={c['name']:c['count'] for c in settings['controls']}
    for section in ('convergent','nozzle','heat','exit_contraction','exit_rounding','exit_recovery','exit_tail'):
        prefix='Nozzle_' if section=='nozzle' else 'Nozzle_'+section+'_'
        axial=counts[prefix+'axial'];radial=counts[prefix+('core_radial' if section=='nozzle' else 'radial')]
        item={'section':section,'faces':[]}
        for fid in names['MESH_'+section].Location.Ids:
            eids=list(md.MeshRegionById(fid).ElementIds)
            incidence={};allquad=True
            for eid in eids:
                e=md.ElementById(eid)
                allquad=allquad and str(e.Type)=='kQuad4'
                for nid in e.NodeIds:incidence[nid]=incidence.get(nid,0)+1
            rows=1 if len(eids)==axial else radial
            frequencies={}
            for v in incidence.values():frequencies[v]=frequencies.get(v,0)+1
            expected={1:4,2:2*(axial+rows-2)}
            if (axial-1)*(rows-1):expected[4]=(axial-1)*(rows-1)
            expected={k:v for k,v in expected.items() if v}
            valid=allquad and len(eids)==axial*rows and len(incidence)==(axial+1)*(rows+1) and frequencies==expected
            item['faces'].append({'id':fid,'elements':len(eids),'nodes':len(incidence),'rows':rows,'incidence':frequencies,'verified':valid})
        item['verified']=len(item['faces'])==21 and all(f['verified'] for f in item['faces']) and sum(f['rows']==1 for f in item['faces'])==20
        r['sections'].append(item)
    r['passed']=len(r['sections'])==7 and all(s['verified'] for s in r['sections'])
except:r['error']=traceback.format_exc()
with open(globals().get('MESH_STRUCTURE_PATH',r'F:\Leontiev_Project\mesh_structure_check.json'),'w') as f:json.dump(r,f,indent=2)
