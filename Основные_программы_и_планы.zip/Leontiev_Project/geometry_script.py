# Python Script, API Version = V242
# Native SpaceClaim geometry. Input lengths are millimetres; API lengths are metres.
import json, math
from System import Array
from System.Collections.Generic import List
from SpaceClaim.Api.V242 import DesignBody, Group, IDocObject
from SpaceClaim.Api.V242.Scripting.Extensions import PartExtensions
from SpaceClaim.Api.V242.Geometry import Point, Plane, CurveSegment, NurbsCurve, NurbsData, Knot, ControlPoint, Circle, Frame, Direction, Interval, ITrimmedCurve
from SpaceClaim.Api.V242.Modeler import Body

ROOT = r'F:\Leontiev_Project'

def build_geometry(values, clear_existing=True, first_layer_height_m=1e-6):
    if not 8e-8 <= first_layer_height_m <= 1e-6:
        raise ValueError("First layer height must be 0.08 to 1 um for this CAD partition")
    reference = {'air_svz': {'edges': [{'bounds': [-1.4650835884880085e-19, 0.6941458124179959], 'start': [0.0058865230400438895, 0.003300000000000762, 0.0], 'end': [0.7000000000000001, 0.00999999999999996, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}, {'bounds': [7.693953267888526e-19, 0.018939128807841165], 'start': [-0.013023476959956093, 0.0022500000000007653, 0.0], 'end': [0.0058865230400438825, 0.0033000000000007615, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}, {'end': [-0.013023476959956093, 0.0022500000000007653, 0.0], 'bounds': [0.0, 1.0], 'knots': [{'parameter': 0.0, 'multiplicity': 4}, {'parameter': 0.09545819220464981, 'multiplicity': 1}, {'parameter': 0.23118113258791523, 'multiplicity': 1}, {'parameter': 0.3932641938680286, 'multiplicity': 1}, {'parameter': 0.5550225199088384, 'multiplicity': 1}, {'parameter': 0.6690315157673081, 'multiplicity': 1}, {'parameter': 0.7788528495041074, 'multiplicity': 1}, {'parameter': 1.0, 'multiplicity': 4}], 'type': 'SpaceClaim.Api.V242.Geometry.NurbsCurve', 'control_points': [{'position': [-0.021042031905249392, 0.007500000000000765, 0.0], 'weight': 1.0}, {'position': [-0.02086864181317477, 0.007240789723417757, 0.0], 'weight': 1.0}, {'position': [-0.02044872481140092, 0.006613032964831589, 0.0], 'weight': 1.0}, {'position': [-0.01960250585208073, 0.005636211790021948, 0.0], 'weight': 1.0}, {'position': [-0.018409023016530024, 0.0047161811207806085, 0.0], 'weight': 1.0}, {'position': [-0.017214892666954806, 0.003925790369305151, 0.0], 'weight': 1.0}, {'position': [-0.01608447779357658, 0.0033638214129686293, 0.0], 'weight': 1.0}, {'position': [-0.014726872024171944, 0.0028424716941135176, 0.0], 'weight': 1.0}, {'position': [-0.01370576331615625, 0.002487311567833687, 0.0], 'weight': 1.0}, {'position': [-0.013023476959956093, 0.0022500000000007653, 0.0], 'weight': 1.0}], 'start': [-0.021042031905249392, 0.007500000000000765, 0.0], 'degree': 3}, {'end': [-0.02302347695993534, 7.615436059538183e-16, 0.0], 'bounds': [0.0, 1.0], 'knots': [{'parameter': 0.0, 'multiplicity': 4}, {'parameter': 0.10991731789157141, 'multiplicity': 1}, {'parameter': 0.2987342451066493, 'multiplicity': 1}, {'parameter': 0.5192384154327128, 'multiplicity': 1}, {'parameter': 0.7790171799621977, 'multiplicity': 1}, {'parameter': 1.0, 'multiplicity': 4}], 'type': 'SpaceClaim.Api.V242.Geometry.NurbsCurve', 'control_points': [{'position': [-0.021042031905249392, 0.007500000000000765, 0.0], 'weight': 1.0}, {'position': [-0.021173338284668275, 0.007244481633865259, 0.0], 'weight': 1.0}, {'position': [-0.021530203907718426, 0.006550031590118075, 0.0], 'weight': 1.0}, {'position': [-0.02210771492954644, 0.005317967920463714, 0.0], 'weight': 1.0}, {'position': [-0.022607829967324466, 0.003638749115850392, 0.0], 'weight': 1.0}, {'position': [-0.023000299792499013, 0.0018384944660802685, 0.0], 'weight': 1.0}, {'position': [-0.023016178354079764, 0.0005789510954024787, 0.0], 'weight': 1.0}, {'position': [-0.02302347695993534, 7.615436059538183e-16, 0.0], 'weight': 1.0}], 'start': [-0.021042031905249392, 0.007500000000000765, 0.0], 'degree': 3}, {'bounds': [2.4616718688963547e-34, 0.7480234769599353], 'start': [-0.02302347695993534, 7.615436059538183e-16, 0.0], 'end': [0.725, 7.733379183295475e-16, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}, {'bounds': [1.214306433183765e-17, 0.009999999999999181], 'start': [0.725, 0.00999999999999996, 0.0], 'end': [0.725, 7.91033905045424e-16, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}, {'bounds': [3.6111186457257436e-33, 0.0050000000000004485], 'start': [0.7199999999999995, 0.009999999999999969, 0.0], 'end': [0.725, 0.009999999999999972, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}, {'bounds': [2.9718642651935347e-18, 0.00933944929474123], 'start': [0.710877209137054, 0.008000000000000004, 0.0], 'end': [0.7199999999999995, 0.009999999999999967, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}, {'end': [0.710877209137054, 0.008, 0.0], 'bounds': [-3.8965729543377824e-17, 0.5235987755983147], 'type': 'SpaceClaim.Api.V242.Geometry.Circle', 'dirY': [0.965925826289064, -0.2588190451025368, 0.0], 'origin': [0.7091706553760958, 0.014368945341743721, 0.0], 'dirX': [-0.2588190451025368, -0.965925826289064, 0.0], 'radius': 0.0065936174066410285, 'start': [0.7074641016151375, 0.008000000000000031, 0.0]}, {'bounds': [-8.979589471384815e-19, 0.0077274066103123346], 'start': [0.7, 0.00999999999999996, 0.0], 'end': [0.7074641016151375, 0.008000000000000024, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}]}, 'wall_abonite': {'edges': [{'bounds': [0.0, 0.694115991927624], 'start': [0.00588400807237599, 0.014492992126556737, 0.0], 'end': [0.7, 0.014492992126556737, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}, {'bounds': [0.0, 0.004492992126556777], 'start': [0.7, 0.014492992126556737, 0.0], 'end': [0.7, 0.00999999999999996, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}, {'bounds': [4.185953109965739e-21, 0.6941458124179959], 'start': [0.0058865230400438895, 0.003300000000000762, 0.0], 'end': [0.7000000000000001, 0.00999999999999996, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}, {'bounds': [4.336808580467593e-19, 0.011192992409101613], 'start': [0.0058865230400438895, 0.0033000000000007624, 0.0], 'end': [0.00588400807237599, 0.014492992126556732, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}]}, 'air_dzv': {'edges': [{'bounds': [0.0, 0.0030067789836028883], 'start': [0.00588400807237599, 0.014492992126556737, 0.0], 'end': [0.005884008072375991, 0.017499771110159625, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}, {'bounds': [0.0, 0.694115991927624], 'start': [0.00588400807237599, 0.014492992126556737, 0.0], 'end': [0.7, 0.014492992126556737, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}, {'bounds': [0.0, 0.0030067789836031034], 'start': [0.7, 0.01749977111015984, 0.0], 'end': [0.7, 0.014492992126556737, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}, {'bounds': [0.0, 0.694115991927624], 'start': [0.005884008072375991, 0.017499771110159625, 0.0], 'end': [0.7, 0.01749977111015984, 0.0], 'type': 'SpaceClaim.Api.V242.Geometry.Line'}]}}
    p = dict((k, float(v)/1000.0) for k,v in values.items())
    def v(name): return p[name + '_mm']
    for name, value in p.items():
        if math.isnan(value) or math.isinf(value):
            raise ValueError('Non-finite parameter: '+name)
        if name not in ('x_origin_mm','secondary_inlet_offset_mm') and value <= 0:
            raise ValueError('Parameter must be positive: '+name)
    if not 0 < v('inlet_curve_offset') < v('l_convergent'):
        raise ValueError('Inlet curve offset must be inside convergent length')
    if not v('r_throat') < min(v('r_inlet'),v('r_nozzle_exit')):
        raise ValueError('Throat radius must be smaller than inlet and nozzle exit')
    if v('r_exit_rounding') <= v('l_exit_rounding')/2:
        raise ValueError('Rounding radius must exceed half its chord length')
    x0=v('x_origin'); xt=x0+v('l_convergent'); xn=xt+v('l_nozzle'); xh=xn+v('l_heat_exchange')
    xi=xn+v('secondary_inlet_offset')
    if xi >= xh: raise ValueError('Secondary inlet is beyond heat exchange end')
    ri=v('r_inlet'); rt=v('r_throat'); rn=v('r_nozzle_exit'); rh=v('r_heat_exchange_end')
    rw0=rn+v('wall_thickness_inlet'); rw1=rh+v('wall_thickness_end')
    ro0=rw0+v('gap_secondary_inlet'); ro1=rw1+v('gap_secondary_end')
    xa=xh+v('l_exit_contraction'); xb=xa+v('l_exit_rounding'); xc=xb+v('l_exit_recovery'); xo=xc+v('l_exit_tail')
    rneck=v('r_exit_neck'); rout=v('r_outlet'); rad=v('r_exit_rounding'); half=v('l_exit_rounding')/2
    cy=rneck+math.sqrt(rad*rad-half*half)
    if cy-rad <= 0: raise ValueError('Rounded neck crosses the axis')
    def pt(x,y): return Point.Create(x,y,0)
    def line(a,b): return CurveSegment.Create(pt(*a),pt(*b))
    def spline(info, transform):
        knots=Array[Knot]([Knot(k['parameter'], k['multiplicity']) for k in info['knots']])
        cps=Array[ControlPoint]([ControlPoint(pt(*transform(cp['position'][0],cp['position'][1])),cp['weight']) for cp in info['control_points']])
        curve=NurbsCurve.CreateFromControlPoints(NurbsData(info['degree']+1,False,False,knots),cps)
        return CurveSegment.Create(curve,Interval.Create(*info['bounds']))
    svz=reference['air_svz']['edges']; refx=svz[4]['start'][0]; reft=svz[1]['start']; refin=svz[2]['start']; refri=refin[1]
    inlet=spline(svz[3], lambda x,y:(x0+(x-refx)/(refin[0]-refx)*v('inlet_curve_offset'), y/refri*ri))
    contraction=spline(svz[2], lambda x,y:(x0+v('inlet_curve_offset')+(x-refin[0])/(reft[0]-refin[0])*(v('l_convergent')-v('inlet_curve_offset')),rt+(y-reft[1])/(refri-reft[1])*(ri-rt)))
    frame=Frame.Create(pt((xa+xb)/2,cy),Direction.Create(0,-1,0),Direction.Create(1,0,0))
    arc=CurveSegment.Create(Circle.Create(frame,rad),Interval.Create(-math.asin(half/rad),math.asin(half/rad)))
    core=[line((xn,rn),(xh,rh)),line((xt,rt),(xn,rn)),contraction,inlet,line((x0,0),(xo,0)),line((xo,rout),(xo,0)),line((xc,rout),(xo,rout)),line((xb,rneck),(xc,rout)),arc,line((xh,rh),(xa,rneck))]
    wall=[line((xi,rw0),(xh,rw1)),line((xh,rw1),(xh,rh)),core[0],line((xn,rn),(xi,rw0))]
    secondary=[line((xi,rw0),(xi,ro0)),wall[0],line((xh,ro1),(xh,rw1)),line((xi,ro0),(xh,ro1))]
    loops=[('air_svz',core),('wall_abonite',wall),('air_dzv',secondary)]
    # Validate all sheets before replacing any existing bodies.
    shapes=[]
    for name,curves in loops:
        collection=List[ITrimmedCurve]()
        for c in curves: collection.Add(c)
        shape=Body.CreatePlanarBody(Plane.PlaneXY,collection)
        if name == 'air_svz':
            cuts=List[ITrimmedCurve]()
            for x,y in ((xt,rt),(xn,rn),(xh,rh)):
                cuts.Add(line((x,0),(x,y)))
            slope=(rn-rt)/(xn-xt)
            normal_factor=math.sqrt(1+slope*slope)
            total=0.0
            for layer in range(20):
                total+=first_layer_height_m*(1.2**layer)
                h=total*normal_factor
                if h>=rt: raise ValueError('Nozzle boundary layers exceed throat radius')
                cuts.Add(line((xt,rt-h),(xn,rn-h)))
            heat_normal_factor=math.sqrt(1+((rh-rn)/(xh-xn))**2)
            total=0.0
            for layer in range(20):
                total+=first_layer_height_m*(1.2**layer)
                if total*max(normal_factor,heat_normal_factor)>=min(rn,rh):
                    raise ValueError('Heat boundary layers exceed local channel radius')
                # Match the same layer endpoints at the nozzle/heat interface.
                cuts.Add(line((xn,rn-total*normal_factor),(xh,rh-total*heat_normal_factor)))
            xstart=x0+v('inlet_curve_offset')
            for x,y in ((xstart,ri),(xa,rneck),(xb,rneck),(xc,rout)):
                cuts.Add(line((x,0),(x,y)))
            total=0.0
            for layer in range(20):
                total+=first_layer_height_m*(1.2**layer)
                def transform_contraction(x,y):
                    xx=xstart+(x-refin[0])/(reft[0]-refin[0])*(v('l_convergent')-v('inlet_curve_offset'))
                    yy=rt+(y-reft[1])/(refri-reft[1])*(ri-rt)
                    factor=1+(normal_factor-1)*(xx-xstart)/(xt-xstart)
                    return (xx,yy-total*factor)
                cuts.Add(spline(svz[2],transform_contraction))
                cuts.Add(line((xh,rh-total*heat_normal_factor),(xa,rneck-total)))
                lower_frame=Frame.Create(pt((xa+xb)/2,cy-total),Direction.Create(0,-1,0),Direction.Create(1,0,0))
                cuts.Add(CurveSegment.Create(Circle.Create(lower_frame,rad),Interval.Create(-math.asin(half/rad),math.asin(half/rad))))
                cuts.Add(line((xb,rneck-total),(xc,rout-total)))
                cuts.Add(line((xc,rout-total),(xo,rout-total)))
            shape.ImprintCurves(cuts,None)
        shapes.append((name,shape))
    root=GetRootPart()
    if clear_existing:
        for g in list(root.Groups):
            # Preserve native script parameters and the published rebuilding script.
            if not g.HasDimension and g.Name != 'TubeGeometry' and not g.Name.startswith('GEO_'): g.Delete()
        for body in list(PartExtensions.GetAllBodies(root)): body.Delete()
    created={}
    for name,shape in shapes:
        created[name]=DesignBody.Create(root,name,shape)
    def group(name,items):
        collection=List[IDocObject]()
        for item in items: collection.Add(item)
        return Group.Create(root,name,collection)
    for name,body in created.items(): group(name,list(body.Faces))
    def match_edge(body,curve):
        a=curve.StartPoint; b=curve.EndPoint
        def distance(c,d): return math.sqrt((c.X-d.X)**2+(c.Y-d.Y)**2+(c.Z-d.Z)**2)
        hits=[]
        for e in body.Edges:
            q=e.Shape
            if min(distance(q.StartPoint,a)+distance(q.EndPoint,b),distance(q.StartPoint,b)+distance(q.EndPoint,a)) < 1e-7:
                hits.append(e)
        if len(hits)!=1: raise ValueError('Ambiguous edge match for '+body.Name)
        return hits[0]
    s=created['air_svz']; d=created['air_dzv']; w=created['wall_abonite']
    sections=[('convergent',x0+v('inlet_curve_offset'),xt),('nozzle',xt,xn),('heat',xn,xh),('exit_contraction',xh,xa),('exit_rounding',xa,xb),('exit_recovery',xb,xc),('exit_tail',xc,xo)]
    all_structured=[]
    for section,lo,hi in sections:
        faces=[]
        for face in s.Faces:
            xs=[q.X for e in face.Edges for q in (e.Shape.StartPoint,e.Shape.EndPoint)]
            if abs(min(xs)-lo)<1e-8 and abs(max(xs)-hi)<1e-8:faces.append(face)
        if len(faces)!=21 or any(f.Edges.Count!=4 for f in faces):raise ValueError('Expected 21 four-sided strips in '+section+'; found '+str(len(faces)))
        group('MESH_'+section,faces)
        all_structured+=faces
        axial=[];thin=[];bulk=[]
        for e in s.Edges:
            a=e.Shape.StartPoint;b=e.Shape.EndPoint
            if min(a.X,b.X)>=lo-1e-8 and max(a.X,b.X)<=hi+1e-8:
                if abs(a.X-b.X)>1e-8:axial.append(e)
                elif abs(a.Y-b.Y)<0.0002:thin.append(e)
                else:bulk.append(e)
        if (len(axial),len(thin),len(bulk))!=(22,40,2):raise ValueError('Bad partition in '+section+': '+str((len(axial),len(thin),len(bulk))))
        group('MESH_'+section+'_axial_edges',axial)
        group('MESH_'+section+'_layer_edges',thin)
        group('MESH_'+section+'_core_radial_edges',bulk)
    group('MESH_core_structured',all_structured)
    group('MESH_inflation_svz',[f for f in s.Faces if f not in all_structured])
    group('inlet_svz',[match_edge(s,core[3])]); group('axis',[e for e in s.Edges if abs(e.Shape.StartPoint.Y)<1e-9 and abs(e.Shape.EndPoint.Y)<1e-9]); group('outlet_svz',[e for e in s.Edges if abs(e.Shape.StartPoint.X-xo)<1e-9 and abs(e.Shape.EndPoint.X-xo)<1e-9])
    group('wall_outer-air_svz',[match_edge(s,core[i]) for i in (1,2,6,7,8,9)])
    group('wall-air_svz-wall_abonite',[match_edge(s,core[0]),match_edge(w,wall[2])])
    group('interior-air_dzv-wall_abonite',[match_edge(d,secondary[1]),match_edge(w,wall[0])])
    group('wall-wall_abonite',[match_edge(w,wall[i]) for i in (1,3)])
    group('inlet_dzv',[match_edge(d,secondary[0])]); group('outlet_dzv',[match_edge(d,secondary[2])]); group('wall_outer-air_dzv',[match_edge(d,secondary[3])])
    return {'bodies':[(b.Name,b.Faces.Count,b.Edges.Count) for b in created.values()], 'x_nozzle_exit_m':xn,'x_heat_exchange_end_m':xh,'x_outlet_m':xo}

def parameter_mm(obj):
    return float(getattr(obj, "Value", obj)) * 1000.0

values = {}
values['x_origin_mm'] = parameter_mm(Parameters.GEO_x_origin)
values['r_inlet_mm'] = parameter_mm(Parameters.GEO_r_inlet)
values['l_convergent_mm'] = parameter_mm(Parameters.GEO_l_convergent)
values['inlet_curve_offset_mm'] = parameter_mm(Parameters.GEO_inlet_curve_offset)
values['r_throat_mm'] = parameter_mm(Parameters.GEO_r_throat)
values['r_nozzle_exit_mm'] = parameter_mm(Parameters.GEO_r_nozzle_exit)
values['l_nozzle_mm'] = parameter_mm(Parameters.GEO_l_nozzle)
values['l_heat_exchange_mm'] = parameter_mm(Parameters.GEO_l_heat_exchange)
values['r_heat_exchange_end_mm'] = parameter_mm(Parameters.GEO_r_heat_exchange_end)
values['wall_thickness_inlet_mm'] = parameter_mm(Parameters.GEO_wall_thickness_inlet)
values['wall_thickness_end_mm'] = parameter_mm(Parameters.GEO_wall_thickness_end)
values['gap_secondary_inlet_mm'] = parameter_mm(Parameters.GEO_gap_secondary_inlet)
values['gap_secondary_end_mm'] = parameter_mm(Parameters.GEO_gap_secondary_end)
values['secondary_inlet_offset_mm'] = parameter_mm(Parameters.GEO_secondary_inlet_offset)
values['l_exit_contraction_mm'] = parameter_mm(Parameters.GEO_l_exit_contraction)
values['r_exit_neck_mm'] = parameter_mm(Parameters.GEO_r_exit_neck)
values['l_exit_rounding_mm'] = parameter_mm(Parameters.GEO_l_exit_rounding)
values['r_exit_rounding_mm'] = parameter_mm(Parameters.GEO_r_exit_rounding)
values['l_exit_recovery_mm'] = parameter_mm(Parameters.GEO_l_exit_recovery)
values['r_outlet_mm'] = parameter_mm(Parameters.GEO_r_outlet)
values['l_exit_tail_mm'] = parameter_mm(Parameters.GEO_l_exit_tail)
build_geometry(values, first_layer_height_m=float(getattr(Parameters.GEO_first_layer_height, "Value", Parameters.GEO_first_layer_height)))
