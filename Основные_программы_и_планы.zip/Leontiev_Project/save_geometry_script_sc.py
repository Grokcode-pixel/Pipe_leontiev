# Python Script, API Version = V242
import json,traceback,clr
from System.Reflection import BindingFlags
from System import Array,Object
r={'groups':[]}
try:
    for assembly in ('SpaceClaim','Stored Selection','ScriptingContextContracts'):clr.AddReference(assembly)
    from SpaceClaim import NamedScriptGroupProxyDef
    flags=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance
    doc=GetRootPart().Document
    inner=doc.GetType().GetField('innerWrapper',flags).GetValue(doc)
    native=inner.GetType().GetProperty('Subject',flags).GetValue(inner,None)
    context=native.GetType().GetProperty('Context',flags).GetValue(native,None)
    code='#V242\n'+open(r'F:\Leontiev_Project\geometry_script.py').read()
    definitions=[d for d in native.Definitions if d.GetType().FullName=='SpaceClaim.ScriptExecutionProxyDef']
    for d in definitions:
        proxy=d.GetEvaluation(context)
        proxy.Script=code
        sg=proxy.ScriptGroup
        item={'id':str(d.Id),'group_type':str(sg.GetType()),'before_length':len(sg.Code)}
        sg.ScriptEnvironment.SetApi(242)
        sg.Code=code
        sg.GetType().GetProperty('Latest',flags).SetValue(sg,code,None)
        sg.ScriptEnvironment.GetType().GetMethod('UpdateCode',flags).Invoke(sg.ScriptEnvironment,Array[Object]([code]))
        item['save_result']=str(sg.Save(False))
        proxy.Script=sg.Code
        item['after_length']=len(sg.Code);item['contains_grid']='MESH_core_structured' in sg.Code
        r['groups'].append(item)
    if not r['groups'] or not all(g['contains_grid'] for g in r['groups']):raise ValueError('Published geometry code not updated')
    DocumentSave.Execute(r'F:\Leontiev_Project\g_08_1_files\dp6\SYS-1\DM\SYS-1.scdoc')
    r['saved']=True
except:r['error']=traceback.format_exc()
with open(r'F:\Leontiev_Project\script_persistence_live.json','w') as f:json.dump(r,f,indent=2)



