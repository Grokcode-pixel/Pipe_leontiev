# Проверка расчёта на собственных формах W2/W3

2026-11-04T02:28:30.7464249+04:00

| Форма | Статус | Q, Вт | Эффект, K | GСВЗ/GДЗВ | Баланс, %Q |
|---|---|---|---|---|---|
| F05 | принято численно | 1353.4660666666666 | 3.761333333333333 | 0.16312334333333334/0.12665253 | 0.7561548052109764 |
| F06 | принято численно | 1499.2016666666666 | 4.166 | 0.16312348666666668/0.12926647666666669 | -0.21237843501152281 |

D48 save is recognized as numerical convergence for legacy reporting; physical classifier still checks flow separately. Software chain/same-shape repeat checks only. Not grid validation of these other shapes, not arbitrary cold start, not training174. Native curved-interface coverage F05≈96%/F06≈95% is recorded; energy balance does not prove geometrical interface accuracy or physical recommendation. F03 repair remains outstanding.
