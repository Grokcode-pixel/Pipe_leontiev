# Проверка сетки: исправленный отчёт и стороны стыка

2026-11-03T22:57:40.1811767+04:00

Исходные расчёты и автоматический отчёт v8 сохранены. Стороны определены по материалу; энтальпия пересчитана по исправленному Q.

# Исправленная проверка отчёта по сторонам стыка

2026-11-03T22:53:28.7705488+04:00

Только сохранённые данные: CFD, исходные отчёты и настройки не изменялись.

| Сетка | Q, Вт | Эффект, K | GСВЗ, кг/с | GДЗВ, кг/с | Дисбаланс, % Q | Окно | y+ ДЗВ |
|---|---:|---:|---:|---:|---:|---|---|
| W1 | 1233.9695 | 3.4300 | 0.16312343 | 0.14532518 | +0.6437 | [13020, 14020] | 0.41654399 |
| G1 | 1234.5263 | 3.4380 | 0.16280755 | 0.14506153 | +0.1468 | [5000, 6000] | не измерен корректно |
| G2 | 1237.8010 | 3.4513 | 0.16259595 | 0.14604097 | -0.5699 | [3500, 4500] | не измерен корректно |

Положительный Q — тепло из ДЗВ через стенку в СВЗ. Сторона доказана материалом и журналом переименования. Эффект заново вычислен по энтальпии, а не простым удалением минуса.
Старый монитор y+ ДЗВ на новых сетках выбрал твёрдую сторону: служебное −1e20 было скрыто нулём внешней симметрии. Нулевой y+ не является результатом измерения; нужно чтение сохранённого поля без итераций.

{
  "finished": "2026-11-03T22:53:28.7705488+04:00",
  "complete": true,
  "pending": [],
  "comparisons": [
    {
      "pair": [
        "W1",
        "G1"
      ],
      "delta": {
        "effect_K": 0.008000000000000007,
        "Q_pct": 0.04512537249368176,
        "G_svz_pct": 0.1936447795726326,
        "G_dzv_pct": 0.18142531157997466
      },
      "passed": true
    },
    {
      "pair": [
        "W1",
        "G2"
      ],
      "delta": {
        "effect_K": 0.021333333333333204,
        "Q_pct": 0.3105020018728144,
        "G_svz_pct": 0.3233625057900924,
        "G_dzv_pct": 0.49253908848787553
      },
      "passed": true
    },
    {
      "pair": [
        "G1",
        "G2"
      ],
      "delta": {
        "effect_K": 0.013333333333333197,
        "Q_pct": 0.26525693120087457,
        "G_svz_pct": 0.12996940518564815,
        "G_dzv_pct": 0.6751893644761031
      },
      "passed": true
    }
  ],
  "local_mesh_sensitivity_passed": true,
  "limitation": "Local nonuniform mesh sensitivity only. Not GCI, all shapes, or physics validation. New mesh DZV y+ needs correct gas-side measurement without iterations."
}


## Чтение сохранённых полей без итераций

{
  "G1": {
    "svz": {
      "gas_wall": "wall-air_svz-wall_abonite-shadow",
      "yplus_at_heat_transfer_wall": 0.30227968
    },
    "dzv": {
      "gas_wall": "interior-air_dzv-wall_abonite",
      "yplus_at_heat_transfer_wall": 0.29890436
    }
  },
  "G2": {
    "svz": {
      "gas_wall": "wall-air_svz-wall_abonite-shadow",
      "yplus_at_heat_transfer_wall": 0.30587879
    },
    "dzv": {
      "gas_wall": "interior-air_dzv-wall_abonite",
      "yplus_at_heat_transfer_wall": 0.24053524
    }
  }
}

## Проверка нового сборщика на исходной G1 без итераций

{
  "attempted": true,
  "passed": true,
  "final_materials": {
    "wall-air_svz-wall_abonite-shadow": "air",
    "wall-air_svz-wall_abonite": "latun",
    "interior-air_dzv-wall_abonite": "latun",
    "interior-air_dzv-wall_abonite-shadow": "air"
  },
  "topology": {
    "initial_case": "F:\\Leontiev_Project\\runs\\knurl_postprocess_1103_v1\\G1_v9_template\\initial.cas.h5",
    "interface_percent": [
      100.0,
      100.0,
      99.51,
      99.65
    ],
    "interface_roles": {
      "svz_shadow": {
        "id": 34,
        "name": "grs_native:02:wall-air_svz-wall_abonite::wall-air_svz-wall_abonite-shadow",
        "material": "air"
      },
      "svz": {
        "id": 17,
        "name": "grs_native:02:wall-air_svz-wall_abonite::wall-air_svz-wall_abonite",
        "material": "latun"
      },
      "dzv_shadow": {
        "id": 33,
        "name": "grs_native:01:interior-air_dzv-wall_abo::interior-air_dzv-wall_abo-shadow",
        "material": "latun"
      },
      "dzv": {
        "id": 23,
        "name": "grs_native:01:interior-air_dzv-wall_abo::interior-air_dzv-wall_abo",
        "material": "air"
      }
    }
  }
}

Оговорка: y+ здесь измерен на газовой стороне теплообменной стенки; общий максимум СВЗ с наружной стенкой хранится в исходных мониторах. Проверка одной формы не доказывает устойчивость всех высот и шагов.
