# -*- coding: utf-8 -*-
import json,traceback,math,time,System
from Ansys.ACT.Interfaces.Common import SelectionTypeEnum
from Ansys.Mechanical.DataModel.Enums import SizingType,SizingBehavior,MethodType,PhaseType,BiasType,BiasOptionType
log=r'F:\Leontiev_Project\runs\knurl_dataset_queue_1104_v1\native\N05\setup.jsonl'
def record(step,value=None):
    with open(log,'a') as f:f.write(json.dumps({'time':time.time(),'step':step,'value':value})+'\n');f.flush()
try:
    model=ExtAPI.DataModel.Project.Model;geo=ExtAPI.DataModel.GeoData
    ns={str(n.Name):n for n in model.NamedSelections.Children if list(n.Location.Ids)}
    sections=('convergent','nozzle','heat','exit_contraction','exit_rounding','exit_recovery','exit_tail')
    for s in sections:
        for group in ('','_axial_edges','_layer_edges','_core_radial_edges'):
            assert 'MESH_'+s+group in ns
    record('scope preflight passed')
    model.Mesh.PhysicsPreference=System.Enum.Parse(model.Mesh.PhysicsPreference.GetType(),'CFD');model.Mesh.ElementSize=Quantity('0.5 [mm]')
    for b in model.Geometry.GetChildren(DataModelObjectCategory.Body,True):
        name=str(b.Name).split('\\')[-1]
        if name in ('air_svz','air_dzv','wall_abonite'):b.FluidSolidPhase=PhaseType.Solid if name=='wall_abonite' else PhaseType.LiquidGas
    record('CFD physics and gas/solid phases configured')
    for name,n in ns.items():
        if name.startswith('MESH_'):n.SendToSolver=False
    old=[o for o in model.Mesh.Children if str(o.Name)=='Structured_core']
    fm=old[0] if old else model.Mesh.AddFaceMeshing();fm.Name='Structured_core';fm.Location=ns['MESH_core_structured'].Location;fm.MappedMesh=True;fm.ConstrainBoundary=True
    record('face meshing configured')
    for section in sections:
        faces=[geo.GeoEntityById(i) for i in ns['MESH_'+section].Location.Ids]
        assert len(faces)==21 and all(len(f.Edges)==4 for f in faces)
        try:
            _v=json.load(open(r'F:\Leontiev_Project\runs\knurl_dataset_queue_1104_v1\native\N05\native_spec.json'))
        except Exception:
            _v={}
        _ax=float(_v.get('axial_size_m') or .0005);_conv=int(_v.get('convergent_div') or 200)
        # stage A3 (07.10.2026): divisions per geometric wall strip (20 strips, first 1 um) and core radial divisions
        _lay=int(_v.get('layer_div') or 1);_core=int(_v.get('core_div') or 70)
        axial=int(math.ceil(max(geo.GeoEntityById(i).Length for i in ns['MESH_'+section+'_axial_edges'].Location.Ids)/_ax))
        if section=='convergent':axial=_conv
        # 08.10.2026 (mesh v2): nozzle axial divisions with growth from the throat cell to the channel cell (no x10 jump);
        # convergent wall strips may keep a coarser split than the rest (inlet reversed flow on the fine mesh)
        _ndiv=int(_v.get('nozzle_div') or 0);_nbias=float(_v.get('nozzle_bias') or 0)
        if section=='nozzle' and _ndiv:axial=_ndiv
        _lay_s=int(_v.get('layer_div_convergent') or _lay) if section=='convergent' else _lay
        prefix='Nozzle_' if section=='nozzle' else 'Nozzle_'+section+'_'
        for suffix,group,count in (('axial','_axial_edges',axial),('layers','_layer_edges',_lay_s),('core_radial' if section=='nozzle' else 'radial','_core_radial_edges',_core)):
            name=prefix+suffix;old=[o for o in model.Mesh.Children if str(o.Name)==name];o=old[0] if old else model.Mesh.AddSizing()
            o.Name=name;o.NamedSelection=ns['MESH_'+section+group];o.Type=SizingType.NumberOfDivisions;o.NumberOfDivisions=count;o.Behavior=SizingBehavior.Hard
            if group=='_axial_edges':
                if section=='nozzle' and _nbias>1:
                    # same convention as the core radial bias below: small cells at the end of a non-reversed edge;
                    # keep edges that end at the throat (low x), reverse the others
                    o.BiasType=BiasType.ooooo_ooo_o_o;o.BiasOption=BiasOptionType.Factor;o.BiasFactor=_nbias
                    reverse=[i for i in o.Location.Ids if list(geo.GeoEntityById(i).Vertices)[0].X<list(geo.GeoEntityById(i).Vertices)[-1].X]
                    if reverse:
                        info=ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities);info.Ids=reverse;o.ReverseBias=info
                else:
                    o.BiasType=BiasType.NoBias
            if group=='_core_radial_edges':
                o.BiasType=BiasType.ooooo_ooo_o_o;o.BiasOption=BiasOptionType.Factor;o.BiasFactor=100.
                reverse=[]
                for i in o.Location.Ids:
                    e=geo.GeoEntityById(i)
                    vertices=list(e.Vertices)
                    if vertices[0].Y>vertices[-1].Y:reverse.append(i)
                if reverse:
                    info=ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities);info.Ids=reverse;o.ReverseBias=info
            record('sizing '+name,{'count':count,'ids':list(o.Location.Ids),'bias':str(o.BiasType)})
    bodies={str(b.Name).split('\\')[-1]:b for a in geo.Assemblies for p in a.Parts for b in p.Bodies}
    gas_edges=set(e.Id for e in bodies['air_dzv'].Edges)
    wallids=sorted(gas_edges.intersection(set(i for n in ('wall_outer-air_dzv','interior-air_dzv-wall_abonite') for i in ns[n].Location.Ids)))
    assert wallids
    old=[n for n in model.NamedSelections.Children if str(n.Name)=='MESH_walls_dzv'];n=old[0] if old else model.AddNamedSelection();n.Name='MESH_walls_dzv'
    info=ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities);info.Ids=wallids;n.Location=info;n.SendToSolver=False
    old=[o for o in model.Mesh.Children if str(o.Name)=='Inflation_air_dzv'];o=old[0] if old else model.Mesh.AddInflation();o.Name='Inflation_air_dzv';o.NamedSelection=ns['air_dzv'];o.BoundaryNamedSelection=n
    o.InflationOption=1;o.FirstLayerHeight=Quantity('0.0001 [mm]');o.MaximumLayers=20;o.NumberOfLayers=20;o.GrowthRate=1.2
    record('DC inflation configured',{'walls':wallids,'h1_um':.1,'layers':20,'growth':1.2})
    for o in model.Mesh.Children:
        if str(o.Name)=='Core_quadrilateral_method':o.NamedSelection=ns['MESH_core_structured']
    record('setup finished; no mesh generation yet')
except:record('python exception',traceback.format_exc())

