# -*- coding: utf-8 -*-
# runs INSIDE Meshing (Mechanical) python.  Spec: F:\Leontiev_Project\runs\knurl_dataset_queue_1104_v1\native\N04\native_spec.json
import json,traceback,time
spec=json.load(open(r'F:\Leontiev_Project\runs\knurl_dataset_queue_1104_v1\native\N04\native_spec.json'))
msh=spec['msh'];out=spec['result']
_t_setup=time.time()-1
execfile(r'F:\Leontiev_Project\runs\knurl_dataset_queue_1104_v1\native\N04\grs_setup.py')   # re-attach controls by named selections
from Ansys.ACT.Interfaces.Common import SelectionTypeEnum
r={'id':spec['id']}
try:
    model=ExtAPI.DataModel.Project.Model;geo=ExtAPI.DataModel.GeoData
    # 08.10.2026 (review): grs_g2_setup.py only logs its exceptions -> a failed setup must fail the mesh
    for _ln in open(r'F:\Leontiev_Project\runs\knurl_dataset_queue_1104_v1\native\N04\setup.jsonl'):
        try:_e=json.loads(_ln)
        except ValueError:continue
        if _e.get('time',0)>=_t_setup and _e.get('step')=='python exception':
            raise Exception('grs_g2_setup failed: '+str(_e.get('value'))[:500])
    for o in list(model.Mesh.Children):
        if str(o.Name)=='Core_quadrilateral_method':o.Delete();r['deleted_core_method']=True
    ns={str(n.Name):n for n in model.NamedSelections.Children if list(n.Location.Ids)}
    bodies={str(b.Name).split('\\')[-1]:b for a in geo.Assemblies for p in a.Parts for b in p.Bodies}
    inner=sorted(set(e.Id for e in bodies['air_dzv'].Edges).intersection(set(ns['interior-air_dzv-wall_abonite'].Location.Ids)))
    for c in model.Connections.GetChildren(DataModelObjectCategory.ContactRegion,True):
        if str(c.Name)=='Contact Region 2':
            info=ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities);info.Ids=inner
            c.TargetLocation=info;r['contact2_target']=list(c.TargetLocation.Ids)
    o=[o for o in model.Mesh.Children if str(o.Name)=='Inflation_air_dzv'][0]
    _h1=float(spec.get('dzv_h1_mm') or 0.0001);_nl=int(spec.get('dzv_layers') or 20)   # stage A3: DZV first layer
    o.InflationOption=1;o.FirstLayerHeight=Quantity('%g [mm]'%_h1);o.MaximumLayers=_nl;o.NumberOfLayers=_nl;o.GrowthRate=1.2
    _gs=float(spec.get('global_size_mm') or 0.5);model.Mesh.ElementSize=Quantity('%g [mm]'%_gs)   # DZV / wall size
    r['mesh_settings']={'dzv_h1_mm':_h1,'dzv_layers':_nl,'global_size_mm':_gs,
                        'layer_div':spec.get('layer_div') or 1,'core_div':spec.get('core_div') or 70}
    # 02.11.2026 (D-36, D0): structural passport of bodies before/after meshing -- KS1_04 lost air_dzv with 'passed'
    def _bodies_state():
        out=[]
        try:
            for b in model.Geometry.GetChildren(DataModelObjectCategory.Body,True):
                d={'name':str(b.Name)}
                for k in ('Suppressed','Area','Volume','Nodes','Elements','ObjectState'):
                    try:d[k]=str(getattr(b,k))
                    except:pass
                out.append(d)
        except:out=traceback.format_exc()[-300:]
        return out
    r['bodies_before_mesh']=_bodies_state()
    # Technical repair: remove only empty stale duplicate contacts before meshing.
    _all=list(model.Connections.GetChildren(DataModelObjectCategory.ContactRegion,True))
    _valid=[c for c in _all if list(c.SourceLocation.Ids) and list(c.TargetLocation.Ids)]
    if len(_valid)!=2 or sorted(str(c.Name) for c in _valid)!=['Contact Region','Contact Region 2']:
        raise Exception('Expected exactly two nonempty original contacts')
    r['contacts_cleanup_before']=[(str(c.Name),len(list(c.SourceLocation.Ids)),len(list(c.TargetLocation.Ids))) for c in _all]
    for c in _all:
        if not list(c.SourceLocation.Ids) or not list(c.TargetLocation.Ids):c.Delete()
    r['contacts_cleanup_after']=[(str(c.Name),len(list(c.SourceLocation.Ids)),len(list(c.TargetLocation.Ids))) for c in model.Connections.GetChildren(DataModelObjectCategory.ContactRegion,True)]
    if len(r['contacts_cleanup_after'])!=2:raise Exception('Empty contact cleanup failed')
    # The reference project retains messages from previous mesh attempts.
    r['messages_before_clear']=[str(m.DisplayString) for m in ExtAPI.Application.Messages]
    r['clear_message_methods']=[]
    for _obj in (ExtAPI.Application,ExtAPI.Application.Messages):
        try:r['clear_message_methods'] += [str(m.Name) for m in _obj.GetType().GetMethods() if 'Clear' in str(m.Name)]
        except:pass
    if hasattr(ExtAPI.Application,'ClearMessages'):
        ExtAPI.Application.ClearMessages()
    elif hasattr(ExtAPI.Application.Messages,'Clear'):
        ExtAPI.Application.Messages.Clear()
    else:raise Exception('No verified message-clear API: '+str(r['clear_message_methods']))
    r['message_count_after_clear']=len(list(ExtAPI.Application.Messages))
    if r['message_count_after_clear']!=0:raise Exception('Cannot separate old and new meshing messages')
    model.Mesh.PinchTolerance=Quantity('1e-8 [m]')
    model.Mesh.MinimumSize=Quantity('1e-8 [m]')
    _fm=[x for x in model.Mesh.Children if str(x.Name)=='Structured_core'][0]
    _fm.ConstrainBoundary=1
    r['recipe']={'pinch_m':1e-8,'curvature_min_m':1e-8,'constrain_boundary':str(_fm.ConstrainBoundary)}
    _used=json.load(open(r'F:\Leontiev_cold_full_cycle_1104_v6\geometry_options_used.json'))
    _wanted=json.load(open(r'F:\Leontiev_cold_full_cycle_1104_v6\geometry_options.json'))
    for _k in ('knurl_dzv','knurl_svz','dzv_counterflow','l_cone_mm'):
        if _used.get(_k)!=_wanted.get(_k):raise Exception('Actual geometry mismatch: '+_k)
    r['geometry_options_used']=_used
    if set(bodies.keys())!=set(('air_svz','air_dzv','wall_abonite')):raise Exception('Wrong body set')
    if len(list(_fm.Location.Ids))!=147 or not _fm.MappedMesh:raise Exception('Need147mappedSVZfaces')
    if any(not list(n.Location.Ids) for n in model.NamedSelections.Children):raise Exception('Empty named selection')
    if any(int(d.get('Elements','0'))!=0 for d in r['bodies_before_mesh']):raise Exception('Fresh geometry has old mesh elements')
    t0=time.time();model.Mesh.GenerateMesh()
    r['geometry_bodies']=[{'name':str(b.Name),'edges':len(list(b.Edges)),'faces':len(list(b.Faces))} for b in bodies.values()]
    r['elements']=model.Mesh.Elements;r['nodes']=model.Mesh.Nodes;r['gen_seconds']=time.time()-t0
    r['bodies_after_mesh']=_bodies_state()
    try:r['messages_after_mesh']=[str(m.DisplayString)[:300] for m in ExtAPI.Application.Messages][-20:]
    except:r['messages_after_mesh']=traceback.format_exc()[-200:]
    # 02.11.2026 (next stage, item 5): bindings dump -- named selections, mesh controls, contacts; process memory
    try:r['named_selections']=[(str(n.Name),len(list(n.Location.Ids))) for n in model.NamedSelections.Children]
    except:r['named_selections']=traceback.format_exc()[-200:]
    try:
        _mc=[]
        for o in model.Mesh.Children:
            d={'name':str(o.Name)}
            try:d['ids']=len(list(o.Location.Ids))
            except:pass
            try:d['divisions']=int(o.NumberOfDivisions)
            except:pass
            try:d['suppressed']=str(o.Suppressed)
            except:pass
            _mc.append(d)
        r['mesh_controls']=_mc
    except:r['mesh_controls']=traceback.format_exc()[-200:]
    try:
        import System
        _p=System.Diagnostics.Process.GetCurrentProcess();r['memory_mb']={'working_set':_p.WorkingSet64/1048576,'peak_working_set':_p.PeakWorkingSet64/1048576}
    except:r['memory_mb']=traceback.format_exc()[-200:]
    # success = EVERY body has elements (KS1_04 / D0: air_dzv had 0 cells, mesher crash, but 'passed') and both contact
    # regions have non-empty source and target
    _zero=[]
    try:
        for d in r['bodies_after_mesh']:
            if int(str(d.get('Elements','0')).split()[0])<=0:_zero.append(d['name'])
    except:_zero=['bodies check failed: '+traceback.format_exc()[-150:]]
    r['bodies_without_elements']=_zero
    try:
        _crs=[(str(cr.Name),len(list(cr.SourceLocation.Ids)),len(list(cr.TargetLocation.Ids))) for cr in model.Connections.GetChildren(DataModelObjectCategory.ContactRegion,True)]
        r['contacts_ok']=any(c[0]=='Contact Region' and c[1]>0 and c[2]>0 for c in _crs) and any(c[0]=='Contact Region 2' and c[1]>0 and c[2]>0 for c in _crs)
        r['contact_regions_count']=len(_crs)
    except:r['contacts_ok']=False;r['contacts_check_error']=traceback.format_exc()[-200:]
    try:
        r['contacts_all']=[(str(cr.Name),len(list(cr.SourceLocation.Ids)),len(list(cr.TargetLocation.Ids))) for cr in model.Connections.GetChildren(DataModelObjectCategory.ContactRegion,True)]
    except:r['contacts_all']=traceback.format_exc()[-200:]
    def _xy(i):
        vv=list(geo.GeoEntityById(i).Vertices)
        return [round(vv[0].X*1e3,2),round(vv[0].Y*1e3,3),round(vv[-1].X*1e3,2),round(vv[-1].Y*1e3,3)]
    def _owner(i):
        return [k for k,b in bodies.items() if i in set(e.Id for e in b.Edges)]
    try:   # 15.10: contact scoping before export (edge coords mm + owner body)
        r['contacts_before']=[(str(cr.Name),[(i,_xy(i),_owner(i)) for i in cr.SourceLocation.Ids][:3],len(list(cr.SourceLocation.Ids)),
                               [(i,_xy(i),_owner(i)) for i in cr.TargetLocation.Ids][:3],len(list(cr.TargetLocation.Ids)))
                              for cr in model.Connections.GetChildren(DataModelObjectCategory.ContactRegion,True)][:6]
    except:r['contacts_before']=traceback.format_exc()[-300:]
    if r['messages_after_mesh'] or r['bodies_without_elements'] or r['contact_regions_count']!=2 or not r['contacts_ok']:
        raise Exception('Native mesh gate: messages, empty body or contacts')
    if not all(d.get('ObjectState')=='Meshed' for d in r['bodies_after_mesh']):
        raise Exception('Body not fully meshed')
    model.Mesh.InternalObject.WriteFluentInputFile(msh);r['exported']=msh
    r['passed']=r['elements']>0 and not r.get('bodies_without_elements') and bool(r.get('contacts_ok'))
except:
    r['error']=traceback.format_exc();r['passed']=False
    try:   # 15.10: Mechanical messages for a failed export (COM E_FAIL on some geometries)
        r['messages']=[str(m.DisplayString)[:300] for m in ExtAPI.Application.Messages][-15:]
    except:r['messages_error']=traceback.format_exc()[-300:]
with open(out,'w') as f:f.write(json.dumps(r,indent=1))
