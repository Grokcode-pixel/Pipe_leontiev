@echo off
rem Окно запуска расчётов трубы Леонтьева (геометрия -> сетка -> Fluent)
start "" pythonw "F:\Leontiev_Project\dataset\leontiev_gui.py"
