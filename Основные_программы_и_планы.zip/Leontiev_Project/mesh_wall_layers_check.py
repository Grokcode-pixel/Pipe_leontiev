# Follow actual quadrilateral neighbours from each physical gas wall.
import json,math,traceback,time
FIRST_LAYER_HEIGHT_M=float(json.load(open(r'F:\Leontiev_Project\mesh_run_config.json'))['first_layer_height_um'])*1e-6
from System import Array,Double
r={'profiles':[],'started':time.time()}
r['first_layer_height_um']=FIRST_LAYER_HEIGHT_M*1e6
try:
    model=ExtAPI.DataModel.Project.Model
    md=ExtAPI.DataModel.MeshDataByName('Global')
    names={str(n.Name):n for n in model.NamedSelections.Children if list(n.Location.Ids)}
    bodies={str(b.Name).split('\\')[-1]:b for a in ExtAPI.DataModel.GeoData.Assemblies for p in a.Parts for b in p.Bodies}
    pts={}
    def point(nid):
        if nid not in pts:
            n=md.NodeById(nid);pts[nid]=(n.X,n.Y)
        return pts[nid]
    def midpoint(pair):
        a=point(pair[0]);b=point(pair[1]);return ((a[0]+b[0])/2,(a[1]+b[1])/2)
    def key(pair):return tuple(sorted(pair))
    for gas,helper in (('air_svz','MESH_walls_svz'),('air_dzv','MESH_walls_dzv')):
        elements={};adj={}
        for eid in md.MeshRegionById(bodies[gas].Id).ElementIds:
            elem=md.ElementById(eid);nodes=list(elem.NodeIds)
            if str(elem.Type)!='kQuad4':continue
            elements[eid]=nodes
            for i in range(4):adj.setdefault(key((nodes[i],nodes[(i+1)%4])),[]).append(eid)
        for wall in names[helper].Location.Ids:
            edge=ExtAPI.DataModel.GeoData.GeoEntityById(wall)
            bounds=[edge.ParamAtPoint(Array[Double]([v.X,v.Y,v.Z])) for v in edge.Vertices]
            lo=min(bounds);hi=max(bounds)
            def parameter(nid):
                p=point(nid)
                t=edge.ParamAtPoint(Array[Double]([p[0],p[1],0.0]))
                q=edge.PointAtParam(t)
                distance=math.sqrt((q[0]-p[0])**2+(q[1]-p[1])**2+q[2]**2)
                return t,distance
            wallnodes=set(md.MeshRegionById(wall).NodeIds)
            pairs=[pair for pair,eids in adj.items() if len(eids)==1 and pair[0] in wallnodes and pair[1] in wallnodes]
            candidates=[]
            for pair in pairs:
                ts=[parameter(nid) for nid in pair]
                if max(t[1] for t in ts)<2e-8:
                    t=sum(t[0] for t in ts)/2
                    if lo-1e-8<=t<=hi+1e-8:candidates.append((t,pair))
            pairs=candidates
            if not pairs:
                r['profiles'].append({'gas':gas,'wall_edge':wall,'verified':False,'reason':'No quadrilateral boundary segment'})
                continue
            for fraction in (0.1,0.5,0.9):
                pair=min(pairs,key=lambda item:abs(item[0]-(lo+fraction*(hi-lo))))[1]
                start=midpoint(pair);a=point(pair[0]);b=point(pair[1])
                dx=b[0]-a[0];dy=b[1]-a[1];length=math.sqrt(dx*dx+dy*dy)
                normal=(-dy/length,dx/length)
                previous=None;levels=[];reason=None
                for layer in range(20):
                    candidates=[eid for eid in adj.get(key(pair),[]) if eid!=previous]
                    if len(candidates)!=1:reason='No unique next quad at layer '+str(layer+1);break
                    eid=candidates[0];nodes=elements[eid]
                    index=[i for i in range(4) if key((nodes[i],nodes[(i+1)%4]))==key(pair)][0]
                    opposite=(nodes[(index+2)%4],nodes[(index+3)%4])
                    p=midpoint(opposite)
                    levels.append(abs((p[0]-start[0])*normal[0]+(p[1]-start[1])*normal[1]))
                    previous=eid;pair=opposite
                heights=[levels[0]]+[levels[i]-levels[i-1] for i in range(1,len(levels))] if levels else []
                ratios=[heights[i+1]/heights[i] for i in range(len(heights)-1)] if heights and min(heights)>0 else []
                growth_error=max(abs(v/1.2-1) for v in ratios) if len(ratios)==19 else None
                verified=len(levels)==20 and bool(ratios) and growth_error<0.1 and 0<heights[0]<=1.02*FIRST_LAYER_HEIGHT_M
                r['profiles'].append({'gas':gas,'wall_edge':wall,'fraction':fraction,'start':start,'levels_m':levels,'heights_m':heights,'first_height_m':heights[0] if heights else None,'max_relative_growth_error':growth_error,'verified':verified,'reason':reason})
    r['passed']=len(r['profiles'])==27 and all(p['verified'] for p in r['profiles'])
except:r['error']=traceback.format_exc();r['passed']=False
r['seconds']=time.time()-r['started']
with open(globals().get('MESH_WALL_CHECK_PATH',r'F:\Leontiev_Project\mesh_wall_layers_check.json'),'w') as f:json.dump(r,f,indent=2)
