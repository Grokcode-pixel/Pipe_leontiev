import json,math,traceback
FIRST_LAYER_HEIGHT_M=float(json.load(open(r'F:\Leontiev_Project\mesh_run_config.json'))['first_layer_height_um'])*1e-6
r={}
r['first_layer_height_um']=FIRST_LAYER_HEIGHT_M*1e6
try:
    model=ExtAPI.DataModel.Project.Model
    md=ExtAPI.DataModel.MeshDataByName('Global')
    r['unit']=str(md.Unit)
    ns={str(n.Name):n for n in model.NamedSelections.Children if list(n.Location.Ids)}
    bodies={}
    for a in ExtAPI.DataModel.GeoData.Assemblies:
        for p in a.Parts:
            for b in p.Bodies:bodies[str(b.Name).split('\\')[-1]]=b
    r['profiles']=[]
    for gas,helper in (('air_svz','MESH_walls_svz'),('air_dzv','MESH_walls_dzv')):
        points=[]
        for nid in md.MeshRegionById(bodies[gas].Id).NodeIds:
            node=md.NodeById(nid)
            points.append((node.X,node.Y))
        for eid in ns[helper].Location.Ids:
            edgepoints=[]
            for nid in md.MeshRegionById(eid).NodeIds:
                node=md.NodeById(nid);edgepoints.append((node.X,node.Y))
            if not edgepoints:continue
            a=min(edgepoints);b=max(edgepoints)
            dx=b[0]-a[0];dy=b[1]-a[1]
            if dx<0.5:continue
            length=math.sqrt(dx*dx+dy*dy)
            xmid=(a[0]+b[0])/2
            distances=sorted(abs(dx*(y-a[1])-dy*(x-a[0]))/length for x,y in points if abs(x-xmid)<0.0006)
            distances=[d for d in distances if d>1e-9 and d<FIRST_LAYER_HEIGHT_M*(1.2**20-1)/0.2*1.04]
            clusters=[]
            for d in distances:
                if not clusters or abs(d-clusters[-1][0])>max(2e-8,d*0.01):clusters.append([d])
                else:clusters[-1].append(d)
            levels=[sum(c)/len(c) for c in clusters]
            heights=[levels[0]]+[levels[i]-levels[i-1] for i in range(1,len(levels))] if levels else []
            r['profiles'].append({'gas':gas,'edge':eid,'x':xmid,'wall_start':a,'wall_end':b,'distance_levels_m':levels,'first_distance_m':levels[0] if levels else None,'layer_heights_m':heights,'height_ratios':[heights[i+1]/heights[i] for i in range(len(heights)-1)]})
    expected=[FIRST_LAYER_HEIGHT_M*(1.2**(k+1)-1)/0.2 for k in range(20)]
    for profile in r['profiles']:
        levels=profile['distance_levels_m']
        profile['max_relative_distance_error']=max(abs(a-b)/b for a,b in zip(levels,expected)) if len(levels)==20 else None
        profile['verified']=len(levels)==20 and profile['max_relative_distance_error']<0.02
    r['passed']=len(r['profiles'])==3 and all(p['verified'] for p in r['profiles'])
except:r['error']=traceback.format_exc()
with open(globals().get('MESH_LAYERS_PATH',r'F:\Leontiev_Project\mesh_layers.json'),'w') as f:json.dump(r,f,indent=2)
