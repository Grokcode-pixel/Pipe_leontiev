import json,traceback,math
from Ansys.ACT.Interfaces.Common import SelectionTypeEnum
from Ansys.Mechanical.DataModel.Enums import SizingType,SizingBehavior,MethodType
r={}
try:
    model=ExtAPI.DataModel.Project.Model
    ns={str(n.Name):n for n in model.NamedSelections.Children if list(n.Location.Ids)}
    sections=('convergent','nozzle','heat','exit_contraction','exit_rounding','exit_recovery','exit_tail')
    for name,n in ns.items():
        if name.startswith('MESH_'):n.SendToSolver=False
    mode=globals().get('MESH_MODE','series')
    h={'series':0.00075,'control':0.00025}[mode]
    radial_count=int(math.ceil(max(ExtAPI.DataModel.GeoData.GeoEntityById(i).Length for section in sections for i in ns['MESH_'+section+'_core_radial_edges'].Location.Ids)/h))
    gas=[b for a in ExtAPI.DataModel.GeoData.Assemblies for p in a.Parts for b in p.Bodies if str(b.Name).split('\\')[-1]=='air_svz'][0]
    old=[o for o in model.Mesh.Children if str(o.GetType()).endswith('.AutomaticMethod')]
    method=old[0] if old else model.Mesh.AddAutomaticMethod()
    for duplicate in old[1:]:duplicate.Suppressed=True
    method.Method=MethodType.Automatic
    method.Name='Core_quadrilateral_method'
    method.Suppressed=False
    info=ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities)
    info.Ids=[gas.Id];method.Location=info
    infl=[o for o in model.Mesh.Children if str(o.Name)=='Inflation_air_svz'][0]
    infl.Suppressed=True
    for o in model.Mesh.Children:
        if str(o.Name)=='Short_sections_refinement':o.Suppressed=True
    faces=[o for o in model.Mesh.Children if str(o.GetType()).endswith('.FaceMeshing')]
    fm=faces[0] if faces else model.Mesh.AddFaceMeshing()
    fm.Name='Structured_core'
    fm.Location=ns['MESH_core_structured'].Location
    fm.Suppressed=False;fm.MappedMesh=True;fm.ConstrainBoundary=True
    for section in sections:
        fs=[ExtAPI.DataModel.GeoData.GeoEntityById(i) for i in ns['MESH_'+section].Location.Ids]
        if len(fs)!=21 or any(len(f.Edges)!=4 for f in fs):raise ValueError('Invalid structured section '+section)
    controls=[]
    for section in sections:
        axial_count=int(math.ceil(max(ExtAPI.DataModel.GeoData.GeoEntityById(i).Length for i in ns['MESH_'+section+'_axial_edges'].Location.Ids)/h))
        prefix='Nozzle_' if section=='nozzle' else 'Nozzle_'+section+'_'
        for suffix,group,count in (('axial','MESH_'+section+'_axial_edges',axial_count),('layers','MESH_'+section+'_layer_edges',1),('core_radial' if section=='nozzle' else 'radial','MESH_'+section+'_core_radial_edges',radial_count)):
            name=prefix+suffix
            old=[o for o in model.Mesh.Children if str(o.Name)==name]
            o=old[0] if old else model.Mesh.AddSizing()
            o.Name=name;o.NamedSelection=ns[group]
            o.Type=SizingType.NumberOfDivisions;o.NumberOfDivisions=count
            o.Behavior=SizingBehavior.Hard;o.Suppressed=False
            controls.append({'name':name,'count':count,'ids':list(ns[group].Location.Ids)})
    r['controls']=controls;r['configured']=True
except:r['error']=traceback.format_exc()
with open(r'F:\Leontiev_Project\nozzle_setup.json','w') as f:json.dump(r,f,indent=2)

